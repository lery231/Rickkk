# 1001 SK — Coffee Ordering

Starter project aplikasi pemesanan kopi responsif dengan pemisahan pembeli/penjual, katalog yang bisa diatur, pesanan realtime, dan QRIS dengan unggah bukti pembayaran.

## Fitur
- Login dan daftar dengan Firebase Authentication (email/password).
- Pembeli: lihat menu, buat pesanan, bayar via QRIS statis, unggah bukti pembayaran, pantau status realtime.
- Penjual: ubah status pesanan dan pembayaran, lihat bukti, tambah/edit/nonaktifkan menu, atur nama toko/pesan/status buka-tutup/URL QRIS.
- Firestore dan Storage rules awal untuk membatasi akses.
- GitHub Actions membangun folder `dist` setiap push dan menyediakan artifact.
- UI responsif untuk browser HP. Dapat dipasang sebagai PWA dari browser yang mendukung.

## Menyiapkan Firebase
1. Buat project di Firebase Console.
2. Tambahkan Web App dan salin konfigurasi ke file `.env` berdasarkan `.env.example`.
3. Aktifkan Authentication → Sign-in method → Email/Password.
4. Buat Firestore Database dan Storage.
5. Terapkan isi `firestore.rules` pada Firestore Rules dan `storage.rules` pada Storage Rules.
6. Jalankan `npm install` lalu `npm run dev` untuk mencoba lokal; `npm run build` untuk build.
7. Buat akun dari aplikasi. Di Firestore, buka `users/{UID}` untuk akun penjual dan ubah field `role` menjadi `seller`. Lakukan hanya untuk akun yang Anda percaya. Pengguna tidak dapat mengubah perannya sendiri lewat aplikasi.
8. Dari akun penjual, buka Pengaturan toko dan masukkan URL gambar QRIS milik toko.

## Build lewat GitHub
1. Buat repository GitHub baru dan unggah seluruh isi folder ini.
2. Pada repository, buka tab **Actions** dan aktifkan Actions jika diminta.
3. Push ke branch `main` atau jalankan workflow **Build 1001 SK** secara manual.
4. Buka run terbaru dan unduh artifact `1001-SK-dist` dari bagian Artifacts.

Artifact ini adalah build web (folder `dist`), bukan APK Android. Untuk publikasi online, deploy `dist` ke Firebase Hosting atau layanan hosting statis dan isi konfigurasi Firebase untuk environment production.

## Catatan pembayaran
Implementasi awal menggunakan **QRIS statis + pemeriksaan bukti secara manual**, bukan konfirmasi pembayaran otomatis. Jangan menandai pesanan lunas sebelum memeriksa transaksi pada aplikasi merchant. Pembayaran otomatis membutuhkan akun merchant dan integrasi server-side dengan penyedia payment gateway (misalnya Midtrans/Xendit); rahasia API jangan pernah diletakkan di aplikasi/browser.

## Keamanan dan production
- Review rules sebelum dipakai untuk transaksi sungguhan. Pengaturan role penjual dilakukan melalui Firebase Console.
- Firebase Web API config bukan password, tetapi rules wajib dipasang dengan benar.
- Tambahkan App Check, validasi harga/total di backend atau Cloud Functions, kebijakan privasi, dan mekanisme refund sebelum rilis komersial.
