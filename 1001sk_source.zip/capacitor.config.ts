import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.kopi1001sk.app',
  appName: '1001 SK',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;