import React, { useState, useEffect, useRef, useCallback } from 'react';
import { auth, db } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';
import {
  doc,
  getDoc,
  collection,
  onSnapshot,
  query,
  orderBy,
  where,
  updateDoc,
} from 'firebase/firestore';
import CustomerView from './components/CustomerView';
import SellerView from './components/SellerView';
import AuthModal from './components/AuthModal';
import UpdateModal from './components/UpdateModal';
import { useSwipe } from './hooks/useSwipe';
import { CURRENT_APP_VERSION, compareVersions } from './utils/versionUtils';
import { extractAmountFromNotification } from './utils/qrisAutoMatcher';
import {
  playNewOrderChime,
  playOrderReadyChime,
  playPaymentSuccessChime,
  triggerHaptic,
  sendSystemNotification,
} from './utils/soundEffects';
import {
  Coffee,
  Receipt,
  LayoutDashboard,
  User,
  Store,
  Sparkles,
  Sun,
  Moon,
  Volume2,
  VolumeX,
  Search,
  BellRing,
  X,
  QrCode,
  ShoppingBag,
} from 'lucide-react';

const CUSTOMER_TABS = ['menu', 'cart', 'orders'];
const SELLER_TABS = ['orders', 'menu', 'qris', 'update'];

function App() {
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState('customer');
  const [activeTab, setActiveTab] = useState('menu');
  const [sellerSubTab, setSellerSubTab] = useState('orders');
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  const [readyAlertOrder, setReadyAlertOrder] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [storeOpen, setStoreOpen] = useState(true);
  const [showIosInstallHint, setShowIosInstallHint] = useState(() => {
    try {
      if (typeof window === 'undefined') return false;
      const ua = window.navigator.userAgent || '';
      const isIos = /iPhone|iPad|iPod/i.test(ua);
      const isStandalone = window.navigator.standalone === true || window.matchMedia('(display-mode: standalone)').matches;
      const dismissed = localStorage.getItem('1001sk_ios_pwa_dismissed') === 'true';
      return isIos && !isStandalone && !dismissed;
    } catch {
      return false;
    }
  });

  // State In-App Updater
  const [updateInfo, setUpdateInfo] = useState(null);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const hasAutoPromptedUpdate = useRef(false);

  // Persistent Dark / Light Theme
  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem('1001sk_theme') || 'dark';
    } catch {
      return 'dark';
    }
  });

  // Persistent Notification Sound Toggle
  const [soundEnabled, setSoundEnabled] = useState(() => {
    try {
      const saved = localStorage.getItem('1001sk_sound');
      return saved === null ? true : saved === 'true';
    } catch {
      return true;
    }
  });

  const searchInputRef = useRef(null);
  const isInitialOrdersLoad = useRef(true);
  const prevOrderStatusMap = useRef({});
  const soundEnabledRef = useRef(soundEnabled);
  const userRoleRef = useRef(userRole);
  const ordersRef = useRef(orders);

  useEffect(() => {
    ordersRef.current = orders;
  }, [orders]);

  useEffect(() => {
    soundEnabledRef.current = soundEnabled;
    try {
      localStorage.setItem('1001sk_sound', String(soundEnabled));
    } catch {}
  }, [soundEnabled]);

  useEffect(() => {
    userRoleRef.current = userRole;
    if (userRole === 'seller') {
      setCart([]);
      setActiveTab('seller');
    } else if (activeTab === 'seller') {
      setActiveTab('menu');
    }
  }, [userRole]);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) {
      metaTheme.setAttribute('content', theme === 'dark' ? '#0a090f' : '#f3f1ed');
    }
    try {
      localStorage.setItem('1001sk_theme', theme);
    } catch {}
  }, [theme]);

  const showToast = useCallback((msg) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? '' : prev));
    }, 3200);
  }, []);

  // Auth & Role Listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setAuthReady(true);
      if (currentUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists() && userDoc.data().role === 'seller') {
            setUserRole('seller');
            setCart([]);
            setActiveTab('seller');
          } else {
            setUserRole('customer');
          }
        } catch (e) {
          console.error(e);
        }
      } else {
        setUserRole('customer');
      }
    });
    return () => unsub();
  }, []);

  // Listener Realtime Pembaruan Aplikasi (settings/app_info)
  useEffect(() => {
    const unsubUpdate = onSnapshot(doc(db, 'settings', 'app_info'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.latestVersion && compareVersions(data.latestVersion, CURRENT_APP_VERSION) > 0) {
          setUpdateInfo(data);
          if (!hasAutoPromptedUpdate.current) {
            hasAutoPromptedUpdate.current = true;
            setIsUpdateModalOpen(true);
          }
        } else {
          setUpdateInfo(null);
        }
      }
    }, () => {});
    return () => unsubUpdate();
  }, []);

  // Realtime pesanan: seller melihat semua, pembeli hanya pesanannya sendiri
  useEffect(() => {
    isInitialOrdersLoad.current = true;
    prevOrderStatusMap.current = {};

    if (!user) {
      setOrders([]);
      return;
    }

    const isSeller = userRole === 'seller';
    const q = isSeller
      ? query(collection(db, 'orders'), orderBy('createdAt', 'desc'))
      : query(collection(db, 'orders'), where('uid', '==', user.uid));

    const unsub = onSnapshot(q, (snap) => {
      let list = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      if (!isSeller) {
        list = list
          .filter(o => !o.hiddenByCustomer)
          .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
      }
      setOrders(list);

      if (isInitialOrdersLoad.current) {
        const initMap = {};
        list.forEach(o => { initMap[o.id] = o.status; });
        prevOrderStatusMap.current = initMap;
        isInitialOrdersLoad.current = false;
        return;
      }

      const prevMap = prevOrderStatusMap.current;
      const nextMap = {};

      list.forEach(ord => {
        nextMap[ord.id] = ord.status;
        const oldStatus = prevMap[ord.id];

        // Seller: bunyikan notifikasi saat pesanan baru masuk (Tunai atau QRIS yang baru terkonfirmasi lunas)
        if ((!oldStatus || oldStatus === 'menunggu_pembayaran') && ord.status === 'pending' && isSeller) {
          if (soundEnabledRef.current) playNewOrderChime();
          triggerHaptic([30, 50, 30]);
          const qrisTag = ord.paymentMethod === 'QRIS' ? ' (QRIS Lunas)' : '';
          showToast(`Pesanan baru dari ${ord.customerName}${qrisTag}!`);
          sendSystemNotification(
            `Pesanan Baru Masuk${qrisTag} - 1001 SK`,
            `${ord.customerName} memesan Rp ${ord.totalPrice?.toLocaleString('id-ID')}`
          );
        }

        // Customer: notifikasi otomatis saat QRIS terkonfirmasi lunas
        if (oldStatus === 'menunggu_pembayaran' && ord.status === 'pending' && !isSeller) {
          if (soundEnabledRef.current) playPaymentSuccessChime();
          triggerHaptic([25, 45, 25]);
          showToast('Pembayaran QRIS lunas otomatis! Pesanan diteruskan ke kasir.');
        }

        // Customer: bunyikan notifikasi saat pesanan SIAP DIAMBIL
        if (oldStatus && oldStatus !== 'siap' && ord.status === 'siap' && !isSeller) {
          if (soundEnabledRef.current) playOrderReadyChime();
          triggerHaptic([60, 40, 80]);
          setReadyAlertOrder(ord);
          sendSystemNotification(
            'Pesanan Siap Diambil - 1001 SK',
            `Pesanan atas nama ${ord.customerName} sudah siap!`
          );
        }
      });

      prevOrderStatusMap.current = nextMap;
    }, (err) => console.error(err));

    return () => unsub();
  }, [user, userRole, showToast]);

  // Auto-Matcher QRIS Otomatis (mendengarkan webhook notifikasi dari HP Kasir -> qris_payments)
  useEffect(() => {
    if (!user || userRole !== 'seller') return;

    const qPayments = query(collection(db, 'qris_payments'), where('matched', '==', false));
    const unsubPayments = onSnapshot(qPayments, async (snap) => {
      if (snap.empty) return;
      const now = Date.now();

      for (const payDoc of snap.docs) {
        const payData = payDoc.data();
        const detectedAmount = extractAmountFromNotification(payData.amount || payData.rawText);
        if (!detectedAmount) continue;

        const matchingOrder = ordersRef.current.find((ord) => {
          if (ord.status !== 'menunggu_pembayaran' || ord.paymentStatus === 'paid') return false;
          if (Number(ord.totalPrice) !== detectedAmount) return false;
          if (ord.paymentExpiresAt && new Date(ord.paymentExpiresAt).getTime() < now) return false;
          return true;
        });

        if (matchingOrder) {
          try {
            await updateDoc(doc(db, 'orders', matchingOrder.id), {
              status: 'pending',
              paymentStatus: 'paid',
              paidAt: new Date().toISOString(),
              paymentProofText: String(payData.rawText || `QRIS Rp ${detectedAmount.toLocaleString('id-ID')}`),
            });
            await updateDoc(doc(db, 'qris_payments', payDoc.id), {
              matched: true,
              matchedOrderId: matchingOrder.id,
              matchedAmount: detectedAmount,
              matchedAt: new Date().toISOString(),
            });
          } catch (err) {
            console.error('Gagal mencocokkan QRIS otomatis:', err);
          }
        }
      }
    }, () => {});

    return () => unsubPayments();
  }, [user, userRole]);

  // Status buka/tutup toko
  useEffect(() => {
    if (!user) return;
    return onSnapshot(
      doc(db, 'settings', 'store'),
      (s) => setStoreOpen(!s.exists() || s.data().open !== false),
      () => {}
    );
  }, [user]);

  // Geser kiri/kanan antar tab
  const moveTab = useCallback((dir) => {
    triggerHaptic(10);
    if (userRole === 'seller') {
      const i = SELLER_TABS.indexOf(sellerSubTab) + dir;
      if (i >= 0 && i < SELLER_TABS.length) setSellerSubTab(SELLER_TABS[i]);
    } else {
      const i = CUSTOMER_TABS.indexOf(activeTab) + dir;
      if (i >= 0 && i < CUSTOMER_TABS.length) setActiveTab(CUSTOMER_TABS[i]);
    }
  }, [userRole, sellerSubTab, activeTab]);

  const { stageRef, swipeHandlers } = useSwipe({
    onSwipeLeft: () => moveTab(1),
    onSwipeRight: () => moveTab(-1),
  });

  const toggleTheme = () => {
    triggerHaptic(12);
    setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  const toggleSound = () => {
    triggerHaptic(12);
    setSoundEnabled(prev => {
      const next = !prev;
      if (next) {
        playNewOrderChime();
        showToast('Nada notifikasi pesanan diaktifkan');
      } else {
        showToast('Nada notifikasi dimatikan');
      }
      return next;
    });
  };

  const handleManualCheckUpdate = () => {
    triggerHaptic(12);
    if (updateInfo) {
      setIsUpdateModalOpen(true);
    } else {
      showToast(`Aplikasi 1001 SK sudah versi terbaru (v${CURRENT_APP_VERSION})`);
    }
  };

  const handleCircleAction = () => {
    triggerHaptic(12);
    if (userRole === 'seller') {
      setSellerSubTab(prev => (prev === 'qris' ? 'orders' : 'qris'));
    } else {
      setActiveTab('menu');
      setTimeout(() => {
        if (searchInputRef.current) {
          searchInputRef.current.focus();
        }
      }, 80);
    }
  };

  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const pendingCount = orders.filter(o => o.status === 'pending').length;

  if (!authReady) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 14, color: 'var(--accent-primary)' }}>
        <Coffee size={42} />
        <div style={{ fontWeight: 800, fontSize: 16 }}>Memuat 1001 SK...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="app-shell">
        <div className="ambient-canvas">
          <div className="ambient-orb orb-1" />
          <div className="ambient-orb orb-2" />
          <div className="ambient-orb orb-3" />
        </div>
        {toastMsg && (
          <div className="ios-toast">
            <Sparkles size={16} color="var(--accent-primary)" />
            <span>{toastMsg}</span>
          </div>
        )}
        <AuthModal
          isOpen
          forced
          onClose={() => {}}
          user={null}
          userRole="customer"
          setUserRole={setUserRole}
          showToast={showToast}
          hasUpdate={Boolean(updateInfo)}
          onCheckUpdate={handleManualCheckUpdate}
        />
        <UpdateModal
          isOpen={isUpdateModalOpen}
          onClose={() => setIsUpdateModalOpen(false)}
          updateInfo={updateInfo}
          showToast={showToast}
        />
      </div>
    );
  }

  return (
    <div className="app-shell">
      {/* GPU Ambient Lighting Canvas */}
      <div className="ambient-canvas">
        <div className="ambient-orb orb-1" />
        <div className="ambient-orb orb-2" />
        <div className="ambient-orb orb-3" />
      </div>

      {/* Dynamic Island Toast */}
      {toastMsg && (
        <div className="ios-toast">
          <Sparkles size={16} color="var(--accent-primary)" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Customer "Pesanan Siap Diambil" Prominent Frosted Alert Banner */}
      {readyAlertOrder && userRole !== 'seller' && (
        <div className="ready-banner-alert">
          <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
            <div style={{ width: 38, height: 38, borderRadius: '50%', background: 'rgba(50, 215, 75, 0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent-green)' }}>
              <BellRing size={20} />
            </div>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 800, color: 'var(--accent-green)' }}>Pesanan Siap Diambil!</div>
              <div style={{ fontSize: 12, color: 'var(--text-main)' }}>Atas nama <strong>{readyAlertOrder.customerName}</strong></div>
            </div>
          </div>
          <button
            onClick={() => setReadyAlertOrder(null)}
            style={{ background: 'var(--glass-pill)', border: '1px solid var(--glass-border)', color: 'var(--text-main)', width: 30, height: 30, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
            aria-label="Tutup notifikasi"
          >
            <X size={15} />
          </button>
        </div>
      )}

      {/* iOS Safari "Tambah ke Layar Utama" PWA Install Hint */}
      {showIosInstallHint && (
        <div style={{ margin: '10px 16px 0', padding: '11px 14px', borderRadius: 18, background: 'var(--glass-surface-strong)', border: '1px solid var(--accent-primary)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
          <div style={{ fontSize: 12, lineHeight: 1.4, color: 'var(--text-main)' }}>
            <strong style={{ color: 'var(--accent-primary)' }}>Pasang 1001 SK di iPhone:</strong> Ketuk tombol <strong>Bagikan (↑)</strong> di Safari lalu pilih <strong>Tambah ke Layar Utama</strong>.
          </div>
          <button
            type="button"
            onClick={() => {
              setShowIosInstallHint(false);
              try { localStorage.setItem('1001sk_ios_pwa_dismissed', 'true'); } catch {}
            }}
            style={{ background: 'var(--glass-pill)', border: '1px solid var(--glass-border)', color: 'var(--text-main)', width: 28, height: 28, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, cursor: 'pointer' }}
            aria-label="Tutup panduan pasang iPhone"
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* Sticky Frosted Header */}
      <header className="ios-header">
        <div>
          <div className="brand-title">1001 SK</div>
          <div className="brand-sub">
            {userRole === 'seller' ? `Kasir & Manajemen • v${CURRENT_APP_VERSION}` : `Coffee & Lounge • v${CURRENT_APP_VERSION}`}
          </div>
        </div>

        <div className="header-actions">
          {updateInfo && (
            <button
              className="icon-glass-btn active-accent"
              onClick={() => setIsUpdateModalOpen(true)}
              aria-label="Pembaruan tersedia"
              title={`Update v${updateInfo.latestVersion} tersedia`}
            >
              <span className="update-dot" />
            </button>
          )}

          <button
            className={`icon-glass-btn ${soundEnabled ? 'active-accent' : ''}`}
            onClick={toggleSound}
            aria-label="Toggle Nada Notifikasi"
            title={soundEnabled ? 'Nada Notifikasi Aktif' : 'Nada Notifikasi Mati'}
          >
            {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>

          <button
            className="icon-glass-btn"
            onClick={toggleTheme}
            aria-label="Ganti Tema Terang/Gelap"
            title={theme === 'dark' ? 'Beralih ke Tema Terang' : 'Beralih ke Tema Gelap'}
          >
            {theme === 'dark' ? <Sun size={16} color="var(--accent-primary)" /> : <Moon size={16} />}
          </button>

          <button
            className={`tab-btn ${userRole === 'seller' ? 'active' : ''}`}
            style={{ padding: '7px 12px', fontSize: 11.5 }}
            onClick={() => setIsAuthOpen(true)}
          >
            {user ? (
              userRole === 'seller' ? <><Store size={13} /> Seller</> : <><User size={13} /> Akun</>
            ) : (
              <><User size={13} /> Login</>
            )}
          </button>
        </div>
      </header>

      {/* Main Swipeable Viewport */}
      <main ref={stageRef} className="swipe-stage" {...swipeHandlers}>
        {userRole === 'seller' ? (
          <SellerView
            orders={orders}
            sellerSubTab={sellerSubTab}
            setSellerSubTab={setSellerSubTab}
            showToast={showToast}
            storeOpen={storeOpen}
          />
        ) : (
          <CustomerView
            cart={cart}
            setCart={setCart}
            activeTab={activeTab}
            user={user}
            userRole={userRole}
            orders={orders}
            showToast={showToast}
            searchInputRef={searchInputRef}
            setActiveTab={setActiveTab}
            storeOpen={storeOpen}
          />
        )}
      </main>

      {/* Floating Frosted Capsule Dock + Separate Circular Action Button */}
      <div className="floating-nav-wrapper">
        <nav className="ios-dock">
          {userRole === 'seller' ? (
            <>
              <button
                className={`dock-item ${sellerSubTab === 'orders' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setSellerSubTab('orders'); }}
              >
                <Receipt size={19} />
                <span>Pesanan</span>
                {pendingCount > 0 && <span className="dock-badge">{pendingCount}</span>}
              </button>
              <button
                className={`dock-item ${sellerSubTab === 'menu' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setSellerSubTab('menu'); }}
              >
                <LayoutDashboard size={19} />
                <span>Menu</span>
              </button>
              <button
                className={`dock-item ${sellerSubTab === 'update' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setSellerSubTab('update'); }}
              >
                <Sparkles size={19} />
                <span>Update</span>
              </button>
            </>
          ) : (
            <>
              <button
                className={`dock-item ${activeTab === 'menu' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setActiveTab('menu'); }}
              >
                <Coffee size={19} />
                <span>Beranda</span>
              </button>
              <button
                className={`dock-item ${activeTab === 'cart' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setActiveTab('cart'); }}
              >
                <ShoppingBag size={19} />
                <span>Keranjang</span>
                {cartCount > 0 && <span className="dock-badge">{cartCount}</span>}
              </button>
              <button
                className={`dock-item ${activeTab === 'orders' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setActiveTab('orders'); }}
              >
                <Receipt size={19} />
                <span>Pesanan</span>
              </button>
            </>
          )}
        </nav>

        <button
          className="dock-circle-btn"
          onClick={handleCircleAction}
          aria-label={userRole === 'seller' ? 'Pengaturan QRIS Toko' : 'Cari Menu'}
          title={userRole === 'seller' ? 'QRIS Toko' : 'Cari Kopi & Camilan'}
        >
          {userRole === 'seller' ? <QrCode size={22} /> : <Search size={22} />}
        </button>
      </div>

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        user={user}
        userRole={userRole}
        setUserRole={setUserRole}
        showToast={showToast}
        hasUpdate={Boolean(updateInfo)}
        onCheckUpdate={handleManualCheckUpdate}
      />

      <UpdateModal
        isOpen={isUpdateModalOpen}
        onClose={() => setIsUpdateModalOpen(false)}
        updateInfo={updateInfo}
        showToast={showToast}
      />
    </div>
  );
}

export default App;
