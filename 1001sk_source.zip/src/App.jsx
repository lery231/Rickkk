import React, { useState, useEffect, useRef, useCallback } from 'react';
import { auth, db } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';
import {
  doc,
  getDoc,
  collection,
  onSnapshot,
  query,
  orderBy,
  where,
  updateDoc,
} from 'firebase/firestore';
import CustomerView from './components/CustomerView';
import SellerView from './components/SellerView';
import AuthModal from './components/AuthModal';
import UpdateModal from './components/UpdateModal';
import FloatingOrderReadyBanner from './components/FloatingOrderReadyBanner';
import { useSwipe } from './hooks/useSwipe';
import { useRealtimeRecovery } from './hooks/useRealtimeRecovery';
import { CURRENT_APP_VERSION, compareVersions } from './utils/versionUtils';
import { extractAmountFromNotification } from './utils/qrisAutoMatcher';
import { isOrderReadyStatus } from './utils/constants';
import {
  playNewOrderChime,
  playOrderReadyChime,
  playPaymentSuccessChime,
  triggerHaptic,
  sendSystemNotification,
} from './utils/soundEffects';
import {
  Coffee,
  Receipt,
  LayoutDashboard,
  User,
  Store,
  Sparkles,
  Sun,
  Moon,
  Volume2,
  VolumeX,
  Search,
  QrCode,
  ShoppingBag,
  RefreshCw,
} from 'lucide-react';

const CUSTOMER_TABS = ['menu', 'cart', 'orders'];
const SELLER_TABS = ['orders', 'menu', 'qris', 'update'];

function App() {
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState('customer');
  const [activeTab, setActiveTab] = useState('menu');
  const [sellerSubTab, setSellerSubTab] = useState('orders');
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  const [readyAlerts, setReadyAlerts] = useState([]);
  const [authReady, setAuthReady] = useState(false);
  const [storeOpen, setStoreOpen] = useState(true);

  const { syncGeneration, connectionState, manualSync } = useRealtimeRecovery();

  const [updateInfo, setUpdateInfo] = useState(null);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const hasAutoPromptedUpdate = useRef(false);

  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem('1001sk_theme') || 'dark';
    } catch {
      return 'dark';
    }
  });

  const [soundEnabled, setSoundEnabled] = useState(() => {
    try {
      const saved = localStorage.getItem('1001sk_sound');
      return saved === null ? true : saved === 'true';
    } catch {
      return true;
    }
  });

  const searchInputRef = useRef(null);
  const isInitialOrdersLoad = useRef(true);
  const prevOrderStatusMap = useRef({});
  const soundEnabledRef = useRef(soundEnabled);
  const userRoleRef = useRef(userRole);
  const ordersRef = useRef(orders);

  useEffect(() => {
    ordersRef.current = orders;
  }, [orders]);

  useEffect(() => {
    soundEnabledRef.current = soundEnabled;
    try {
      localStorage.setItem('1001sk_sound', String(soundEnabled));
    } catch {}
  }, [soundEnabled]);

  useEffect(() => {
    userRoleRef.current = userRole;
    if (userRole === 'seller') {
      setCart([]);
      setActiveTab('seller');
    } else if (activeTab === 'seller') {
      setActiveTab('menu');
    }
  }, [userRole]);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) {
      metaTheme.setAttribute('content', theme === 'dark' ? '#0a090f' : '#f3f1ed');
    }
    try {
      localStorage.setItem('1001sk_theme', theme);
    } catch {}
  }, [theme]);

  const showToast = useCallback((msg) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? '' : prev));
    }, 3200);
  }, []);

  useEffect(() => {
    if (!('serviceWorker' in navigator)) return;
    const onSwMessage = (event) => {
      if (event.data?.type === 'OPEN_ORDER_DETAIL' && userRoleRef.current !== 'seller') {
        setActiveTab('orders');
      }
    };
    navigator.serviceWorker.addEventListener('message', onSwMessage);
    return () => navigator.serviceWorker.removeEventListener('message', onSwMessage);
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setAuthReady(true);
      if (currentUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists() && userDoc.data().role === 'seller') {
            setUserRole('seller');
            setCart([]);
            setActiveTab('seller');
          } else {
            setUserRole('customer');
          }
        } catch (e) {
          console.error(e);
        }
      } else {
        setUserRole('customer');
      }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    const unsubUpdate = onSnapshot(doc(db, 'settings', 'app_info'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.latestVersion && compareVersions(data.latestVersion, CURRENT_APP_VERSION) > 0) {
          setUpdateInfo(data);
          if (!hasAutoPromptedUpdate.current) {
            hasAutoPromptedUpdate.current = true;
            setIsUpdateModalOpen(true);
          }
        } else {
          setUpdateInfo(null);
        }
      }
    }, () => {});
    return () => unsubUpdate();
  }, [syncGeneration]);

  useEffect(() => {
    isInitialOrdersLoad.current = true;
    prevOrderStatusMap.current = {};

    if (!user) {
      setOrders([]);
      return;
    }

    const isSeller = userRole === 'seller';
    const q = isSeller
      ? query(collection(db, 'orders'), orderBy('createdAt', 'desc'))
      : query(collection(db, 'orders'), where('uid', '==', user.uid));

    const unsub = onSnapshot(q, (snap) => {
      let list = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      if (!isSeller) {
        list = list
          .filter(o => !o.hiddenByCustomer)
          .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
      }
      setOrders(list);

      if (isInitialOrdersLoad.current) {
        const initMap = {};
        list.forEach(o => { initMap[o.id] = o.status; });
        prevOrderStatusMap.current = initMap;
        isInitialOrdersLoad.current = false;
        return;
      }

      const prevMap = prevOrderStatusMap.current;
      const nextMap = {};

      list.forEach(ord => {
        nextMap[ord.id] = ord.status;
        const oldStatus = prevMap[ord.id];

        if ((!oldStatus || oldStatus === 'menunggu_pembayaran') && ord.status === 'pending' && isSeller) {
          if (soundEnabledRef.current) playNewOrderChime();
          triggerHaptic([30, 50, 30]);
          const qrisTag = ord.paymentMethod === 'QRIS' ? ' (QRIS Lunas)' : '';
          showToast(`Pesanan baru dari ${ord.customerName}${qrisTag}!`);
          sendSystemNotification(
            `Pesanan Baru Masuk${qrisTag} - 1001 SK`,
            `${ord.customerName} memesan Rp ${ord.totalPrice?.toLocaleString('id-ID')}`,
            { tag: `order-new-${ord.id}`, data: { orderId: ord.id } }
          );
        }

        if (oldStatus === 'menunggu_pembayaran' && ord.status === 'pending' && !isSeller) {
          if (soundEnabledRef.current) playPaymentSuccessChime();
          triggerHaptic([25, 45, 25]);
          showToast('Pembayaran QRIS lunas otomatis! Pesanan diteruskan ke kasir.');
        }

        if (oldStatus && !isOrderReadyStatus(oldStatus) && isOrderReadyStatus(ord.status) && !isSeller) {
          if (soundEnabledRef.current) playOrderReadyChime();
          triggerHaptic([60, 40, 80]);
          setReadyAlerts((prev) => [ord, ...prev.filter((item) => item.id !== ord.id)]);
          sendSystemNotification(
            'Pesanan Siap Diambil - 1001 SK',
            `Pesanan atas nama ${ord.customerName} sudah siap!`,
            { tag: `order-ready-${ord.id}`, data: { orderId: ord.id } }
          );
        }
      });

      prevOrderStatusMap.current = nextMap;
    }, (err) => console.error(err));

    return () => unsub();
  }, [user, userRole, showToast, syncGeneration]);

  useEffect(() => {
    if (!user || userRole !== 'seller') return;

    const qPayments = query(collection(db, 'qris_payments'), where('matched', '==', false));
    const unsubPayments = onSnapshot(qPayments, async (snap) => {
      if (snap.empty) return;
      const now = Date.now();

      for (const payDoc of snap.docs) {
        const payData = payDoc.data();
        const detectedAmount = extractAmountFromNotification(payData.amount || payData.rawText);
        if (!detectedAmount) continue;

        const matchingOrder = ordersRef.current.find((ord) => {
          if (ord.status !== 'menunggu_pembayaran' || ord.paymentStatus === 'paid') return false;
          if (Number(ord.totalPrice) !== detectedAmount) return false;
          if (ord.paymentExpiresAt && new Date(ord.paymentExpiresAt).getTime() < now) return false;
          return true;
        });

        if (matchingOrder) {
          try {
            await updateDoc(doc(db, 'orders', matchingOrder.id), {
              status: 'pending',
              paymentStatus: 'paid',
              paidAt: new Date().toISOString(),
              paymentProofText: String(payData.rawText || `QRIS Rp ${detectedAmount.toLocaleString('id-ID')}`),
            });
            await updateDoc(doc(db, 'qris_payments', payDoc.id), {
              matched: true,
              matchedOrderId: matchingOrder.id,
              matchedAmount: detectedAmount,
              matchedAt: new Date().toISOString(),
            });
          } catch (err) {
            console.error('Gagal mencocokkan QRIS otomatis:', err);
          }
        }
      }
    }, () => {});

    return () => unsubPayments();
  }, [user, userRole, syncGeneration]);

  useEffect(() => {
    if (!user) return;
    return onSnapshot(
      doc(db, 'settings', 'store'),
      (s) => setStoreOpen(!s.exists() || s.data().open !== false),
      () => {}
    );
  }, [user, syncGeneration]);

  const moveTab = useCallback((dir) => {
    triggerHaptic(10);
    if (userRole === 'seller') {
      const i = SELLER_TABS.indexOf(sellerSubTab) + dir;
      if (i >= 0 && i < SELLER_TABS.length) setSellerSubTab(SELLER_TABS[i]);
    } else {
      const i = CUSTOMER_TABS.indexOf(activeTab) + dir;
      if (i >= 0 && i < CUSTOMER_TABS.length) setActiveTab(CUSTOMER_TABS[i]);
    }
  }, [userRole, sellerSubTab, activeTab]);

  const { stageRef, swipeHandlers } = useSwipe({
    onSwipeLeft: () => moveTab(1),
    onSwipeRight: () => moveTab(-1),
  });

  const toggleTheme = () => {
    triggerHaptic(12);
    setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  const toggleSound = () => {
    triggerHaptic(12);
    setSoundEnabled(prev => {
      const next = !prev;
      if (next) {
        playNewOrderChime();
        showToast('Nada notifikasi pesanan diaktifkan');
      } else {
        showToast('Nada notifikasi dimatikan');
      }
      return next;
    });
  };

  const handleManualCheckUpdate = () => {
    triggerHaptic(12);
    if (updateInfo) {
      setIsUpdateModalOpen(true);
    } else {
      showToast(`Aplikasi 1001 SK sudah versi terbaru (v${CURRENT_APP_VERSION})`);
    }
  };

  const handleCircleAction = () => {
    triggerHaptic(12);
    if (userRole === 'seller') {
      setSellerSubTab(prev => (prev === 'qris' ? 'orders' : 'qris'));
    } else {
      setActiveTab('menu');
      setTimeout(() => {
        if (searchInputRef.current) {
          searchInputRef.current.focus();
        }
      }, 80);
    }
  };

  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const pendingCount = orders.filter(o => o.status === 'pending').length;

  if (!authReady) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 14, color: 'var(--accent-primary)' }}>
        <Coffee size={42} />
        <div style={{ fontWeight: 800, fontSize: 16 }}>Memuat 1001 SK...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="app-shell">
        <div className="ambient-canvas">
          <div className="ambient-orb orb-1" />
          <div className="ambient-orb orb-2" />
          <div className="ambient-orb orb-3" />
        </div>
        {toastMsg && (
          <div className="ios-toast">
            <Sparkles size={16} color="var(--accent-primary)" />
            <span>{toastMsg}</span>
          </div>
        )}
        <AuthModal
          isOpen
          forced
          onClose={() => {}}
          user={null}
          userRole="customer"
          setUserRole={setUserRole}
          showToast={showToast}
          hasUpdate={Boolean(updateInfo)}
          onCheckUpdate={handleManualCheckUpdate}
        />
        <UpdateModal
          isOpen={isUpdateModalOpen}
          onClose={() => setIsUpdateModalOpen(false)}
          updateInfo={updateInfo}
          showToast={showToast}
        />
      </div>
    );
  }

  return (
    <div className="app-shell">
      <div className="ambient-canvas">
        <div className="ambient-orb orb-1" />
        <div className="ambient-orb orb-2" />
        <div className="ambient-orb orb-3" />
      </div>

      {toastMsg && (
        <div className="ios-toast">
          <Sparkles size={16} color="var(--accent-primary)" />
          <span>{toastMsg}</span>
        </div>
      )}

      {userRole !== 'seller' && (
        <FloatingOrderReadyBanner
          readyOrders={readyAlerts}
          onDismiss={(id) => setReadyAlerts((prev) => prev.filter((item) => item.id !== id))}
          onOpenOrders={() => setActiveTab('orders')}
        />
      )}

      <header className="ios-header">
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
            <span className="brand-title">1001 SK</span>
            <button
              type="button"
              className={`conn-pill ${connectionState}`}
              onClick={() => {
                triggerHaptic(10);
                manualSync();
                showToast('Menyegarkan koneksi realtime...');
              }}
              title="Ketuk untuk sinkronisasi ulang"
            >
              {connectionState === 'reconnecting' ? (
                <RefreshCw size={10} className="spin-slow" />
              ) : (
                <span className="conn-dot" />
              )}
              <span>{connectionState === 'online' ? 'Live' : connectionState === 'reconnecting' ? 'Sync' : 'Offline'}</span>
            </button>
          </div>
          <div className="brand-sub">
            {userRole === 'seller' ? `Kasir & Manajemen • v${CURRENT_APP_VERSION}` : `Coffee & Lounge • v${CURRENT_APP_VERSION}`}
          </div>
        </div>

        <div className="header-actions">
          {updateInfo && (
            <button
              className="icon-glass-btn active-accent"
              onClick={() => setIsUpdateModalOpen(true)}
              aria-label="Pembaruan tersedia"
              title={`Update v${updateInfo.latestVersion} tersedia`}
            >
              <span className="update-dot" />
            </button>
          )}

          <button
            className={`icon-glass-btn ${soundEnabled ? 'active-accent' : ''}`}
            onClick={toggleSound}
            aria-label="Toggle Nada Notifikasi"
            title={soundEnabled ? 'Nada Notifikasi Aktif' : 'Nada Notifikasi Mati'}
          >
            {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>

          <button
            className="icon-glass-btn"
            onClick={toggleTheme}
            aria-label="Ganti Tema Terang/Gelap"
            title={theme === 'dark' ? 'Beralih ke Tema Terang' : 'Beralih ke Tema Gelap'}
          >
            {theme === 'dark' ? <Sun size={16} color="var(--accent-primary)" /> : <Moon size={16} />}
          </button>

          <button
            className={`tab-btn ${userRole === 'seller' ? 'active' : ''}`}
            style={{ padding: '7px 12px', fontSize: 11.5 }}
            onClick={() => setIsAuthOpen(true)}
          >
            {user ? (
              userRole === 'seller' ? <><Store size={13} /> Seller</> : <><User size={13} /> Akun</>
            ) : (
              <><User size={13} /> Login</>
            )}
          </button>
        </div>
      </header>

      <main ref={stageRef} className="swipe-stage" {...swipeHandlers}>
        {userRole === 'seller' ? (
          <SellerView
            orders={orders}
            sellerSubTab={sellerSubTab}
            setSellerSubTab={setSellerSubTab}
            showToast={showToast}
            storeOpen={storeOpen}
          />
        ) : (
          <CustomerView
            cart={cart}
            setCart={setCart}
            activeTab={activeTab}
            user={user}
            userRole={userRole}
            orders={orders}
            showToast={showToast}
            searchInputRef={searchInputRef}
            setActiveTab={setActiveTab}
            storeOpen={storeOpen}
          />
        )}
      </main>

      <div className="floating-nav-wrapper">
        <nav className="ios-dock">
          {userRole === 'seller' ? (
            <>
              <button
                className={`dock-item ${sellerSubTab === 'orders' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setSellerSubTab('orders'); }}
              >
                <Receipt size={19} />
                <span>Pesanan</span>
                {pendingCount > 0 && <span className="dock-badge">{pendingCount}</span>}
              </button>
              <button
                className={`dock-item ${sellerSubTab === 'menu' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setSellerSubTab('menu'); }}
              >
                <LayoutDashboard size={19} />
                <span>Menu</span>
              </button>
              <button
                className={`dock-item ${sellerSubTab === 'update' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setSellerSubTab('update'); }}
              >
                <Sparkles size={19} />
                <span>Update</span>
              </button>
            </>
          ) : (
            <>
              <button
                className={`dock-item ${activeTab === 'menu' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setActiveTab('menu'); }}
              >
                <Coffee size={19} />
                <span>Beranda</span>
              </button>
              <button
                className={`dock-item ${activeTab === 'cart' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setActiveTab('cart'); }}
              >
                <ShoppingBag size={19} />
                <span>Keranjang</span>
                {cartCount > 0 && <span className="dock-badge">{cartCount}</span>}
              </button>
              <button
                className={`dock-item ${activeTab === 'orders' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setActiveTab('orders'); }}
              >
                <Receipt size={19} />
                <span>Pesanan</span>
              </button>
            </>
          )}
        </nav>

        <button
          className="dock-circle-btn"
          onClick={handleCircleAction}
          aria-label={userRole === 'seller' ? 'Pengaturan QRIS Toko' : 'Cari Menu'}
          title={userRole === 'seller' ? 'QRIS Toko' : 'Cari Kopi & Camilan'}
        >
          {userRole === 'seller' ? <QrCode size={22} /> : <Search size={22} />}
        </button>
      </div>

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        user={user}
        userRole={userRole}
        setUserRole={setUserRole}
        showToast={showToast}
        hasUpdate={Boolean(updateInfo)}
        onCheckUpdate={handleManualCheckUpdate}
      />

      <UpdateModal
        isOpen={isUpdateModalOpen}
        onClose={() => setIsUpdateModalOpen(false)}
        updateInfo={updateInfo}
        showToast={showToast}
      />
    </div>
  );
}

export default App;
