import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Coffee,
  ShoppingBag,
  Clock,
  Sun,
  Moon,
  RefreshCw,
  Trash2,
  CheckCircle2,
  Bell,
  LogOut,
  LogIn,
  ShieldCheck,
  Plus,
  Minus,
  Camera,
  ImagePlus
} from 'lucide-react';
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  getDoc,
  serverTimestamp
} from 'firebase/firestore';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut
} from 'firebase/auth';
import { db, auth } from './firebase';
import { useRealtimeRecovery } from './hooks/useRealtimeRecovery';
import { useSwipe } from './hooks/useSwipe';
import FloatingOrderReadyBanner from './components/FloatingOrderReadyBanner';
import UpdateModal from './components/UpdateModal';
import {
  DEFAULT_CATEGORIES,
  ORDER_STATUS_LABELS,
  isOrderReadyStatus
} from './utils/constants';
import { compressAndConvertImage } from './utils/imageCompressor';
import { generateUniquePaymentCode } from './utils/qrisAutoMatcher';
import {
  playNewOrderChime,
  playOrderReadyChime,
  playPaymentSuccessChime,
  triggerHaptic,
  sendSystemNotification
} from './utils/soundEffects';

const FALLBACK_COFFEE_IMG =
  'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80';

const INITIAL_MENU = [
  {
    id: 'm1',
    name: 'Kopi Susu 1001 SK',
    price: 18000,
    category: 'Signature',
    desc: 'Espresso double shot dengan gula aren organik & susu segar creamy',
    img: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80',
    stock: true
  },
  {
    id: 'm2',
    name: 'Caramel Macchiato',
    price: 22000,
    category: 'Espresso',
    desc: 'Espresso house-blend dengan saus karamel lembut & foam susu',
    img: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=400&q=80',
    stock: true
  },
  {
    id: 'm3',
    name: 'Matcha Latte',
    price: 20000,
    category: 'Non-Kopi',
    desc: 'Matcha Jepang autentik berpadu dengan susu segar pilihan',
    img: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=400&q=80',
    stock: true
  },
  {
    id: 'm4',
    name: 'Butter Croissant',
    price: 16000,
    category: 'Camilan',
    desc: 'Pastry croissant renyah berlapis dengan mentega hangat',
    img: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=400&q=80',
    stock: true
  }
];

const NOTIFIED_READY_STORAGE_KEY = '1001sk_notified_ready_ids_v1';

function resolveProductImage(item) {
  return item?.img || item?.image || item?.imageUrl || item?.photo || FALLBACK_COFFEE_IMG;
}

function loadNotifiedReadySet() {
  try {
    const raw = localStorage.getItem(NOTIFIED_READY_STORAGE_KEY);
    return new Set(raw ? JSON.parse(raw) : []);
  } catch {
    return new Set();
  }
}

function saveNotifiedReadySet(setObj) {
  try {
    localStorage.setItem(
      NOTIFIED_READY_STORAGE_KEY,
      JSON.stringify(Array.from(setObj).slice(-60))
    );
  } catch {}
}

export default function App() {
  const [theme, setTheme] = useState(() => localStorage.getItem('1001sk_theme') || 'dark');
  const [activeTab, setActiveTab] = useState('menu'); // 'menu' | 'orders' | 'seller' | 'account'
  const [sellerSubTab, setSellerSubTab] = useState('orders'); // 'orders' | 'manage_menu'
  const [selectedCategory, setSelectedCategory] = useState('Semua');

  // Auth state yang terjamin siap sebelum membaca sesi (mencegah logout palsu di APK)
  const [user, setUser] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [firestoreRole, setFirestoreRole] = useState(null);
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);

  // Deteksi Role Seller dari Firestore users/{uid} maupun email (Seller tidak bisa memesan di dalam aplikasi)
  const isSeller = useMemo(() => {
    if (firestoreRole === 'seller') return true;
    if (!user?.email) return false;
    const mail = user.email.toLowerCase();
    return mail.includes('seller') || mail.includes('admin') || mail.includes('kasir');
  }, [user, firestoreRole]);

  // Realtime connection recovery hook (mengatasi delay web & APK)
  const { syncGeneration, connectionState, manualSync } = useRealtimeRecovery();

  // Menu & Orders state
  const [menuItems, setMenuItems] = useState(INITIAL_MENU);
  const [cart, setCart] = useState([]);
  const [customerName, setCustomerName] = useState('');
  const [orders, setOrders] = useState([]);
  const [submittingOrder, setSubmittingOrder] = useState(false);

  // State Form Tambah / Upload Foto Menu di Tab Seller
  const [newMenuName, setNewMenuName] = useState('');
  const [newMenuCategory, setNewMenuCategory] = useState('Signature');
  const [newMenuPrice, setNewMenuPrice] = useState('');
  const [newMenuDesc, setNewMenuDesc] = useState('');
  const [newMenuPhoto, setNewMenuPhoto] = useState('');
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [savingMenu, setSavingMenu] = useState(false);
  const [updatingPhotoItemId, setUpdatingPhotoItemId] = useState(null);

  const newPhotoInputRef = useRef(null);
  const editPhotoInputRef = useRef(null);

  // State Notifikasi Mengambang saat pesanan siap diambil
  const [floatingReadyQueue, setFloatingReadyQueue] = useState([]);
  const notifiedReadyRef = useRef(loadNotifiedReadySet());
  const prevStatusMapRef = useRef({});
  const knownSellerOrderIdsRef = useRef(null);

  const [toast, setToast] = useState('');
  const [updateInfo] = useState(null);
  const [showUpdateModal, setShowUpdateModal] = useState(false);

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(''), 3200);
  };

  // Sinkronisasi tema gelap / terang
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('1001sk_theme', theme);
  }, [theme]);

  // Listener Firebase Auth + cek dokumen role di Firestore users/{uid}
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setAuthReady(true);
      if (currentUser) {
        if (currentUser.displayName && !customerName) {
          setCustomerName(currentUser.displayName);
        }
        try {
          const userSnap = await getDoc(doc(db, 'users', currentUser.uid));
          if (userSnap.exists()) {
            setFirestoreRole(userSnap.data().role || null);
          } else {
            setFirestoreRole(null);
          }
        } catch {
          setFirestoreRole(null);
        }
      } else {
        setFirestoreRole(null);
      }
    });
    return () => unsub();
  }, []);

  // Minta izin notifikasi sistem & dengarkan klik notifikasi dari Service Worker
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }
    const handleSwMessage = (event) => {
      if (event.data?.type === 'OPEN_ORDER_DETAIL') {
        setActiveTab('orders');
      }
    };
    navigator.serviceWorker?.addEventListener?.('message', handleSwMessage);
    return () => navigator.serviceWorker?.removeEventListener?.('message', handleSwMessage);
  }, []);

  // Listener Realtime Menu Firestore (membaca seluruh produk beserta foto img/image/photo)
  useEffect(() => {
    let retryTimer = null;
    const unsub = onSnapshot(
      collection(db, 'menu'),
      (snap) => {
        if (!snap.empty) {
          const loaded = snap.docs
            .map((d) => ({ id: d.id, ...d.data() }))
            .sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
          setMenuItems(loaded);
        }
      },
      () => {
        retryTimer = setTimeout(() => manualSync(), 4000);
      }
    );
    return () => {
      unsub();
      if (retryTimer) clearTimeout(retryTimer);
    };
  }, [syncGeneration]);

  // Listener Realtime Pesanan Firestore + Pemicu Notifikasi Mengambang "Siap Diambil"
  useEffect(() => {
    let retryTimer = null;
    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        setOrders(list);

        // 1. Deteksi pesanan baru masuk untuk Kasir/Seller
        if (isSeller) {
          const currentIds = new Set(list.map((o) => o.id));
          if (knownSellerOrderIdsRef.current !== null) {
            const hasNew = list.some((o) => !knownSellerOrderIdsRef.current.has(o.id));
            if (hasNew) {
              playNewOrderChime();
              triggerHaptic([30, 50, 30]);
              showToast('Pesanan baru masuk!');
            }
          }
          knownSellerOrderIdsRef.current = currentIds;
        }

        // 2. Deteksi perubahan status ke "siap_diambil" / "siap" untuk Pembeli -> tampilkan Notifikasi Mengambang
        const myOrders = user
          ? list.filter((o) => o.userId === user.uid || o.uid === user.uid || o.userEmail === user.email)
          : list;

        const newlyReady = [];
        for (const ord of myOrders) {
          const prevStatus = prevStatusMapRef.current[ord.id];
          const currReady = isOrderReadyStatus(ord.status);
          const wasReady = isOrderReadyStatus(prevStatus);

          if (currReady && !wasReady && !notifiedReadyRef.current.has(ord.id)) {
            notifiedReadyRef.current.add(ord.id);
            newlyReady.push(ord);
          }
          prevStatusMapRef.current[ord.id] = ord.status;
        }

        if (newlyReady.length > 0) {
          saveNotifiedReadySet(notifiedReadyRef.current);
          playOrderReadyChime();
          triggerHaptic([35, 70, 35, 70, 100]);

          setFloatingReadyQueue((prev) => {
            const existingIds = new Set(prev.map((p) => p.id));
            const uniqueNew = newlyReady.filter((n) => !existingIds.has(n.id));
            return [...uniqueNew, ...prev];
          });

          const first = newlyReady[0];
          const code =
            first.orderCode || `#SK-${String(first.id || '').slice(-4).toUpperCase()}`;
          sendSystemNotification(
            `Pesanan ${code} Siap Diambil! ☕`,
            `Pesanan ${first.customerName || 'Anda'} sudah siap di meja pengambilan 1001 SK.`,
            { tag: `order-ready-${first.id}`, data: { orderId: first.id } }
          );
        }
      },
      () => {
        retryTimer = setTimeout(() => manualSync(), 3500);
      }
    );

    return () => {
      unsub();
      if (retryTimer) clearTimeout(retryTimer);
    };
  }, [syncGeneration, user, isSeller]);

  const dismissFloatingReady = (orderId) => {
    setFloatingReadyQueue((prev) => prev.filter((o) => o.id !== orderId));
  };

  const handleOpenReadyOrder = (order) => {
    dismissFloatingReady(order.id);
    setActiveTab('orders');
  };

  // Seller: Pilih & Kompres Foto Produk Baru dari Galeri HP
  const handleSelectNewProductPhoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingPhoto(true);
    try {
      const compressedDataUrl = await compressAndConvertImage(file, 600, 600, 0.75);
      setNewMenuPhoto(compressedDataUrl);
      triggerHaptic(14);
      showToast('Foto produk berhasil dikompresi & siap disimpan');
    } catch (err) {
      showToast('Gagal memproses foto: ' + (err?.message || 'Coba foto lain'));
    } finally {
      setUploadingPhoto(false);
      e.target.value = '';
    }
  };

  // Seller: Simpan Produk Baru ke Firestore koleksi 'menu'
  const handleCreateMenuItem = async (e) => {
    e.preventDefault();
    if (!newMenuName.trim() || !newMenuPrice) return;
    setSavingMenu(true);
    triggerHaptic(16);
    try {
      const finalImg = newMenuPhoto || FALLBACK_COFFEE_IMG;
      await addDoc(collection(db, 'menu'), {
        name: newMenuName.trim(),
        category: newMenuCategory,
        price: parseInt(newMenuPrice, 10) || 0,
        desc: newMenuDesc.trim() || 'Racikan Kopi Spesial 1001 SK',
        img: finalImg,
        image: finalImg,
        stock: true,
        createdAt: new Date().toISOString()
      });
      setNewMenuName('');
      setNewMenuPrice('');
      setNewMenuDesc('');
      setNewMenuPhoto('');
      showToast('Menu baru & foto produk berhasil ditambahkan!');
    } catch (err) {
      showToast('Gagal menyimpan menu: ' + (err?.message || 'Periksa koneksi'));
    } finally {
      setSavingMenu(false);
    }
  };

  // Seller: Ganti Foto Produk yang Sudah Ada
  const handleTriggerReplacePhoto = (itemId) => {
    setUpdatingPhotoItemId(itemId);
    editPhotoInputRef.current?.click();
  };

  const handleReplaceExistingPhoto = async (e) => {
    const file = e.target.files?.[0];
    const targetId = updatingPhotoItemId;
    e.target.value = '';
    if (!file || !targetId) return;

    try {
      showToast('Mengompresi & mengunggah foto baru...');
      const compressedDataUrl = await compressAndConvertImage(file, 600, 600, 0.75);
      await updateDoc(doc(db, 'menu', targetId), {
        img: compressedDataUrl,
        image: compressedDataUrl,
        updatedAt: new Date().toISOString()
      });
      triggerHaptic(18);
      showToast('Foto produk berhasil diperbarui!');
    } catch (err) {
      showToast('Gagal memperbarui foto: ' + (err?.message || 'Coba lagi'));
    } finally {
      setUpdatingPhotoItemId(null);
    }
  };

  const handleToggleMenuStock = async (item) => {
    triggerHaptic(12);
    const nextStock = item.stock === false;
    try {
      await updateDoc(doc(db, 'menu', item.id), { stock: nextStock });
      showToast(nextStock ? `${item.name} tersedia kembali` : `${item.name} ditandai habis`);
    } catch {
      showToast('Gagal memperbarui stok menu.');
    }
  };

  const handleDeleteMenuItem = async (item) => {
    triggerHaptic(15);
    try {
      await deleteDoc(doc(db, 'menu', item.id));
      showToast(`Menu "${item.name}" dihapus.`);
    } catch {
      showToast('Gagal menghapus menu.');
    }
  };

  // Cart & Checkout
  const addToCart = (item) => {
    if (isSeller) {
      showToast('Akun Seller tidak dapat membuat pesanan.');
      return;
    }
    if (item.stock === false) {
      showToast(`${item.name} sedang habis.`);
      return;
    }
    triggerHaptic(12);
    setCart((prev) => {
      const idx = prev.findIndex((c) => c.id === item.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = { ...copy[idx], qty: copy[idx].qty + 1 };
        return copy;
      }
      return [...prev, { ...item, qty: 1 }];
    });
  };

  const updateCartQty = (itemId, delta) => {
    triggerHaptic(10);
    setCart((prev) =>
      prev
        .map((c) => (c.id === itemId ? { ...c, qty: c.qty + delta } : c))
        .filter((c) => c.qty > 0)
    );
  };

  const baseCartTotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  const handlePlaceOrder = async () => {
    if (isSeller) {
      showToast('Seller tidak diizinkan memesan di dalam aplikasi.');
      return;
    }
    if (cart.length === 0) return;

    setSubmittingOrder(true);
    try {
      const uniqueCode = generateUniquePaymentCode(orders, baseCartTotal);
      const totalPrice = baseCartTotal + uniqueCode;
      const orderCode = `#SK-${Math.floor(1000 + Math.random() * 9000)}`;

      await addDoc(collection(db, 'orders'), {
        orderCode,
        uid: user?.uid || 'guest',
        userId: user?.uid || 'guest',
        userEmail: user?.email || '',
        customerName: customerName.trim() || user?.email?.split('@')[0] || 'Pelanggan',
        items: cart.map(({ id, name, price, qty }) => ({ id, name, price, qty })),
        baseAmount: baseCartTotal,
        uniqueCode,
        totalPrice,
        status: 'diproses',
        paymentStatus: 'paid',
        createdAt: serverTimestamp()
      });

      playPaymentSuccessChime();
      triggerHaptic([20, 40, 20]);
      setCart([]);
      setActiveTab('orders');
      showToast(`Pesanan ${orderCode} berhasil dikirim!`);
    } catch {
      showToast('Gagal mengirim pesanan. Periksa koneksi.');
    } finally {
      setSubmittingOrder(false);
    }
  };

  // Update status oleh Seller
  const handleUpdateOrderStatus = async (orderId, newStatus) => {
    triggerHaptic(16);
    try {
      await updateDoc(doc(db, 'orders', orderId), {
        status: newStatus,
        updatedAt: serverTimestamp()
      });
      showToast(`Status diubah: ${ORDER_STATUS_LABELS[newStatus] || newStatus}`);
    } catch {
      showToast('Gagal memperbarui status pesanan.');
    }
  };

  // Hapus riwayat pesanan
  const handleDeleteOrder = async (orderId) => {
    triggerHaptic(15);
    try {
      await deleteDoc(doc(db, 'orders', orderId));
      showToast('Riwayat pesanan dihapus.');
    } catch {
      showToast('Gagal menghapus riwayat.');
    }
  };

  // Login / Register
  const handleAuthSubmit = async (e) => {
    e.preventDefault();
    if (!emailInput || !passwordInput) return;
    setAuthLoading(true);
    try {
      if (isRegisterMode) {
        await createUserWithEmailAndPassword(auth, emailInput.trim(), passwordInput);
        showToast('Akun berhasil dibuat!');
      } else {
        await signInWithEmailAndPassword(auth, emailInput.trim(), passwordInput);
        showToast('Berhasil masuk!');
      }
      setActiveTab(emailInput.toLowerCase().includes('seller') ? 'seller' : 'menu');
    } catch (err) {
      showToast(err?.message || 'Gagal autentikasi.');
    } finally {
      setAuthLoading(false);
    }
  };

  const tabs = isSeller ? ['seller', 'menu', 'account'] : ['menu', 'orders', 'account'];
  const { stageRef, swipeHandlers } = useSwipe({
    onSwipeLeft: () => {
      const idx = tabs.indexOf(activeTab);
      if (idx >= 0 && idx < tabs.length - 1) setActiveTab(tabs[idx + 1]);
    },
    onSwipeRight: () => {
      const idx = tabs.indexOf(activeTab);
      if (idx > 0) setActiveTab(tabs[idx - 1]);
    }
  });

  const filteredMenu =
    selectedCategory === 'Semua'
      ? menuItems
      : menuItems.filter((m) => m.category === selectedCategory);

  const visibleOrders = useMemo(() => {
    if (isSeller) return orders;
    if (!user) return orders;
    return orders.filter(
      (o) => o.userId === user.uid || o.uid === user.uid || o.userEmail === user.email
    );
  }, [orders, user, isSeller]);

  return (
    <div className="app-shell" ref={stageRef} {...swipeHandlers}>
      <div className="ambient-orb one" />
      <div className="ambient-orb two" />

      {/* NOTIFIKASI MENGAMBANG SAAT PESANAN SIAP DIAMBIL */}
      <FloatingOrderReadyBanner
        readyQueue={floatingReadyQueue}
        onOpenOrder={handleOpenReadyOrder}
        onDismissOrder={dismissFloatingReady}
        theme={theme}
      />

      {/* HEADER BAR + INDIKATOR REALTIME INSTAN */}
      <header className="header-bar">
        <div>
          <h1 className="brand-title">1001 SK</h1>
          <button
            type="button"
            className="sync-pill"
            onClick={() => {
              triggerHaptic(12);
              manualSync();
              showToast('Menyegarkan koneksi realtime...');
            }}
            title="Ketuk untuk sinkronisasi instan"
          >
            <span className={`sync-dot ${connectionState}`} />
            <span>
              {connectionState === 'online'
                ? 'Live Realtime'
                : connectionState === 'reconnecting'
                ? 'Menyambungkan...'
                : 'Offline'}
            </span>
            <RefreshCw
              size={11}
              className={connectionState === 'reconnecting' ? 'spin' : ''}
            />
          </button>
        </div>

        <div style={{ display: 'flex', gap: 8 }}>
          <button
            type="button"
            className="icon-btn"
            aria-label="Ganti Tema"
            onClick={() => {
              triggerHaptic(12);
              setTheme((t) => (t === 'dark' ? 'light' : 'dark'));
            }}
          >
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </div>
      </header>

      {/* TAB 1: MENU & PEMESANAN (DENGAN FOTO PRODUK) */}
      {activeTab === 'menu' && (
        <main>
          {isSeller && (
            <div className="glass-card" style={{ marginBottom: 14, borderColor: 'rgba(224,159,76,0.45)' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, fontSize: 12.5, fontWeight: 700 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <ShieldCheck size={18} color="#e09f4c" />
                  <span>Mode Seller — Pemesanan dinonaktifkan.</span>
                </div>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => {
                    setActiveTab('seller');
                    setSellerSubTab('manage_menu');
                  }}
                >
                  <ImagePlus size={14} /> Kelola Foto
                </button>
              </div>
            </div>
          )}

          <div className="category-row" data-no-swipe="true">
            {['Semua', ...DEFAULT_CATEGORIES].map((cat) => (
              <button
                key={cat}
                type="button"
                className={`cat-chip ${selectedCategory === cat ? 'active' : ''}`}
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="menu-grid">
            {filteredMenu.map((item) => {
              const isSoldOut = item.stock === false;
              return (
                <div key={item.id} className={`menu-card ${isSoldOut ? 'sold-out' : ''}`}>
                  <div>
                    <div className="menu-img-wrap">
                      <img
                        src={resolveProductImage(item)}
                        alt={item.name}
                        className="menu-img"
                        loading="lazy"
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = FALLBACK_COFFEE_IMG;
                        }}
                      />
                      <span className="menu-cat-badge">{item.category}</span>
                    </div>
                    <h3 className="menu-name">{item.name}</h3>
                    {item.desc && <p className="menu-desc">{item.desc}</p>}
                    <p className="menu-price">
                      Rp {Number(item.price).toLocaleString('id-ID')}
                    </p>
                  </div>

                  {!isSeller && (
                    <button
                      type="button"
                      className="btn-primary"
                      disabled={isSoldOut}
                      onClick={() => addToCart(item)}
                    >
                      {isSoldOut ? (
                        <span>Stok Habis</span>
                      ) : (
                        <>
                          <Plus size={15} />
                          <span>Tambah</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          {!isSeller && cart.length > 0 && (
            <div className="glass-card" style={{ marginTop: 16 }}>
              <h3 style={{ margin: '0 0 10px', fontSize: 15 }}>Keranjang Pesanan</h3>
              <input
                type="text"
                className="input-field"
                placeholder="Nama Pemesan (contoh: Budi)"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
              />
              {cart.map((item) => (
                <div
                  key={item.id}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '6px 0'
                  }}
                >
                  <span style={{ fontSize: 13 }}>
                    {item.name} (Rp {(item.price * item.qty).toLocaleString('id-ID')})
                  </span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <button
                      type="button"
                      className="icon-btn"
                      style={{ width: 28, height: 28 }}
                      onClick={() => updateCartQty(item.id, -1)}
                    >
                      <Minus size={14} />
                    </button>
                    <span style={{ fontWeight: 700, fontSize: 13 }}>{item.qty}</span>
                    <button
                      type="button"
                      className="icon-btn"
                      style={{ width: 28, height: 28 }}
                      onClick={() => updateCartQty(item.id, 1)}
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                </div>
              ))}
              <button
                type="button"
                className="btn-primary"
                style={{ width: '100%', marginTop: 12 }}
                disabled={submittingOrder}
                onClick={handlePlaceOrder}
              >
                <ShoppingBag size={16} />
                <span>
                  {submittingOrder
                    ? 'Memproses...'
                    : `Pesan Sekarang • Rp ${baseCartTotal.toLocaleString('id-ID')}`}
                </span>
              </button>
            </div>
          )}
        </main>
      )}

      {/* TAB 2: PESANAN SAYA (PEMBELI) */}
      {activeTab === 'orders' && !isSeller && (
        <main>
          <h2 style={{ fontSize: 17, margin: '0 0 12px' }}>Pesanan & Riwayat</h2>
          {visibleOrders.length === 0 ? (
            <div className="glass-card" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
              Belum ada pesanan aktif.
            </div>
          ) : (
            visibleOrders.map((ord) => {
              const ready = isOrderReadyStatus(ord.status);
              return (
                <div
                  key={ord.id}
                  className="glass-card order-card"
                  style={
                    ready
                      ? {
                          borderColor: 'rgba(16, 185, 129, 0.6)',
                          boxShadow: '0 0 22px rgba(16, 185, 129, 0.22)'
                        }
                      : undefined
                  }
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <strong>{ord.orderCode || `#SK-${ord.id.slice(-4).toUpperCase()}`}</strong>
                    <span className={`status-pill ${ready ? 'ready' : ''}`}>
                      {ORDER_STATUS_LABELS[ord.status] || ord.status}
                    </span>
                  </div>
                  <p style={{ margin: '6px 0', fontSize: 13 }}>
                    Pemesan: <strong>{ord.customerName}</strong>
                  </p>
                  <p style={{ margin: '0 0 10px', fontSize: 12.5, color: 'var(--text-muted)' }}>
                    {(ord.items || []).map((i) => `${i.qty}x ${i.name}`).join(', ')}
                  </p>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <strong>Rp {Number(ord.totalPrice || 0).toLocaleString('id-ID')}</strong>
                    <button
                      type="button"
                      className="btn-secondary"
                      onClick={() => handleDeleteOrder(ord.id)}
                      title="Hapus riwayat pesanan"
                    >
                      <Trash2 size={14} />
                      <span>Hapus</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </main>
      )}

      {/* TAB 3: DASHBOARD SELLER / KASIR (ANTREAN + UPLOAD FOTO & KELOLA MENU) */}
      {activeTab === 'seller' && isSeller && (
        <main>
          <div className="category-row" data-no-swipe="true">
            <button
              type="button"
              className={`cat-chip ${sellerSubTab === 'orders' ? 'active' : ''}`}
              onClick={() => setSellerSubTab('orders')}
            >
              Antrean Pesanan ({orders.length})
            </button>
            <button
              type="button"
              className={`cat-chip ${sellerSubTab === 'manage_menu' ? 'active' : ''}`}
              onClick={() => setSellerSubTab('manage_menu')}
            >
              Kelola Menu & Foto ({menuItems.length})
            </button>
          </div>

          {sellerSubTab === 'orders' && (
            <>
              <h2 style={{ fontSize: 17, margin: '0 0 12px' }}>Antrean Pesanan Masuk</h2>
              {orders.length === 0 ? (
                <div className="glass-card" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
                  Belum ada pesanan masuk.
                </div>
              ) : (
                orders.map((ord) => {
                  const ready = isOrderReadyStatus(ord.status);
                  return (
                    <div key={ord.id} className="glass-card order-card">
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <strong>
                          {ord.orderCode || `#SK-${ord.id.slice(-4).toUpperCase()}`} • {ord.customerName}
                        </strong>
                        <span className={`status-pill ${ready ? 'ready' : ''}`}>
                          {ORDER_STATUS_LABELS[ord.status] || ord.status}
                        </span>
                      </div>
                      <p style={{ margin: '8px 0', fontSize: 13 }}>
                        {(ord.items || []).map((i) => `${i.qty}x ${i.name}`).join(', ')}
                      </p>
                      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
                        {!ready && ord.status !== 'selesai' && (
                          <button
                            type="button"
                            className="btn-ready"
                            onClick={() => handleUpdateOrderStatus(ord.id, 'siap_diambil')}
                          >
                            <Bell size={14} />
                            <span>Siap Diambil (Kirim Notif)</span>
                          </button>
                        )}
                        {ord.status !== 'selesai' && (
                          <button
                            type="button"
                            className="btn-secondary"
                            onClick={() => handleUpdateOrderStatus(ord.id, 'selesai')}
                          >
                            <CheckCircle2 size={14} />
                            <span>Selesai</span>
                          </button>
                        )}
                        <button
                          type="button"
                          className="btn-secondary"
                          onClick={() => handleDeleteOrder(ord.id)}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </>
          )}

          {sellerSubTab === 'manage_menu' && (
            <>
              {/* FORM TAMBAH MENU & UPLOAD FOTO DARI GALERI HP */}
              <div className="glass-card" style={{ marginBottom: 16 }}>
                <h2 style={{ fontSize: 16, margin: '0 0 10px' }}>Tambah Produk & Upload Foto</h2>
                <form onSubmit={handleCreateMenuItem}>
                  <input
                    ref={newPhotoInputRef}
                    type="file"
                    accept="image/*"
                    style={{ display: 'none' }}
                    onChange={handleSelectNewProductPhoto}
                  />

                  <div
                    className="photo-upload-box"
                    onClick={() => newPhotoInputRef.current?.click()}
                  >
                    {uploadingPhoto ? (
                      <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--accent)' }}>
                        Mengompresi foto produk...
                      </div>
                    ) : newMenuPhoto ? (
                      <div className="photo-preview-wrap">
                        <img src={newMenuPhoto} alt="Pratinjau Produk" />
                        <span className="photo-change-badge">Ketuk untuk Ganti Foto</span>
                      </div>
                    ) : (
                      <div>
                        <Camera size={26} color="var(--accent)" style={{ marginBottom: 6 }} />
                        <div style={{ fontSize: 13, fontWeight: 700 }}>
                          Pilih Foto Produk dari Galeri HP
                        </div>
                        <div style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 3 }}>
                          Otomatis dikompresi agar cepat dimuat (JPG / PNG / WEBP)
                        </div>
                      </div>
                    )}
                  </div>

                  <input
                    type="text"
                    className="input-field"
                    placeholder="Nama Produk (contoh: Kopi Susu Aren 1001)"
                    value={newMenuName}
                    onChange={(e) => setNewMenuName(e.target.value)}
                    required
                  />

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                    <select
                      className="input-field"
                      value={newMenuCategory}
                      onChange={(e) => setNewMenuCategory(e.target.value)}
                    >
                      {DEFAULT_CATEGORIES.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>

                    <input
                      type="number"
                      className="input-field"
                      placeholder="Harga (contoh: 18000)"
                      value={newMenuPrice}
                      onChange={(e) => setNewMenuPrice(e.target.value)}
                      required
                    />
                  </div>

                  <input
                    type="text"
                    className="input-field"
                    placeholder="Deskripsi singkat menu (opsional)"
                    value={newMenuDesc}
                    onChange={(e) => setNewMenuDesc(e.target.value)}
                  />

                  <button
                    type="submit"
                    className="btn-primary"
                    style={{ width: '100%' }}
                    disabled={savingMenu || uploadingPhoto}
                  >
                    <Plus size={16} />
                    <span>{savingMenu ? 'Menyimpan ke Database...' : 'Simpan Menu & Foto'}</span>
                  </button>
                </form>
              </div>

              {/* INPUT TERSEMBUNYI UNTUK GANTI FOTO PRODUK YANG SUDAH ADA */}
              <input
                ref={editPhotoInputRef}
                type="file"
                accept="image/*"
                style={{ display: 'none' }}
                onChange={handleReplaceExistingPhoto}
              />

              {/* DAFTAR MENU TERPASANG + GANTI FOTO / STOK / HAPUS */}
              <h3 style={{ fontSize: 15, margin: '0 0 10px' }}>Daftar Menu Terpasang</h3>
              {menuItems.map((item) => {
                const isSoldOut = item.stock === false;
                return (
                  <div key={item.id} className="glass-card seller-menu-row">
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0, flex: 1 }}>
                      <img
                        src={resolveProductImage(item)}
                        alt={item.name}
                        className="seller-menu-thumb"
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = FALLBACK_COFFEE_IMG;
                        }}
                      />
                      <div style={{ minWidth: 0 }}>
                        <div
                          style={{
                            fontWeight: 700,
                            fontSize: 13.5,
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis'
                          }}
                        >
                          {item.name}
                        </div>
                        <div style={{ fontSize: 12, color: 'var(--accent)', fontWeight: 700 }}>
                          Rp {Number(item.price).toLocaleString('id-ID')} • {item.category}
                        </div>
                      </div>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
                      <button
                        type="button"
                        className="btn-secondary"
                        onClick={() => handleTriggerReplacePhoto(item.id)}
                        title="Ganti foto produk"
                      >
                        <Camera size={14} />
                        <span>Foto</span>
                      </button>
                      <button
                        type="button"
                        className="btn-secondary"
                        style={
                          isSoldOut
                            ? { color: '#ef4444', borderColor: 'rgba(239,68,68,0.4)' }
                            : { color: '#10b981', borderColor: 'rgba(16,185,129,0.4)' }
                        }
                        onClick={() => handleToggleMenuStock(item)}
                      >
                        {isSoldOut ? 'Habis' : 'Ada'}
                      </button>
                      <button
                        type="button"
                        className="btn-secondary"
                        onClick={() => handleDeleteMenuItem(item)}
                        title="Hapus menu"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </>
          )}
        </main>
      )}

      {/* TAB 4: AKUN (SESI PERSISTEN ANTI-RELOG) */}
      {activeTab === 'account' && (
        <main>
          <div className="glass-card">
            <h2 style={{ margin: '0 0 10px', fontSize: 17 }}>Akun & Sinkronisasi</h2>
            {!authReady ? (
              <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>Memuat sesi tersimpan...</p>
            ) : user ? (
              <div>
                <p style={{ fontSize: 13.5, margin: '0 0 6px' }}>
                  Masuk sebagai: <strong>{user.email}</strong>
                </p>
                <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '0 0 14px' }}>
                  Peran: {isSeller ? 'Seller / Barista' : 'Pelanggan'} • Sesi tersimpan otomatis
                </p>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => signOut(auth)}
                >
                  <LogOut size={15} />
                  <span>Keluar Akun</span>
                </button>
              </div>
            ) : (
              <form onSubmit={handleAuthSubmit}>
                <input
                  type="email"
                  className="input-field"
                  placeholder="Email (gunakan kata 'seller' untuk kasir)"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  required
                />
                <input
                  type="password"
                  className="input-field"
                  placeholder="Kata Sandi"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  required
                />
                <button
                  type="submit"
                  className="btn-primary"
                  style={{ width: '100%' }}
                  disabled={authLoading}
                >
                  <LogIn size={15} />
                  <span>
                    {authLoading
                      ? 'Memproses...'
                      : isRegisterMode
                      ? 'Daftar Akun Baru'
                      : 'Masuk'}
                  </span>
                </button>
                <button
                  type="button"
                  className="btn-secondary"
                  style={{ width: '100%', marginTop: 8 }}
                  onClick={() => setIsRegisterMode((m) => !m)}
                >
                  {isRegisterMode ? 'Sudah punya akun? Masuk' : 'Belum punya akun? Daftar'}
                </button>
              </form>
            )}
          </div>
        </main>
      )}

      {/* BOTTOM NAVIGATION */}
      <nav className="bottom-nav">
        {isSeller && (
          <button
            type="button"
            className={`nav-item ${activeTab === 'seller' ? 'active' : ''}`}
            onClick={() => setActiveTab('seller')}
          >
            <Bell size={18} />
            <span>Seller</span>
          </button>
        )}
        <button
          type="button"
          className={`nav-item ${activeTab === 'menu' ? 'active' : ''}`}
          onClick={() => setActiveTab('menu')}
        >
          <Coffee size={18} />
          <span>Menu</span>
        </button>
        {!isSeller && (
          <button
            type="button"
            className={`nav-item ${activeTab === 'orders' ? 'active' : ''}`}
            onClick={() => setActiveTab('orders')}
          >
            <Clock size={18} />
            <span>Pesanan</span>
          </button>
        )}
        <button
          type="button"
          className={`nav-item ${activeTab === 'account' ? 'active' : ''}`}
          onClick={() => setActiveTab('account')}
        >
          <ShieldCheck size={18} />
          <span>Akun</span>
        </button>
      </nav>

      {toast && <div className="toast-banner">{toast}</div>}

      <UpdateModal
        isOpen={showUpdateModal}
        onClose={() => setShowUpdateModal(false)}
        updateInfo={updateInfo}
        showToast={showToast}
      />
    </div>
  );
}
