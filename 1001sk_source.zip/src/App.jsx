import React, { useState, useEffect } from 'react';
import { auth, db } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import CustomerView from './components/CustomerView';
import SellerView from './components/SellerView';
import AuthModal from './components/AuthModal';
import { Coffee, Receipt, LayoutDashboard, User, Store, Sparkles } from 'lucide-react';

function App() {
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState('customer');
  const [activeTab, setActiveTab] = useState('menu');
  const [cart, setCart] = useState([]);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState('');

  const showToast = (msg) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? '' : prev));
    }, 2800);
  };

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists() && userDoc.data().role === 'seller') {
            setUserRole('seller');
            setActiveTab('seller');
          } else {
            setUserRole('customer');
          }
        } catch (e) {
          console.error(e);
        }
      } else {
        setUserRole('customer');
      }
    });

    return () => unsub();
  }, []);

  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);

  return (
    <div>
      {/* Ambient Floating Orbs for iOS Frosted Blur Effect */}
      <div className="ambient-canvas">
        <div className="ambient-orb orb-1" />
        <div className="ambient-orb orb-2" />
        <div className="ambient-orb orb-3" />
      </div>

      {/* iOS Dynamic Island Style Toast */}
      {toastMsg && (
        <div className="ios-toast">
          <Sparkles size={16} color="var(--accent-gold)" />
          <span>{toastMsg}</span>
        </div>
      )}

      <header className="ios-header">
        <div>
          <div className="brand-title">1001 SK</div>
          <div className="brand-sub">Coffee & Lounge • v2.2</div>
        </div>
        <button 
          className="tab-btn" 
          style={{ borderColor: 'var(--glass-border-glow)', padding: '8px 14px' }} 
          onClick={() => setIsAuthOpen(true)}
        >
          {user ? (
            userRole === 'seller' ? <><Store size={14} /> Seller</> : <><User size={14} /> Akun</>
          ) : (
            <><User size={14} /> Login</>
          )}
        </button>
      </header>

      <main>
        {userRole === 'seller' && activeTab === 'seller' ? (
          <SellerView userRole={userRole} showToast={showToast} />
        ) : (
          <CustomerView 
            cart={cart} 
            setCart={setCart} 
            activeTab={activeTab} 
            user={user} 
            showToast={showToast} 
          />
        )}
      </main>

      <nav className="ios-dock">
        {userRole === 'seller' && (
          <button 
            className={`dock-item ${activeTab === 'seller' ? 'active' : ''}`} 
            onClick={() => setActiveTab('seller')}
          >
            <LayoutDashboard size={19} />
            <span>Dashboard</span>
          </button>
        )}
        <button 
          className={`dock-item ${activeTab === 'menu' ? 'active' : ''}`} 
          onClick={() => setActiveTab('menu')}
        >
          <Coffee size={19} />
          <span>Menu</span>
          {cartCount > 0 && <span className="dock-badge">{cartCount}</span>}
        </button>
        <button 
          className={`dock-item ${activeTab === 'orders' ? 'active' : ''}`} 
          onClick={() => setActiveTab('orders')}
        >
          <Receipt size={19} />
          <span>Pesanan</span>
        </button>
      </nav>

      <AuthModal 
        isOpen={isAuthOpen} 
        onClose={() => setIsAuthOpen(false)} 
        user={user} 
        userRole={userRole} 
        setUserRole={setUserRole}
        showToast={showToast}
      />
    </div>
  );
}

export default App;
