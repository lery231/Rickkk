import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Bell,
  Check,
  ChevronRight,
  Clock,
  Coffee,
  ImagePlus,
  Lock,
  LogOut,
  Minus,
  Moon,
  Plus,
  QrCode,
  Search,
  ShoppingBag,
  Sparkles,
  Store,
  Sun,
  Trash2,
  User,
  Volume2,
  VolumeX,
  X
} from 'lucide-react';
import {
  APP_VERSION,
  DEFAULT_MENU_IMAGE,
  DEFAULT_SELLER_PIN,
  MENU_CATEGORIES,
  ORDER_STATUS_META,
  formatDateTime,
  formatRupiah
} from './utils/constants.js';
import { isValidImageSrc, sanitizeText } from './utils/securityGuard.js';
import { compressImageFile } from './utils/imageCompressor.js';
import { extractNominalFromText } from './utils/qrisAutoMatcher.js';
import { compareSemver } from './utils/versionUtils.js';
import { playOrderChime } from './utils/soundNotifier.js';
import { useSwipe } from './hooks/useSwipe.js';
import { useAndroidBackButton } from './hooks/useAndroidBackButton.js';
import { useRealtimeRecovery } from './hooks/useRealtimeRecovery.js';
import {
  clearFinishedOrders,
  createOrder,
  deleteMenuItem,
  deleteOrderById,
  isCloudConnected,
  saveMenuItem,
  subscribeMenu,
  subscribeOrders,
  subscribeSettings,
  updateOrderStatus,
  updateStoreSettings
} from './services/dataStore.js';
import QrisFullscreenModal from './components/QrisFullscreenModal.jsx';
import PeekPopModal from './components/PeekPopModal.jsx';
import UpdateModal from './components/UpdateModal.jsx';

export default function App() {
  // Theme (Light & Dark Mode)
  const [theme, setTheme] = useState(() => localStorage.getItem('1001sk_theme') || 'dark');
  const [soundEnabled, setSoundEnabled] = useState(() => localStorage.getItem('1001sk_sound') !== 'off');

  // Role: 'customer' | 'seller'
  const [role, setRole] = useState(() => localStorage.getItem('1001sk_role') || 'customer');
  const isSeller = role === 'seller';

  // Active Tab
  const [activeTab, setActiveTab] = useState('home');

  // Realtime Data
  const [menu, setMenu] = useState([]);
  const [orders, setOrders] = useState([]);
  const [settings, setSettings] = useState({ storeOpen: true, qrisImage: '' });
  const [syncTick, setSyncTick] = useState(0);

  // Customer Profile & Cart
  const [customerName, setCustomerName] = useState(() => localStorage.getItem('1001sk_cust_name') || '');
  const [tableNumber, setTableNumber] = useState(() => localStorage.getItem('1001sk_table') || '');
  const [orderNote, setOrderNote] = useState('');
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);

  // Filters & Search
  const [selectedCategory, setSelectedCategory] = useState('Semua');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals & Overlays
  const [qrisModalOrder, setQrisModalOrder] = useState(null);
  const [peekItem, setPeekItem] = useState(null);
  const [updateModalInfo, setUpdateModalInfo] = useState(null);
  const [pinInput, setPinInput] = useState('');
  const [toastMsg, setToastMsg] = useState('');

  // Seller Menu Editor State
  const [editingItem, setEditingItem] = useState(null);
  const [menuForm, setMenuForm] = useState({
    name: '',
    category: 'Signature Coffee',
    price: '',
    desc: '',
    image: '',
    featured: false,
    available: true
  });
  const [mutationText, setMutationText] = useState('');

  // Refs for notifications & long-press
  const prevOrderCountRef = useRef(null);
  const prevOrderStatusMapRef = useRef({});
  const longPressTimerRef = useRef(null);

  const showToast = (msg) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg((curr) => (curr === msg ? '' : curr)), 2600);
  };

  // Apply theme attribute
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('1001sk_theme', theme);
    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) metaTheme.setAttribute('content', theme === 'dark' ? '#0b0e14' : '#f5f7fb');
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('1001sk_sound', soundEnabled ? 'on' : 'off');
  }, [soundEnabled]);

  useEffect(() => {
    localStorage.setItem('1001sk_role', role);
    if (role === 'seller') {
      setCart([]);
      setCartOpen(false);
      setActiveTab('orders');
    } else {
      setActiveTab('home');
    }
  }, [role]);

  // Subscribe to realtime streams
  useEffect(() => {
    const unsubMenu = subscribeMenu(setMenu);
    const unsubOrders = subscribeOrders((incoming) => {
      // Order sound notifications
      if (soundEnabled) {
        if (prevOrderCountRef.current !== null && incoming.length > prevOrderCountRef.current && isSeller) {
          playOrderChime('new_order');
          showToast('Pesanan baru masuk!');
        }
        if (!isSeller) {
          incoming.forEach((ord) => {
            const oldStatus = prevOrderStatusMapRef.current[ord.id];
            if (oldStatus && oldStatus !== 'ready' && ord.status === 'ready') {
              playOrderChime('ready');
              showToast(`Pesanan ${ord.id} siap diambil!`);
            }
          });
        }
      }
      prevOrderCountRef.current = incoming.length;
      const statusMap = {};
      incoming.forEach((o) => {
        statusMap[o.id] = o.status;
      });
      prevOrderStatusMapRef.current = statusMap;
      setOrders(incoming);
    });
    const unsubSettings = subscribeSettings((cfg) => {
      setSettings(cfg);
      if (cfg.latestVersion && compareSemver(cfg.latestVersion, APP_VERSION) > 0) {
        setUpdateModalInfo(cfg);
      }
    });

    return () => {
      unsubMenu();
      unsubOrders();
      unsubSettings();
    };
  }, [isSeller, soundEnabled, syncTick]);

  useRealtimeRecovery(() => setSyncTick((n) => n + 1));

  // Tab navigation lists
  const tabs = isSeller
    ? [
        { id: 'orders', label: 'Pesanan', icon: Bell },
        { id: 'menu', label: 'Kelola Menu', icon: Coffee },
        { id: 'qris', label: 'QRIS & Toko', icon: QrCode }
      ]
    : [
        { id: 'home', label: 'Menu', icon: Coffee },
        { id: 'orders', label: 'Pesanan', icon: Clock },
        { id: 'profile', label: 'Akun', icon: User }
      ];

  const currentTabIndex = tabs.findIndex((t) => t.id === activeTab);

  const swipeHandlers = useSwipe({
    onSwipeLeft: () => {
      if (currentTabIndex < tabs.length - 1) setActiveTab(tabs[currentTabIndex + 1].id);
    },
    onSwipeRight: () => {
      if (currentTabIndex > 0) setActiveTab(tabs[currentTabIndex - 1].id);
    }
  });

  // Android Hardware Back Button
  useAndroidBackButton(() => {
    if (peekItem) {
      setPeekItem(null);
      return true;
    }
    if (qrisModalOrder) {
      setQrisModalOrder(null);
      return true;
    }
    if (cartOpen) {
      setCartOpen(false);
      return true;
    }
    if (editingItem) {
      setEditingItem(null);
      return true;
    }
    const defaultTab = isSeller ? 'orders' : 'home';
    if (activeTab !== defaultTab) {
      setActiveTab(defaultTab);
      return true;
    }
    return false;
  });

  // Filtered Menu
  const filteredMenu = useMemo(() => {
    return menu.filter((item) => {
      const matchCat = selectedCategory === 'Semua' || item.category === selectedCategory;
      const q = searchQuery.trim().toLowerCase();
      const matchSearch =
        !q ||
        item.name?.toLowerCase().includes(q) ||
        item.desc?.toLowerCase().includes(q) ||
        item.category?.toLowerCase().includes(q);
      return matchCat && matchSearch;
    });
  }, [menu, selectedCategory, searchQuery]);

  const featuredMenu = useMemo(() => menu.filter((m) => m.featured && m.available), [menu]);

  // Cart Actions (Strictly blocked if isSeller)
  const addToCart = (item) => {
    if (isSeller) {
      showToast('Akun penjual tidak dapat memesan di dalam aplikasi.');
      return;
    }
    if (!settings.storeOpen) {
      showToast('Maaf, toko sedang tutup sementara.');
      return;
    }
    if (!item.available) return;

    setCart((prev) => {
      const found = prev.find((c) => c.id === item.id);
      if (found) {
        return prev.map((c) => (c.id === item.id ? { ...c, qty: c.qty + 1 } : c));
      }
      return [...prev, { id: item.id, name: item.name, price: item.price, image: item.image, qty: 1 }];
    });
    showToast(`+1 ${item.name}`);
  };

  const updateCartQty = (id, delta) => {
    setCart((prev) =>
      prev
        .map((c) => (c.id === id ? { ...c, qty: c.qty + delta } : c))
        .filter((c) => c.qty > 0)
    );
  };

  const cartCount = useMemo(() => cart.reduce((acc, c) => acc + c.qty, 0), [cart]);
  const cartTotal = useMemo(() => cart.reduce((acc, c) => acc + c.price * c.qty, 0), [cart]);

  // Submit Customer Order
  const handleCheckout = async () => {
    if (isSeller) {
      showToast('Penjual tidak dapat membuat pesanan.');
      return;
    }
    if (!cart.length) return;
    const cleanName = sanitizeText(customerName || 'Pelanggan', 50);
    const cleanTable = sanitizeText(tableNumber || 'Takeaway', 25);
    const cleanNote = sanitizeText(orderNote, 140);

    localStorage.setItem('1001sk_cust_name', cleanName);
    localStorage.setItem('1001sk_table', cleanTable);

    const created = await createOrder({
      customerName: cleanName,
      tableNumber: cleanTable,
      note: cleanNote,
      items: cart,
      total: cartTotal,
      status: 'pending_payment'
    });

    setCart([]);
    setOrderNote('');
    setCartOpen(false);
    setQrisModalOrder(created);
    setActiveTab('orders');
  };

  const handleConfirmQrisPaid = async (orderId) => {
    await updateOrderStatus(orderId, 'queued', { paymentMethod: 'QRIS', paidReportedAt: Date.now() });
    setQrisModalOrder(null);
    showToast('Konfirmasi pembayaran terkirim ke barista!');
  };

  // Active Order for Mini-Player
  const activeCustomerOrder = useMemo(() => {
    if (isSeller) return null;
    return orders.find((o) => ['pending_payment', 'queued', 'preparing', 'ready'].includes(o.status)) || null;
  }, [orders, isSeller]);

  // Long Press Handlers for Peek & Pop
  const startLongPress = (item) => {
    longPressTimerRef.current = setTimeout(() => {
      if (navigator?.vibrate) navigator.vibrate(25);
      setPeekItem(item);
    }, 380);
  };

  const cancelLongPress = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  // Seller Menu Photo Upload
  const handleMenuPhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageFile(file, 850, 0.82);
      setMenuForm((prev) => ({ ...prev, image: compressed }));
      showToast('Foto produk siap disimpan');
    } catch (err) {
      showToast(err.message || 'Gagal mengunggah foto');
    }
  };

  const handleSaveMenuSubmit = async (e) => {
    e.preventDefault();
    const cleanName = sanitizeText(menuForm.name, 70);
    const numPrice = parseInt(String(menuForm.price).replace(/\D/g, ''), 10);
    if (!cleanName || !numPrice || numPrice < 500) {
      showToast('Isi nama menu dan harga yang valid');
      return;
    }
    await saveMenuItem({
      id: editingItem?.id,
      name: cleanName,
      category: menuForm.category,
      price: numPrice,
      desc: sanitizeText(menuForm.desc, 180),
      image: menuForm.image || DEFAULT_MENU_IMAGE,
      featured: Boolean(menuForm.featured),
      available: Boolean(menuForm.available)
    });
    setEditingItem(null);
    setMenuForm({
      name: '',
      category: 'Signature Coffee',
      price: '',
      desc: '',
      image: '',
      featured: false,
      available: true
    });
    showToast('Menu berhasil disimpan!');
  };

  const handleQuickReplacePhoto = async (item, file) => {
    if (!file) return;
    try {
      const compressed = await compressImageFile(file, 850, 0.82);
      await saveMenuItem({ ...item, image: compressed });
      showToast(`Foto ${item.name} diperbarui!`);
    } catch {
      showToast('Gagal mengganti foto produk');
    }
  };

  // Seller QRIS Upload & Auto-Matcher
  const handleQrisUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageFile(file, 960, 0.88);
      await updateStoreSettings({ qrisImage: compressed });
      showToast('Gambar QRIS toko berhasil diperbarui!');
    } catch {
      showToast('Gagal mengunggah QRIS');
    }
  };

  const handleVerifyMutation = async () => {
    const detectedAmount = extractNominalFromText(mutationText);
    if (!detectedAmount) {
      showToast('Nominal tidak terdeteksi dari teks mutasi.');
      return;
    }
    const matched = orders.find(
      (o) => o.status === 'pending_payment' && Number(o.total) === Number(detectedAmount)
    );
    if (matched) {
      await updateOrderStatus(matched.id, 'queued', { verifiedNominal: detectedAmount });
      setMutationText('');
      showToast(`Cocok! Pesanan ${matched.id} (${formatRupiah(detectedAmount)}) masuk antrean.`);
    } else {
      showToast(`Nominal ${formatRupiah(detectedAmount)} terdeteksi, namun tidak ada tagihan pending yang cocok.`);
    }
  };

  // Delete Order History
  const handleDeleteOrder = async (orderId) => {
    await deleteOrderById(orderId);
    showToast('Riwayat pesanan dihapus');
  };

  const handleClearFinishedHistory = async () => {
    const finishedIds = orders
      .filter((o) => o.status === 'completed' || o.status === 'cancelled')
      .map((o) => o.id);
    if (!finishedIds.length) {
      showToast('Tidak ada riwayat selesai untuk dihapus');
      return;
    }
    await clearFinishedOrders(finishedIds);
    showToast(`${finishedIds.length} riwayat pesanan dihapus`);
  };

  // Seller Login
  const handleSellerLogin = (e) => {
    e.preventDefault();
    const expectedPin = settings.sellerPin || DEFAULT_SELLER_PIN;
    if (pinInput.trim() === expectedPin) {
      setRole('seller');
      setPinInput('');
      showToast('Masuk sebagai Penjual / Barista');
    } else {
      showToast('PIN Penjual salah');
    }
  };

  const pendingOrdersCount = useMemo(
    () => orders.filter((o) => ['pending_payment', 'queued', 'preparing'].includes(o.status)).length,
    [orders]
  );

  return (
    <div className="app-shell" {...swipeHandlers}>
      {/* Ambient Liquid Orbs */}
      <div className="ambient-orb orb-1" />
      <div className="ambient-orb orb-2" />

      {/* Floating Island Header */}
      <header className="floating-island-header">
        <div className="island-left">
          <div className="brand-dot">
            <Coffee size={16} />
          </div>
          <div>
            <div className="brand-title">
              1001 SK <span className="version-pill">v{APP_VERSION}</span>
            </div>
            <div className="status-row">
              <span className={`live-dot ${settings.storeOpen ? 'open' : 'closed'}`} />
              <span className="muted-xs">
                {settings.storeOpen ? 'Buka • Siap Racik' : 'Tutup Sementara'}
                {isCloudConnected() ? ' • Cloud' : ''}
              </span>
            </div>
          </div>
        </div>

        <div className="island-actions">
          <button
            className="icon-pill-btn"
            onClick={() => setSoundEnabled((s) => !s)}
            aria-label="Suara Notifikasi"
            title={soundEnabled ? 'Notifikasi Suara Aktif' : 'Notifikasi Suara Mati'}
          >
            {soundEnabled ? <Volume2 size={17} /> : <VolumeX size={17} />}
          </button>

          <button
            className="icon-pill-btn"
            onClick={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
            aria-label="Ganti Tema"
            title="Tema Terang / Gelap"
          >
            {theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}
          </button>

          {isSeller && (
            <button
              className="icon-pill-btn danger-tint"
              onClick={() => setRole('customer')}
              aria-label="Keluar Mode Penjual"
              title="Keluar Mode Penjual"
            >
              <LogOut size={17} />
            </button>
          )}
        </div>
      </header>

      {/* Toast Notification */}
      {toastMsg && <div className="floating-toast">{toastMsg}</div>}

      {/* Main Content Scroll Area */}
      <main className="main-scroll-area">
        {/* ================= CUSTOMER: HOME / MENU ================= */}
        {!isSeller && activeTab === 'home' && (
          <div className="tab-stage">
            {/* Search Bar */}
            <div className="glass-search-bar">
              <Search size={17} className="muted-icon" />
              <input
                type="text"
                placeholder="Cari kopi susu, matcha, V60..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              {searchQuery && (
                <button className="clear-input-btn" onClick={() => setSearchQuery('')}>
                  <X size={15} />
                </button>
              )}
            </div>

            {/* Pilihan Hari Ini (Featured Horizontal Carousel) */}
            {!searchQuery && featuredMenu.length > 0 && (
              <section style={{ marginTop: 18 }}>
                <div className="section-head">
                  <div className="row-gap">
                    <Sparkles size={16} className="accent-icon" />
                    <strong>Pilihan Hari Ini</strong>
                  </div>
                  <span className="muted-xs">Tekan lama untuk pratinjau</span>
                </div>

                <div className="h-scroll featured-strip">
                  {featuredMenu.map((item) => (
                    <div
                      key={item.id}
                      className="glass-card featured-card"
                      onTouchStart={() => startLongPress(item)}
                      onTouchEnd={cancelLongPress}
                      onTouchMove={cancelLongPress}
                      onContextMenu={(e) => {
                        e.preventDefault();
                        setPeekItem(item);
                      }}
                    >
                      <div className="featured-thumb-wrap" onClick={() => setPeekItem(item)}>
                        <img
                          src={isValidImageSrc(item.image) ? item.image : DEFAULT_MENU_IMAGE}
                          alt={item.name}
                          className="featured-thumb"
                          loading="lazy"
                        />
                      </div>
                      <div className="featured-body">
                        <div className="item-title-clamp">{item.name}</div>
                        <div className="row-between" style={{ marginTop: 8 }}>
                          <span className="price-tag">{formatRupiah(item.price)}</span>
                          <button
                            className="mini-add-btn"
                            onClick={() => addToCart(item)}
                            aria-label={`Tambah ${item.name}`}
                          >
                            <Plus size={16} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Category Pills */}
            <div className="ios-pills" style={{ marginTop: 18 }}>
              {MENU_CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  className={`ios-pill ${selectedCategory === cat ? 'active' : ''}`}
                  onClick={() => setSelectedCategory(cat)}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* All Menu Grid */}
            <section style={{ marginTop: 14 }}>
              <div className="section-head">
                <strong>{selectedCategory === 'Semua' ? 'Semua Menu' : selectedCategory}</strong>
                <span className="muted-xs">{filteredMenu.length} menu</span>
              </div>

              <div className="menu-grid">
                {filteredMenu.map((item) => (
                  <div
                    key={item.id}
                    className={`glass-card menu-card ${!item.available ? 'sold-out' : ''}`}
                    onTouchStart={() => startLongPress(item)}
                    onTouchEnd={cancelLongPress}
                    onTouchMove={cancelLongPress}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      setPeekItem(item);
                    }}
                  >
                    <div className="menu-photo-box" onClick={() => setPeekItem(item)}>
                      <img
                        src={isValidImageSrc(item.image) ? item.image : DEFAULT_MENU_IMAGE}
                        alt={item.name}
                        className="menu-photo"
                        loading="lazy"
                      />
                      {!item.available && <span className="sold-out-pill">Habis</span>}
                    </div>

                    <div className="menu-card-info">
                      <span className="muted-xxs">{item.category}</span>
                      <h4 className="menu-name" onClick={() => setPeekItem(item)}>
                        {item.name}
                      </h4>
                      <p className="menu-desc-clamp">{item.desc}</p>

                      <div className="row-between" style={{ marginTop: 10 }}>
                        <strong className="price-tag">{formatRupiah(item.price)}</strong>
                        <button
                          className="glass-add-pill"
                          disabled={!item.available}
                          onClick={() => addToCart(item)}
                        >
                          <Plus size={15} />
                          <span>Tambah</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>
        )}

        {/* ================= CUSTOMER & SELLER: ORDERS ================= */}
        {activeTab === 'orders' && (
          <div className="tab-stage">
            <div className="row-between" style={{ marginBottom: 14 }}>
              <div>
                <h2 style={{ margin: 0, fontSize: 20 }}>
                  {isSeller ? 'Antrean & Riwayat Pesanan' : 'Pesanan Saya'}
                </h2>
                <span className="muted-xs">
                  {orders.length} total transaksi • {pendingOrdersCount} aktif
                </span>
              </div>

              {orders.some((o) => o.status === 'completed' || o.status === 'cancelled') && (
                <button className="glass-btn danger-outline small" onClick={handleClearFinishedHistory}>
                  <Trash2 size={14} />
                  <span>Hapus Riwayat</span>
                </button>
              )}
            </div>

            {orders.length === 0 ? (
              <div className="glass-card empty-state">
                <Coffee size={34} className="muted-icon" />
                <p>Belum ada pesanan tercatat.</p>
              </div>
            ) : (
              <div className="stack-list">
                {orders.map((ord) => {
                  const meta = ORDER_STATUS_META[ord.status] || ORDER_STATUS_META.queued;
                  const canDelete = ord.status === 'completed' || ord.status === 'cancelled' || isSeller;

                  return (
                    <div key={ord.id} className="glass-card order-card">
                      <div className="row-between">
                        <div>
                          <strong>{ord.id}</strong>
                          <span className="muted-xs" style={{ marginLeft: 8 }}>
                            {ord.customerName} • {ord.tableNumber}
                          </span>
                        </div>
                        <div className="row-gap">
                          <span
                            className="status-badge"
                            style={{ color: meta.color, backgroundColor: meta.bg }}
                          >
                            {meta.shortLabel}
                          </span>
                          {canDelete && (
                            <button
                              className="icon-pill-btn small danger-tint"
                              onClick={() => handleDeleteOrder(ord.id)}
                              title="Hapus Riwayat Pesanan"
                            >
                              <Trash2 size={14} />
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="order-items-list">
                        {(ord.items || []).map((it, idx) => (
                          <div key={idx} className="row-between muted-sm" style={{ padding: '4px 0' }}>
                            <div className="row-gap">
                              <img
                                src={isValidImageSrc(it.image) ? it.image : DEFAULT_MENU_IMAGE}
                                alt={it.name}
                                className="tiny-thumb"
                              />
                              <span>
                                {it.qty}x {it.name}
                              </span>
                            </div>
                            <span>{formatRupiah(it.price * it.qty)}</span>
                          </div>
                        ))}
                      </div>

                      {ord.note && <div className="order-note-box">Catatan: {ord.note}</div>}

                      <div className="row-between" style={{ marginTop: 12, paddingTop: 10, borderTop: '1px solid var(--glass-border)' }}>
                        <div>
                          <span className="muted-xxs">{formatDateTime(ord.createdAtMs)}</span>
                          <div className="price-tag">{formatRupiah(ord.total)}</div>
                        </div>

                        {/* Customer Pay QRIS Action */}
                        {!isSeller && ord.status === 'pending_payment' && (
                          <button
                            className="glass-btn primary small"
                            onClick={() => setQrisModalOrder(ord)}
                          >
                            <QrCode size={15} />
                            <span>Bayar QRIS</span>
                          </button>
                        )}

                        {/* Seller Status Progression Controls */}
                        {isSeller && (
                          <div className="row-gap">
                            {ord.status === 'pending_payment' && (
                              <button
                                className="glass-btn secondary small"
                                onClick={() => updateOrderStatus(ord.id, 'queued')}
                              >
                                Terima Lunas
                              </button>
                            )}
                            {ord.status === 'queued' && (
                              <button
                                className="glass-btn primary small"
                                onClick={() => updateOrderStatus(ord.id, 'preparing')}
                              >
                                Mulai Racik
                              </button>
                            )}
                            {ord.status === 'preparing' && (
                              <button
                                className="glass-btn primary small"
                                onClick={() => updateOrderStatus(ord.id, 'ready')}
                              >
                                Siap Diambil
                              </button>
                            )}
                            {ord.status === 'ready' && (
                              <button
                                className="glass-btn secondary small"
                                onClick={() => updateOrderStatus(ord.id, 'completed')}
                              >
                                <Check size={14} /> Selesai
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ================= CUSTOMER: PROFILE & SELLER LOGIN ================= */}
        {!isSeller && activeTab === 'profile' && (
          <div className="tab-stage">
            <div className="glass-card" style={{ padding: 18 }}>
              <h3 style={{ marginTop: 0 }}>Preferensi Pelanggan</h3>
              <label className="field-label">Nama Pemesan</label>
              <input
                className="glass-input"
                value={customerName}
                onChange={(e) => {
                  setCustomerName(e.target.value);
                  localStorage.setItem('1001sk_cust_name', e.target.value);
                }}
                placeholder="Contoh: Ricko"
              />

              <label className="field-label" style={{ marginTop: 12 }}>
                Nomor Meja / Tipe Pesanan
              </label>
              <input
                className="glass-input"
                value={tableNumber}
                onChange={(e) => {
                  setTableNumber(e.target.value);
                  localStorage.setItem('1001sk_table', e.target.value);
                }}
                placeholder="Contoh: Meja 04 atau Takeaway"
              />

              <div className="row-between" style={{ marginTop: 16 }}>
                <span>Tes Nada Notifikasi</span>
                <button
                  className="glass-btn secondary small"
                  onClick={() => playOrderChime('ready')}
                >
                  <Volume2 size={15} /> Bunyikan
                </button>
              </div>
            </div>

            <form className="glass-card" style={{ padding: 18, marginTop: 16 }} onSubmit={handleSellerLogin}>
              <div className="row-gap" style={{ marginBottom: 8 }}>
                <Lock size={17} className="accent-icon" />
                <strong>Akses Barista / Penjual</strong>
              </div>
              <p className="muted-xs" style={{ marginBottom: 12 }}>
                Masuk dengan PIN penjual untuk mengelola pesanan, foto menu, dan QRIS toko (PIN default: 1001).
              </p>
              <div className="row-gap">
                <input
                  type="password"
                  inputMode="numeric"
                  className="glass-input"
                  placeholder="Masukkan PIN Penjual"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                />
                <button type="submit" className="glass-btn primary">
                  Masuk
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ================= SELLER: MANAGE MENU & PHOTOS ================= */}
        {isSeller && activeTab === 'menu' && (
          <div className="tab-stage">
            <div className="seller-guard-banner" style={{ marginBottom: 14 }}>
              Mode Penjual Aktif — akun penjual tidak dapat membuat pesanan pelanggan.
            </div>

            <form className="glass-card" style={{ padding: 18, marginBottom: 18 }} onSubmit={handleSaveMenuSubmit}>
              <h3 style={{ marginTop: 0 }}>{editingItem ? 'Edit Menu' : 'Tambah Menu Baru'}</h3>

              <div className="row-gap" style={{ marginBottom: 12 }}>
                <img
                  src={isValidImageSrc(menuForm.image) ? menuForm.image : DEFAULT_MENU_IMAGE}
                  alt="Preview Produk"
                  className="editor-preview-img"
                />
                <label className="glass-btn secondary small" style={{ cursor: 'pointer' }}>
                  <ImagePlus size={16} />
                  <span>Unggah Foto Produk</span>
                  <input type="file" accept="image/*" hidden onChange={handleMenuPhotoUpload} />
                </label>
              </div>

              <input
                className="glass-input"
                placeholder="Nama minuman / makanan"
                value={menuForm.name}
                onChange={(e) => setMenuForm({ ...menuForm, name: e.target.value })}
              />

              <div className="row-gap" style={{ marginTop: 10 }}>
                <select
                  className="glass-input"
                  value={menuForm.category}
                  onChange={(e) => setMenuForm({ ...menuForm, category: e.target.value })}
                >
                  {MENU_CATEGORIES.filter((c) => c !== 'Semua').map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
                <input
                  className="glass-input"
                  type="number"
                  placeholder="Harga (Rp)"
                  value={menuForm.price}
                  onChange={(e) => setMenuForm({ ...menuForm, price: e.target.value })}
                />
              </div>

              <textarea
                className="glass-input"
                rows={2}
                style={{ marginTop: 10 }}
                placeholder="Deskripsi singkat menu..."
                value={menuForm.desc}
                onChange={(e) => setMenuForm({ ...menuForm, desc: e.target.value })}
              />

              <div className="row-between" style={{ marginTop: 12 }}>
                <label className="row-gap muted-sm">
                  <input
                    type="checkbox"
                    checked={menuForm.featured}
                    onChange={(e) => setMenuForm({ ...menuForm, featured: e.target.checked })}
                  />
                  Pilihan Hari Ini
                </label>
                <label className="row-gap muted-sm">
                  <input
                    type="checkbox"
                    checked={menuForm.available}
                    onChange={(e) => setMenuForm({ ...menuForm, available: e.target.checked })}
                  />
                  Tersedia
                </label>
              </div>

              <div className="row-gap" style={{ marginTop: 14 }}>
                <button type="submit" className="glass-btn primary full-width">
                  {editingItem ? 'Simpan Perubahan' : 'Tambah ke Daftar Menu'}
                </button>
                {editingItem && (
                  <button
                    type="button"
                    className="glass-btn secondary"
                    onClick={() => {
                      setEditingItem(null);
                      setMenuForm({
                        name: '',
                        category: 'Signature Coffee',
                        price: '',
                        desc: '',
                        image: '',
                        featured: false,
                        available: true
                      });
                    }}
                  >
                    Batal
                  </button>
                )}
              </div>
            </form>

            {/* Existing Menu List with 1-tap photo replacement */}
            <div className="stack-list">
              {menu.map((item) => (
                <div key={item.id} className="glass-card seller-menu-row">
                  <img
                    src={isValidImageSrc(item.image) ? item.image : DEFAULT_MENU_IMAGE}
                    alt={item.name}
                    className="seller-row-thumb"
                  />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="item-title-clamp">{item.name}</div>
                    <div className="price-tag">{formatRupiah(item.price)}</div>
                    <div className="row-gap" style={{ marginTop: 6 }}>
                      <label className="glass-btn secondary tiny" style={{ cursor: 'pointer' }}>
                        <ImagePlus size={13} /> Ganti Foto
                        <input
                          type="file"
                          accept="image/*"
                          hidden
                          onChange={(e) => handleQuickReplacePhoto(item, e.target.files?.[0])}
                        />
                      </label>
                      <button
                        className="glass-btn secondary tiny"
                        onClick={() => {
                          setEditingItem(item);
                          setMenuForm(item);
                        }}
                      >
                        Edit
                      </button>
                      <button
                        className="glass-btn danger-outline tiny"
                        onClick={() => deleteMenuItem(item.id)}
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= SELLER: QRIS & STORE SETTINGS ================= */}
        {isSeller && activeTab === 'qris' && (
          <div className="tab-stage">
            <div className="glass-card" style={{ padding: 18 }}>
              <div className="row-between">
                <div className="row-gap">
                  <Store size={18} className="accent-icon" />
                  <strong>Status Operasional Toko</strong>
                </div>
                <button
                  className={`glass-btn small ${settings.storeOpen ? 'primary' : 'secondary'}`}
                  onClick={() => updateStoreSettings({ storeOpen: !settings.storeOpen })}
                >
                  {settings.storeOpen ? 'Toko Buka' : 'Toko Tutup'}
                </button>
              </div>
            </div>

            <div className="glass-card" style={{ padding: 18, marginTop: 16 }}>
              <h3 style={{ marginTop: 0 }}>Kode QRIS Toko</h3>
              <p className="muted-xs" style={{ marginBottom: 12 }}>
                Unggah gambar QRIS statis toko agar tampil otomatis saat pelanggan checkout.
              </p>

              {isValidImageSrc(settings.qrisImage) && (
                <div className="qris-frame" style={{ marginBottom: 12 }}>
                  <img src={settings.qrisImage} alt="QRIS Toko" className="qris-image" />
                </div>
              )}

              <label className="glass-btn primary full-width" style={{ cursor: 'pointer' }}>
                <ImagePlus size={17} />
                <span>{settings.qrisImage ? 'Ganti Gambar QRIS' : 'Unggah Gambar QRIS'}</span>
                <input type="file" accept="image/*" hidden onChange={handleQrisUpload} />
              </label>
            </div>

            <div className="glass-card" style={{ padding: 18, marginTop: 16 }}>
              <h3 style={{ marginTop: 0 }}>Verifikasi Otomatis Mutasi QRIS</h3>
              <p className="muted-xs" style={{ marginBottom: 10 }}>
                Tempel teks notifikasi pembayaran masuk (DANA/GoPay/M-Banking) untuk mencocokkan nominal otomatis.
              </p>
              <textarea
                className="glass-input"
                rows={2}
                placeholder="Contoh: Pembayaran QRIS diterima sebesar Rp 36.000..."
                value={mutationText}
                onChange={(e) => setMutationText(e.target.value)}
              />
              <button
                className="glass-btn secondary full-width"
                style={{ marginTop: 10 }}
                onClick={handleVerifyMutation}
              >
                Cocokkan & Verifikasi Otomatis
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Active Order Swipeable Mini-Player (Customer) */}
      {!isSeller && activeCustomerOrder && !cartOpen && (
        <div
          className="active-order-mini-bar"
          onClick={() => {
            if (activeCustomerOrder.status === 'pending_payment') {
              setQrisModalOrder(activeCustomerOrder);
            } else {
              setActiveTab('orders');
            }
          }}
        >
          <div className="row-gap">
            <span className="pulse-indicator" />
            <div>
              <div style={{ fontSize: 13, fontWeight: 700 }}>
                {ORDER_STATUS_META[activeCustomerOrder.status]?.label}
              </div>
              <div className="muted-xxs">
                {activeCustomerOrder.id} • {formatRupiah(activeCustomerOrder.total)}
              </div>
            </div>
          </div>
          <ChevronRight size={18} />
        </div>
      )}

      {/* Floating Cart Button (Customer Only — Strictly Hidden for Seller) */}
      {!isSeller && cartCount > 0 && !cartOpen && (
        <button className="floating-cart-pill" onClick={() => setCartOpen(true)}>
          <div className="row-gap">
            <ShoppingBag size={18} />
            <span>{cartCount} Item</span>
          </div>
          <strong>{formatRupiah(cartTotal)}</strong>
        </button>
      )}

      {/* Interactive Capsule Dock */}
      <nav className="capsule-dock" aria-label="Navigasi Utama">
        {tabs.map((t) => {
          const Icon = t.icon;
          const active = activeTab === t.id;
          return (
            <button
              key={t.id}
              className={`dock-item ${active ? 'active' : ''}`}
              onClick={() => setActiveTab(t.id)}
            >
              <Icon size={19} />
              <span>{t.label}</span>
              {t.id === 'orders' && pendingOrdersCount > 0 && (
                <span className="dock-badge">{pendingOrdersCount}</span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Cart Drawer Sheet */}
      {!isSeller && cartOpen && (
        <div className="glass-modal-backdrop" onClick={() => setCartOpen(false)}>
          <div className="glass-sheet" onClick={(e) => e.stopPropagation()}>
            <div className="sheet-handle" />
            <div className="row-between" style={{ marginBottom: 14 }}>
              <strong>Keranjang Pesanan ({cartCount})</strong>
              <button className="icon-pill-btn" onClick={() => setCartOpen(false)}>
                <X size={18} />
              </button>
            </div>

            <div className="stack-list" style={{ maxHeight: '42vh', overflowY: 'auto' }}>
              {cart.map((item) => (
                <div key={item.id} className="row-between cart-item-row">
                  <div className="row-gap" style={{ flex: 1, minWidth: 0 }}>
                    <img
                      src={isValidImageSrc(item.image) ? item.image : DEFAULT_MENU_IMAGE}
                      alt={item.name}
                      className="tiny-thumb"
                    />
                    <div style={{ minWidth: 0 }}>
                      <div className="item-title-clamp">{item.name}</div>
                      <div className="muted-xs">{formatRupiah(item.price)}</div>
                    </div>
                  </div>
                  <div className="row-gap">
                    <button className="qty-btn" onClick={() => updateCartQty(item.id, -1)}>
                      <Minus size={14} />
                    </button>
                    <span style={{ minWidth: 20, textAlign: 'center', fontWeight: 700 }}>{item.qty}</span>
                    <button className="qty-btn" onClick={() => updateCartQty(item.id, 1)}>
                      <Plus size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div style={{ marginTop: 14 }}>
              <input
                className="glass-input"
                placeholder="Nama pemesan (opsional)"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
              />
              <input
                className="glass-input"
                style={{ marginTop: 8 }}
                placeholder="No. Meja / Takeaway"
                value={tableNumber}
                onChange={(e) => setTableNumber(e.target.value)}
              />
              <input
                className="glass-input"
                style={{ marginTop: 8 }}
                placeholder="Catatan racikan (less sugar, extra ice...)"
                value={orderNote}
                onChange={(e) => setOrderNote(e.target.value)}
              />
            </div>

            <div className="row-between" style={{ margin: '16px 0 12px' }}>
              <span className="muted-sm">Total Pembayaran</span>
              <strong style={{ fontSize: 19 }}>{formatRupiah(cartTotal)}</strong>
            </div>

            <button className="glass-btn primary full-width" onClick={handleCheckout}>
              <QrCode size={18} />
              <span>Lanjut Bayar QRIS</span>
            </button>
          </div>
        </div>
      )}

      {/* Full-Screen QRIS Checkout Modal */}
      <QrisFullscreenModal
        order={qrisModalOrder}
        qrisImage={settings.qrisImage}
        onConfirmPaid={handleConfirmQrisPaid}
        onClose={() => setQrisModalOrder(null)}
      />

      {/* Long-Press Peek & Pop Modal */}
      <PeekPopModal
        item={peekItem}
        isSeller={isSeller}
        onAdd={addToCart}
        onClose={() => setPeekItem(null)}
      />

      {/* OTA App Update Modal */}
      <UpdateModal updateInfo={updateModalInfo} onClose={() => setUpdateModalInfo(null)} />
    </div>
  );
}
