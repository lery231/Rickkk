import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Home,
  ShoppingBag,
  Receipt,
  Search,
  User,
  Store,
  Plus,
  QrCode,
  ClipboardList,
  Coffee
} from 'lucide-react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile
} from 'firebase/auth';
import {
  collection,
  doc,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  serverTimestamp
} from 'firebase/firestore';
import { auth, db, googleProvider, isFirebaseConfigured } from './firebase.js';
import {
  APP_VERSION,
  DEFAULT_MENU_IMAGE,
  INITIAL_MENU,
  SELLER_EMAIL,
  ORDER_STATUS_META,
  formatRupiah
} from './utils/constants.js';
import { initGlobalPressEffects } from './utils/pressEffects.js';
import {
  playOrderReadyChime,
  playNewOrderSellerChime,
  playTapHaptic
} from './utils/soundEffects.js';
import { compareSemver } from './utils/versionUtils.js';
import { useSwipe } from './hooks/useSwipe.js';
import { useAndroidBackButton } from './hooks/useAndroidBackButton.js';
import { useRealtimeRecovery } from './hooks/useRealtimeRecovery.js';
import CustomerView from './components/CustomerView.jsx';
import SellerView from './components/SellerView.jsx';
import AuthModal from './components/AuthModal.jsx';
import FloatingOrderReadyBanner from './components/FloatingOrderReadyBanner.jsx';
import UpdateModal from './components/UpdateModal.jsx';

const TABS = ['home', 'cart', 'orders'];

export default function App() {
  const [theme, setTheme] = useState(() => localStorage.getItem('1001sk_theme') || 'light');
  const [activeTab, setActiveTab] = useState('home');
  const [tabDirection, setTabDirection] = useState('right');
  const [isScrolled, setIsScrolled] = useState(false);
  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState('');

  const [menuItems, setMenuItems] = useState(INITIAL_MENU);
  const [cart, setCart] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('1001sk_cart') || '[]');
    } catch {
      return [];
    }
  });
  const [orders, setOrders] = useState([]);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [readyBannerOrder, setReadyBannerOrder] = useState(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [storeName, setStoreName] = useState('1001 SK Coffee & Lounge');
  const [qrisImageUrl, setQrisImageUrl] = useState('');
  const [updateInfo, setUpdateInfo] = useState(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncTick, setSyncTick] = useState(0);
  const [notifPermission, setNotifPermission] = useState(
    typeof Notification !== 'undefined' ? Notification.permission : 'default'
  );

  const knownReadyIdsRef = useRef(new Set());
  const knownOrderIdsRef = useRef(new Set());
  const initialOrdersLoadedRef = useRef(false);

  const isSeller = userProfile?.role === 'seller';

  const switchTab = (nextTab) => {
    if (nextTab === activeTab) return;
    const prevIdx = TABS.indexOf(activeTab);
    const nextIdx = TABS.indexOf(nextTab);
    setTabDirection(nextIdx >= prevIdx ? 'right' : 'left');
    setActiveTab(nextTab);
  };

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('1001sk_theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('1001sk_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    return initGlobalPressEffects();
  }, []);

  useEffect(() => {
    const onScroll = () => {
      setIsScrolled(window.scrollY > 22);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (!isFirebaseConfigured) return;
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      setUser(fbUser);
      if (!fbUser) {
        setUserProfile(null);
        return;
      }
      const userRef = doc(db, 'users', fbUser.uid);
      const unsubProfile = onSnapshot(userRef, async (snap) => {
        if (snap.exists()) {
          setUserProfile({ id: snap.id, ...snap.data() });
        } else {
          const defaultRole =
            fbUser.email?.toLowerCase() === SELLER_EMAIL.toLowerCase() ? 'seller' : 'customer';
          const newProfile = {
            name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Pelanggan',
            email: fbUser.email || '',
            role: defaultRole
          };
          await setDoc(userRef, newProfile, { merge: true }).catch(() => {});
          setUserProfile(newProfile);
        }
      });
      return () => unsubProfile();
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!isFirebaseConfigured) return;
    const unsubMenu = onSnapshot(collection(db, 'menu'), (snap) => {
      if (!snap.empty) {
        setMenuItems(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      }
    });
    const unsubSettings = onSnapshot(doc(db, 'settings', 'store'), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        if (data.storeName) setStoreName(data.storeName);
        if (data.qrisImageUrl !== undefined) setQrisImageUrl(data.qrisImageUrl);
        if (data.latestVersion && compareSemver(data.latestVersion, APP_VERSION) > 0) {
          setUpdateInfo(data);
        }
      }
    });
    return () => {
      unsubMenu();
      unsubSettings();
    };
  }, [syncTick]);

  useEffect(() => {
    if (!isFirebaseConfigured || !user) return;
    const ordersRef = collection(db, 'orders');
    const q = isSeller
      ? query(ordersRef, orderBy('createdAt', 'desc'))
      : query(ordersRef, where('uid', '==', user.uid), orderBy('createdAt', 'desc'));

    const unsub = onSnapshot(q, (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      setOrders(list);

      if (!initialOrdersLoadedRef.current) {
        list.forEach((o) => {
          knownOrderIdsRef.current.add(o.id);
          if (o.status === 'ready') knownReadyIdsRef.current.add(o.id);
        });
        initialOrdersLoadedRef.current = true;
        return;
      }

      if (isSeller) {
        list.forEach((o) => {
          if (!knownOrderIdsRef.current.has(o.id)) {
            knownOrderIdsRef.current.add(o.id);
            playNewOrderSellerChime();
          }
        });
      } else {
        list.forEach((o) => {
          if (o.status === 'ready' && !knownReadyIdsRef.current.has(o.id)) {
            knownReadyIdsRef.current.add(o.id);
            playOrderReadyChime();
            setReadyBannerOrder(o);
          }
        });
      }
    });
    return () => unsub();
  }, [user, isSeller, syncTick]);

  useRealtimeRecovery(() => {
    setSyncTick((t) => t + 1);
  });

  useAndroidBackButton(() => {
    if (selectedOrder) {
      setSelectedOrder(null);
      return true;
    }
    if (searchOpen) {
      setSearchOpen(false);
      return true;
    }
    if (authOpen) {
      setAuthOpen(false);
      return true;
    }
    if (activeTab !== 'home') {
      switchTab('home');
      return true;
    }
    return false;
  });

  const swipeHandlers = useSwipe({
    onSwipeLeft: () => {
      const idx = TABS.indexOf(activeTab);
      if (idx < TABS.length - 1) {
        playTapHaptic();
        switchTab(TABS[idx + 1]);
      }
    },
    onSwipeRight: () => {
      const idx = TABS.indexOf(activeTab);
      if (idx > 0) {
        playTapHaptic();
        switchTab(TABS[idx - 1]);
      }
    }
  });

  const handleAddToCart = (item) => {
    if (isSeller) return;
    setCart((prev) => {
      const existing = prev.find((p) => p.id === item.id);
      if (existing) {
        return prev.map((p) => (p.id === item.id ? { ...p, qty: p.qty + 1 } : p));
      }
      return [...prev, { ...item, qty: 1 }];
    });
  };

  const handleUpdateCartQty = (id, qty) => {
    if (qty <= 0) {
      setCart((prev) => prev.filter((item) => item.id !== id));
    } else {
      setCart((prev) => prev.map((item) => (item.id === id ? { ...item, qty } : item)));
    }
  };

  const handleSubmitOrder = async (payload) => {
    if (isSeller) return null;
    const newOrderObj = {
      uid: user?.uid || 'guest_local',
      customerName: payload.customerName,
      tableNumber: payload.tableNumber,
      note: payload.note,
      items: payload.items,
      totalPrice: payload.totalPrice,
      status: 'pending_payment',
      hiddenByCustomer: false,
      createdAt: new Date().toISOString()
    };
    if (isFirebaseConfigured && user) {
      const docRef = await addDoc(collection(db, 'orders'), {
        ...newOrderObj,
        createdAt: serverTimestamp()
      });
      setCart([]);
      return { id: docRef.id, ...newOrderObj };
    }
    const localOrder = { id: 'local-' + Date.now(), ...newOrderObj };
    setOrders((prev) => [localOrder, ...prev]);
    setCart([]);
    return localOrder;
  };

  const handleHideOrderHistory = async (orderId) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, hiddenByCustomer: true } : o))
    );
    if (isFirebaseConfigured && user && !String(orderId).startsWith('local-')) {
      await updateDoc(doc(db, 'orders', orderId), { hiddenByCustomer: true }).catch(() => {});
    }
  };

  const handleClearAllOrderHistory = async () => {
    const visibleIds = orders.filter((o) => !o.hiddenByCustomer).map((o) => o.id);
    setOrders((prev) => prev.map((o) => ({ ...o, hiddenByCustomer: true })));
    if (isFirebaseConfigured && user) {
      await Promise.all(
        visibleIds
          .filter((id) => !String(id).startsWith('local-'))
          .map((id) => updateDoc(doc(db, 'orders', id), { hiddenByCustomer: true }).catch(() => {}))
      );
    }
  };

  const handleConfirmPaymentSelf = async (orderId) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: 'queued' } : o))
    );
    if (selectedOrder?.id === orderId) {
      setSelectedOrder((prev) => (prev ? { ...prev, status: 'queued' } : null));
    }
    if (isFirebaseConfigured && user && !String(orderId).startsWith('local-')) {
      await updateDoc(doc(db, 'orders', orderId), { status: 'queued' }).catch(() => {});
    }
  };

  const handleUpdateOrderStatus = async (orderId, status) => {
    setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, status } : o)));
    if (isFirebaseConfigured && !String(orderId).startsWith('local-')) {
      await updateDoc(doc(db, 'orders', orderId), { status }).catch(() => {});
    }
  };

  const handleDeleteOrder = async (orderId) => {
    setOrders((prev) => prev.filter((o) => o.id !== orderId));
    if (isFirebaseConfigured && !String(orderId).startsWith('local-')) {
      await deleteDoc(doc(db, 'orders', orderId)).catch(() => {});
    }
  };

  const handleSaveMenuItem = async (item) => {
    if (item.id) {
      setMenuItems((prev) => prev.map((m) => (m.id === item.id ? item : m)));
      if (isFirebaseConfigured) {
        await setDoc(doc(db, 'menu', item.id), item, { merge: true }).catch(() => {});
      }
    } else {
      const id = 'menu-' + Date.now();
      const created = { ...item, id };
      setMenuItems((prev) => [created, ...prev]);
      if (isFirebaseConfigured) {
        await setDoc(doc(db, 'menu', id), created).catch(() => {});
      }
    }
  };

  const handleDeleteMenuItem = async (id) => {
    setMenuItems((prev) => prev.filter((m) => m.id !== id));
    if (isFirebaseConfigured) {
      await deleteDoc(doc(db, 'menu', id)).catch(() => {});
    }
  };

  const handleSaveStoreSettings = async (settings) => {
    if (settings.storeName) setStoreName(settings.storeName);
    if (settings.qrisImageUrl !== undefined) setQrisImageUrl(settings.qrisImageUrl);
    if (isFirebaseConfigured) {
      await setDoc(doc(db, 'settings', 'store'), settings, { merge: true }).catch(() => {});
    }
  };

  const handleGoogleLogin = async () => {
    setAuthLoading(true);
    setAuthError('');
    try {
      await signInWithPopup(auth, googleProvider);
      setAuthOpen(false);
    } catch (err) {
      setAuthError(err.message || 'Gagal masuk dengan Google');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleEmailLogin = async (email, password) => {
    setAuthLoading(true);
    setAuthError('');
    try {
      await signInWithEmailAndPassword(auth, email, password);
      setAuthOpen(false);
    } catch (err) {
      setAuthError(err.message || 'Email atau kata sandi salah');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleEmailRegister = async (name, email, password) => {
    setAuthLoading(true);
    setAuthError('');
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      if (name) {
        await updateProfile(cred.user, { displayName: name });
      }
      setAuthOpen(false);
    } catch (err) {
      setAuthError(err.message || 'Gagal membuat akun baru');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = async () => {
    await signOut(auth).catch(() => {});
    setUser(null);
    setUserProfile(null);
    setActiveTab('home');
    setAuthOpen(false);
  };

  const handleManualSync = () => {
    setIsSyncing(true);
    setSyncTick((t) => t + 1);
    window.setTimeout(() => setIsSyncing(false), 750);
  };

  const handleRequestNotifPermission = async () => {
    if (typeof Notification === 'undefined') return;
    const perm = await Notification.requestPermission();
    setNotifPermission(perm);
  };

  const totalCartCount = useMemo(
    () => cart.reduce((sum, item) => sum + Number(item.qty || 1), 0),
    [cart]
  );

  const activeOrderForMiniBar = useMemo(
    () =>
      orders.find(
        (o) => !o.hiddenByCustomer && !['completed', 'cancelled'].includes(o.status)
      ) || null,
    [orders]
  );

  const headerTitle = useMemo(() => {
    if (isSeller) {
      if (activeTab === 'home') return 'Pesanan';
      if (activeTab === 'cart') return 'Kelola Menu';
      return 'Toko & QRIS';
    }
    if (activeTab === 'home') return 'Beranda';
    if (activeTab === 'cart') return 'Keranjang';
    return 'Pesanan';
  }, [activeTab, isSeller]);

  const activeTabIndex = Math.max(0, TABS.indexOf(activeTab));

  return (
    <>
      <div className="convx-ambient-backdrop" />

      <div className="app-shell" {...swipeHandlers}>
        <FloatingOrderReadyBanner
          order={readyBannerOrder}
          onOpenOrder={(o) => {
            setReadyBannerOrder(null);
            setSelectedOrder(o);
          }}
          onDismiss={() => setReadyBannerOrder(null)}
        />

        <header className={`ios-header ${isScrolled ? 'is-scrolled' : ''}`}>
          <div className="header-title-wrap">
            <h1 className="ios-large-title">{headerTitle}</h1>
          </div>
          <button
            type="button"
            className="ios-avatar-btn glass-pressable"
            onClick={() => {
              playTapHaptic();
              setAuthOpen(true);
            }}
            aria-label="Pengaturan & Akun"
          >
            {user?.photoURL ? (
              <img src={user.photoURL} alt="Profil" />
            ) : isSeller ? (
              <Store size={19} />
            ) : (
              <User size={19} />
            )}
          </button>
        </header>

        <main>
          {isSeller ? (
            <SellerView
              activeTab={activeTab}
              tabDirection={tabDirection}
              orders={orders}
              menuItems={menuItems}
              qrisImageUrl={qrisImageUrl}
              storeName={storeName}
              onUpdateOrderStatus={handleUpdateOrderStatus}
              onDeleteOrder={handleDeleteOrder}
              onSaveMenuItem={handleSaveMenuItem}
              onDeleteMenuItem={handleDeleteMenuItem}
              onSaveStoreSettings={handleSaveStoreSettings}
            />
          ) : (
            <CustomerView
              activeTab={activeTab}
              tabDirection={tabDirection}
              setActiveTab={switchTab}
              menuItems={menuItems}
              cart={cart}
              onAddToCart={handleAddToCart}
              onUpdateCartQty={handleUpdateCartQty}
              onClearCart={() => setCart([])}
              onSubmitOrder={handleSubmitOrder}
              orders={orders}
              onHideOrderHistory={handleHideOrderHistory}
              onClearAllOrderHistory={handleClearAllOrderHistory}
              onConfirmPaymentSelf={handleConfirmPaymentSelf}
              qrisImageUrl={qrisImageUrl}
              storeName={storeName}
              selectedOrder={selectedOrder}
              setSelectedOrder={setSelectedOrder}
              searchOpen={searchOpen}
              setSearchOpen={setSearchOpen}
              userProfile={userProfile}
            />
          )}
        </main>

        {/* Convx Floating MiniPlayer Pill + Morphing Liquid Lens Dock */}
        <div className="floating-bottom-stack">
          {!isSeller && (
            <div className={`floating-aux-row ${activeOrderForMiniBar ? 'has-minibar' : ''}`}>
              {activeOrderForMiniBar && (
                <div
                  className="mini-player-pill refractive-glass"
                  onClick={() => {
                    playTapHaptic();
                    setSelectedOrder(activeOrderForMiniBar);
                  }}
                >
                  <img
                    src={activeOrderForMiniBar.items?.[0]?.image || DEFAULT_MENU_IMAGE}
                    alt="Pesanan Aktif"
                    className="mini-player-thumb"
                    onError={(e) => {
                      e.currentTarget.src = DEFAULT_MENU_IMAGE;
                    }}
                  />
                  <div className="mini-player-text">
                    <div className="mini-player-title">
                      {ORDER_STATUS_META[activeOrderForMiniBar.status]?.label || 'Pesanan Aktif'}
                    </div>
                    <div className="mini-player-sub">
                      {formatRupiah(activeOrderForMiniBar.totalPrice)} • Ketuk kartu QRIS
                    </div>
                  </div>
                  <QrCode size={18} style={{ color: 'var(--accent)', position: 'relative', zIndex: 1 }} />
                </div>
              )}

              <button
                type="button"
                className="dock-aux-circle refractive-glass"
                onClick={() => {
                  playTapHaptic();
                  switchTab('cart');
                }}
                aria-label="Pesan Cepat"
              >
                <Plus size={21} style={{ position: 'relative', zIndex: 1 }} />
              </button>
            </div>
          )}

          <div className="dock-row">
            <nav className="ios-dock refractive-glass" aria-label="Navigasi Utama">
              <div
                className="dock-liquid-indicator"
                style={{ transform: `translateX(${activeTabIndex * 100}%)` }}
              />
              <button
                type="button"
                className={`dock-item ${activeTab === 'home' ? 'active' : ''}`}
                onClick={() => {
                  playTapHaptic();
                  switchTab('home');
                }}
              >
                {isSeller ? <ClipboardList size={20} /> : <Home size={20} />}
                <span>{isSeller ? 'Antrean' : 'Beranda'}</span>
              </button>
              <button
                type="button"
                className={`dock-item ${activeTab === 'cart' ? 'active' : ''}`}
                onClick={() => {
                  playTapHaptic();
                  switchTab('cart');
                }}
              >
                {isSeller ? <Coffee size={20} /> : <ShoppingBag size={20} />}
                <span>{isSeller ? 'Menu' : 'Keranjang'}</span>
                {!isSeller && totalCartCount > 0 && (
                  <span className="dock-badge">{totalCartCount}</span>
                )}
              </button>
              <button
                type="button"
                className={`dock-item ${activeTab === 'orders' ? 'active' : ''}`}
                onClick={() => {
                  playTapHaptic();
                  switchTab('orders');
                }}
              >
                {isSeller ? <QrCode size={20} /> : <Receipt size={20} />}
                <span>{isSeller ? 'QRIS' : 'Pesanan'}</span>
              </button>
            </nav>

            <button
              type="button"
              className="dock-search-btn refractive-glass"
              onClick={() => {
                playTapHaptic();
                if (isSeller) switchTab('cart');
                else setSearchOpen(true);
              }}
              aria-label="Cari Menu"
            >
              <Search size={22} style={{ position: 'relative', zIndex: 1 }} />
            </button>
          </div>
        </div>

        <AuthModal
          isOpen={authOpen}
          onClose={() => setAuthOpen(false)}
          user={user}
          userProfile={userProfile}
          theme={theme}
          onToggleTheme={() => setTheme((prev) => (prev === 'light' ? 'dark' : 'light'))}
          onGoogleLogin={handleGoogleLogin}
          onEmailLogin={handleEmailLogin}
          onEmailRegister={handleEmailRegister}
          onLogout={handleLogout}
          onManualSync={handleManualSync}
          isSyncing={isSyncing}
          notifPermission={notifPermission}
          onRequestNotifPermission={handleRequestNotifPermission}
          authLoading={authLoading}
          authError={authError}
          storeName={storeName}
          qrisImageUrl={qrisImageUrl}
          onSaveStoreSettings={handleSaveStoreSettings}
          orders={orders}
          onUpdateOrderStatus={handleUpdateOrderStatus}
        />

        <UpdateModal updateInfo={updateInfo} onClose={() => setUpdateInfo(null)} />
      </div>
    </>
  );
}
