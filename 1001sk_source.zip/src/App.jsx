import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Coffee,
  ShoppingBag,
  Clock,
  Sun,
  Moon,
  Volume2,
  VolumeX,
  RefreshCw,
  Trash2,
  CheckCircle2,
  Bell,
  LogOut,
  LogIn,
  ShieldCheck,
  Plus,
  Minus,
} from 'lucide-react';
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  serverTimestamp,
} from 'firebase/firestore';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
} from 'firebase/auth';
import { db, auth } from './firebase';
import { useRealtimeRecovery } from './hooks/useRealtimeRecovery';
import { useSwipe } from './hooks/useSwipe';
import { useAndroidBackButton } from './hooks/useAndroidBackButton';
import FloatingOrderReadyBanner from './components/FloatingOrderReadyBanner';
import UpdateModal from './components/UpdateModal';
import {
  DEFAULT_CATEGORIES,
  ORDER_STATUS_LABELS,
  isOrderReadyStatus,
} from './utils/constants';
import { generateUniquePaymentCode } from './utils/qrisAutoMatcher';
import {
  sanitizeText,
  checkLoginRateLimit,
  recordAuthResult,
} from './utils/securityGuard';
import {
  playNewOrderChime,
  playOrderReadyChime,
  playPaymentSuccessChime,
  triggerHaptic,
  sendSystemNotification,
} from './utils/soundEffects';

const INITIAL_MENU = [
  { id: 'm1', name: 'Kopi Susu 1001 SK', price: 18000, category: 'Signature' },
  { id: 'm2', name: 'Caramel Macchiato', price: 22000, category: 'Espresso' },
  { id: 'm3', name: 'Matcha Latte', price: 20000, category: 'Non-Kopi' },
  { id: 'm4', name: 'Butter Croissant', price: 16000, category: 'Camilan' },
];

const NOTIFIED_READY_STORAGE_KEY = '1001sk_notified_ready_ids_v1';

function loadNotifiedReadySet() {
  try {
    const raw = localStorage.getItem(NOTIFIED_READY_STORAGE_KEY);
    return new Set(raw ? JSON.parse(raw) : []);
  } catch {
    return new Set();
  }
}

function saveNotifiedReadySet(setObj) {
  try {
    localStorage.setItem(
      NOTIFIED_READY_STORAGE_KEY,
      JSON.stringify(Array.from(setObj).slice(-60))
    );
  } catch {}
}

export default function App() {
  const [theme, setTheme] = useState(() => localStorage.getItem('1001sk_theme') || 'dark');
  const [soundEnabled, setSoundEnabled] = useState(() => {
    try {
      const saved = localStorage.getItem('1001sk_sound');
      return saved === null ? true : saved === 'true';
    } catch {
      return true;
    }
  });
  const [activeTab, setActiveTab] = useState('menu');
  const [selectedCategory, setSelectedCategory] = useState('Semua');

  const [user, setUser] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);

  const isSeller = useMemo(() => {
    if (!user?.email) return false;
    const mail = user.email.toLowerCase();
    return mail.includes('seller') || mail.includes('admin') || mail.includes('kasir');
  }, [user]);

  const { syncGeneration, connectionState, manualSync } = useRealtimeRecovery();

  const [menuItems, setMenuItems] = useState(INITIAL_MENU);
  const [cart, setCart] = useState([]);
  const [customerName, setCustomerName] = useState('');
  const [orders, setOrders] = useState([]);
  const [submittingOrder, setSubmittingOrder] = useState(false);

  const [floatingReadyQueue, setFloatingReadyQueue] = useState([]);
  const notifiedReadyRef = useRef(loadNotifiedReadySet());
  const prevStatusMapRef = useRef({});
  const knownSellerOrderIdsRef = useRef(null);

  const [toast, setToast] = useState('');
  const [updateInfo] = useState(null);
  const [showUpdateModal, setShowUpdateModal] = useState(false);

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(''), 3200);
  };

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('1001sk_theme', theme);
  }, [theme]);

  useEffect(() => {
    try {
      localStorage.setItem('1001sk_sound', String(soundEnabled));
    } catch {}
  }, [soundEnabled]);

  useAndroidBackButton({
    onBackPress: () => {
      if (showUpdateModal) {
        setShowUpdateModal(false);
        return true;
      }
      if (floatingReadyQueue.length > 0) {
        setFloatingReadyQueue([]);
        return true;
      }
      const homeTab = isSeller ? 'seller' : 'menu';
      if (activeTab !== homeTab) {
        setActiveTab(homeTab);
        return true;
      }
      return false;
    },
  });

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthReady(true);
      if (currentUser?.displayName && !customerName) {
        setCustomerName(sanitizeText(currentUser.displayName, 40));
      }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }
    const handleSwMessage = (event) => {
      if (event.data?.type === 'OPEN_ORDER_DETAIL') {
        setActiveTab('orders');
      }
    };
    navigator.serviceWorker?.addEventListener?.('message', handleSwMessage);
    return () => navigator.serviceWorker?.removeEventListener?.('message', handleSwMessage);
  }, []);

  useEffect(() => {
    let retryTimer = null;
    const q = query(collection(db, 'menu'), orderBy('name', 'asc'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        if (!snap.empty) {
          setMenuItems(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
        }
      },
      () => {
        retryTimer = setTimeout(() => manualSync(), 4000);
      }
    );
    return () => {
      unsub();
      if (retryTimer) clearTimeout(retryTimer);
    };
  }, [syncGeneration]);

  useEffect(() => {
    let retryTimer = null;
    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        setOrders(list);

        if (isSeller) {
          const currentIds = new Set(list.map((o) => o.id));
          if (knownSellerOrderIdsRef.current !== null) {
            const hasNew = list.some((o) => !knownSellerOrderIdsRef.current.has(o.id));
            if (hasNew) {
              if (soundEnabled) playNewOrderChime();
              triggerHaptic([30, 50, 30]);
              showToast('Pesanan baru masuk!');
            }
          }
          knownSellerOrderIdsRef.current = currentIds;
        }

        const myOrders = user
          ? list.filter((o) => o.userId === user.uid || o.userEmail === user.email)
          : list;

        const newlyReady = [];
        for (const ord of myOrders) {
          const prevStatus = prevStatusMapRef.current[ord.id];
          const currReady = isOrderReadyStatus(ord.status);
          const wasReady = isOrderReadyStatus(prevStatus);

          if (currReady && !wasReady && !notifiedReadyRef.current.has(ord.id)) {
            notifiedReadyRef.current.add(ord.id);
            newlyReady.push(ord);
          }
          prevStatusMapRef.current[ord.id] = ord.status;
        }

        if (newlyReady.length > 0) {
          saveNotifiedReadySet(notifiedReadyRef.current);
          if (soundEnabled) playOrderReadyChime();
          triggerHaptic([35, 70, 35, 70, 100]);

          setFloatingReadyQueue((prev) => {
            const existingIds = new Set(prev.map((p) => p.id));
            const uniqueNew = newlyReady.filter((n) => !existingIds.has(n.id));
            return [...uniqueNew, ...prev];
          });

          const first = newlyReady[0];
          const code =
            first.orderCode || `#SK-${String(first.id || '').slice(-4).toUpperCase()}`;
          sendSystemNotification(
            `Pesanan ${code} Siap Diambil! ☕`,
            `Pesanan ${sanitizeText(first.customerName || 'Anda', 40)} sudah siap di meja pengambilan 1001 SK.`,
            { tag: `order-ready-${first.id}`, data: { orderId: first.id } }
          );
        }
      },
      () => {
        retryTimer = setTimeout(() => manualSync(), 3500);
      }
    );

    return () => {
      unsub();
      if (retryTimer) clearTimeout(retryTimer);
    };
  }, [syncGeneration, user, isSeller, soundEnabled]);

  const dismissFloatingReady = (orderId) => {
    setFloatingReadyQueue((prev) => prev.filter((o) => o.id !== orderId));
  };

  const handleOpenReadyOrder = (order) => {
    dismissFloatingReady(order.id);
    setActiveTab('orders');
  };

  const addToCart = (item) => {
    if (isSeller) {
      showToast('Akun Seller tidak dapat membuat pesanan.');
      return;
    }
    triggerHaptic(12);
    setCart((prev) => {
      const idx = prev.findIndex((c) => c.id === item.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = { ...copy[idx], qty: Math.min(50, copy[idx].qty + 1) };
        return copy;
      }
      return [...prev, { ...item, qty: 1 }];
    });
  };

  const updateCartQty = (itemId, delta) => {
    triggerHaptic(10);
    setCart((prev) =>
      prev
        .map((c) => (c.id === itemId ? { ...c, qty: Math.min(50, c.qty + delta) } : c))
        .filter((c) => c.qty > 0)
    );
  };

  const baseCartTotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  const handlePlaceOrder = async () => {
    if (isSeller) {
      showToast('Seller tidak diizinkan memesan di dalam aplikasi.');
      return;
    }
    if (cart.length === 0) return;

    setSubmittingOrder(true);
    try {
      const cleanCustomer = sanitizeText(
        customerName || user?.email?.split('@')[0] || 'Pelanggan',
        40
      );
      const uniqueCode = generateUniquePaymentCode(orders, baseCartTotal);
      const totalPrice = baseCartTotal + uniqueCode;
      const orderCode = `#SK-${Math.floor(1000 + Math.random() * 9000)}`;

      await addDoc(collection(db, 'orders'), {
        orderCode,
        userId: user?.uid || 'guest',
        userEmail: user?.email || '',
        customerName: cleanCustomer || 'Pelanggan',
        items: cart.map((c) => ({
          id: c.id,
          name: sanitizeText(c.name, 60),
          price: Number(c.price) || 0,
          qty: Number(c.qty) || 1,
        })),
        baseAmount: baseCartTotal,
        uniqueCode,
        totalPrice,
        status: 'diproses',
        paymentStatus: 'paid',
        createdAt: serverTimestamp(),
      });

      if (soundEnabled) playPaymentSuccessChime();
      triggerHaptic([20, 40, 20]);
      setCart([]);
      setActiveTab('orders');
      showToast(`Pesanan ${orderCode} berhasil dikirim!`);
    } catch {
      showToast('Gagal mengirim pesanan. Periksa koneksi.');
    } finally {
      setSubmittingOrder(false);
    }
  };

  const handleUpdateOrderStatus = async (orderId, newStatus) => {
    triggerHaptic(16);
    try {
      await updateDoc(doc(db, 'orders', orderId), {
        status: newStatus,
        updatedAt: serverTimestamp(),
      });
      showToast(`Status diubah: ${ORDER_STATUS_LABELS[newStatus] || newStatus}`);
    } catch {
      showToast('Gagal memperbarui status pesanan.');
    }
  };

  const handleDeleteOrder = async (orderId) => {
    triggerHaptic(15);
    try {
      await deleteDoc(doc(db, 'orders', orderId));
      showToast('Riwayat pesanan dihapus.');
    } catch {
      showToast('Gagal menghapus riwayat.');
    }
  };

  const handleAuthSubmit = async (e) => {
    e.preventDefault();
    const rate = checkLoginRateLimit();
    if (!rate.allowed) {
      showToast(`Terlalu banyak percobaan. Tunggu ${rate.remainingSeconds} detik.`);
      return;
    }
    const cleanEmail = sanitizeText(emailInput, 100).toLowerCase();
    if (!cleanEmail || !passwordInput) return;

    setAuthLoading(true);
    try {
      if (isRegisterMode) {
        await createUserWithEmailAndPassword(auth, cleanEmail, passwordInput);
        recordAuthResult(true);
        showToast('Akun berhasil dibuat!');
      } else {
        await signInWithEmailAndPassword(auth, cleanEmail, passwordInput);
        recordAuthResult(true);
        showToast('Berhasil masuk!');
      }
      setActiveTab(cleanEmail.includes('seller') ? 'seller' : 'menu');
    } catch (err) {
      recordAuthResult(false);
      showToast(err?.message || 'Gagal autentikasi.');
    } finally {
      setAuthLoading(false);
    }
  };

  const tabs = isSeller ? ['seller', 'menu', 'account'] : ['menu', 'orders', 'account'];
  const { stageRef, swipeHandlers } = useSwipe({
    onSwipeLeft: () => {
      const idx = tabs.indexOf(activeTab);
      if (idx >= 0 && idx < tabs.length - 1) setActiveTab(tabs[idx + 1]);
    },
    onSwipeRight: () => {
      const idx = tabs.indexOf(activeTab);
      if (idx > 0) setActiveTab(tabs[idx - 1]);
    },
  });

  const filteredMenu =
    selectedCategory === 'Semua'
      ? menuItems
      : menuItems.filter((m) => m.category === selectedCategory);

  const visibleOrders = useMemo(() => {
    if (isSeller) return orders;
    if (!user) return orders;
    return orders.filter((o) => o.userId === user.uid || o.userEmail === user.email);
  }, [orders, user, isSeller]);

  return (
    <div className="app-shell" ref={stageRef} {...swipeHandlers}>
      <div className="ambient-orb one" />
      <div className="ambient-orb two" />
      <div className="ambient-orb three" />

      <FloatingOrderReadyBanner
        readyQueue={floatingReadyQueue}
        onOpenOrder={handleOpenReadyOrder}
        onDismissOrder={dismissFloatingReady}
        theme={theme}
      />

      <header className="header-bar">
        <div>
          <h1 className="brand-title">1001 SK</h1>
          <button
            type="button"
            className="sync-pill"
            onClick={() => {
              triggerHaptic(12);
              manualSync();
              showToast('Menyegarkan koneksi realtime...');
            }}
            title="Ketuk untuk sinkronisasi instan"
          >
            <span className={`sync-dot ${connectionState}`} />
            <span>
              {connectionState === 'online'
                ? 'Live Realtime'
                : connectionState === 'reconnecting'
                ? 'Menyambungkan...'
                : 'Offline'}
            </span>
            <RefreshCw
              size={11}
              className={connectionState === 'reconnecting' ? 'spin' : ''}
            />
          </button>
        </div>

        <div style={{ display: 'flex', gap: 8 }}>
          <button
            type="button"
            className="icon-btn"
            aria-label="Suara Notifikasi"
            onClick={() => {
              triggerHaptic(12);
              setSoundEnabled((s) => {
                const next = !s;
                showToast(next ? 'Suara notifikasi aktif' : 'Suara notifikasi senyap');
                return next;
              });
            }}
          >
            {soundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
          </button>
          <button
            type="button"
            className="icon-btn"
            aria-label="Ganti Tema"
            onClick={() => {
              triggerHaptic(12);
              setTheme((t) => (t === 'dark' ? 'light' : 'dark'));
            }}
          >
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </div>
      </header>

      {activeTab === 'menu' && (
        <main>
          {isSeller && (
            <div className="glass-card" style={{ marginBottom: 14, borderColor: 'rgba(235,196,138,0.45)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, fontWeight: 700 }}>
                <ShieldCheck size={18} color="var(--accent)" />
                <span>Mode Seller Aktif — Pemesanan dinonaktifkan untuk akun Seller.</span>
              </div>
            </div>
          )}

          <div className="category-row" data-no-swipe="true">
            {['Semua', ...DEFAULT_CATEGORIES].map((cat) => (
              <button
                key={cat}
                type="button"
                className={`cat-chip ${selectedCategory === cat ? 'active' : ''}`}
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="menu-grid">
            {filteredMenu.map((item) => (
              <div key={item.id} className="menu-card">
                <div>
                  <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                    {item.category}
                  </span>
                  <h3 className="menu-name">{item.name}</h3>
                  <p className="menu-price">
                    Rp {Number(item.price).toLocaleString('id-ID')}
                  </p>
                </div>
                {!isSeller && (
                  <button
                    type="button"
                    className="btn-primary"
                    onClick={() => addToCart(item)}
                  >
                    <Plus size={15} />
                    <span>Tambah</span>
                  </button>
                )}
              </div>
            ))}
          </div>

          {!isSeller && cart.length > 0 && (
            <div className="glass-card" style={{ marginTop: 16 }}>
              <h3 style={{ margin: '0 0 10px', fontSize: 15 }}>Keranjang Pesanan</h3>
              <input
                type="text"
                className="input-field"
                placeholder="Nama Pemesan (contoh: Budi)"
                maxLength={40}
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
              />
              {cart.map((item) => (
                <div
                  key={item.id}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '6px 0',
                  }}
                >
                  <span style={{ fontSize: 13 }}>
                    {item.name} (Rp {(item.price * item.qty).toLocaleString('id-ID')})
                  </span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <button
                      type="button"
                      className="icon-btn"
                      style={{ width: 28, height: 28 }}
                      onClick={() => updateCartQty(item.id, -1)}
                    >
                      <Minus size={14} />
                    </button>
                    <span style={{ fontWeight: 700, fontSize: 13 }}>{item.qty}</span>
                    <button
                      type="button"
                      className="icon-btn"
                      style={{ width: 28, height: 28 }}
                      onClick={() => updateCartQty(item.id, 1)}
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                </div>
              ))}
              <button
                type="button"
                className="btn-primary"
                style={{ width: '100%', marginTop: 12 }}
                disabled={submittingOrder}
                onClick={handlePlaceOrder}
              >
                <ShoppingBag size={16} />
                <span>
                  {submittingOrder
                    ? 'Memproses...'
                    : `Pesan Sekarang • Rp ${baseCartTotal.toLocaleString('id-ID')}`}
                </span>
              </button>
            </div>
          )}
        </main>
      )}

      {activeTab === 'orders' && !isSeller && (
        <main>
          <h2 style={{ fontSize: 17, margin: '0 0 12px' }}>Pesanan & Riwayat</h2>
          {visibleOrders.length === 0 ? (
            <div className="glass-card" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
              Belum ada pesanan aktif.
            </div>
          ) : (
            visibleOrders.map((ord) => {
              const ready = isOrderReadyStatus(ord.status);
              return (
                <div
                  key={ord.id}
                  className="glass-card order-card"
                  style={
                    ready
                      ? {
                          borderColor: 'rgba(16, 185, 129, 0.6)',
                          boxShadow: '0 0 22px rgba(16, 185, 129, 0.22)',
                        }
                      : undefined
                  }
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <strong>{ord.orderCode || `#SK-${ord.id.slice(-4).toUpperCase()}`}</strong>
                    <span className={`status-pill ${ready ? 'ready' : ''}`}>
                      {ORDER_STATUS_LABELS[ord.status] || ord.status}
                    </span>
                  </div>
                  <p style={{ margin: '6px 0', fontSize: 13 }}>
                    Pemesan: <strong>{ord.customerName}</strong>
                  </p>
                  <p style={{ margin: '0 0 10px', fontSize: 12.5, color: 'var(--text-muted)' }}>
                    {(ord.items || []).map((i) => `${i.qty}x ${i.name}`).join(', ')}
                  </p>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <strong>Rp {Number(ord.totalPrice || 0).toLocaleString('id-ID')}</strong>
                    <button
                      type="button"
                      className="btn-secondary"
                      onClick={() => handleDeleteOrder(ord.id)}
                      title="Hapus riwayat pesanan"
                    >
                      <Trash2 size={14} />
                      <span>Hapus</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </main>
      )}

      {activeTab === 'seller' && isSeller && (
        <main>
          <h2 style={{ fontSize: 17, margin: '0 0 12px' }}>Antrean Pesanan Masuk</h2>
          {orders.length === 0 ? (
            <div className="glass-card" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
              Belum ada pesanan masuk.
            </div>
          ) : (
            orders.map((ord) => {
              const ready = isOrderReadyStatus(ord.status);
              return (
                <div key={ord.id} className="glass-card order-card">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <strong>
                      {ord.orderCode || `#SK-${ord.id.slice(-4).toUpperCase()}`} • {ord.customerName}
                    </strong>
                    <span className={`status-pill ${ready ? 'ready' : ''}`}>
                      {ORDER_STATUS_LABELS[ord.status] || ord.status}
                    </span>
                  </div>
                  <p style={{ margin: '8px 0', fontSize: 13 }}>
                    {(ord.items || []).map((i) => `${i.qty}x ${i.name}`).join(', ')}
                  </p>
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
                    {!ready && ord.status !== 'selesai' && (
                      <button
                        type="button"
                        className="btn-ready"
                        onClick={() => handleUpdateOrderStatus(ord.id, 'siap_diambil')}
                      >
                        <Bell size={14} />
                        <span>Siap Diambil (Kirim Notif)</span>
                      </button>
                    )}
                    {ord.status !== 'selesai' && (
                      <button
                        type="button"
                        className="btn-secondary"
                        onClick={() => handleUpdateOrderStatus(ord.id, 'selesai')}
                      >
                        <CheckCircle2 size={14} />
                        <span>Selesai</span>
                      </button>
                    )}
                    <button
                      type="button"
                      className="btn-secondary"
                      onClick={() => handleDeleteOrder(ord.id)}
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </main>
      )}

      {activeTab === 'account' && (
        <main>
          <div className="glass-card">
            <h2 style={{ margin: '0 0 10px', fontSize: 17 }}>Akun & Keamanan</h2>
            {!authReady ? (
              <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>Memuat sesi tersimpan...</p>
            ) : user ? (
              <div>
                <p style={{ fontSize: 13.5, margin: '0 0 6px' }}>
                  Masuk sebagai: <strong>{user.email}</strong>
                </p>
                <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '0 0 14px' }}>
                  Peran: {isSeller ? 'Seller / Barista' : 'Pelanggan'} • Sesi terenkripsi v2.7.0
                </p>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => signOut(auth)}
                >
                  <LogOut size={15} />
                  <span>Keluar Akun</span>
                </button>
              </div>
            ) : (
              <form onSubmit={handleAuthSubmit}>
                <input
                  type="email"
                  className="input-field"
                  placeholder="Email (gunakan kata 'seller' untuk kasir)"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  required
                />
                <input
                  type="password"
                  className="input-field"
                  placeholder="Kata Sandi"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  required
                />
                <button
                  type="submit"
                  className="btn-primary"
                  style={{ width: '100%' }}
                  disabled={authLoading}
                >
                  <LogIn size={15} />
                  <span>
                    {authLoading
                      ? 'Memproses...'
                      : isRegisterMode
                      ? 'Daftar Akun Baru'
                      : 'Masuk'}
                  </span>
                </button>
                <button
                  type="button"
                  className="btn-secondary"
                  style={{ width: '100%', marginTop: 8 }}
                  onClick={() => setIsRegisterMode((m) => !m)}
                >
                  {isRegisterMode ? 'Sudah punya akun? Masuk' : 'Belum punya akun? Daftar'}
                </button>
              </form>
            )}
          </div>
        </main>
      )}

      <nav className="bottom-nav">
        {isSeller && (
          <button
            type="button"
            className={`nav-item ${activeTab === 'seller' ? 'active' : ''}`}
            onClick={() => setActiveTab('seller')}
          >
            <Bell size={18} />
            <span>Antrean</span>
          </button>
        )}
        <button
          type="button"
          className={`nav-item ${activeTab === 'menu' ? 'active' : ''}`}
          onClick={() => setActiveTab('menu')}
        >
          <Coffee size={18} />
          <span>Menu</span>
        </button>
        {!isSeller && (
          <button
            type="button"
            className={`nav-item ${activeTab === 'orders' ? 'active' : ''}`}
            onClick={() => setActiveTab('orders')}
          >
            <Clock size={18} />
            <span>Pesanan</span>
          </button>
        )}
        <button
          type="button"
          className={`nav-item ${activeTab === 'account' ? 'active' : ''}`}
          onClick={() => setActiveTab('account')}
        >
          <ShieldCheck size={18} />
          <span>Akun</span>
        </button>
      </nav>

      {toast && <div className="toast-banner">{toast}</div>}

      <UpdateModal
        isOpen={showUpdateModal}
        onClose={() => setShowUpdateModal(false)}
        updateInfo={updateInfo}
        showToast={showToast}
      />
    </div>
  );
}
