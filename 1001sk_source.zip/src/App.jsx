import React, { useState, useEffect, useRef, useCallback } from 'react';
import { auth, db } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';
import {
  doc,
  getDoc,
  collection,
  onSnapshot,
  query,
  orderBy,
  where,
  updateDoc,
} from 'firebase/firestore';
import CustomerView from './components/CustomerView';
import SellerView from './components/SellerView';
import AuthModal from './components/AuthModal';
import UpdateModal from './components/UpdateModal';
import FloatingOrderReadyBanner from './components/FloatingOrderReadyBanner';
import { useSwipe } from './hooks/useSwipe';
import { useRealtimeRecovery } from './hooks/useRealtimeRecovery';
import { useAndroidBackButton } from './hooks/useAndroidBackButton';
import { CURRENT_APP_VERSION, compareVersions } from './utils/versionUtils';
import { extractAmountFromNotification } from './utils/qrisAutoMatcher';
import { isOrderReadyStatus, FALLBACK_COFFEE_IMG } from './utils/constants';
import {
  playNewOrderChime,
  playOrderReadyChime,
  playPaymentSuccessChime,
  triggerHaptic,
  sendSystemNotification,
} from './utils/soundEffects';
import {
  Home,
  Receipt,
  LayoutDashboard,
  User,
  Store,
  Search,
  QrCode,
  ShoppingBag,
  RefreshCw,
  ChevronRight,
  X,
} from 'lucide-react';

const CUSTOMER_TABS = ['menu', 'cart', 'orders'];
const SELLER_TABS = ['orders', 'menu', 'qris', 'update'];

function App() {
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState('customer');
  const [activeTab, setActiveTab] = useState('menu');
  const [sellerSubTab, setSellerSubTab] = useState('orders');
  const [swipeDir, setSwipeDir] = useState('none');
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [toastMsg, setToastMsg] = useState('');
  const [readyAlerts, setReadyAlerts] = useState([]);
  const [authReady, setAuthReady] = useState(false);
  const [storeOpen, setStoreOpen] = useState(true);

  const { syncGeneration, connectionState, manualSync } = useRealtimeRecovery();
  const [updateInfo, setUpdateInfo] = useState(null);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const hasAutoPromptedUpdate = useRef(false);

  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem('1001sk_theme') || 'light';
    } catch {
      return 'light';
    }
  });

  const [soundEnabled, setSoundEnabled] = useState(() => {
    try {
      const saved = localStorage.getItem('1001sk_sound');
      return saved === null ? true : saved === 'true';
    } catch {
      return true;
    }
  });

  const searchInputRef = useRef(null);
  const isInitialOrdersLoad = useRef(true);
  const prevOrderStatusMap = useRef({});
  const soundEnabledRef = useRef(soundEnabled);
  const userRoleRef = useRef(userRole);
  const ordersRef = useRef(orders);

  useEffect(() => {
    ordersRef.current = orders;
  }, [orders]);

  useEffect(() => {
    soundEnabledRef.current = soundEnabled;
    try {
      localStorage.setItem('1001sk_sound', String(soundEnabled));
    } catch {}
  }, [soundEnabled]);

  useEffect(() => {
    userRoleRef.current = userRole;
    if (userRole === 'seller') {
      setCart([]);
      setActiveTab('seller');
    } else if (activeTab === 'seller') {
      setActiveTab('menu');
    }
  }, [userRole]);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) {
      metaTheme.setAttribute('content', theme === 'dark' ? '#0d0d0f' : '#ffffff');
    }
    try {
      localStorage.setItem('1001sk_theme', theme);
    } catch {}
  }, [theme]);

  useAndroidBackButton({
    onBackPress: () => {
      if (isSearchOpen) {
        setIsSearchOpen(false);
        setSearchQuery('');
        return true;
      }
      if (isUpdateModalOpen && !updateInfo?.forceUpdate) {
        setIsUpdateModalOpen(false);
        return true;
      }
      if (isAuthOpen && user) {
        setIsAuthOpen(false);
        return true;
      }
      if (readyAlerts.length > 0) {
        setReadyAlerts([]);
        return true;
      }
      if (userRole === 'seller') {
        if (sellerSubTab !== 'orders') {
          setSwipeDir('right');
          setSellerSubTab('orders');
          return true;
        }
        return false;
      }
      if (activeTab !== 'menu') {
        setSwipeDir('right');
        setActiveTab('menu');
        return true;
      }
      return false;
    },
  });

  const showToast = useCallback((msg) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? '' : prev));
    }, 3200);
  }, []);

  useEffect(() => {
    if (!('serviceWorker' in navigator)) return;
    const onSwMessage = (event) => {
      if (event.data?.type === 'OPEN_ORDER_DETAIL' && userRoleRef.current !== 'seller') {
        setActiveTab('orders');
      }
    };
    navigator.serviceWorker.addEventListener('message', onSwMessage);
    return () => navigator.serviceWorker.removeEventListener('message', onSwMessage);
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setAuthReady(true);
      if (currentUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists() && userDoc.data().role === 'seller') {
            setUserRole('seller');
            setCart([]);
            setActiveTab('seller');
          } else {
            setUserRole('customer');
          }
        } catch (e) {
          console.error(e);
        }
      } else {
        setUserRole('customer');
      }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    const unsubUpdate = onSnapshot(
      doc(db, 'settings', 'app_info'),
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (data.latestVersion && compareVersions(data.latestVersion, CURRENT_APP_VERSION) > 0) {
            setUpdateInfo(data);
            if (!hasAutoPromptedUpdate.current) {
              hasAutoPromptedUpdate.current = true;
              setIsUpdateModalOpen(true);
            }
          } else {
            setUpdateInfo(null);
          }
        }
      },
      () => {}
    );
    return () => unsubUpdate();
  }, [syncGeneration]);

  useEffect(() => {
    isInitialOrdersLoad.current = true;
    prevOrderStatusMap.current = {};

    if (!user) {
      setOrders([]);
      return;
    }
    const isSeller = userRole === 'seller';
    const q = isSeller
      ? query(collection(db, 'orders'), orderBy('createdAt', 'desc'))
      : query(collection(db, 'orders'), where('uid', '==', user.uid));

    const unsub = onSnapshot(
      q,
      (snap) => {
        let list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        if (!isSeller) {
          list = list
            .filter((o) => !o.hiddenByCustomer)
            .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
        }
        setOrders(list);

        if (isInitialOrdersLoad.current) {
          const initMap = {};
          list.forEach((o) => {
            initMap[o.id] = o.status;
          });
          prevOrderStatusMap.current = initMap;
          isInitialOrdersLoad.current = false;
          return;
        }

        const prevMap = prevOrderStatusMap.current;
        const nextMap = {};

        list.forEach((ord) => {
          nextMap[ord.id] = ord.status;
          const oldStatus = prevMap[ord.id];

          if ((!oldStatus || oldStatus === 'menunggu_pembayaran') && ord.status === 'pending' && isSeller) {
            if (soundEnabledRef.current) playNewOrderChime();
            triggerHaptic([30, 50, 30]);
            const qrisTag = ord.paymentMethod === 'QRIS' ? ' (QRIS Lunas)' : '';
            showToast(`Pesanan baru dari ${ord.customerName}${qrisTag}!`);
            sendSystemNotification(
              `Pesanan Baru Masuk${qrisTag} - 1001 SK`,
              `${ord.customerName} memesan Rp ${ord.totalPrice?.toLocaleString('id-ID')}`,
              { tag: `order-new-${ord.id}`, data: { orderId: ord.id } }
            );
          }

          if (oldStatus === 'menunggu_pembayaran' && ord.status === 'pending' && !isSeller) {
            if (soundEnabledRef.current) playPaymentSuccessChime();
            triggerHaptic([25, 45, 25]);
            showToast('Pembayaran QRIS lunas otomatis! Pesanan diteruskan ke kasir.');
          }

          if (oldStatus && !isOrderReadyStatus(oldStatus) && isOrderReadyStatus(ord.status) && !isSeller) {
            if (soundEnabledRef.current) playOrderReadyChime();
            triggerHaptic([60, 40, 80]);
            setReadyAlerts((prev) => [ord, ...prev.filter((item) => item.id !== ord.id)]);
            sendSystemNotification(
              'Pesanan Siap Diambil - 1001 SK',
              `Pesanan atas nama ${ord.customerName} sudah siap!`,
              { tag: `order-ready-${ord.id}`, data: { orderId: ord.id } }
            );
          }
        });

        prevOrderStatusMap.current = nextMap;
      },
      (err) => console.error(err)
    );
    return () => unsub();
  }, [user, userRole, showToast, syncGeneration]);

  // Automatic QRIS Webhook Watcher on Seller Device
  useEffect(() => {
    if (!user || userRole !== 'seller') return;

    const qPayments = query(collection(db, 'qris_payments'), where('matched', '==', false));
    const unsubPayments = onSnapshot(
      qPayments,
      async (snap) => {
        if (snap.empty) return;
        const now = Date.now();
        for (const payDoc of snap.docs) {
          const payData = payDoc.data();
          const detectedAmount = extractAmountFromNotification(payData.amount || payData.rawText);
          if (!detectedAmount) continue;

          const matchingOrder = ordersRef.current.find((ord) => {
            if (ord.status !== 'menunggu_pembayaran' || ord.paymentStatus === 'paid') return false;
            if (Number(ord.totalPrice) !== detectedAmount) return false;
            if (ord.paymentExpiresAt && new Date(ord.paymentExpiresAt).getTime() < now) return false;
            return true;
          });

          if (matchingOrder) {
            try {
              await updateDoc(doc(db, 'orders', matchingOrder.id), {
                status: 'pending',
                paymentStatus: 'paid',
                paidAt: new Date().toISOString(),
                paymentProofText: String(
                  payData.rawText || `QRIS Rp ${detectedAmount.toLocaleString('id-ID')}`
                ),
              });
              await updateDoc(doc(db, 'qris_payments', payDoc.id), {
                matched: true,
                matchedOrderId: matchingOrder.id,
                matchedAmount: detectedAmount,
                matchedAt: new Date().toISOString(),
              });
            } catch (err) {
              console.error('Gagal mencocokkan QRIS otomatis:', err);
            }
          }
        }
      },
      () => {}
    );

    return () => unsubPayments();
  }, [user, userRole, syncGeneration]);

  useEffect(() => {
    if (!user) return;
    return onSnapshot(
      doc(db, 'settings', 'store'),
      (s) => setStoreOpen(!s.exists() || s.data().open !== false),
      () => {}
    );
  }, [user, syncGeneration]);

  const moveTab = useCallback(
    (dir) => {
      triggerHaptic(10);
      if (userRole === 'seller') {
        const i = SELLER_TABS.indexOf(sellerSubTab) + dir;
        if (i >= 0 && i < SELLER_TABS.length) {
          setSwipeDir(dir > 0 ? 'left' : 'right');
          setSellerSubTab(SELLER_TABS[i]);
        }
      } else {
        const i = CUSTOMER_TABS.indexOf(activeTab) + dir;
        if (i >= 0 && i < CUSTOMER_TABS.length) {
          setSwipeDir(dir > 0 ? 'left' : 'right');
          setActiveTab(CUSTOMER_TABS[i]);
        }
      }
    },
    [userRole, sellerSubTab, activeTab]
  );

  const handlePullRefresh = useCallback(async () => {
    triggerHaptic([14, 28]);
    await manualSync();
    showToast('Data menu & pesanan diperbarui');
  }, [manualSync, showToast]);

  const { stageRef, pullDistance, isRefreshing, swipeHandlers } = useSwipe({
    onSwipeLeft: () => moveTab(1),
    onSwipeRight: () => moveTab(-1),
    onPullRefresh: handlePullRefresh,
  });

  const selectCustomerTab = (nextTab) => {
    triggerHaptic(10);
    const curIdx = CUSTOMER_TABS.indexOf(activeTab);
    const nextIdx = CUSTOMER_TABS.indexOf(nextTab);
    setSwipeDir(nextIdx >= curIdx ? 'left' : 'right');
    setActiveTab(nextTab);
  };

  const selectSellerTab = (nextTab) => {
    triggerHaptic(10);
    const curIdx = SELLER_TABS.indexOf(sellerSubTab);
    const nextIdx = SELLER_TABS.indexOf(nextTab);
    setSwipeDir(nextIdx >= curIdx ? 'left' : 'right');
    setSellerSubTab(nextTab);
  };

  const toggleTheme = () => {
    triggerHaptic(12);
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const toggleSound = () => {
    triggerHaptic(12);
    setSoundEnabled((prev) => {
      const next = !prev;
      if (next) {
        playNewOrderChime();
        showToast('Nada notifikasi pesanan diaktifkan');
      } else {
        showToast('Nada notifikasi dimatikan');
      }
      return next;
    });
  };

  const handleManualCheckUpdate = () => {
    triggerHaptic(12);
    if (updateInfo) {
      setIsUpdateModalOpen(true);
    } else {
      showToast(`Aplikasi 1001 SK sudah versi terbaru (v${CURRENT_APP_VERSION})`);
    }
  };

  const handleCircleAction = () => {
    triggerHaptic(12);
    if (userRole === 'seller') {
      selectSellerTab(sellerSubTab === 'qris' ? 'orders' : 'qris');
    } else {
      setIsSearchOpen((prev) => {
        const next = !prev;
        if (next) {
          setActiveTab('menu');
          setTimeout(() => {
            searchInputRef.current?.focus();
          }, 90);
        } else {
          setSearchQuery('');
        }
        return next;
      });
    }
  };

  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const pendingCount = orders.filter((o) => o.status === 'pending').length;
  const activeOrder = orders.find((o) =>
    ['menunggu_pembayaran', 'pending', 'diproses', 'siap', 'siap_diambil'].includes(o.status)
  );

  const headerTitle =
    userRole === 'seller'
      ? 'Kasir 1001 SK'
      : activeTab === 'menu'
      ? 'Beranda'
      : activeTab === 'cart'
      ? 'Keranjang'
      : 'Pesanan';

  if (!authReady) {
    return (
      <div
        className="app-wrapper"
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          minHeight: '100vh',
        }}
      >
        <div style={{ textAlign: 'center', color: 'var(--text-sub)', fontSize: 13.5, fontWeight: 600 }}>
          Memuat 1001 SK...
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="app-wrapper">
        {toastMsg && (
          <div className="ios-toast">
            <span>{toastMsg}</span>
          </div>
        )}
        <AuthModal
          isOpen={true}
          forced={true}
          onClose={() => {}}
          user={null}
          userRole="customer"
          setUserRole={setUserRole}
          showToast={showToast}
          hasUpdate={Boolean(updateInfo)}
          onCheckUpdate={handleManualCheckUpdate}
          theme={theme}
          onToggleTheme={toggleTheme}
          soundEnabled={soundEnabled}
          onToggleSound={toggleSound}
          connectionState={connectionState}
          onManualSync={manualSync}
        />
        <UpdateModal
          isOpen={isUpdateModalOpen}
          onClose={() => setIsUpdateModalOpen(false)}
          updateInfo={updateInfo}
          showToast={showToast}
        />
      </div>
    );
  }

  return (
    <div className="app-wrapper">
      {toastMsg && (
        <div className="ios-toast">
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Pull-to-Refresh Floating Pill (Swipe Bawah di Atas Layar) */}
      {(pullDistance > 16 || isRefreshing) && (
        <div
          className="pull-refresh-indicator"
          style={{
            opacity: isRefreshing ? 1 : Math.min(1, pullDistance / 55),
            transform: `translate3d(-50%, ${isRefreshing ? 0 : Math.min(16, (pullDistance - 16) * 0.25)}px, 0) scale(${
              isRefreshing ? 1 : Math.min(1, 0.88 + pullDistance / 400)
            })`,
          }}
        >
          <RefreshCw
            size={14}
            color="var(--accent-primary)"
            className={isRefreshing ? 'spin-slow' : ''}
            style={
              !isRefreshing
                ? { transform: `rotate(${Math.round(pullDistance * 3.2)}deg)` }
                : undefined
            }
          />
          <span>
            {isRefreshing
              ? 'Menyegarkan...'
              : pullDistance >= 74
              ? 'Lepas untuk sinkronisasi'
              : 'Tarik ke bawah untuk refresh'}
          </span>
        </div>
      )}

      {userRole !== 'seller' && (
        <FloatingOrderReadyBanner
          readyOrders={readyAlerts}
          onDismiss={(id) => setReadyAlerts((prev) => prev.filter((item) => item.id !== id))}
          onOpenOrders={() => selectCustomerTab('orders')}
        />
      )}

      {/* Sticky Frosted Glass Header ("Beranda" + Circular Avatar Button) */}
      <header className="ios-header">
        <div>
          <div className="brand-row">
            <h1 className="brand-title">{headerTitle}</h1>
            <button
              type="button"
              className={`conn-pill ${connectionState}`}
              onClick={() => {
                triggerHaptic(10);
                manualSync();
                showToast('Menyegarkan koneksi realtime...');
              }}
              title="Ketuk untuk sinkronisasi ulang"
            >
              {connectionState === 'reconnecting' ? (
                <RefreshCw size={10} className="spin-slow" />
              ) : (
                <span className="conn-dot" />
              )}
              <span>
                {connectionState === 'online'
                  ? 'Live'
                  : connectionState === 'reconnecting'
                  ? 'Sync'
                  : 'Offline'}
              </span>
            </button>
          </div>
          <div className="brand-sub">
            {userRole === 'seller'
              ? `1001 SK Coffee & Lounge • v${CURRENT_APP_VERSION}`
              : `1001 SK Coffee & Lounge • v${CURRENT_APP_VERSION}`}
          </div>
        </div>

        <div className="header-actions">
          <button
            type="button"
            className="avatar-glass-btn"
            onClick={() => {
              triggerHaptic(12);
              setIsAuthOpen(true);
            }}
            aria-label="Pengaturan & Akun"
            title="Pengaturan & Akun"
          >
            {userRole === 'seller' ? (
              <Store size={19} color="var(--accent-primary)" />
            ) : (
              <User size={20} />
            )}
            {updateInfo && <span className="avatar-update-dot" />}
          </button>
        </div>
      </header>

      {/* Swipeable Main Content (Kanan/Kiri & Bawah/Atas) */}
      <main ref={stageRef} className="swipe-stage" {...swipeHandlers}>
        {userRole === 'seller' ? (
          <SellerView
            key={`seller-${sellerSubTab}`}
            swipeDir={swipeDir}
            orders={orders}
            sellerSubTab={sellerSubTab}
            setSellerSubTab={selectSellerTab}
            showToast={showToast}
            storeOpen={storeOpen}
          />
        ) : (
          <CustomerView
            key={`cust-${activeTab}`}
            swipeDir={swipeDir}
            cart={cart}
            setCart={setCart}
            activeTab={activeTab}
            user={user}
            userRole={userRole}
            orders={orders}
            showToast={showToast}
            setActiveTab={selectCustomerTab}
            storeOpen={storeOpen}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
          />
        )}
      </main>

      {/* Floating Search Pill Overlay */}
      {userRole !== 'seller' && isSearchOpen && (
        <div className="floating-search-overlay">
          <Search size={17} color="var(--text-sub)" />
          <input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari kopi favorit, matcha, camilan..."
          />
          <button
            type="button"
            onClick={() => {
              if (searchQuery) {
                setSearchQuery('');
              } else {
                setIsSearchOpen(false);
              }
            }}
            style={{
              background: 'none',
              border: 'none',
              color: 'var(--text-sub)',
              display: 'flex',
              cursor: 'pointer',
            }}
          >
            <X size={17} />
          </button>
        </div>
      )}

      {/* Floating Liquid Glass Mini-Bar above Dock */}
      {userRole !== 'seller' && !isSearchOpen && activeTab === 'menu' && (cartCount > 0 || activeOrder) && (
        <div
          className="floating-mini-bar"
          onClick={() => {
            triggerHaptic(12);
            selectCustomerTab(cartCount > 0 ? 'cart' : 'orders');
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
            <img
              src={cartCount > 0 ? cart[0]?.img || FALLBACK_COFFEE_IMG : FALLBACK_COFFEE_IMG}
              alt="1001 SK"
              className="mini-bar-thumb"
              onError={(e) => {
                e.currentTarget.onerror = null;
                e.currentTarget.src = FALLBACK_COFFEE_IMG;
              }}
            />
            <div style={{ minWidth: 0 }}>
              <div
                style={{
                  fontSize: 13.5,
                  fontWeight: 700,
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                }}
              >
                {cartCount > 0
                  ? `${cartCount} Item di Keranjang`
                  : `Pesanan ${activeOrder.customerName}`}
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>
                {cartCount > 0
                  ? `Rp ${cartTotal.toLocaleString('id-ID')} • Ketuk untuk bayar`
                  : activeOrder.status === 'menunggu_pembayaran'
                  ? 'Menunggu transfer QRIS otomatis'
                  : 'Sedang diproses barista'}
              </div>
            </div>
          </div>
          <ChevronRight size={18} color="var(--text-sub)" />
        </div>
      )}

      {/* iOS 26 Liquid Glass Bottom Capsule Dock + Circular Search/Action Button */}
      <div className="floating-nav-wrapper">
        <nav className="ios-dock" aria-label="Navigasi Utama">
          {userRole === 'seller' ? (
            <>
              <button
                type="button"
                className={`dock-item ${sellerSubTab === 'orders' ? 'active' : ''}`}
                onClick={() => selectSellerTab('orders')}
              >
                <Receipt size={19} />
                <span>Pesanan</span>
                {pendingCount > 0 && <span className="dock-badge">{pendingCount}</span>}
              </button>

              <button
                type="button"
                className={`dock-item ${sellerSubTab === 'menu' ? 'active' : ''}`}
                onClick={() => selectSellerTab('menu')}
              >
                <LayoutDashboard size={19} />
                <span>Menu</span>
              </button>

              <button
                type="button"
                className={`dock-item ${sellerSubTab === 'update' ? 'active' : ''}`}
                onClick={() => selectSellerTab('update')}
              >
                <QrCode size={19} />
                <span>Update</span>
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                className={`dock-item ${activeTab === 'menu' ? 'active' : ''}`}
                onClick={() => selectCustomerTab('menu')}
              >
                <Home size={19} />
                <span>Beranda</span>
              </button>

              <button
                type="button"
                className={`dock-item ${activeTab === 'cart' ? 'active' : ''}`}
                onClick={() => selectCustomerTab('cart')}
              >
                <ShoppingBag size={19} />
                <span>Keranjang</span>
                {cartCount > 0 && <span className="dock-badge">{cartCount}</span>}
              </button>

              <button
                type="button"
                className={`dock-item ${activeTab === 'orders' ? 'active' : ''}`}
                onClick={() => selectCustomerTab('orders')}
              >
                <Receipt size={19} />
                <span>Pesanan</span>
              </button>
            </>
          )}
        </nav>

        <button
          type="button"
          className={`dock-circle-btn ${isSearchOpen ? 'active-search' : ''}`}
          onClick={handleCircleAction}
          aria-label={userRole === 'seller' ? 'QRIS Toko' : 'Cari Menu'}
          title={userRole === 'seller' ? 'Pengaturan QRIS' : 'Cari Menu'}
        >
          {userRole === 'seller' ? <QrCode size={22} /> : <Search size={22} />}
        </button>
      </div>

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        user={user}
        userRole={userRole}
        setUserRole={setUserRole}
        showToast={showToast}
        hasUpdate={Boolean(updateInfo)}
        onCheckUpdate={handleManualCheckUpdate}
        theme={theme}
        onToggleTheme={toggleTheme}
        soundEnabled={soundEnabled}
        onToggleSound={toggleSound}
        connectionState={connectionState}
        onManualSync={manualSync}
      />

      <UpdateModal
        isOpen={isUpdateModalOpen}
        onClose={() => setIsUpdateModalOpen(false)}
        updateInfo={updateInfo}
        showToast={showToast}
      />
    </div>
  );
}

export default App;
