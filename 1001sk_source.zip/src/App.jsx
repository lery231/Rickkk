import React, { useState, useEffect, useRef } from 'react';
import { Settings, Coffee, Sparkles } from 'lucide-react';
import { APP_VERSION } from './utils/constants.js';
import {
  subscribeAuth,
  loginWithEmail,
  registerWithEmail,
  loginWithGoogle,
  logoutAccount,
  subscribeMenu,
  saveMenuItem,
  deleteMenuItem,
  subscribeOrders,
  createOrder,
  updateOrderStatus,
  deleteOrderById,
  subscribeStoreSettings,
  saveStoreSettings
} from './services/firebaseService.js';
import { playOrderReadyChime, playNewOrderAlert, playTapHaptic } from './utils/soundEffects.js';
import LiquidGlassTabBar from './components/LiquidGlassTabBar.jsx';
import AuthModal from './components/AuthModal.jsx';
import SellerView from './components/SellerView.jsx';
import CustomerHome from './components/CustomerHome.jsx';
import CartSheet from './components/CartSheet.jsx';
import QrisPaymentModal from './components/QrisPaymentModal.jsx';
import OrdersView from './components/OrdersView.jsx';

export default function App() {
  const [theme, setTheme] = useState(() => localStorage.getItem('1001sk_theme') || 'dark');
  const [activeTab, setActiveTab] = useState('home');
  const [settingsOpen, setSettingsOpen] = useState(false);

  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState('');

  const [menuItems, setMenuItems] = useState([]);
  const [orders, setOrders] = useState([]);
  const [storeSettings, setStoreSettings] = useState({
    storeName: '1001 SK Coffee & Lounge',
    qrisImageUrl: ''
  });

  const [cart, setCart] = useState([]);
  const [activeQrisOrder, setActiveQrisOrder] = useState(null);
  const [toastMsg, setToastMsg] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);
  const [notifPermission, setNotifPermission] = useState(() =>
    typeof Notification !== 'undefined' ? Notification.permission : 'default'
  );

  const prevOrdersRef = useRef([]);
  const isSeller = userProfile?.role === 'seller';

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('1001sk_theme', theme);
  }, [theme]);

  useEffect(() => {
    const unsubAuth = subscribeAuth((u, profile) => {
      setUser(u);
      setUserProfile(profile);
    });
    const unsubMenu = subscribeMenu((items) => setMenuItems(items));
    const unsubOrders = subscribeOrders((nextOrders) => {
      const prev = prevOrdersRef.current;
      if (prev.length > 0) {
        // Deteksi pesanan siap diambil (untuk pelanggan)
        const newlyReady = nextOrders.find((o) => {
          const old = prev.find((p) => p.id === o.id);
          return old && old.status !== 'ready' && o.status === 'ready';
        });
        if (newlyReady) {
          playOrderReadyChime();
          showToast(`Pesanan #${newlyReady.id} sudah siap diambil!`);
          sendDeviceNotif('1001 SK Coffee', `Pesanan #${newlyReady.id} sudah siap diambil!`);
        }

        // Deteksi pesanan baru masuk (untuk penjual)
        if (nextOrders.length > prev.length) {
          playNewOrderAlert();
        }
      }
      prevOrdersRef.current = nextOrders;
      setOrders(nextOrders);
    });
    const unsubSettings = subscribeStoreSettings((s) => setStoreSettings(s));

    return () => {
      unsubAuth();
      unsubMenu();
      unsubOrders();
      unsubSettings();
    };
  }, []);

  const showToast = (msg) => {
    setToastMsg(msg);
    window.setTimeout(() => setToastMsg(''), 3000);
  };

  const sendDeviceNotif = (title, body) => {
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
      try {
        new Notification(title, { body });
      } catch {
        // ignore mobile webview restriction
      }
    }
  };

  const handleRequestNotifPermission = async () => {
    if (typeof Notification === 'undefined') {
      showToast('Notifikasi browser tidak didukung di perangkat ini');
      return;
    }
    const perm = await Notification.requestPermission();
    setNotifPermission(perm);
    showToast(perm === 'granted' ? 'Notifikasi diaktifkan' : 'Izin notifikasi ditolak');
  };

  const handleToggleTheme = () => {
    playTapHaptic();
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const handleEmailLogin = async (email, password) => {
    setAuthLoading(true);
    setAuthError('');
    try {
      await loginWithEmail(email, password);
      setSettingsOpen(false);
      showToast('Berhasil masuk akun');
    } catch (err) {
      setAuthError(err.message);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleEmailRegister = async (name, email, password) => {
    setAuthLoading(true);
    setAuthError('');
    try {
      await registerWithEmail(name, email, password);
      setSettingsOpen(false);
      showToast('Akun baru berhasil dibuat');
    } catch (err) {
      setAuthError(err.message);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setAuthLoading(true);
    setAuthError('');
    try {
      await loginWithGoogle();
      setSettingsOpen(false);
      showToast('Berhasil masuk dengan Google');
    } catch (err) {
      setAuthError(err.message);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = async () => {
    await logoutAccount();
    setSettingsOpen(false);
    setActiveTab('home');
    showToast('Keluar dari akun');
  };

  const handleAddToCart = (item, variant) => {
    if (isSeller) {
      showToast('Akun penjual tidak dapat memesan di dalam aplikasi');
      return;
    }
    const cartKey = `${item.id}::${variant}`;
    setCart((prev) => {
      const existing = prev.find((c) => c.cartKey === cartKey);
      if (existing) {
        return prev.map((c) => (c.cartKey === cartKey ? { ...c, qty: c.qty + 1 } : c));
      }
      return [...prev, { ...item, variant, cartKey, qty: 1 }];
    });
    showToast(`${item.name} ditambahkan ke keranjang`);
  };

  const handleUpdateQty = (cartKey, qty) => {
    if (qty <= 0) {
      setCart((prev) => prev.filter((c) => c.cartKey !== cartKey));
    } else {
      setCart((prev) => prev.map((c) => (c.cartKey === cartKey ? { ...c, qty } : c)));
    }
  };

  const handleRemoveItem = (cartKey) => {
    setCart((prev) => prev.filter((c) => c.cartKey !== cartKey));
  };

  const handleCheckoutQris = async (payload) => {
    if (isSeller) return;
    const created = await createOrder({
      ...payload,
      customerUid: user?.uid || 'guest',
      status: 'pending_payment'
    });
    setCart([]);
    setActiveQrisOrder(created);
    setActiveTab('orders');
  };

  const handleConfirmPaid = async (orderId) => {
    await updateOrderStatus(orderId, 'queued');
    setActiveQrisOrder(null);
    showToast('Konfirmasi pembayaran terkirim ke barista!');
  };

  const handleDeleteOrder = async (orderId) => {
    await deleteOrderById(orderId);
    showToast('Riwayat pesanan dihapus');
  };

  const activeOrdersCount = orders.filter(
    (o) => !['completed', 'cancelled'].includes(o.status)
  ).length;
  const totalCartItems = cart.reduce((acc, item) => acc + item.qty, 0);

  return (
    <div style={{ minHeight: '100vh', position: 'relative' }}>
      {/* Ambient Liquid Mesh */}
      <div className="convx-ambient-backdrop">
        <div className="convx-orb convx-orb-1" />
        <div className="convx-orb convx-orb-2" />
        <div className="convx-orb convx-orb-3" />
      </div>

      {/* Convx Refractive Header */}
      <header className="convx-header-bar">
        <div
          style={{
            maxWidth: 520,
            margin: '0 auto',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 10
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div
              style={{
                width: 38,
                height: 38,
                borderRadius: 13,
                background: 'linear-gradient(135deg, #ff9f0a, #ff5e00)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#fff',
                boxShadow: '0 6px 18px rgba(255, 149, 0, 0.45)'
              }}
            >
              <Coffee size={20} />
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ fontWeight: 800, fontSize: 16.5, letterSpacing: -0.3 }}>
                  {storeSettings.storeName}
                </span>
              </div>
              <div
                style={{
                  fontSize: 11,
                  color: 'var(--text-secondary)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 4
                }}
              >
                <Sparkles size={11} style={{ color: '#ff9f0a' }} />
                <span>v{APP_VERSION} • Convx Refractive Liquid Glass</span>
              </div>
            </div>
          </div>

          <button
            type="button"
            className="btn-ios-glass"
            onClick={() => {
              playTapHaptic();
              setSettingsOpen(true);
            }}
            style={{ padding: '8px 12px' }}
            aria-label="Pengaturan"
          >
            <Settings size={17} />
          </button>
        </div>
      </header>

      {/* Toast Notification */}
      {toastMsg && (
        <div
          style={{
            position: 'fixed',
            top: 78,
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 90,
            padding: '10px 18px',
            borderRadius: 999,
            background: 'rgba(24, 30, 46, 0.88)',
            color: '#fff',
            fontSize: 13,
            fontWeight: 600,
            backdropFilter: 'blur(20px)',
            border: '1px solid rgba(255,255,255,0.22)',
            boxShadow: '0 10px 28px rgba(0,0,0,0.4)',
            whiteSpace: 'nowrap'
          }}
        >
          {toastMsg}
        </div>
      )}

      {/* Main Content */}
      <main
        style={{
          position: 'relative',
          zIndex: 10,
          maxWidth: 520,
          margin: '0 auto',
          padding: '16px 16px 115px'
        }}
      >
        {isSeller ? (
          <SellerView
            activeTab={activeTab}
            orders={orders}
            menuItems={menuItems}
            qrisImageUrl={storeSettings.qrisImageUrl}
            storeName={storeSettings.storeName}
            onUpdateOrderStatus={updateOrderStatus}
            onDeleteOrder={handleDeleteOrder}
            onSaveMenuItem={saveMenuItem}
            onDeleteMenuItem={deleteMenuItem}
            onSaveStoreSettings={saveStoreSettings}
          />
        ) : (
          <>
            {activeTab === 'home' && (
              <CustomerHome menuItems={menuItems} onAddToCart={handleAddToCart} />
            )}
            {activeTab === 'cart' && (
              <CartSheet
                cart={cart}
                defaultCustomerName={userProfile?.name || ''}
                onUpdateQty={handleUpdateQty}
                onRemoveItem={handleRemoveItem}
                onCheckoutQris={handleCheckoutQris}
              />
            )}
            {activeTab === 'orders' && (
              <OrdersView
                orders={orders}
                onOpenQris={(ord) => setActiveQrisOrder(ord)}
                onDeleteOrder={handleDeleteOrder}
              />
            )}
          </>
        )}
      </main>

      {/* Bottom Floating Convx Dock */}
      <LiquidGlassTabBar
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        cartCount={totalCartItems}
        activeOrdersCount={activeOrdersCount}
        isSeller={isSeller}
      />

      {/* QRIS Payment Modal */}
      <QrisPaymentModal
        order={activeQrisOrder}
        storeName={storeSettings.storeName}
        qrisImageUrl={storeSettings.qrisImageUrl}
        onConfirmPaid={handleConfirmPaid}
        onClose={() => setActiveQrisOrder(null)}
      />

      {/* Settings & Account Modal */}
      <AuthModal
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        user={user}
        userProfile={userProfile}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        onGoogleLogin={handleGoogleLogin}
        onEmailLogin={handleEmailLogin}
        onEmailRegister={handleEmailRegister}
        onLogout={handleLogout}
        onManualSync={() => {
          setIsSyncing(true);
          window.setTimeout(() => {
            setIsSyncing(false);
            showToast('Data tersinkronisasi');
          }, 500);
        }}
        isSyncing={isSyncing}
        notifPermission={notifPermission}
        onRequestNotifPermission={handleRequestNotifPermission}
        authLoading={authLoading}
        authError={authError}
      />
    </div>
  );
}
