import React, { useState, useEffect } from 'react';
import { auth, db } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import CustomerView from './components/CustomerView';
import SellerView from './components/SellerView';
import AuthModal from './components/AuthModal';

function App() {
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState('customer');
  const [activeTab, setActiveTab] = useState('menu');
  const [cart, setCart] = useState([]);
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists() && userDoc.data().role === 'seller') {
            setUserRole('seller');
            setActiveTab('seller');
          } else {
            setUserRole('customer');
          }
        } catch (e) {
          console.error(e);
        }
      } else {
        setUserRole('customer');
      }
    });

    return () => unsub();
  }, []);

  return (
    <div>
      <header className="ios-header">
        <div>
          <div className="brand-title">1001 SK</div>
          <div style={{ fontSize: 11, color: 'var(--text-sub)', fontWeight: 600 }}>Coffee & Realtime Order v2.1</div>
        </div>
        <button className="tab-btn" style={{ borderColor: 'var(--glass-border-glow)' }} onClick={() => setIsAuthOpen(true)}>
          {user ? (userRole === 'seller' ? '⚙️ Seller' : '👤 Akun') : '🔑 Login'}
        </button>
      </header>

      {userRole === 'seller' && activeTab === 'seller' ? (
        <SellerView userRole={userRole} />
      ) : (
        <CustomerView cart={cart} setCart={setCart} activeTab={activeTab} user={user} />
      )}

      <nav className="ios-dock">
        {userRole === 'seller' && (
          <button className={`dock-item ${activeTab === 'seller' ? 'active' : ''}`} onClick={() => setActiveTab('seller')}>
            <span>📊</span>
            <span>Dashboard</span>
          </button>
        )}
        <button className={`dock-item ${activeTab === 'menu' ? 'active' : ''}`} onClick={() => setActiveTab('menu')}>
          <span>☕</span>
          <span>Menu</span>
        </button>
        <button className={`dock-item ${activeTab === 'orders' ? 'active' : ''}`} onClick={() => setActiveTab('orders')}>
          <span>📜</span>
          <span>Pesanan</span>
        </button>
      </nav>

      <AuthModal 
        isOpen={isAuthOpen} 
        onClose={() => setIsAuthOpen(false)} 
        user={user} 
        userRole={userRole} 
        setUserRole={setUserRole} 
      />
    </div>
  );
}

export default App;
