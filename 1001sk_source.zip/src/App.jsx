import React, { useState } from 'react';
import { db } from './firebase'; // Siap dikonfigurasi nanti

function App() {
  const [cart, setCart] = useState([]);

  const menu = [
    { id: 1, name: 'Kopi Susu Gula Aren', price: 15000 },
    { id: 2, name: 'Americano', price: 12000 },
    { id: 3, name: 'Latte', price: 18000 },
    { id: 4, name: 'V60 Manual Brew', price: 20000 },
  ];

  const addToCart = (item) => {
    setCart([...cart, item]);
    alert(`${item.name} ditambahkan ke keranjang!`);
  };

  return (
    <div className="app-container">
      <div className="header">
        <h2>1001 SK - Pemesanan Kopi</h2>
      </div>
      
      <h3>Menu Kami</h3>
      <br/>
      <div className="menu-grid">
        {menu.map((item) => (
          <div className="menu-item" key={item.id}>
            <h4>{item.name}</h4>
            <p>Rp {item.price.toLocaleString('id-ID')}</p>
            <button className="btn" onClick={() => addToCart(item)}>Tambah</button>
          </div>
        ))}
      </div>

      <br/>
      <div style={{ background: '#fff', padding: '15px', borderRadius: '10px' }}>
        <h3>Keranjang ({cart.length} item)</h3>
        {cart.length > 0 && <button className="btn" style={{background: '#ff9800'}}>Checkout (Setup Firebase Nanti)</button>}
      </div>
    </div>
  );
}

export default App;