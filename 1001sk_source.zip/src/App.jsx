import React, { useState, useEffect, useRef, useCallback } from 'react';
import { auth, db } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, collection, onSnapshot, query, orderBy, where } from 'firebase/firestore';
import CustomerView from './components/CustomerView';
import SellerView from './components/SellerView';
import AuthModal from './components/AuthModal';
import UpdateModal from './components/UpdateModal';
import { useSwipe } from './hooks/useSwipe';
import { CURRENT_APP_VERSION, compareVersions } from './utils/versionUtils';
import {
  playNewOrderChime,
  playOrderReadyChime,
  triggerHaptic,
  sendSystemNotification,
} from './utils/soundEffects';
import {
  Coffee,
  Receipt,
  LayoutDashboard,
  User,
  Store,
  Sparkles,
  Sun,
  Moon,
  Volume2,
  VolumeX,
  Search,
  BellRing,
  X,
  QrCode,
  ShoppingBag,
} from 'lucide-react';

const CUSTOMER_TABS = ['menu', 'cart', 'orders'];
const SELLER_TABS = ['orders', 'menu', 'qris', 'update'];

function App() {
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState('customer');
  const [activeTab, setActiveTab] = useState('menu');
  const [sellerSubTab, setSellerSubTab] = useState('orders');
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  const [readyAlertOrder, setReadyAlertOrder] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [storeOpen, setStoreOpen] = useState(true);

  // State In-App Updater
  const [updateInfo, setUpdateInfo] = useState(null);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const hasAutoPromptedUpdate = useRef(false);

  // Persistent Dark / Light Theme
  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem('1001sk_theme') || 'dark';
    } catch {
      return 'dark';
    }
  });

  // Persistent Notification Sound Toggle
  const [soundEnabled, setSoundEnabled] = useState(() => {
    try {
      const saved = localStorage.getItem('1001sk_sound');
      return saved === null ? true : saved === 'true';
    } catch {
      return true;
    }
  });

  const searchInputRef = useRef(null);
  const isInitialOrdersLoad = useRef(true);
  const prevOrderStatusMap = useRef({});
  const soundEnabledRef = useRef(soundEnabled);
  const userRoleRef = useRef(userRole);

  useEffect(() => {
    soundEnabledRef.current = soundEnabled;
    try {
      localStorage.setItem('1001sk_sound', String(soundEnabled));
    } catch {}
  }, [soundEnabled]);

  useEffect(() => {
    userRoleRef.current = userRole;
    if (userRole === 'seller') {
      setCart([]);
      setActiveTab('seller');
    } else if (activeTab === 'seller') {
      setActiveTab('menu');
    }
  }, [userRole]);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) {
      metaTheme.setAttribute('content', theme === 'dark' ? '#0a090f' : '#f3f1ed');
    }
    try {
      localStorage.setItem('1001sk_theme', theme);
    } catch {}
  }, [theme]);

  const showToast = useCallback((msg) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? '' : prev));
    }, 2800);
  }, []);

  // Auth & Role Listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setAuthReady(true);
      if (currentUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists() && userDoc.data().role === 'seller') {
            setUserRole('seller');
            setCart([]);
            setActiveTab('seller');
          } else {
            setUserRole('customer');
          }
        } catch (e) {
          console.error(e);
        }
      } else {
        setUserRole('customer');
      }
    });

    return () => unsub();
  }, []);

  // Listener Realtime Pembaruan Aplikasi (settings/app_info)
  useEffect(() => {
    const unsubUpdate = onSnapshot(doc(db, 'settings', 'app_info'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.latestVersion && compareVersions(data.latestVersion, CURRENT_APP_VERSION) > 0) {
          setUpdateInfo(data);
          if (!hasAutoPromptedUpdate.current) {
            hasAutoPromptedUpdate.current = true;
            setIsUpdateModalOpen(true);
          }
        } else {
          setUpdateInfo(null);
        }
      }
    }, () => {});

    return () => unsubUpdate();
  }, []);

  // Realtime pesanan: seller melihat semua, pembeli hanya pesanannya sendiri
  useEffect(() => {
    isInitialOrdersLoad.current = true;
    prevOrderStatusMap.current = {};
    if (!user) { setOrders([]); return; }

    const isSeller = userRole === 'seller';
    const q = isSeller
      ? query(collection(db, 'orders'), orderBy('createdAt', 'desc'))
      : query(collection(db, 'orders'), where('uid', '==', user.uid));

    const unsub = onSnapshot(q, (snap) => {
      let list = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      if (!isSeller) {
        list = list
          .filter(o => !o.hiddenByCustomer)
          .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
      }
      setOrders(list);

      if (isInitialOrdersLoad.current) {
        const initMap = {};
        list.forEach(o => { initMap[o.id] = o.status; });
        prevOrderStatusMap.current = initMap;
        isInitialOrdersLoad.current = false;
        return;
      }

      const prevMap = prevOrderStatusMap.current;
      const nextMap = {};

      list.forEach(ord => {
        nextMap[ord.id] = ord.status;
        const oldStatus = prevMap[ord.id];

        if (!oldStatus && ord.status === 'pending' && isSeller) {
          if (soundEnabledRef.current) playNewOrderChime();
          triggerHaptic([30, 50, 30]);
          showToast(`🔔 Pesanan baru dari ${ord.customerName}!`);
          sendSystemNotification(
            'Pesanan Baru Masuk - 1001 SK',
            `${ord.customerName} memesan Rp ${ord.totalPrice?.toLocaleString('id-ID')}`
          );
        }

        if (oldStatus && oldStatus !== 'siap' && ord.status === 'siap' && !isSeller) {
          if (soundEnabledRef.current) playOrderReadyChime();
          triggerHaptic([60, 40, 80]);
          setReadyAlertOrder(ord);
          sendSystemNotification(
            '☕ Pesanan Siap Diambil - 1001 SK',
            `Pesanan atas nama ${ord.customerName} sudah siap!`
          );
        }
      });

      prevOrderStatusMap.current = nextMap;
    }, (err) => console.error(err));

    return () => unsub();
  }, [user, userRole, showToast]);

  // Status buka/tutup toko
  useEffect(() => {
    if (!user) return;
    return onSnapshot(
      doc(db, 'settings', 'store'),
      (s) => setStoreOpen(!s.exists() || s.data().open !== false),
      () => {}
    );
  }, [user]);

  // Geser kiri/kanan antar tab
  const moveTab = useCallback((dir) => {
    triggerHaptic(10);
    if (userRole === 'seller') {
      const i = SELLER_TABS.indexOf(sellerSubTab) + dir;
      if (i >= 0 && i < SELLER_TABS.length) setSellerSubTab(SELLER_TABS[i]);
    } else {
      const i = CUSTOMER_TABS.indexOf(activeTab) + dir;
      if (i >= 0 && i < CUSTOMER_TABS.length) setActiveTab(CUSTOMER_TABS[i]);
    }
  }, [userRole, sellerSubTab, activeTab]);

  const { stageRef, swipeHandlers } = useSwipe({
    onSwipeLeft: () => moveTab(1),
    onSwipeRight: () => moveTab(-1),
  });

  const toggleTheme = () => {
    triggerHaptic(12);
    setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  const toggleSound = () => {
    triggerHaptic(12);
    setSoundEnabled(prev => {
      const next = !prev;
      if (next) {
        playNewOrderChime();
        showToast('Nada notifikasi pesanan diaktifkan');
      } else {
        showToast('Nada notifikasi dimatikan');
      }
      return next;
    });
  };

  const handleManualCheckUpdate = () => {
    triggerHaptic(12);
    if (updateInfo) {
      setIsUpdateModalOpen(true);
    } else {
      showToast(`Aplikasi 1001 SK sudah versi terbaru (v${CURRENT_APP_VERSION})`);
    }
  };

  const handleCircleAction = () => {
    triggerHaptic(12);
    if (userRole === 'seller') {
      setSellerSubTab(prev => (prev === 'qris' ? 'orders' : 'qris'));
    } else {
      setActiveTab('menu');
      setTimeout(() => {
        if (searchInputRef.current) {
          searchInputRef.current.focus();
        }
      }, 80);
    }
  };

  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const pendingCount = orders.filter(o => o.status === 'pending').length;

  if (!authReady) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-sub)', fontWeight: 700 }}>
        <div className="ambient-canvas"><div className="ambient-orb orb-1" /><div className="ambient-orb orb-2" /></div>
        Memuat 1001 SK...
      </div>
    );
  }

  if (!user) {
    return (
      <div>
        <div className="ambient-canvas">
          <div className="ambient-orb orb-1" />
          <div className="ambient-orb orb-2" />
          <div className="ambient-orb orb-3" />
        </div>
        {toastMsg && (
          <div className="ios-toast">
            <Sparkles size={16} color="var(--accent-primary)" />
            <span>{toastMsg}</span>
          </div>
        )}
        <AuthModal
          isOpen
          forced
          user={null}
          userRole="customer"
          setUserRole={setUserRole}
          showToast={showToast}
          onClose={() => {}}
          hasUpdate={Boolean(updateInfo)}
          onCheckUpdate={handleManualCheckUpdate}
        />
        <UpdateModal
          isOpen={isUpdateModalOpen}
          onClose={() => setIsUpdateModalOpen(false)}
          updateInfo={updateInfo}
          showToast={showToast}
        />
      </div>
    );
  }

  return (
    <div {...swipeHandlers}>
      {/* GPU Ambient Lighting Canvas */}
      <div className="ambient-canvas">
        <div className="ambient-orb orb-1" />
        <div className="ambient-orb orb-2" />
        <div className="ambient-orb orb-3" />
      </div>

      {/* Dynamic Island Toast */}
      {toastMsg && (
        <div className="ios-toast">
          <Sparkles size={16} color="var(--accent-primary)" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Customer "Pesanan Siap Diambil" Prominent Frosted Alert Banner */}
      {readyAlertOrder && userRole !== 'seller' && (
        <div className="ready-banner-alert">
          <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
            <div style={{ width: 40, height: 40, borderRadius: 14, background: 'rgba(50, 215, 75, 0.2)', color: 'var(--accent-green)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <BellRing size={20} />
            </div>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 800, color: 'var(--accent-green)' }}>
                Pesanan Siap Diambil!
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-main)', marginTop: 2 }}>
                Atas nama <strong>{readyAlertOrder.customerName}</strong>
              </div>
            </div>
          </div>
          <button
            type="button"
            className="icon-glass-btn"
            onClick={() => setReadyAlertOrder(null)}
            aria-label="Tutup notifikasi"
          >
            <X size={15} />
          </button>
        </div>
      )}

      {/* Sticky Frosted Header */}
      <header className="ios-header">
        <div>
          <div className="brand-title">1001 SK</div>
          <div className="brand-sub" onClick={handleManualCheckUpdate} style={{ display: 'inline-flex', alignItems: 'center', gap: 5, cursor: 'pointer' }}>
            <span>{userRole === 'seller' ? `Kasir & Manajemen • v${CURRENT_APP_VERSION}` : `Coffee & Lounge • v${CURRENT_APP_VERSION}`}</span>
            {updateInfo && <span className="update-dot" title="Pembaruan tersedia" />}
          </div>
        </div>

        <div className="header-actions">
          <button
            type="button"
            className={`icon-glass-btn ${soundEnabled ? 'active-accent' : ''}`}
            onClick={toggleSound}
            title={soundEnabled ? 'Nada Notifikasi Aktif' : 'Nada Notifikasi Nonaktif'}
          >
            {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>

          <button
            type="button"
            className="icon-glass-btn"
            onClick={toggleTheme}
            title={theme === 'dark' ? 'Ganti ke Tema Terang' : 'Ganti ke Tema Gelap'}
          >
            {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
          </button>

          <button
            type="button"
            className="tab-btn active"
            style={{ padding: '7px 13px' }}
            onClick={() => setIsAuthOpen(true)}
          >
            {user ? (
              userRole === 'seller' ? <><Store size={14} /> Seller</> : <><User size={14} /> Akun</>
            ) : (
              <><User size={14} /> Login</>
            )}
          </button>
        </div>
      </header>

      {/* Main Swipeable Viewport */}
      <main ref={stageRef} className="swipe-stage">
        {userRole === 'seller' ? (
          <SellerView
            orders={orders}
            sellerSubTab={sellerSubTab}
            setSellerSubTab={setSellerSubTab}
            showToast={showToast}
            storeOpen={storeOpen}
          />
        ) : (
          <CustomerView
            cart={cart}
            setCart={setCart}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            user={user}
            userRole={userRole}
            orders={orders}
            showToast={showToast}
            searchInputRef={searchInputRef}
            storeOpen={storeOpen}
          />
        )}
      </main>

      {/* Floating Frosted Capsule Dock + Separate Circular Action Button */}
      <div className="floating-nav-wrapper">
        <nav className="ios-dock">
          {userRole === 'seller' ? (
            <>
              <button
                type="button"
                className={`dock-item ${sellerSubTab === 'orders' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setSellerSubTab('orders'); }}
              >
                <Receipt size={18} />
                <span>Pesanan</span>
                {pendingCount > 0 && <span className="dock-badge">{pendingCount}</span>}
              </button>
              <button
                type="button"
                className={`dock-item ${sellerSubTab === 'menu' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setSellerSubTab('menu'); }}
              >
                <Coffee size={18} />
                <span>Menu</span>
              </button>
              <button
                type="button"
                className={`dock-item ${sellerSubTab === 'update' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setSellerSubTab('update'); }}
              >
                <LayoutDashboard size={18} />
                <span>Update</span>
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                className={`dock-item ${activeTab === 'menu' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setActiveTab('menu'); }}
              >
                <Coffee size={18} />
                <span>Beranda</span>
              </button>
              <button
                type="button"
                className={`dock-item ${activeTab === 'cart' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setActiveTab('cart'); }}
              >
                <ShoppingBag size={18} />
                <span>Keranjang</span>
                {cartCount > 0 && <span className="dock-badge">{cartCount}</span>}
              </button>
              <button
                type="button"
                className={`dock-item ${activeTab === 'orders' ? 'active' : ''}`}
                onClick={() => { triggerHaptic(10); setActiveTab('orders'); }}
              >
                <Receipt size={18} />
                <span>Pesanan</span>
              </button>
            </>
          )}
        </nav>

        <button
          type="button"
          className="dock-circle-btn"
          onClick={handleCircleAction}
          aria-label={userRole === 'seller' ? 'QRIS Toko' : 'Cari Menu'}
        >
          {userRole === 'seller' ? <QrCode size={21} /> : <Search size={21} />}
        </button>
      </div>

      <AuthModal
        isOpen={isAuthOpen || !user}
        forced={!user}
        onClose={() => setIsAuthOpen(false)}
        user={user}
        userRole={userRole}
        setUserRole={setUserRole}
        showToast={showToast}
        hasUpdate={Boolean(updateInfo)}
        onCheckUpdate={handleManualCheckUpdate}
      />

      <UpdateModal
        isOpen={isUpdateModalOpen}
        onClose={() => setIsUpdateModalOpen(false)}
        updateInfo={updateInfo}
        showToast={showToast}
      />
    </div>
  );
}

export default App;
