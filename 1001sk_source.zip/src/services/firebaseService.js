import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  onAuthStateChanged,
  updateProfile
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy
} from 'firebase/firestore';
import { FIREBASE_CONFIG, IS_FIREBASE_CONFIGURED } from '../firebaseConfig.js';
import { INITIAL_MENU, SELLER_EMAIL } from '../utils/constants.js';

let auth = null;
let db = null;

if (IS_FIREBASE_CONFIGURED) {
  const app = initializeApp(FIREBASE_CONFIG);
  auth = getAuth(app);
  db = getFirestore(app);
}

const LS_KEYS = {
  USER: '1001sk_local_user',
  MENU: '1001sk_local_menu_v284',
  ORDERS: '1001sk_local_orders_v284',
  SETTINGS: '1001sk_local_settings_v284'
};

function readLS(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function writeLS(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new CustomEvent('1001sk-storage-sync', { detail: { key } }));
  } catch {
    // ignore quota errors
  }
}

function buildProfile(user) {
  if (!user) return null;
  const email = (user.email || '').toLowerCase();
  const isSeller = email === SELLER_EMAIL.toLowerCase();
  return {
    uid: user.uid,
    email: user.email,
    name: user.displayName || (isSeller ? 'Barista & Owner 1001 SK' : 'Pelanggan 1001 SK'),
    role: isSeller ? 'seller' : 'customer',
    photoURL: user.photoURL || ''
  };
}

export function subscribeAuth(callback) {
  if (IS_FIREBASE_CONFIGURED && auth) {
    return onAuthStateChanged(auth, (fbUser) => {
      if (fbUser) {
        callback(fbUser, buildProfile(fbUser));
      } else {
        callback(null, null);
      }
    });
  }
  const emitLocal = () => {
    const saved = readLS(LS_KEYS.USER, null);
    callback(saved, saved ? buildProfile(saved) : null);
  };
  emitLocal();
  window.addEventListener('1001sk-storage-sync', emitLocal);
  return () => window.removeEventListener('1001sk-storage-sync', emitLocal);
}

export async function loginWithEmail(email, password) {
  if (IS_FIREBASE_CONFIGURED && auth) {
    const cred = await signInWithEmailAndPassword(auth, email, password);
    return buildProfile(cred.user);
  }
  if (!email || !password) throw new Error('Email dan kata sandi wajib diisi.');
  const user = {
    uid: 'local-' + btoa(email.toLowerCase()).slice(0, 12),
    email: email.trim(),
    displayName: email.toLowerCase() === SELLER_EMAIL ? 'Owner 1001 SK' : email.split('@')[0]
  };
  writeLS(LS_KEYS.USER, user);
  return buildProfile(user);
}

export async function registerWithEmail(name, email, password) {
  if (IS_FIREBASE_CONFIGURED && auth) {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    if (name) {
      await updateProfile(cred.user, { displayName: name });
    }
    return buildProfile(cred.user);
  }
  if (!email || password.length < 4) {
    throw new Error('Gunakan email valid dan kata sandi minimal 4 karakter.');
  }
  const user = {
    uid: 'local-' + Date.now(),
    email: email.trim(),
    displayName: name?.trim() || email.split('@')[0]
  };
  writeLS(LS_KEYS.USER, user);
  return buildProfile(user);
}

export async function loginWithGoogle() {
  if (IS_FIREBASE_CONFIGURED && auth) {
    const provider = new GoogleAuthProvider();
    const cred = await signInWithPopup(auth, provider);
    return buildProfile(cred.user);
  }
  const user = {
    uid: 'google-demo-1001sk',
    email: 'pelanggan.1001sk@gmail.com',
    displayName: 'Pelanggan 1001 SK'
  };
  writeLS(LS_KEYS.USER, user);
  return buildProfile(user);
}

export async function logoutAccount() {
  if (IS_FIREBASE_CONFIGURED && auth) {
    await signOut(auth);
  }
  localStorage.removeItem(LS_KEYS.USER);
  window.dispatchEvent(new CustomEvent('1001sk-storage-sync'));
}

export function subscribeMenu(callback) {
  if (IS_FIREBASE_CONFIGURED && db) {
    return onSnapshot(collection(db, 'menu'), (snap) => {
      if (snap.empty) {
        callback(INITIAL_MENU);
      } else {
        callback(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      }
    });
  }
  const emit = () => {
    const existing = readLS(LS_KEYS.MENU, null);
    if (!existing || existing.length === 0) {
      writeLS(LS_KEYS.MENU, INITIAL_MENU);
      callback(INITIAL_MENU);
    } else {
      callback(existing);
    }
  };
  emit();
  window.addEventListener('1001sk-storage-sync', emit);
  return () => window.removeEventListener('1001sk-storage-sync', emit);
}

export async function saveMenuItem(item) {
  if (IS_FIREBASE_CONFIGURED && db) {
    if (item.id) {
      await setDoc(doc(db, 'menu', item.id), item, { merge: true });
    } else {
      await addDoc(collection(db, 'menu'), item);
    }
    return;
  }
  const current = readLS(LS_KEYS.MENU, INITIAL_MENU);
  if (item.id) {
    const updated = current.map((m) => (m.id === item.id ? { ...m, ...item } : m));
    writeLS(LS_KEYS.MENU, updated);
  } else {
    const newItem = { ...item, id: 'sk-' + Date.now() };
    writeLS(LS_KEYS.MENU, [newItem, ...current]);
  }
}

export async function deleteMenuItem(id) {
  if (IS_FIREBASE_CONFIGURED && db) {
    await deleteDoc(doc(db, 'menu', id));
    return;
  }
  const current = readLS(LS_KEYS.MENU, INITIAL_MENU);
  writeLS(
    LS_KEYS.MENU,
    current.filter((m) => m.id !== id)
  );
}

export function subscribeOrders(callback) {
  if (IS_FIREBASE_CONFIGURED && db) {
    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    return onSnapshot(q, (snap) => {
      callback(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });
  }
  const emit = () => {
    const orders = readLS(LS_KEYS.ORDERS, []);
    callback(orders);
  };
  emit();
  window.addEventListener('1001sk-storage-sync', emit);
  return () => window.removeEventListener('1001sk-storage-sync', emit);
}

export async function createOrder(orderPayload) {
  const newOrder = {
    ...orderPayload,
    createdAt: new Date().toISOString()
  };
  if (IS_FIREBASE_CONFIGURED && db) {
    const ref = await addDoc(collection(db, 'orders'), newOrder);
    return { id: ref.id, ...newOrder };
  }
  const id = 'ORD-' + Math.floor(100000 + Math.random() * 900000);
  const created = { id, ...newOrder };
  const current = readLS(LS_KEYS.ORDERS, []);
  writeLS(LS_KEYS.ORDERS, [created, ...current]);
  return created;
}

export async function updateOrderStatus(orderId, status) {
  if (IS_FIREBASE_CONFIGURED && db) {
    await updateDoc(doc(db, 'orders', orderId), { status });
    return;
  }
  const current = readLS(LS_KEYS.ORDERS, []);
  writeLS(
    LS_KEYS.ORDERS,
    current.map((o) => (o.id === orderId ? { ...o, status } : o))
  );
}

export async function deleteOrderById(orderId) {
  if (IS_FIREBASE_CONFIGURED && db) {
    await deleteDoc(doc(db, 'orders', orderId));
    return;
  }
  const current = readLS(LS_KEYS.ORDERS, []);
  writeLS(
    LS_KEYS.ORDERS,
    current.filter((o) => o.id !== orderId)
  );
}

export function subscribeStoreSettings(callback) {
  const defaults = {
    storeName: '1001 SK Coffee & Lounge',
    qrisImageUrl: ''
  };
  if (IS_FIREBASE_CONFIGURED && db) {
    return onSnapshot(doc(db, 'settings', 'store'), (snap) => {
      callback(snap.exists() ? { ...defaults, ...snap.data() } : defaults);
    });
  }
  const emit = () => {
    callback({ ...defaults, ...readLS(LS_KEYS.SETTINGS, defaults) });
  };
  emit();
  window.addEventListener('1001sk-storage-sync', emit);
  return () => window.removeEventListener('1001sk-storage-sync', emit);
}

export async function saveStoreSettings(settings) {
  if (IS_FIREBASE_CONFIGURED && db) {
    await setDoc(doc(db, 'settings', 'store'), settings, { merge: true });
    return;
  }
  const current = readLS(LS_KEYS.SETTINGS, {});
  writeLS(LS_KEYS.SETTINGS, { ...current, ...settings });
}
