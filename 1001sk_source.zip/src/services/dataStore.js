import { initializeApp, getApps } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  onSnapshot,
  setDoc,
  updateDoc,
  deleteDoc,
  serverTimestamp
} from 'firebase/firestore';
import { INITIAL_MENU, DEFAULT_SELLER_PIN, APP_VERSION } from '../utils/constants.js';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || '',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || '',
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || '',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || '',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || ''
};

const hasFirebase = Boolean(firebaseConfig.apiKey && firebaseConfig.projectId);
let db = null;

if (hasFirebase) {
  try {
    const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
    db = getFirestore(app);
  } catch (err) {
    console.warn('Firebase fallback ke mode lokal:', err);
    db = null;
  }
}

const LS_MENU = '1001sk_menu_v290';
const LS_ORDERS = '1001sk_orders_v290';
const LS_SETTINGS = '1001sk_settings_v290';

const DEFAULT_SETTINGS = {
  storeOpen: true,
  storeName: '1001 SK — Coffee & Lounge',
  qrisImage: '',
  sellerPin: DEFAULT_SELLER_PIN,
  latestVersion: APP_VERSION,
  apkUrl: '',
  releaseNotes: 'Pembaruan v2.9.0 Convx Refractive Liquid Glass, Swipe Gestures & QRIS Penuh.',
  forceUpdate: false
};

function readLS(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function writeLS(key, val) {
  try {
    localStorage.setItem(key, JSON.stringify(val));
    window.dispatchEvent(new CustomEvent('1001sk-sync', { detail: { key } }));
  } catch (e) {
    console.error('Gagal menyimpan ke penyimpanan lokal:', e);
  }
}

export function isCloudConnected() {
  return Boolean(db);
}

export function subscribeMenu(callback) {
  if (db) {
    return onSnapshot(
      collection(db, 'menu'),
      (snap) => {
        if (snap.empty) {
          callback(INITIAL_MENU);
        } else {
          const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
          callback(items);
        }
      },
      () => callback(readLS(LS_MENU, INITIAL_MENU))
    );
  }

  const emit = () => {
    const saved = readLS(LS_MENU, null);
    if (!saved) {
      writeLS(LS_MENU, INITIAL_MENU);
      callback(INITIAL_MENU);
    } else {
      callback(saved);
    }
  };
  emit();
  const listener = (e) => {
    if (!e.detail || e.detail.key === LS_MENU) emit();
  };
  window.addEventListener('1001sk-sync', listener);
  window.addEventListener('storage', emit);
  return () => {
    window.removeEventListener('1001sk-sync', listener);
    window.removeEventListener('storage', emit);
  };
}

export async function saveMenuItem(item) {
  const id = item.id || `sk-${Date.now()}`;
  const payload = { ...item, id, updatedAt: Date.now() };
  if (db) {
    await setDoc(doc(db, 'menu', id), payload, { merge: true });
    return payload;
  }
  const current = readLS(LS_MENU, INITIAL_MENU);
  const idx = current.findIndex((m) => m.id === id);
  if (idx >= 0) current[idx] = payload;
  else current.unshift(payload);
  writeLS(LS_MENU, current);
  return payload;
}

export async function deleteMenuItem(id) {
  if (db) {
    await deleteDoc(doc(db, 'menu', id));
    return;
  }
  const current = readLS(LS_MENU, INITIAL_MENU).filter((m) => m.id !== id);
  writeLS(LS_MENU, current);
}

export function subscribeOrders(callback) {
  if (db) {
    return onSnapshot(
      collection(db, 'orders'),
      (snap) => {
        const list = snap.docs
          .map((d) => ({ id: d.id, ...d.data() }))
          .sort((a, b) => (b.createdAtMs || 0) - (a.createdAtMs || 0));
        callback(list);
      },
      () => callback(readLS(LS_ORDERS, []))
    );
  }

  const emit = () => {
    const list = readLS(LS_ORDERS, []).sort((a, b) => (b.createdAtMs || 0) - (a.createdAtMs || 0));
    callback(list);
  };
  emit();
  const listener = (e) => {
    if (!e.detail || e.detail.key === LS_ORDERS) emit();
  };
  window.addEventListener('1001sk-sync', listener);
  window.addEventListener('storage', emit);
  return () => {
    window.removeEventListener('1001sk-sync', listener);
    window.removeEventListener('storage', emit);
  };
}

export async function createOrder(orderData) {
  const id = `ORD-${Date.now().toString().slice(-6)}`;
  const payload = {
    ...orderData,
    id,
    createdAtMs: Date.now()
  };
  if (db) {
    await setDoc(doc(db, 'orders', id), { ...payload, createdAt: serverTimestamp() });
    return payload;
  }
  const current = readLS(LS_ORDERS, []);
  current.unshift(payload);
  writeLS(LS_ORDERS, current);
  return payload;
}

export async function updateOrderStatus(orderId, status, extra = {}) {
  if (db) {
    await updateDoc(doc(db, 'orders', orderId), { status, ...extra, updatedAtMs: Date.now() });
    return;
  }
  const current = readLS(LS_ORDERS, []).map((o) =>
    o.id === orderId ? { ...o, status, ...extra, updatedAtMs: Date.now() } : o
  );
  writeLS(LS_ORDERS, current);
}

export async function deleteOrderById(orderId) {
  if (db) {
    await deleteDoc(doc(db, 'orders', orderId));
    return;
  }
  const current = readLS(LS_ORDERS, []).filter((o) => o.id !== orderId);
  writeLS(LS_ORDERS, current);
}

export async function clearFinishedOrders(orderIds = []) {
  if (!orderIds.length) return;
  if (db) {
    await Promise.all(orderIds.map((id) => deleteDoc(doc(db, 'orders', id))));
    return;
  }
  const setIds = new Set(orderIds);
  const current = readLS(LS_ORDERS, []).filter((o) => !setIds.has(o.id));
  writeLS(LS_ORDERS, current);
}

export function subscribeSettings(callback) {
  if (db) {
    return onSnapshot(
      doc(db, 'settings', 'store'),
      (snap) => {
        callback({ ...DEFAULT_SETTINGS, ...(snap.exists() ? snap.data() : {}) });
      },
      () => callback({ ...DEFAULT_SETTINGS, ...readLS(LS_SETTINGS, {}) })
    );
  }

  const emit = () => {
    callback({ ...DEFAULT_SETTINGS, ...readLS(LS_SETTINGS, {}) });
  };
  emit();
  const listener = (e) => {
    if (!e.detail || e.detail.key === LS_SETTINGS) emit();
  };
  window.addEventListener('1001sk-sync', listener);
  window.addEventListener('storage', emit);
  return () => {
    window.removeEventListener('1001sk-sync', listener);
    window.removeEventListener('storage', emit);
  };
}

export async function updateStoreSettings(patch) {
  if (db) {
    await setDoc(doc(db, 'settings', 'store'), patch, { merge: true });
    return;
  }
  const current = { ...DEFAULT_SETTINGS, ...readLS(LS_SETTINGS, {}), ...patch };
  writeLS(LS_SETTINGS, current);
}
