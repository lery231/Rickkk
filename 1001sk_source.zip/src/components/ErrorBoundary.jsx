import React from 'react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, errorMsg: '' };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, errorMsg: error?.message || 'Terjadi kesalahan antarmuka' };
  }

  componentDidCatch(error, info) {
    console.error('[1001SK ErrorBoundary]', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            minHeight: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 24,
            background: '#ffffff',
            color: '#111113',
            fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif',
          }}
        >
          <div
            style={{
              maxWidth: 380,
              width: '100%',
              padding: 24,
              borderRadius: 24,
              background: '#f5f5f7',
              textAlign: 'center',
            }}
          >
            <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 8 }}>
              Memuat Ulang 1001 SK
            </h2>
            <p style={{ fontSize: 13, color: '#86868b', marginBottom: 16 }}>
              {this.state.errorMsg}
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              style={{
                padding: '12px 20px',
                borderRadius: 14,
                border: 'none',
                background: '#fa2d48',
                color: '#ffffff',
                fontWeight: 700,
                fontSize: 14,
                cursor: 'pointer',
              }}
            >
              Muat Ulang Aplikasi
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
