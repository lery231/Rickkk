import React from 'react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, message: error?.message || 'Terjadi kendala tampilan.' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            minHeight: '100vh',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 24,
            textAlign: 'center',
            background: '#0f1117',
            color: '#fff',
            fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif'
          }}
        >
          <h2 style={{ marginBottom: 8 }}>1001 SK Pemulihan Cepat</h2>
          <p style={{ opacity: 0.75, fontSize: 14, marginBottom: 20 }}>{this.state.message}</p>
          <button
            onClick={() => window.location.reload()}
            style={{
              padding: '12px 24px',
              borderRadius: 999,
              border: 'none',
              background: '#d4a373',
              color: '#111',
              fontWeight: 700,
              cursor: 'pointer'
            }}
          >
            Muat Ulang Aplikasi
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
