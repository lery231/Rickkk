import React from 'react';
import { RefreshCw, ShieldAlert } from 'lucide-react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error) {
    return {
      hasError: true,
      errorMessage: error?.message || 'Terjadi gangguan tampilan sementara.',
    };
  }

  componentDidCatch(error, info) {
    console.error('[1001SK Stability Guard]', error, info);
  }

  handleRecover = () => {
    try {
      sessionStorage.clear();
    } catch {}
    this.setState({ hasError: false, errorMessage: '' });
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            minHeight: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 24,
            background: '#09080f',
            color: '#f5f5f7',
          }}
        >
          <div
            style={{
              maxWidth: 380,
              width: '100%',
              background: 'rgba(24, 22, 34, 0.85)',
              border: '1px solid rgba(255, 255, 255, 0.14)',
              borderRadius: 26,
              padding: 24,
              textAlign: 'center',
            }}
          >
            <ShieldAlert size={36} color="#e6c38e" style={{ marginBottom: 12 }} />
            <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 8 }}>
              Pemulihan Otomatis 1001 SK
            </h3>
            <p style={{ fontSize: 13, color: '#a1a1aa', marginBottom: 18 }}>
              {this.state.errorMessage}
            </p>
            <button
              type="button"
              onClick={this.handleRecover}
              style={{
                width: '100%',
                padding: '12px 16px',
                borderRadius: 15,
                border: 'none',
                background: '#e6c38e',
                color: '#100e17',
                fontWeight: 800,
                fontSize: 14,
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8,
                cursor: 'pointer',
              }}
            >
              <RefreshCw size={16} /> Muat Ulang Aplikasi
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
