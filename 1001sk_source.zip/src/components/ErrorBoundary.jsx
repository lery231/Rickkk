import React from 'react';
import { RefreshCw, ShieldAlert } from 'lucide-react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error) {
    return {
      hasError: true,
      errorMessage: error?.message || 'Terjadi gangguan tampilan sementara.',
    };
  }

  componentDidCatch(error, info) {
    console.error('[1001SK Stability Guard]', error, info);
  }

  handleRecover = () => {
    try {
      sessionStorage.clear();
    } catch {}
    this.setState({ hasError: false, errorMessage: '' });
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            minHeight: '100dvh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 22,
          }}
        >
          <div
            className="glass-card"
            style={{ padding: 24, maxWidth: 390, width: '100%', textAlign: 'center' }}
          >
            <ShieldAlert
              size={38}
              color="var(--accent)"
              style={{ margin: '0 auto 12px' }}
            />
            <h3 style={{ fontSize: 18, fontWeight: 800, margin: '0 0 6px' }}>
              Pemulihan Otomatis 1001 SK
            </h3>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: '0 0 18px' }}>
              {this.state.errorMessage}
            </p>
            <button
              type="button"
              className="btn-primary"
              style={{ width: '100%' }}
              onClick={this.handleRecover}
            >
              <RefreshCw size={16} />
              <span>Muat Ulang Aplikasi</span>
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
