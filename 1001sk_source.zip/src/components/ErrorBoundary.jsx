import React from 'react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, errorMsg: '' };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, errorMsg: error?.message || 'Terjadi kesalahan tampilan.' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            minHeight: '100vh',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 24,
            textAlign: 'center',
            background: 'var(--bg-page)',
            color: 'var(--text-primary)'
          }}
        >
          <div style={{ fontSize: 42, marginBottom: 12 }}>☕</div>
          <h2 style={{ fontSize: 20, fontWeight: 800 }}>1001 SK Memulihkan Tampilan</h2>
          <p style={{ fontSize: 13.5, color: 'var(--text-secondary)', margin: '8px 0 18px' }}>
            {this.state.errorMsg}
          </p>
          <button
            type="button"
            className="btn-ios-primary"
            style={{ maxWidth: 220 }}
            onClick={() => window.location.reload()}
          >
            Muat Ulang Aplikasi
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
