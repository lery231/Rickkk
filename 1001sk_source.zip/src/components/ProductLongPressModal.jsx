import React, { useState, useEffect } from 'react';
import {
  ShoppingBag,
  Zap,
  Share2,
  Layers,
  X,
  Sparkles,
  Coffee
} from 'lucide-react';
import { formatRupiah } from '../utils/constants.js';
import { playTapHaptic } from '../utils/soundEffects.js';

export default function ProductLongPressModal({
  item,
  onClose,
  onAddToCart,
  onOrderNow,
  onFilterCategory,
  onShareProduct
}) {
  const [closing, setClosing] = useState(false);

  useEffect(() => {
    setClosing(false);
  }, [item]);

  if (!item) return null;

  const triggerClose = (callback) => {
    setClosing(true);
    window.setTimeout(() => {
      setClosing(false);
      if (callback) callback();
      onClose();
    }, 220);
  };

  const soldOut = item.available === false;

  return (
    <div
      className={`peek-backdrop ${closing ? 'is-closing' : ''}`}
      onClick={() => triggerClose()}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div
        className="peek-container"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Floating Cupertino Product Preview Card (Photo-Free Convx Glass) */}
        <div
          className={`peek-preview-card refractive-glass ${closing ? 'is-closing' : ''}`}
          style={{
            backgroundImage: item.accentGradient || undefined
          }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: 8,
              marginBottom: 14,
              position: 'relative',
              zIndex: 1
            }}
          >
            <span
              style={{
                padding: '5px 12px',
                borderRadius: 999,
                background: 'var(--bg-subtle)',
                border: '1px solid var(--border-hairline)',
                fontSize: 12,
                fontWeight: 700,
                color: 'var(--text-primary)'
              }}
            >
              {item.category}
            </span>
            {item.featured && (
              <span
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 4,
                  padding: '5px 11px',
                  borderRadius: 999,
                  background: 'var(--accent-soft)',
                  color: 'var(--accent)',
                  fontSize: 11.5,
                  fontWeight: 800
                }}
              >
                <Sparkles size={12} /> Pilihan Utama
              </span>
            )}
          </div>

          <div
            style={{
              width: 48,
              height: 48,
              borderRadius: 16,
              background: 'var(--accent-soft)',
              color: 'var(--accent)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: 12,
              position: 'relative',
              zIndex: 1
            }}
          >
            <Coffee size={24} />
          </div>

          <h3
            style={{
              fontSize: 21,
              fontWeight: 800,
              letterSpacing: '-0.02em',
              lineHeight: 1.22,
              color: 'var(--text-primary)',
              position: 'relative',
              zIndex: 1
            }}
          >
            {item.name}
          </h3>

          <p
            style={{
              fontSize: 13.5,
              lineHeight: 1.48,
              color: 'var(--text-secondary)',
              marginTop: 7,
              position: 'relative',
              zIndex: 1
            }}
          >
            {item.desc || 'Racikan kopi dan minuman spesial pilihan 1001 SK.'}
          </p>

          <div
            style={{
              marginTop: 15,
              paddingTop: 12,
              borderTop: '1px solid var(--border-hairline)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              position: 'relative',
              zIndex: 1
            }}
          >
            <span style={{ fontSize: 19, fontWeight: 800, color: 'var(--accent)' }}>
              {soldOut ? 'Stok Habis' : formatRupiah(item.price)}
            </span>
            <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)' }}>
              {soldOut ? 'Tidak tersedia' : 'Siap diracik'}
            </span>
          </div>
        </div>

        {/* Bottom Floating Frosted Glass Action Menu (Cupertino Style) */}
        <div className={`peek-menu-card refractive-glass ${closing ? 'is-closing' : ''}`}>
          {/* Top Prominent Action Block */}
          <button
            type="button"
            className="peek-primary-btn"
            disabled={soldOut}
            style={{ opacity: soldOut ? 0.5 : 1 }}
            onClick={() => {
              if (soldOut) return;
              playTapHaptic();
              triggerClose(() => onAddToCart && onAddToCart(item));
            }}
          >
            <ShoppingBag size={20} style={{ color: 'var(--accent)' }} />
            <span>Tambah ke Keranjang</span>
          </button>

          <div className="peek-divider" />

          {/* Staggered Secondary Menu Rows */}
          <button
            type="button"
            className="peek-menu-row"
            style={{ '--stagger': 1, opacity: soldOut ? 0.5 : 1 }}
            disabled={soldOut}
            onClick={() => {
              if (soldOut) return;
              playTapHaptic();
              triggerClose(() => onOrderNow && onOrderNow(item));
            }}
          >
            <Zap size={18} style={{ color: '#ff9f0a' }} />
            <span>Pesan Langsung Sekarang</span>
          </button>

          <button
            type="button"
            className="peek-menu-row"
            style={{ '--stagger': 2 }}
            onClick={() => {
              playTapHaptic();
              triggerClose(() => onShareProduct && onShareProduct(item));
            }}
          >
            <Share2 size={18} style={{ color: '#0a84ff' }} />
            <span>Bagikan Menu</span>
          </button>

          <button
            type="button"
            className="peek-menu-row"
            style={{ '--stagger': 3 }}
            onClick={() => {
              playTapHaptic();
              triggerClose(() => onFilterCategory && onFilterCategory(item.category));
            }}
          >
            <Layers size={18} style={{ color: '#30d158' }} />
            <span>Filter Kategori: {item.category}</span>
          </button>

          <div className="peek-divider" />

          <button
            type="button"
            className="peek-menu-row"
            style={{ '--stagger': 4, color: 'var(--text-secondary)' }}
            onClick={() => {
              playTapHaptic();
              triggerClose();
            }}
          >
            <X size={18} />
            <span>Tutup Pratinjau</span>
          </button>
        </div>
      </div>
    </div>
  );
}
