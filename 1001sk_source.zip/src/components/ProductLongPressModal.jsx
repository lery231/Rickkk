import React, { useState, useEffect } from 'react';
import { ShoppingBag, Zap, Share2, Layers, X } from 'lucide-react';
import { DEFAULT_MENU_IMAGE, formatRupiah } from '../utils/constants.js';
import { playTapHaptic } from '../utils/soundEffects.js';

export default function ProductLongPressModal({
  item,
  onClose,
  onAddToCart,
  onOrderNow,
  onFilterCategory,
  onShareProduct
}) {
  const [closing, setClosing] = useState(false);

  useEffect(() => {
    setClosing(false);
  }, [item]);

  if (!item) return null;

  const triggerClose = (callback) => {
    setClosing(true);
    window.setTimeout(() => {
      setClosing(false);
      if (callback) callback();
      onClose();
    }, 220);
  };

  const soldOut = item.available === false;

  return (
    <div
      className={`peek-backdrop ${closing ? 'is-closing' : ''}`}
      onClick={() => triggerClose()}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div className="peek-container" onClick={(e) => e.stopPropagation()}>
        {/* Top Floating Cupertino Product Preview Card with Product Photo */}
        <div
          className={`peek-preview-card refractive-glass ${closing ? 'is-closing' : ''}`}
          style={{ padding: 0, overflow: 'hidden' }}
        >
          <div style={{ position: 'relative', width: '100%', height: 185, background: 'var(--bg-subtle)' }}>
            <img
              src={item.image || DEFAULT_MENU_IMAGE}
              alt={item.name}
              onError={(e) => {
                e.currentTarget.src = DEFAULT_MENU_IMAGE;
              }}
              style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
            />
            <div
              style={{
                position: 'absolute',
                top: 12,
                left: 12,
                display: 'flex',
                gap: 6,
                zIndex: 2
              }}
            >
              <span className="hero-badge">{item.category}</span>
              {item.featured && <span className="hero-badge">Pilihan Utama</span>}
            </div>
          </div>

          <div style={{ padding: '16px 18px 18px', position: 'relative', zIndex: 1 }}>
            <h3 style={{ fontSize: 19, fontWeight: 800, lineHeight: 1.24, color: 'var(--text-primary)' }}>
              {item.name}
            </h3>
            <p style={{ fontSize: 13, lineHeight: 1.44, color: 'var(--text-secondary)', marginTop: 6 }}>
              {item.desc || 'Racikan kopi dan minuman spesial pilihan 1001 SK.'}
            </p>
            <div
              style={{
                marginTop: 14,
                paddingTop: 12,
                borderTop: '1px solid var(--border-hairline)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              <span style={{ fontSize: 18, fontWeight: 800, color: 'var(--accent)' }}>
                {soldOut ? 'Stok Habis' : formatRupiah(item.price)}
              </span>
              <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)' }}>
                {soldOut ? 'Tidak tersedia' : 'Siap diracik'}
              </span>
            </div>
          </div>
        </div>

        {/* Bottom Floating Frosted Glass Action Menu (Cupertino Style) */}
        <div
          className={`peek-menu-card refractive-glass ${closing ? 'is-closing' : ''}`}
          style={{ alignSelf: 'center' }}
        >
          <button
            type="button"
            className="peek-primary-btn"
            disabled={soldOut}
            onClick={() => {
              if (soldOut) return;
              playTapHaptic();
              triggerClose(() => onAddToCart && onAddToCart(item));
            }}
          >
            <ShoppingBag size={20} style={{ color: 'var(--accent)' }} />
            <span>Tambah ke Keranjang</span>
          </button>

          <div className="peek-divider" />

          <button
            type="button"
            className="peek-menu-row"
            style={{ '--stagger': 0 }}
            disabled={soldOut}
            onClick={() => {
              if (soldOut) return;
              playTapHaptic();
              triggerClose(() => onOrderNow && onOrderNow(item));
            }}
          >
            <Zap size={17} style={{ color: '#ff9f0a' }} />
            <span>Pesan Langsung Sekarang</span>
          </button>

          <button
            type="button"
            className="peek-menu-row"
            style={{ '--stagger': 1 }}
            onClick={() => {
              playTapHaptic();
              triggerClose(() => onShareProduct && onShareProduct(item));
            }}
          >
            <Share2 size={17} style={{ color: '#0a84ff' }} />
            <span>Bagikan Menu</span>
          </button>

          <button
            type="button"
            className="peek-menu-row"
            style={{ '--stagger': 2 }}
            onClick={() => {
              playTapHaptic();
              triggerClose(() => onFilterCategory && onFilterCategory(item.category));
            }}
          >
            <Layers size={17} style={{ color: '#30d158' }} />
            <span>Filter Kategori: {item.category}</span>
          </button>

          <div className="peek-divider" />

          <button
            type="button"
            className="peek-menu-row"
            style={{ '--stagger': 3, color: '#ff453a' }}
            onClick={() => {
              playTapHaptic();
              triggerClose();
            }}
          >
            <X size={17} />
            <span>Tutup Pratinjau</span>
          </button>
        </div>
      </div>
    </div>
  );
}
