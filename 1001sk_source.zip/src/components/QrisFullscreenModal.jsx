import React, { useState } from 'react';
import { CheckCircle2, Copy, Download, QrCode, Share2, X } from 'lucide-react';
import { Capacitor } from '@capacitor/core';
import { Share } from '@capacitor/share';
import { formatRupiah } from '../utils/constants.js';
import { saveDataUrlImage } from '../utils/saveImage.js';
import { isValidImageSrc } from '../utils/securityGuard.js';

export default function QrisFullscreenModal({ order, qrisImage, onConfirmPaid, onClose }) {
  const [copied, setCopied] = useState(false);
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState('');

  if (!order) return null;

  const fallbackQr = `https://api.qrserver.com/v1/create-qr-code/?size=420x420&data=${encodeURIComponent(
    `1001SK|${order.id}|${order.total}`
  )}`;
  const activeQrSrc = isValidImageSrc(qrisImage) ? qrisImage : fallbackQr;

  const handleCopyNominal = async () => {
    try {
      await navigator.clipboard.writeText(String(order.total));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setFeedback(`Nominal: ${formatRupiah(order.total)}`);
    }
  };

  const handleSaveQris = async () => {
    setSaving(true);
    try {
      if (activeQrSrc.startsWith('data:image/')) {
        const res = await saveDataUrlImage(activeQrSrc, `QRIS-1001SK-${order.id}.png`);
        setFeedback(res.mode === 'native' ? 'QRIS tersimpan di folder Documents!' : 'QRIS berhasil diunduh!');
      } else {
        window.open(activeQrSrc, '_blank', 'noopener,noreferrer');
        setFeedback('Gambar QRIS dibuka.');
      }
    } catch (err) {
      setFeedback(err.message || 'Gagal menyimpan QRIS');
    } finally {
      setSaving(false);
    }
  };

  const handleShare = async () => {
    const text = `Pembayaran 1001 SK (${order.id}) sebesar ${formatRupiah(order.total)}`;
    try {
      if (Capacitor.isNativePlatform()) {
        await Share.share({ title: 'QRIS 1001 SK', text });
      } else if (navigator.share) {
        await navigator.share({ title: 'QRIS 1001 SK', text });
      } else {
        await handleCopyNominal();
      }
    } catch {
      // user cancelled share
    }
  };

  return (
    <div className="glass-modal-backdrop" onClick={onClose}>
      <div className="glass-sheet qris-fullscreen-card" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-handle" />
        <div className="row-between" style={{ marginBottom: 14 }}>
          <div className="row-gap">
            <QrCode size={20} />
            <strong>Pembayaran QRIS Penuh</strong>
          </div>
          <button className="icon-pill-btn" onClick={onClose} aria-label="Tutup QRIS">
            <X size={18} />
          </button>
        </div>

        <div className="qris-amount-banner">
          <span className="muted-xs">Total Tagihan • {order.id}</span>
          <div className="qris-nominal">{formatRupiah(order.total)}</div>
          <span className="muted-xs">A/N 1001 SK Coffee & Lounge</span>
        </div>

        <div className="qris-frame">
          <img src={activeQrSrc} alt="Kode QRIS 1001 SK" className="qris-image" />
        </div>

        {feedback && <div className="inline-toast">{feedback}</div>}

        <div className="qris-actions-grid">
          <button className="glass-btn secondary" onClick={handleCopyNominal}>
            <Copy size={16} />
            <span>{copied ? 'Tersalin!' : 'Salin Nominal'}</span>
          </button>
          <button className="glass-btn secondary" onClick={handleSaveQris} disabled={saving}>
            <Download size={16} />
            <span>{saving ? 'Menyimpan...' : 'Simpan QRIS'}</span>
          </button>
          <button className="glass-btn secondary" onClick={handleShare}>
            <Share2 size={16} />
            <span>Bagikan</span>
          </button>
        </div>

        <button
          className="glass-btn primary full-width"
          style={{ marginTop: 14 }}
          onClick={() => onConfirmPaid(order.id)}
        >
          <CheckCircle2 size={18} />
          <span>Saya Sudah Bayar</span>
        </button>
      </div>
    </div>
  );
}
