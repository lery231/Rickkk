import React, { useState, useMemo } from 'react';
import {
  ChevronRight,
  Plus,
  Minus,
  Trash2,
  QrCode,
  CheckCircle2,
  Sparkles,
  Download,
  Copy,
  Share2,
  MoreHorizontal,
  X,
  Search,
  ShoppingBag,
  Receipt
} from 'lucide-react';
import {
  DEFAULT_MENU_IMAGE,
  MENU_CATEGORIES,
  ORDER_STATUS_META,
  formatRupiah,
  formatDateTime
} from '../utils/constants.js';
import { saveDataUrlImage } from '../utils/saveImage.js';
import { useSheetSwipeDismiss } from '../hooks/useSheetSwipeDismiss.js';
import { useLongPress } from '../hooks/useLongPress.js';
import { playTapHaptic, playPeekHaptic } from '../utils/soundEffects.js';
import ProductLongPressModal from './ProductLongPressModal.jsx';

const MOOD_TILES = [
  {
    title: 'Pagi Produktif',
    cat: 'Signature Coffee',
    bg: 'linear-gradient(135deg, rgba(245, 158, 11, 0.88) 0%, rgba(180, 83, 9, 0.94) 100%)'
  },
  {
    title: 'Manual Brew',
    cat: 'Manual Brew',
    bg: 'linear-gradient(135deg, rgba(55, 65, 81, 0.88) 0%, rgba(17, 24, 39, 0.94) 100%)'
  },
  {
    title: 'Dingin & Segar',
    cat: 'Cold Brew & Mocktail',
    bg: 'linear-gradient(135deg, rgba(2, 132, 199, 0.88) 0%, rgba(3, 105, 161, 0.94) 100%)'
  },
  {
    title: 'Matcha & Santai',
    cat: 'Non-Coffee',
    bg: 'linear-gradient(135deg, rgba(22, 163, 74, 0.88) 0%, rgba(21, 128, 61, 0.94) 100%)'
  }
];

function InteractiveProductCard({ item, variant, index, onQuickAdd, onLongPressOpen }) {
  const soldOut = item.available === false;
  const imgSrc = item.image || DEFAULT_MENU_IMAGE;

  const pressBind = useLongPress({
    delay: 360,
    onLongPress: () => {
      playPeekHaptic();
      onLongPressOpen(item);
    },
    onClick: () => {
      if (soldOut) return;
      playTapHaptic();
      onQuickAdd(item);
    }
  });

  if (variant === 'hero') {
    return (
      <div
        className="hero-card card-stagger-in"
        style={{ '--stagger': index }}
        {...pressBind}
      >
        <img
          src={imgSrc}
          alt={item.name}
          loading="lazy"
          onError={(e) => {
            e.currentTarget.src = DEFAULT_MENU_IMAGE;
          }}
        />
        <span className="hero-badge">{item.category}</span>
        <div className="hero-card-overlay">
          <div className="hero-title">{item.name}</div>
          <div className="hero-sub">
            {formatRupiah(item.price)} • Ketuk pesan / tahan opsi
          </div>
        </div>
      </div>
    );
  }

  if (variant === 'speed') {
    return (
      <div
        className="speed-row card-stagger-in"
        style={{ '--stagger': index, opacity: soldOut ? 0.55 : 1 }}
        {...pressBind}
      >
        <img
          src={imgSrc}
          alt={item.name}
          className="speed-thumb"
          loading="lazy"
          onError={(e) => {
            e.currentTarget.src = DEFAULT_MENU_IMAGE;
          }}
        />
        <div className="speed-info">
          <div className="speed-name">{item.name}</div>
          <div className="speed-meta">
            {formatRupiah(item.price)} • {item.category}
          </div>
        </div>
        <button
          type="button"
          className="speed-add-btn glass-pressable"
          disabled={soldOut}
          aria-label={`Tambah ${item.name}`}
        >
          <Plus size={18} />
        </button>
      </div>
    );
  }

  return (
    <div
      className="menu-card card-stagger-in"
      style={{ '--stagger': index, opacity: soldOut ? 0.55 : 1 }}
      {...pressBind}
    >
      <div className="menu-card-img-wrap">
        <img
          src={imgSrc}
          alt={item.name}
          loading="lazy"
          onError={(e) => {
            e.currentTarget.src = DEFAULT_MENU_IMAGE;
          }}
        />
        <button
          type="button"
          className="refractive-glass"
          aria-label={`Tambah ${item.name}`}
          style={{
            position: 'absolute',
            right: 9,
            bottom: 9,
            width: 34,
            height: 34,
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--text-primary)',
            cursor: 'pointer'
          }}
        >
          <Plus size={17} style={{ position: 'relative', zIndex: 1 }} />
        </button>
      </div>
      <div className="menu-card-body">
        <div className="menu-card-title">{item.name}</div>
        <div className="menu-card-price">
          {soldOut ? 'Habis' : formatRupiah(item.price)}
        </div>
      </div>
    </div>
  );
}

export default function CustomerView({
  activeTab,
  tabDirection,
  setActiveTab,
  menuItems,
  cart,
  onAddToCart,
  onUpdateCartQty,
  onClearCart,
  onSubmitOrder,
  orders,
  onHideOrderHistory,
  onClearAllOrderHistory,
  onConfirmPaymentSelf,
  qrisImageUrl,
  storeName,
  selectedOrder,
  setSelectedOrder,
  searchOpen,
  setSearchOpen,
  userProfile
}) {
  const [selectedCategory, setSelectedCategory] = useState('Semua');
  const [searchText, setSearchText] = useState('');
  const [customerName, setCustomerName] = useState(userProfile?.name || '');
  const [tableNumber, setTableNumber] = useState('');
  const [orderNote, setOrderNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [peekProduct, setPeekProduct] = useState(null);
  const [qrisTab, setQrisTab] = useState('qris');
  const [popoverOpen, setPopoverOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState('');

  const showToast = (msg) => {
    setToastMsg(msg);
    window.setTimeout(() => setToastMsg(''), 2600);
  };

  const featuredItems = useMemo(
    () => menuItems.filter((m) => m.featured && m.available !== false),
    [menuItems]
  );

  const filteredMenu = useMemo(() => {
    return menuItems.filter((item) => {
      const catOk = selectedCategory === 'Semua' || item.category === selectedCategory;
      const q = searchText.trim().toLowerCase();
      const searchOk =
        !q ||
        item.name?.toLowerCase().includes(q) ||
        item.category?.toLowerCase().includes(q) ||
        item.desc?.toLowerCase().includes(q);
      return catOk && searchOk;
    });
  }, [menuItems, selectedCategory, searchText]);

  const searchResults = useMemo(() => {
    const q = searchText.trim().toLowerCase();
    if (!q) return menuItems.slice(0, 8);
    return menuItems.filter(
      (item) =>
        item.name?.toLowerCase().includes(q) ||
        item.category?.toLowerCase().includes(q) ||
        item.desc?.toLowerCase().includes(q)
    );
  }, [menuItems, searchText]);

  const cartTotal = useMemo(
    () => cart.reduce((sum, item) => sum + Number(item.price || 0) * Number(item.qty || 1), 0),
    [cart]
  );

  const visibleOrders = useMemo(
    () => orders.filter((o) => !o.hiddenByCustomer),
    [orders]
  );

  const qrisDismiss = useSheetSwipeDismiss({
    onDismiss: () => {
      setPopoverOpen(false);
      setSelectedOrder(null);
    },
    enabled: Boolean(selectedOrder)
  });

  const handleCheckout = async (e) => {
    e.preventDefault();
    if (!cart.length || submitting) return;
    setSubmitting(true);
    try {
      const created = await onSubmitOrder({
        customerName: customerName.trim() || userProfile?.name || 'Pelanggan',
        tableNumber: tableNumber.trim() || 'Takeaway',
        note: orderNote.trim(),
        items: cart,
        totalPrice: cartTotal
      });
      if (created) {
        setOrderNote('');
        setActiveTab('orders');
        setSelectedOrder(created);
        setQrisTab('qris');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const activeQrisSrc =
    qrisImageUrl ||
    `https://api.qrserver.com/v1/create-qr-code/?size=460x460&data=1001SK-COFFEE-${selectedOrder?.totalPrice || 0}`;

  const handleSaveQris = async () => {
    try {
      if (activeQrisSrc.startsWith('data:image/')) {
        await saveDataUrlImage(
          activeQrisSrc,
          `QRIS-1001SK-${selectedOrder?.id?.slice(-5) || 'PAY'}.png`
        );
        showToast('Kode QRIS disimpan ke perangkat');
        setPopoverOpen(false);
        return;
      }
      const res = await fetch(activeQrisSrc);
      const blob = await res.blob();
      const reader = new FileReader();
      reader.onloadend = async () => {
        await saveDataUrlImage(
          reader.result,
          `QRIS-1001SK-${selectedOrder?.id?.slice(-5) || 'PAY'}.png`
        );
        showToast('Kode QRIS disimpan ke perangkat');
        setPopoverOpen(false);
      };
      reader.readAsDataURL(blob);
    } catch {
      showToast('Gagal menyimpan otomatis, silakan screenshot QRIS');
      setPopoverOpen(false);
    }
  };

  const handleCopyTotal = async () => {
    try {
      await navigator.clipboard.writeText(String(selectedOrder?.totalPrice || 0));
      showToast(`Nominal ${formatRupiah(selectedOrder?.totalPrice)} disalin`);
    } catch {
      showToast('Nominal disalin');
    }
    setPopoverOpen(false);
  };

  const handleShareProduct = async (item) => {
    const text = `${item.name} (${formatRupiah(item.price)}) — ${item.desc || ''} di ${storeName || '1001 SK Coffee'}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: item.name, text });
      } else {
        await navigator.clipboard.writeText(text);
        showToast('Info menu disalin ke papan klip');
      }
    } catch {
      // ignore cancel
    }
  };

  const handleShareOrder = async () => {
    const text = `Pesanan ${storeName || '1001 SK'} • Total ${formatRupiah(selectedOrder?.totalPrice || 0)}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: '1001 SK Coffee', text });
      } else {
        await navigator.clipboard.writeText(text);
        showToast('Detail pesanan disalin');
      }
    } catch {
      // ignore cancel
    }
    setPopoverOpen(false);
  };

  const tabAnimClass = tabDirection === 'left' ? 'tab-slide-left' : 'tab-slide-right';

  return (
    <>
      {toastMsg && (
        <div
          className="toast-spring-in"
          style={{
            position: 'fixed',
            top: 'calc(env(safe-area-inset-top, 12px) + 56px)',
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 185
          }}
        >
          <div
            className="refractive-glass"
            style={{
              padding: '9px 18px',
              borderRadius: 999,
              fontSize: 13,
              fontWeight: 700,
              color: 'var(--text-primary)'
            }}
          >
            <span style={{ position: 'relative', zIndex: 1 }}>{toastMsg}</span>
          </div>
        </div>
      )}

      {activeTab === 'home' && (
        <div key="tab-home" className={tabAnimClass}>
          <div className="ios-pills">
            {MENU_CATEGORIES.map((cat) => (
              <button
                key={cat}
                type="button"
                className={`ios-pill ${selectedCategory === cat ? 'active' : ''}`}
                onClick={() => {
                  playTapHaptic();
                  setSelectedCategory(cat);
                }}
              >
                {cat}
              </button>
            ))}
          </div>

          {selectedCategory === 'Semua' && featuredItems.length > 0 && (
            <>
              <div className="section-header">
                <h2 className="section-title">
                  Pilihan Hari Ini
                  <ChevronRight size={20} style={{ color: 'var(--text-secondary)' }} />
                </h2>
              </div>
              <div className="h-scroll">
                {featuredItems.map((item, idx) => (
                  <InteractiveProductCard
                    key={item.id}
                    item={item}
                    variant="hero"
                    index={idx}
                    onQuickAdd={(prod) => {
                      onAddToCart(prod);
                      showToast(`${prod.name} masuk keranjang`);
                    }}
                    onLongPressOpen={(prod) => setPeekProduct(prod)}
                  />
                ))}
              </div>
            </>
          )}

          <div className="section-header">
            <h2 className="section-title">Pesan Cepat</h2>
            <button
              type="button"
              className="section-action"
              onClick={() => setActiveTab('cart')}
            >
              Keranjang ({cart.reduce((s, i) => s + i.qty, 0)})
            </button>
          </div>
          <div className="speed-list">
            {filteredMenu.slice(0, 5).map((item, idx) => (
              <InteractiveProductCard
                key={item.id}
                item={item}
                variant="speed"
                index={idx}
                onQuickAdd={(prod) => {
                  onAddToCart(prod);
                  showToast(`+1 ${prod.name}`);
                }}
                onLongPressOpen={(prod) => setPeekProduct(prod)}
              />
            ))}
          </div>

          {selectedCategory === 'Semua' && (
            <>
              <div className="section-header" style={{ marginTop: 8 }}>
                <h2 className="section-title">
                  Suasana & Kategori
                  <ChevronRight size={20} style={{ color: 'var(--text-secondary)' }} />
                </h2>
              </div>
              <div className="genre-grid">
                {MOOD_TILES.map((tile, idx) => (
                  <div
                    key={tile.title}
                    className="genre-tile card-stagger-in"
                    style={{ '--stagger': idx, background: tile.bg }}
                    onClick={() => {
                      playTapHaptic();
                      setSelectedCategory(tile.cat);
                    }}
                  >
                    <span>{tile.title}</span>
                  </div>
                ))}
              </div>
            </>
          )}

          <div className="section-header">
            <h2 className="section-title">
              {selectedCategory === 'Semua' ? 'Semua Menu' : selectedCategory}
            </h2>
          </div>
          <div className="menu-grid">
            {filteredMenu.map((item, idx) => (
              <InteractiveProductCard
                key={item.id}
                item={item}
                variant="grid"
                index={idx}
                onQuickAdd={(prod) => {
                  onAddToCart(prod);
                  showToast(`+1 ${prod.name}`);
                }}
                onLongPressOpen={(prod) => setPeekProduct(prod)}
              />
            ))}
          </div>
        </div>
      )}

      {activeTab === 'cart' && (
        <div key="tab-cart" className={tabAnimClass} style={{ padding: '4px 18px 20px' }}>
          {cart.length === 0 ? (
            <div
              className="ios-grouped-card"
              style={{ padding: '36px 20px', textAlign: 'center', marginTop: 8 }}
            >
              <ShoppingBag size={38} style={{ color: 'var(--text-tertiary)', marginBottom: 10 }} />
              <div style={{ fontSize: 17, fontWeight: 800 }}>Keranjang Masih Kosong</div>
              <p style={{ fontSize: 13.5, color: 'var(--text-secondary)', marginTop: 4, marginBottom: 18 }}>
                Pilih menu kopi favorit Anda di Beranda untuk mulai memesan.
              </p>
              <button
                type="button"
                className="btn-ios-primary"
                style={{ maxWidth: 210 }}
                onClick={() => setActiveTab('home')}
              >
                Lihat Menu
              </button>
            </div>
          ) : (
            <>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                <span style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text-secondary)' }}>
                  {cart.reduce((s, i) => s + i.qty, 0)} Item Dipilih
                </span>
                <button
                  type="button"
                  onClick={onClearCart}
                  style={{
                    border: 'none',
                    background: 'transparent',
                    color: '#ff453a',
                    fontSize: 13,
                    fontWeight: 700,
                    cursor: 'pointer'
                  }}
                >
                  Kosongkan
                </button>
              </div>

              <div className="ios-grouped-card" style={{ marginBottom: 16 }}>
                {cart.map((item) => (
                  <div
                    key={item.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 12,
                      padding: '12px 14px',
                      borderBottom: '1px solid var(--border-hairline)'
                    }}
                  >
                    <img
                      src={item.image || DEFAULT_MENU_IMAGE}
                      alt={item.name}
                      onError={(e) => {
                        e.currentTarget.src = DEFAULT_MENU_IMAGE;
                      }}
                      style={{ width: 52, height: 52, borderRadius: 12, objectFit: 'cover', flexShrink: 0 }}
                    />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 14.5, fontWeight: 700 }}>{item.name}</div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--accent)', marginTop: 2 }}>
                        {formatRupiah(item.price * item.qty)}
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <button
                        type="button"
                        className="speed-add-btn glass-pressable"
                        onClick={() => onUpdateCartQty(item.id, item.qty - 1)}
                      >
                        <Minus size={15} />
                      </button>
                      <span style={{ fontSize: 14, fontWeight: 800, minWidth: 18, textAlign: 'center' }}>
                        {item.qty}
                      </span>
                      <button
                        type="button"
                        className="speed-add-btn glass-pressable"
                        onClick={() => onUpdateCartQty(item.id, item.qty + 1)}
                      >
                        <Plus size={15} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <form onSubmit={handleCheckout} className="ios-grouped-card" style={{ padding: 16 }}>
                <div style={{ fontSize: 15, fontWeight: 800, marginBottom: 12 }}>Detail Pemesan</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  <input
                    className="ios-input"
                    type="text"
                    placeholder="Nama Pemesan"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    required
                  />
                  <input
                    className="ios-input"
                    type="text"
                    placeholder="Nomor Meja / Takeaway (Contoh: Meja 04)"
                    value={tableNumber}
                    onChange={(e) => setTableNumber(e.target.value)}
                  />
                  <input
                    className="ios-input"
                    type="text"
                    placeholder="Catatan (Contoh: Less sugar, es terpisah)"
                    value={orderNote}
                    onChange={(e) => setOrderNote(e.target.value)}
                  />
                </div>

                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginTop: 16,
                    paddingTop: 14,
                    borderTop: '1px solid var(--border-hairline)'
                  }}
                >
                  <span style={{ fontSize: 14, color: 'var(--text-secondary)', fontWeight: 600 }}>
                    Total Pembayaran
                  </span>
                  <span style={{ fontSize: 20, fontWeight: 800, color: 'var(--text-primary)' }}>
                    {formatRupiah(cartTotal)}
                  </span>
                </div>

                <button type="submit" className="btn-ios-primary" style={{ marginTop: 14 }} disabled={submitting}>
                  <QrCode size={18} />
                  {submitting ? 'Membuat Pesanan...' : 'Pesan & Bayar QRIS'}
                </button>
              </form>
            </>
          )}
        </div>
      )}

      {activeTab === 'orders' && (
        <div key="tab-orders" className={tabAnimClass} style={{ padding: '4px 18px 20px' }}>
          {visibleOrders.length > 0 && (
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
              <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)' }}>
                {visibleOrders.length} Riwayat Pesanan
              </span>
              <button
                type="button"
                onClick={onClearAllOrderHistory}
                style={{
                  border: 'none',
                  background: 'transparent',
                  color: '#ff453a',
                  fontSize: 13,
                  fontWeight: 700,
                  cursor: 'pointer'
                }}
              >
                Hapus Semua Riwayat
              </button>
            </div>
          )}

          {visibleOrders.length === 0 ? (
            <div
              className="ios-grouped-card"
              style={{ padding: '36px 20px', textAlign: 'center', marginTop: 8 }}
            >
              <Receipt size={38} style={{ color: 'var(--text-tertiary)', marginBottom: 10 }} />
              <div style={{ fontSize: 17, fontWeight: 800 }}>Belum Ada Pesanan</div>
              <p style={{ fontSize: 13.5, color: 'var(--text-secondary)', marginTop: 4 }}>
                Pesanan aktif dan kartu pembayaran QRIS Anda tampil di sini.
              </p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {visibleOrders.map((order, idx) => {
                const meta = ORDER_STATUS_META[order.status] || ORDER_STATUS_META.queued;
                return (
                  <div
                    key={order.id}
                    className="ios-grouped-card glass-pressable card-stagger-in"
                    onClick={() => {
                      setSelectedOrder(order);
                      setQrisTab('qris');
                    }}
                    style={{ '--stagger': idx, padding: 15, cursor: 'pointer' }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span
                        style={{
                          padding: '4px 11px',
                          borderRadius: 999,
                          background: meta.bg,
                          color: meta.color,
                          fontSize: 12,
                          fontWeight: 800
                        }}
                      >
                        {meta.label}
                      </span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                          {formatDateTime(order.createdAt)}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onHideOrderHistory(order.id);
                          }}
                          aria-label="Hapus riwayat"
                          style={{
                            width: 28,
                            height: 28,
                            borderRadius: '50%',
                            border: 'none',
                            background: 'var(--bg-subtle)',
                            color: '#ff453a',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: 'pointer'
                          }}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>

                    <div style={{ fontSize: 15.5, fontWeight: 800, marginTop: 10 }}>
                      {order.customerName} • {order.tableNumber || 'Takeaway'}
                    </div>
                    <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 3 }}>
                      {(order.items || []).map((i) => `${i.qty}x ${i.name}`).join(', ')}
                    </div>

                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginTop: 12,
                        paddingTop: 10,
                        borderTop: '1px solid var(--border-hairline)'
                      }}
                    >
                      <span style={{ fontSize: 15, fontWeight: 800, color: 'var(--accent)' }}>
                        {formatRupiah(order.totalPrice)}
                      </span>
                      <span
                        style={{
                          fontSize: 12.5,
                          fontWeight: 700,
                          color: 'var(--text-primary)',
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: 4
                        }}
                      >
                        Buka Kartu QRIS <ChevronRight size={15} />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Search Sheet */}
      {searchOpen && (
        <div className="sheet-backdrop" onClick={() => setSearchOpen(false)}>
          <div
            className="sheet-panel"
            onClick={(e) => e.stopPropagation()}
            style={{ height: '86vh', padding: '0 18px 24px' }}
          >
            <div className="sheet-grabber" />
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 8, marginBottom: 14 }}>
              <div
                className="refractive-glass"
                style={{
                  flex: 1,
                  height: 46,
                  borderRadius: 999,
                  padding: '0 15px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 9
                }}
              >
                <Search size={18} style={{ color: 'var(--text-secondary)', position: 'relative', zIndex: 1 }} />
                <input
                  type="text"
                  autoFocus
                  placeholder="Cari kopi, matcha, pastry..."
                  value={searchText}
                  onChange={(e) => setSearchText(e.target.value)}
                  style={{
                    flex: 1,
                    border: 'none',
                    background: 'transparent',
                    color: 'var(--text-primary)',
                    fontSize: 15,
                    outline: 'none',
                    position: 'relative',
                    zIndex: 1
                  }}
                />
              </div>
              <button
                type="button"
                className="refractive-glass"
                onClick={() => setSearchOpen(false)}
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: 'var(--text-primary)',
                  cursor: 'pointer'
                }}
              >
                <X size={19} style={{ position: 'relative', zIndex: 1 }} />
              </button>
            </div>

            <div style={{ flex: 1, overflowY: 'auto' }}>
              {searchResults.map((item) => (
                <div
                  key={item.id}
                  className="speed-row"
                  onClick={() => {
                    onAddToCart(item);
                    showToast(`+1 ${item.name}`);
                    setSearchOpen(false);
                  }}
                >
                  <img
                    src={item.image || DEFAULT_MENU_IMAGE}
                    alt={item.name}
                    className="speed-thumb"
                    onError={(e) => {
                      e.currentTarget.src = DEFAULT_MENU_IMAGE;
                    }}
                  />
                  <div className="speed-info">
                    <div className="speed-name">{item.name}</div>
                    <div className="speed-meta">
                      {formatRupiah(item.price)} • {item.category}
                    </div>
                  </div>
                  <button type="button" className="speed-add-btn">
                    <Plus size={18} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Long-Press Product Peek & Pop Modal */}
      <ProductLongPressModal
        item={peekProduct}
        onClose={() => setPeekProduct(null)}
        onAddToCart={(prod) => {
          onAddToCart(prod);
          showToast(`${prod.name} masuk keranjang`);
        }}
        onOrderNow={(prod) => {
          onAddToCart(prod);
          setActiveTab('cart');
        }}
        onFilterCategory={(cat) => {
          setSelectedCategory(cat);
        }}
        onShareProduct={handleShareProduct}
      />

      {/* Full-Screen Atmospheric QRIS Payment Sheet */}
      {selectedOrder && (
        <div
          className="dark-qris-overlay"
          style={qrisDismiss.sheetStyle}
          {...qrisDismiss.sheetTouchProps}
        >
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 40, height: 5, borderRadius: 999, background: 'rgba(255, 255, 255, 0.34)' }} />
            <div
              className="dark-glass-pill"
              style={{ borderRadius: 999, padding: 3, display: 'inline-flex', alignItems: 'center', gap: 4 }}
            >
              <button
                type="button"
                onClick={() => setQrisTab('qris')}
                style={{
                  padding: '6px 18px',
                  borderRadius: 999,
                  border: 'none',
                  background: qrisTab === 'qris' ? 'rgba(255,255,255,0.24)' : 'transparent',
                  color: '#fff',
                  fontSize: 13,
                  fontWeight: 700,
                  cursor: 'pointer'
                }}
              >
                QRIS
              </button>
              <button
                type="button"
                onClick={() => setQrisTab('detail')}
                style={{
                  padding: '6px 18px',
                  borderRadius: 999,
                  border: 'none',
                  background: qrisTab === 'detail' ? 'rgba(255,255,255,0.24)' : 'transparent',
                  color: '#fff',
                  fontSize: 13,
                  fontWeight: 700,
                  cursor: 'pointer'
                }}
              >
                Rincian
              </button>
            </div>
          </div>

          {popoverOpen && (
            <div className="dark-glass-popover" onClick={(e) => e.stopPropagation()}>
              <div className="popover-tile-grid">
                <button type="button" className="popover-tile" onClick={handleSaveQris}>
                  <Download size={18} />
                  <span>Simpan</span>
                </button>
                <button type="button" className="popover-tile" onClick={handleCopyTotal}>
                  <Copy size={18} />
                  <span>Salin</span>
                </button>
                <button type="button" className="popover-tile" onClick={handleShareOrder}>
                  <Share2 size={18} />
                  <span>Bagikan</span>
                </button>
              </div>
              {selectedOrder.status === 'pending_payment' && (
                <button
                  type="button"
                  className="popover-menu-row"
                  onClick={() => {
                    onConfirmPaymentSelf(selectedOrder.id);
                    setPopoverOpen(false);
                    showToast('Konfirmasi pembayaran dikirim');
                  }}
                >
                  <CheckCircle2 size={18} style={{ color: '#30d158' }} />
                  <span>Konfirmasi Sudah Bayar</span>
                </button>
              )}
              <button
                type="button"
                className="popover-menu-row"
                onClick={() => {
                  setPopoverOpen(false);
                  setSelectedOrder(null);
                }}
              >
                <X size={18} />
                <span>Tutup Layar QRIS</span>
              </button>
            </div>
          )}

          <div
            style={{
              width: '100%',
              maxWidth: 336,
              margin: '0 auto',
              borderRadius: 26,
              background: '#ffffff',
              padding: 18,
              color: '#101218',
              boxShadow: '0 28px 60px rgba(0, 0, 0, 0.62)'
            }}
          >
            {qrisTab === 'qris' ? (
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 12, fontWeight: 800, color: '#fa2d48', letterSpacing: '0.06em' }}>
                  QRIS PEMBAYARAN • {storeName || '1001 SK'}
                </div>
                <img
                  src={activeQrisSrc}
                  alt="Kode QRIS 1001 SK"
                  style={{
                    width: '100%',
                    aspectRatio: '1 / 1',
                    objectFit: 'contain',
                    borderRadius: 16,
                    marginTop: 10,
                    background: '#f8fafc'
                  }}
                />
                <div style={{ fontSize: 22, fontWeight: 800, marginTop: 10 }}>
                  {formatRupiah(selectedOrder.totalPrice)}
                </div>
                <div style={{ fontSize: 12.5, color: '#5c6270', marginTop: 2 }}>
                  Scan dengan Dana, GoPay, OVO, ShopeePay, atau Mobile Banking
                </div>
              </div>
            ) : (
              <div>
                <div style={{ fontSize: 16, fontWeight: 800, marginBottom: 10 }}>Rincian Pesanan</div>
                {(selectedOrder.items || []).map((item, idx) => (
                  <div
                    key={idx}
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      padding: '8px 0',
                      borderBottom: '1px solid rgba(0,0,0,0.07)',
                      fontSize: 14
                    }}
                  >
                    <span>
                      {item.qty}x {item.name}
                    </span>
                    <strong>{formatRupiah(item.price * item.qty)}</strong>
                  </div>
                ))}
                {selectedOrder.note && (
                  <div style={{ fontSize: 12.5, color: '#5c6270', marginTop: 10 }}>
                    Catatan: {selectedOrder.note}
                  </div>
                )}
              </div>
            )}
          </div>

          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 20, fontWeight: 800 }}>{selectedOrder.customerName}</div>
                <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.74)' }}>
                  {ORDER_STATUS_META[selectedOrder.status]?.label || 'Menunggu'} •{' '}
                  {formatRupiah(selectedOrder.totalPrice)}
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <button
                  type="button"
                  className="dark-glass-pill glass-pressable"
                  onClick={handleSaveQris}
                  aria-label="Simpan QRIS"
                  style={{
                    width: 38,
                    height: 38,
                    borderRadius: '50%',
                    color: '#fff',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer'
                  }}
                >
                  <Download size={17} />
                </button>
                <button
                  type="button"
                  className="dark-glass-pill glass-pressable"
                  onClick={() => setPopoverOpen((v) => !v)}
                  aria-label="Opsi Lainnya"
                  style={{
                    width: 38,
                    height: 38,
                    borderRadius: '50%',
                    color: '#fff',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer'
                  }}
                >
                  <MoreHorizontal size={18} />
                </button>
              </div>
            </div>

            <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
              {selectedOrder.status === 'pending_payment' && (
                <button
                  type="button"
                  className="btn-ios-primary"
                  style={{ flex: 1 }}
                  onClick={() => {
                    onConfirmPaymentSelf(selectedOrder.id);
                    showToast('Pembayaran dikonfirmasi!');
                  }}
                >
                  <Sparkles size={17} /> Saya Sudah Bayar
                </button>
              )}
              <button
                type="button"
                className="dark-glass-pill glass-pressable"
                onClick={() => {
                  setPopoverOpen(false);
                  setSelectedOrder(null);
                }}
                style={{
                  flex: selectedOrder.status === 'pending_payment' ? 0.6 : 1,
                  height: 48,
                  borderRadius: 16,
                  color: '#fff',
                  fontSize: 14.5,
                  fontWeight: 700,
                  cursor: 'pointer'
                }}
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
