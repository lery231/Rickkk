import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot, addDoc, doc, query, orderBy } from 'firebase/firestore';

const DEFAULT_MENU = [
  { id: 'm1', name: 'Kopi Susu Gula Aren 1001', category: 'Signature', price: 18000, desc: 'Espresso double shot + gula aren organik & susu segar', img: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80', stock: true },
  { id: 'm2', name: 'Creamy Cold Brew SK', category: 'Signature', price: 22000, desc: 'Cold brew 12 jam disajikan dengan krim vanilla manis', img: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=400&q=80', stock: true },
  { id: 'm3', name: 'Americano Ice/Hot', category: 'Espresso', price: 15000, desc: 'Espresso murni dengan air mineral dingin/hangat', img: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=400&q=80', stock: true },
  { id: 'm4', name: 'Matcha Oat Latte', category: 'Non-Kopi', price: 24000, desc: 'Matcha Jepang premium dengan susu gandum (Oat)', img: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=400&q=80', stock: true },
  { id: 'm5', name: 'Croissant Butter Warm', category: 'Camilan', price: 18000, desc: 'Roti croissant renyah dengan mentega Prancis', img: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=400&q=80', stock: true },
  { id: 'm6', name: 'Roti Bakar Keju Coklat', category: 'Camilan', price: 16000, desc: 'Roti tawar tebal dipanggang melimpah keju dan meseres', img: 'https://images.unsplash.com/photo-1584776296944-ab6fb57b0bdd?w=400&q=80', stock: true },
];

export default function CustomerView({ cart, setCart, activeTab, user }) {
  const [menuList, setMenuList] = useState(DEFAULT_MENU);
  const [selectedCategory, setSelectedCategory] = useState('Semua');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [qrisModalOpen, setQrisModalOpen] = useState(false);
  const [sellerQrisImg, setSellerQrisImg] = useState(null);

  const [orders, setOrders] = useState([]);
  const [customerName, setCustomerName] = useState(user?.email ? user.email.split('@')[0] : '');
  const [tableNo, setTableNo] = useState('');
  const [orderType, setOrderType] = useState('Dine-In');
  const [paymentMethod, setPaymentMethod] = useState('QRIS');
  const [loadingOrder, setLoadingOrder] = useState(false);
  const [pendingOrderPayload, setPendingOrderPayload] = useState(null);

  useEffect(() => {
    const unsubMenu = onSnapshot(collection(db, 'menu'), (snap) => {
      if (!snap.empty) {
        const items = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setMenuList(items);
      }
    }, () => {});

    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    const unsubOrders = onSnapshot(q, (snap) => {
      const list = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setOrders(list);
    }, () => {});

    const unsubQris = onSnapshot(doc(db, 'settings', 'qris'), (docSnap) => {
      if (docSnap.exists()) {
        setSellerQrisImg(docSnap.data().qrisImage);
      }
    }, () => {});

    return () => {
      unsubMenu();
      unsubOrders();
      unsubQris();
    };
  }, []);

  const addToCart = (item) => {
    const exist = cart.find(c => c.id === item.id);
    if (exist) {
      setCart(cart.map(c => c.id === item.id ? { ...c, qty: c.qty + 1 } : c));
    } else {
      setCart([...cart, { ...item, qty: 1 }]);
    }
  };

  const updateQty = (id, delta) => {
    setCart(cart.map(c => {
      if (c.id === id) {
        const newQty = c.qty + delta;
        return newQty > 0 ? { ...c, qty: newQty } : null;
      }
      return c;
    }).filter(Boolean));
  };

  const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);

  const handleCheckoutInit = (e) => {
    e.preventDefault();
    if (cart.length === 0) return;

    const payload = {
      customerName: customerName || 'Pelanggan 1001 SK',
      tableNo: tableNo || 'Takeaway',
      orderType,
      paymentMethod,
      items: cart,
      totalPrice,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    if (paymentMethod === 'QRIS') {
      setPendingOrderPayload(payload);
      setIsCartOpen(false);
      setQrisModalOpen(true);
    } else {
      submitOrderToFirestore(payload);
    }
  };

  const submitOrderToFirestore = async (payload) => {
    setLoadingOrder(true);
    try {
      await addDoc(collection(db, 'orders'), payload);
      alert('Pesanan berhasil dibuat! Silakan tunggu konfirmasi penjual.');
      setCart([]);
      setIsCartOpen(false);
      setQrisModalOpen(false);
      setPendingOrderPayload(null);
    } catch (err) {
      alert('Gagal buat pesanan: ' + err.message);
    } finally {
      setLoadingOrder(false);
    }
  };

  const categories = ['Semua', 'Signature', 'Espresso', 'Non-Kopi', 'Camilan'];
  const filteredMenu = selectedCategory === 'Semua' 
    ? menuList 
    : menuList.filter(m => m.category === selectedCategory);

  return (
    <div>
      {activeTab === 'menu' && (
        <>
          <div className="ios-tabs">
            {categories.map(cat => (
              <button 
                key={cat} 
                className={`tab-btn ${selectedCategory === cat ? 'active' : ''}`}
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="menu-grid">
            {filteredMenu.map(item => (
              <div key={item.id} className="glass-panel menu-card">
                <img 
                  src={item.img || 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80'} 
                  alt={item.name} 
                  className="menu-img" 
                />
                <div>
                  <h4 className="menu-title">{item.name}</h4>
                  <p className="menu-desc">{item.desc}</p>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span className="menu-price">Rp {item.price.toLocaleString('id-ID')}</span>
                  <button className="btn-add" onClick={() => addToCart(item)}>+ Tambah</button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {activeTab === 'orders' && (
        <div style={{ padding: 20 }}>
          <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 16 }}>Status Pesanan Saya</h3>
          {orders.length === 0 ? (
            <div className="glass-panel" style={{ padding: 24, textAlign: 'center', color: 'var(--text-sub)' }}>
              Belum ada riwayat pesanan. Yuk pesan kopi favoritmu!
            </div>
          ) : (
            orders.map(ord => (
              <div key={ord.id} className="glass-panel" style={{ padding: 16, marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                  <div>
                    <strong style={{ fontSize: 15, color: '#fff' }}>{ord.customerName}</strong>
                    <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>
                      Meja/Tipe: {ord.tableNo} ({ord.orderType}) • {ord.paymentMethod}
                    </div>
                  </div>
                  <span className={`badge-status status-${ord.status}`}>
                    {ord.status === 'pending' ? 'Masuk' : ord.status}
                  </span>
                </div>

                <div style={{ borderTop: '1px solid var(--glass-border)', paddingTop: 8, marginTop: 8 }}>
                  {ord.items.map((it, idx) => (
                    <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: 'var(--text-sub)' }}>
                      <span>{it.qty}x {it.name}</span>
                      <span>Rp {(it.price * it.qty).toLocaleString('id-ID')}</span>
                    </div>
                  ))}
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, fontWeight: 700, color: 'var(--accent-gold)', marginTop: 8 }}>
                    <span>Total Pembayaran</span>
                    <span>Rp {ord.totalPrice.toLocaleString('id-ID')}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {cart.length > 0 && activeTab === 'menu' && (
        <div style={{ position: 'fixed', bottom: 85, left: '50%', transform: 'translateX(-50%)', width: 'calc(100% - 40px)', maxWidth: 440, zIndex: 999 }}>
          <button 
            className="ios-btn-primary" 
            style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 20px' }}
            onClick={() => setIsCartOpen(true)}
          >
            <span>Keranjang ({cart.reduce((s, c) => s + c.qty, 0)} item)</span>
            <span>Rp {totalPrice.toLocaleString('id-ID')} &rarr;</span>
          </button>
        </div>
      )}

      {isCartOpen && (
        <div className="ios-modal-overlay" onClick={() => setIsCartOpen(false)}>
          <div className="ios-modal-sheet" onClick={(e) => e.stopPropagation()}>
            <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 16 }}>Detail Pesanan Kopi</h3>
            {cart.map(item => (
              <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14 }}>{item.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--accent-gold)' }}>Rp {item.price.toLocaleString('id-ID')}</div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <button className="tab-btn" style={{ padding: '4px 10px' }} onClick={() => updateQty(item.id, -1)}>-</button>
                  <span style={{ fontWeight: 700 }}>{item.qty}</span>
                  <button className="tab-btn" style={{ padding: '4px 10px' }} onClick={() => updateQty(item.id, 1)}>+</button>
                </div>
              </div>
            ))}

            <form onSubmit={handleCheckoutInit} style={{ marginTop: 20 }}>
              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)' }}>Nama Pemesan</label>
                <input type="text" className="ios-input" value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Masukkan Nama" required />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
                <div>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)' }}>Tipe Pesanan</label>
                  <select className="ios-input" value={orderType} onChange={(e) => setOrderType(e.target.value)}>
                    <option value="Dine-In">Dine-In (Di Tempat)</option>
                    <option value="Takeaway">Bawa Pulang</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)' }}>Nomor Meja</label>
                  <input type="text" className="ios-input" value={tableNo} onChange={(e) => setTableNo(e.target.value)} placeholder="Contoh: Meja 04" />
                </div>
              </div>

              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)' }}>Metode Pembayaran</label>
                <select className="ios-input" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                  <option value="QRIS">QRIS Instant (Scan Barcode Toko)</option>
                  <option value="Tunai">Bayar Tunai di Kasir</option>
                </select>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 16, fontWeight: 800, margin: '16px 0' }}>
                <span>Total Bayar:</span>
                <span style={{ color: 'var(--accent-gold)' }}>Rp {totalPrice.toLocaleString('id-ID')}</span>
              </div>

              <button type="submit" className="ios-btn-primary" disabled={loadingOrder}>
                {paymentMethod === 'QRIS' ? 'Lanjut ke Pembayaran QRIS' : 'Kirim Pesanan Sekarang'}
              </button>
              <button type="button" className="ios-btn-secondary" onClick={() => setIsCartOpen(false)}>Kembali</button>
            </form>
          </div>
        </div>
      )}

      {qrisModalOpen && pendingOrderPayload && (
        <div className="ios-modal-overlay" onClick={() => setQrisModalOpen(false)}>
          <div className="ios-modal-sheet" style={{ textAlign: 'center' }} onClick={(e) => e.stopPropagation()}>
            <h3 style={{ fontSize: 18, fontWeight: 800 }}>Scan QRIS Pembayaran</h3>
            <p style={{ fontSize: 12, color: 'var(--text-sub)', marginTop: 4 }}>
              Scan QRIS di bawah ini dengan BCA, DANA, GoPay, OVO, atau Mobile Banking Anda.
            </p>

            <div className="qris-display-box">
              {sellerQrisImg ? (
                <img src={sellerQrisImg} alt="QRIS Toko 1001 SK" />
              ) : (
                <div style={{ padding: 20, color: '#666', fontSize: 13 }}>
                  📱 Penjual belum mengunggah gambar QRIS.<br/>Tunjukkan tangkapan layar ini saat bayar di kasir.
                </div>
              )}
            </div>

            <div style={{ background: 'rgba(255,255,255,0.08)', padding: 12, borderRadius: 12, marginBottom: 16 }}>
              <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>Total yang Harus Ditransfer:</div>
              <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--accent-gold)' }}>
                Rp {pendingOrderPayload.totalPrice.toLocaleString('id-ID')}
              </div>
            </div>

            <button 
              className="ios-btn-primary" 
              style={{ background: 'linear-gradient(135deg, #34c759, #30d158)' }}
              disabled={loadingOrder}
              onClick={() => submitOrderToFirestore(pendingOrderPayload)}
            >
              {loadingOrder ? 'Mengonfirmasi...' : '✓ Saya Sudah Transfer / Bayar'}
            </button>
            <button className="ios-btn-secondary" onClick={() => setQrisModalOpen(false)}>Batal</button>
          </div>
        </div>
      )}
    </div>
  );
}
