import React, { useState, useMemo } from 'react';
import {
  ChevronRight,
  Plus,
  Minus,
  Trash2,
  CheckCircle2,
  Sparkles,
  Share2,
  X,
  Search,
  ShoppingBag,
  Receipt,
  Coffee,
  Clock
} from 'lucide-react';
import { MENU_CATEGORIES, ORDER_STATUS_META, formatRupiah, formatDateTime } from '../utils/constants.js';
import { useSheetSwipeDismiss } from '../hooks/useSheetSwipeDismiss.js';
import { useLongPress } from '../hooks/useLongPress.js';
import { playTapHaptic, playPeekHaptic } from '../utils/soundEffects.js';
import ProductLongPressModal from './ProductLongPressModal.jsx';

const MOOD_TILES = [
  {
    title: 'Pagi Produktif',
    sub: 'Espresso & Kopi Susu',
    cat: 'Signature Coffee',
    bg: 'linear-gradient(135deg, rgba(245, 158, 11, 0.88) 0%, rgba(180, 83, 9, 0.94) 100%)'
  },
  {
    title: 'Manual Brew',
    sub: 'Seduhan V60 Pilihan',
    cat: 'Manual Brew',
    bg: 'linear-gradient(135deg, rgba(55, 65, 81, 0.88) 0%, rgba(17, 24, 39, 0.94) 100%)'
  },
  {
    title: 'Dingin & Segar',
    sub: 'Cold Brew & Mocktail',
    cat: 'Cold Brew & Mocktail',
    bg: 'linear-gradient(135deg, rgba(2, 132, 199, 0.88) 0%, rgba(3, 105, 161, 0.94) 100%)'
  },
  {
    title: 'Matcha & Santai',
    sub: 'Non-Coffee Creamy',
    cat: 'Non-Coffee',
    bg: 'linear-gradient(135deg, rgba(22, 163, 74, 0.88) 0%, rgba(21, 128, 61, 0.94) 100%)'
  }
];

function InteractiveProductCard({ item, variant, index, onQuickAdd, onLongPressOpen }) {
  const soldOut = item.available === false;
  const pressBind = useLongPress({
    delay: 360,
    onLongPress: () => {
      playPeekHaptic();
      onLongPressOpen(item);
    },
    onClick: () => {
      if (soldOut) return;
      playTapHaptic();
      onQuickAdd(item);
    }
  });

  if (variant === 'hero') {
    return (
      <div
        className="hero-card refractive-glass card-stagger-in"
        style={{
          '--stagger': index,
          backgroundImage: item.accentGradient || undefined
        }}
        {...pressBind}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            position: 'relative',
            zIndex: 1
          }}
        >
          <span className="hero-badge-glass">{item.category}</span>
          <span
            style={{
              width: 34,
              height: 34,
              borderRadius: '50%',
              background: 'var(--bg-subtle)',
              border: '1px solid var(--border-hairline)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--accent)'
            }}
          >
            <Coffee size={17} />
          </span>
        </div>

        <div style={{ marginTop: 18, position: 'relative', zIndex: 1 }}>
          <div className="hero-title">{item.name}</div>
          <p className="hero-desc">{item.desc}</p>
        </div>

        <div
          style={{
            marginTop: 'auto',
            paddingTop: 12,
            borderTop: '1px solid var(--border-hairline)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            position: 'relative',
            zIndex: 1
          }}
        >
          <div>
            <div style={{ fontSize: 16.5, fontWeight: 800, color: 'var(--accent)' }}>
              {soldOut ? 'Habis' : formatRupiah(item.price)}
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>
              Tahan untuk pratinjau
            </div>
          </div>
          <div className="speed-add-btn">
            <Plus size={18} />
          </div>
        </div>
      </div>
    );
  }

  if (variant === 'speed') {
    return (
      <div
        className="speed-row card-stagger-in"
        style={{ '--stagger': index, opacity: soldOut ? 0.55 : 1 }}
        {...pressBind}
      >
        <div className="speed-icon-badge">
          <Coffee size={19} />
        </div>
        <div className="speed-info">
          <div className="speed-name">{item.name}</div>
          <div className="speed-meta">
            {formatRupiah(item.price)} • {item.category}
          </div>
        </div>
        <button
          type="button"
          className="speed-add-btn glass-pressable"
          disabled={soldOut}
          aria-label={`Tambah ${item.name}`}
        >
          <Plus size={18} />
        </button>
      </div>
    );
  }

  return (
    <div
      className="menu-card card-stagger-in"
      style={{ '--stagger': index, opacity: soldOut ? 0.55 : 1 }}
      {...pressBind}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 8
        }}
      >
        <span
          style={{
            fontSize: 10.5,
            fontWeight: 700,
            padding: '4px 9px',
            borderRadius: 999,
            background: 'var(--bg-subtle)',
            color: 'var(--text-secondary)'
          }}
        >
          {item.category}
        </span>
        <span
          style={{
            width: 30,
            height: 30,
            borderRadius: '50%',
            background: 'var(--accent-soft)',
            color: 'var(--accent)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <Plus size={16} />
        </span>
      </div>
      <div className="menu-card-title">{item.name}</div>
      <div className="menu-card-desc">{item.desc}</div>
      <div className="menu-card-price" style={{ marginTop: 'auto', paddingTop: 10 }}>
        {soldOut ? 'Habis' : formatRupiah(item.price)}
      </div>
    </div>
  );
}

export default function CustomerView({
  activeTab,
  tabDirection,
  setActiveTab,
  menuItems,
  cart,
  onAddToCart,
  onUpdateCartQty,
  onClearCart,
  onSubmitOrder,
  orders,
  onHideOrderHistory,
  onClearAllOrderHistory,
  storeName,
  selectedOrder,
  setSelectedOrder,
  searchOpen,
  setSearchOpen,
  userProfile
}) {
  const [selectedCategory, setSelectedCategory] = useState('Semua');
  const [searchText, setSearchText] = useState('');
  const [customerName, setCustomerName] = useState(userProfile?.name || '');
  const [tableNumber, setTableNumber] = useState('');
  const [orderNote, setOrderNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [peekProduct, setPeekProduct] = useState(null);
  const [toastMsg, setToastMsg] = useState('');

  const showToast = (msg) => {
    setToastMsg(msg);
    window.setTimeout(() => setToastMsg(''), 2500);
  };

  const featuredItems = useMemo(
    () => menuItems.filter((m) => m.featured && m.available !== false),
    [menuItems]
  );

  const filteredMenu = useMemo(() => {
    return menuItems.filter((item) => {
      const catOk = selectedCategory === 'Semua' || item.category === selectedCategory;
      const q = searchText.trim().toLowerCase();
      const searchOk =
        !q ||
        item.name?.toLowerCase().includes(q) ||
        item.category?.toLowerCase().includes(q) ||
        item.desc?.toLowerCase().includes(q);
      return catOk && searchOk;
    });
  }, [menuItems, selectedCategory, searchText]);

  const searchResults = useMemo(() => {
    const q = searchText.trim().toLowerCase();
    if (!q) return menuItems.slice(0, 8);
    return menuItems.filter(
      (item) =>
        item.name?.toLowerCase().includes(q) ||
        item.category?.toLowerCase().includes(q) ||
        item.desc?.toLowerCase().includes(q)
    );
  }, [menuItems, searchText]);

  const cartTotal = useMemo(
    () => cart.reduce((sum, item) => sum + Number(item.price || 0) * Number(item.qty || 1), 0),
    [cart]
  );

  const visibleOrders = useMemo(
    () => orders.filter((o) => !o.hiddenByCustomer),
    [orders]
  );

  const orderSheetDismiss = useSheetSwipeDismiss({
    onDismiss: () => setSelectedOrder(null),
    enabled: Boolean(selectedOrder)
  });

  const handleCheckout = async (e) => {
    e.preventDefault();
    if (!cart.length || submitting) return;
    setSubmitting(true);
    try {
      const created = await onSubmitOrder({
        customerName: customerName.trim() || userProfile?.name || 'Pelanggan',
        tableNumber: tableNumber.trim() || 'Takeaway',
        note: orderNote.trim(),
        items: cart,
        totalPrice: cartTotal
      });
      if (created) {
        setOrderNote('');
        setActiveTab('orders');
        setSelectedOrder(created);
        showToast('Pesanan berhasil dibuat!');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleShareProduct = async (item) => {
    const text = `${item.name} (${formatRupiah(item.price)}) — ${item.desc || ''} di ${storeName || '1001 SK Coffee'}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: item.name, text });
      } else {
        await navigator.clipboard.writeText(text);
        showToast('Info menu disalin ke papan klip');
      }
    } catch {
      // ignore cancel
    }
  };

  const handleShareOrder = async (order) => {
    const summary = (order.items || []).map((i) => `${i.qty}x ${i.name}`).join(', ');
    const text = `Pesanan ${storeName || '1001 SK'} • ${order.customerName} (${summary}) • Total ${formatRupiah(order.totalPrice || 0)}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: 'Pesanan 1001 SK', text });
      } else {
        await navigator.clipboard.writeText(text);
        showToast('Rincian pesanan disalin');
      }
    } catch {
      // ignore
    }
  };

  const tabAnimClass = tabDirection === 'left' ? 'tab-slide-left' : 'tab-slide-right';

  return (
    <>
      {toastMsg && (
        <div
          className="toast-spring-in"
          style={{
            position: 'fixed',
            top: 'calc(env(safe-area-inset-top, 12px) + 56px)',
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 185
          }}
        >
          <div
            className="refractive-glass"
            style={{
              padding: '9px 18px',
              borderRadius: 999,
              fontSize: 13,
              fontWeight: 700,
              color: 'var(--text-primary)'
            }}
          >
            <span style={{ position: 'relative', zIndex: 1 }}>{toastMsg}</span>
          </div>
        </div>
      )}

      {activeTab === 'home' && (
        <div key="tab-home" className={tabAnimClass}>
          <div className="ios-pills">
            {MENU_CATEGORIES.map((cat) => (
              <button
                key={cat}
                type="button"
                className={`ios-pill ${selectedCategory === cat ? 'active' : ''}`}
                onClick={() => {
                  playTapHaptic();
                  setSelectedCategory(cat);
                }}
              >
                {cat}
              </button>
            ))}
          </div>

          {selectedCategory === 'Semua' && featuredItems.length > 0 && (
            <>
              <div className="section-header">
                <h2 className="section-title">
                  Pilihan Hari Ini
                  <ChevronRight size={20} style={{ color: 'var(--text-secondary)' }} />
                </h2>
                <span style={{ fontSize: 11.5, fontWeight: 600, color: 'var(--text-secondary)' }}>
                  Tahan kartu untuk opsi
                </span>
              </div>
              <div className="h-scroll">
                {featuredItems.map((item, idx) => (
                  <InteractiveProductCard
                    key={item.id}
                    item={item}
                    variant="hero"
                    index={idx}
                    onQuickAdd={(prod) => {
                      onAddToCart(prod);
                      showToast(`${prod.name} masuk keranjang`);
                    }}
                    onLongPressOpen={(prod) => setPeekProduct(prod)}
                  />
                ))}
              </div>
            </>
          )}

          <div className="section-header">
            <h2 className="section-title">Pesan Cepat</h2>
            <button
              type="button"
              className="section-action"
              onClick={() => setActiveTab('cart')}
            >
              Keranjang ({cart.reduce((s, i) => s + i.qty, 0)})
            </button>
          </div>
          <div className="speed-list">
            {filteredMenu.slice(0, 5).map((item, idx) => (
              <InteractiveProductCard
                key={item.id}
                item={item}
                variant="speed"
                index={idx}
                onQuickAdd={(prod) => {
                  onAddToCart(prod);
                  showToast(`+1 ${prod.name}`);
                }}
                onLongPressOpen={(prod) => setPeekProduct(prod)}
              />
            ))}
          </div>

          {selectedCategory === 'Semua' && (
            <>
              <div className="section-header" style={{ marginTop: 8 }}>
                <h2 className="section-title">
                  Suasana & Kategori
                  <ChevronRight size={20} style={{ color: 'var(--text-secondary)' }} />
                </h2>
              </div>
              <div className="genre-grid">
                {MOOD_TILES.map((tile, idx) => (
                  <div
                    key={tile.title}
                    className="genre-tile card-stagger-in"
                    style={{ '--stagger': idx, background: tile.bg }}
                    onClick={() => {
                      playTapHaptic();
                      setSelectedCategory(tile.cat);
                    }}
                  >
                    <span style={{ fontSize: 15, fontWeight: 800 }}>{tile.title}</span>
                    <span style={{ fontSize: 11.5, fontWeight: 600, opacity: 0.88, marginTop: 2 }}>
                      {tile.sub}
                    </span>
                  </div>
                ))}
              </div>
            </>
          )}

          <div className="section-header">
            <h2 className="section-title">
              {selectedCategory === 'Semua' ? 'Semua Menu' : selectedCategory}
            </h2>
          </div>
          <div className="menu-grid">
            {filteredMenu.map((item, idx) => (
              <InteractiveProductCard
                key={item.id}
                item={item}
                variant="grid"
                index={idx}
                onQuickAdd={(prod) => {
                  onAddToCart(prod);
                  showToast(`+1 ${prod.name}`);
                }}
                onLongPressOpen={(prod) => setPeekProduct(prod)}
              />
            ))}
          </div>
        </div>
      )}

      {activeTab === 'cart' && (
        <div key="tab-cart" className={tabAnimClass} style={{ padding: '4px 18px 20px' }}>
          {cart.length === 0 ? (
            <div
              className="ios-grouped-card card-stagger-in"
              style={{ padding: '36px 20px', textAlign: 'center', marginTop: 8 }}
            >
              <ShoppingBag size={38} style={{ color: 'var(--text-tertiary)', marginBottom: 10 }} />
              <div style={{ fontSize: 17, fontWeight: 800 }}>Keranjang Masih Kosong</div>
              <p style={{ fontSize: 13.5, color: 'var(--text-secondary)', marginTop: 4, marginBottom: 18 }}>
                Pilih menu kopi favorit Anda di Beranda untuk mulai memesan.
              </p>
              <button
                type="button"
                className="btn-ios-primary"
                style={{ maxWidth: 210 }}
                onClick={() => setActiveTab('home')}
              >
                Lihat Menu
              </button>
            </div>
          ) : (
            <>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: 10
                }}
              >
                <span style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text-secondary)' }}>
                  {cart.reduce((s, i) => s + i.qty, 0)} Item Dipilih
                </span>
                <button
                  type="button"
                  onClick={onClearCart}
                  style={{
                    border: 'none',
                    background: 'transparent',
                    color: '#ff453a',
                    fontSize: 13,
                    fontWeight: 700,
                    cursor: 'pointer'
                  }}
                >
                  Kosongkan
                </button>
              </div>

              <div className="ios-grouped-card card-stagger-in" style={{ marginBottom: 16 }}>
                {cart.map((item) => (
                  <div
                    key={item.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 12,
                      padding: '13px 15px',
                      borderBottom: '1px solid var(--border-hairline)'
                    }}
                  >
                    <div className="speed-icon-badge" style={{ width: 42, height: 42 }}>
                      <Coffee size={18} />
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 14.5, fontWeight: 700 }}>{item.name}</div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--accent)', marginTop: 2 }}>
                        {formatRupiah(item.price * item.qty)}
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <button
                        type="button"
                        className="speed-add-btn glass-pressable"
                        onClick={() => onUpdateCartQty(item.id, item.qty - 1)}
                      >
                        <Minus size={15} />
                      </button>
                      <span style={{ fontSize: 14, fontWeight: 800, minWidth: 18, textAlign: 'center' }}>
                        {item.qty}
                      </span>
                      <button
                        type="button"
                        className="speed-add-btn glass-pressable"
                        onClick={() => onUpdateCartQty(item.id, item.qty + 1)}
                      >
                        <Plus size={15} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <form onSubmit={handleCheckout} className="ios-grouped-card card-stagger-in" style={{ padding: 16 }}>
                <div style={{ fontSize: 15, fontWeight: 800, marginBottom: 12 }}>Detail Pemesan</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  <input
                    className="ios-input"
                    type="text"
                    placeholder="Nama Pemesan"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    required
                  />
                  <input
                    className="ios-input"
                    type="text"
                    placeholder="Nomor Meja / Takeaway (Contoh: Meja 04)"
                    value={tableNumber}
                    onChange={(e) => setTableNumber(e.target.value)}
                  />
                  <input
                    className="ios-input"
                    type="text"
                    placeholder="Catatan (Contoh: Less sugar, es terpisah)"
                    value={orderNote}
                    onChange={(e) => setOrderNote(e.target.value)}
                  />
                </div>
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginTop: 16,
                    paddingTop: 14,
                    borderTop: '1px solid var(--border-hairline)'
                  }}
                >
                  <span style={{ fontSize: 14, color: 'var(--text-secondary)', fontWeight: 600 }}>
                    Total Pesanan
                  </span>
                  <span style={{ fontSize: 20, fontWeight: 800, color: 'var(--text-primary)' }}>
                    {formatRupiah(cartTotal)}
                  </span>
                </div>
                <button
                  type="submit"
                  className="btn-ios-primary"
                  style={{ marginTop: 14 }}
                  disabled={submitting}
                >
                  <CheckCircle2 size={18} />
                  {submitting ? 'Mengirim Pesanan...' : 'Kirim Pesanan Sekarang'}
                </button>
              </form>
            </>
          )}
        </div>
      )}

      {activeTab === 'orders' && (
        <div key="tab-orders" className={tabAnimClass} style={{ padding: '4px 18px 20px' }}>
          {visibleOrders.length > 0 && (
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: 10
              }}
            >
              <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)' }}>
                {visibleOrders.length} Riwayat Pesanan
              </span>
              <button
                type="button"
                onClick={onClearAllOrderHistory}
                style={{
                  border: 'none',
                  background: 'transparent',
                  color: '#ff453a',
                  fontSize: 13,
                  fontWeight: 700,
                  cursor: 'pointer'
                }}
              >
                Hapus Semua Riwayat
              </button>
            </div>
          )}

          {visibleOrders.length === 0 ? (
            <div
              className="ios-grouped-card card-stagger-in"
              style={{ padding: '36px 20px', textAlign: 'center', marginTop: 8 }}
            >
              <Receipt size={38} style={{ color: 'var(--text-tertiary)', marginBottom: 10 }} />
              <div style={{ fontSize: 17, fontWeight: 800 }}>Belum Ada Pesanan</div>
              <p style={{ fontSize: 13.5, color: 'var(--text-secondary)', marginTop: 4 }}>
                Pesanan aktif dan riwayat transaksi Anda tampil di sini.
              </p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {visibleOrders.map((order, idx) => {
                const meta = ORDER_STATUS_META[order.status] || ORDER_STATUS_META.queued;
                return (
                  <div
                    key={order.id}
                    className="ios-grouped-card glass-pressable card-stagger-in"
                    onClick={() => setSelectedOrder(order)}
                    style={{ '--stagger': idx, padding: 15, cursor: 'pointer' }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span
                        style={{
                          padding: '4px 11px',
                          borderRadius: 999,
                          background: meta.bg,
                          color: meta.color,
                          fontSize: 12,
                          fontWeight: 800
                        }}
                      >
                        {meta.label}
                      </span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                          {formatDateTime(order.createdAt)}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onHideOrderHistory(order.id);
                          }}
                          aria-label="Hapus riwayat"
                          style={{
                            width: 28,
                            height: 28,
                            borderRadius: '50%',
                            border: 'none',
                            background: 'var(--bg-subtle)',
                            color: '#ff453a',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: 'pointer'
                          }}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>

                    <div style={{ fontSize: 15.5, fontWeight: 800, marginTop: 10 }}>
                      {order.customerName} • {order.tableNumber || 'Takeaway'}
                    </div>
                    <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 3 }}>
                      {(order.items || []).map((i) => `${i.qty}x ${i.name}`).join(', ')}
                    </div>

                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginTop: 12,
                        paddingTop: 10,
                        borderTop: '1px solid var(--border-hairline)'
                      }}
                    >
                      <span style={{ fontSize: 15, fontWeight: 800, color: 'var(--accent)' }}>
                        {formatRupiah(order.totalPrice)}
                      </span>
                      <span
                        style={{
                          fontSize: 12.5,
                          fontWeight: 700,
                          color: 'var(--text-primary)',
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: 4
                        }}
                      >
                        Lihat Rincian <ChevronRight size={15} />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Search Sheet */}
      {searchOpen && (
        <div className="sheet-backdrop" onClick={() => setSearchOpen(false)}>
          <div
            className="sheet-panel"
            onClick={(e) => e.stopPropagation()}
            style={{ height: '86vh', padding: '0 18px 24px' }}
          >
            <div className="sheet-grabber" />
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 8, marginBottom: 14 }}>
              <div
                className="refractive-glass"
                style={{
                  flex: 1,
                  height: 46,
                  borderRadius: 999,
                  padding: '0 15px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 9
                }}
              >
                <Search size={18} style={{ color: 'var(--text-secondary)', position: 'relative', zIndex: 1 }} />
                <input
                  type="text"
                  autoFocus
                  placeholder="Cari kopi, matcha, pastry..."
                  value={searchText}
                  onChange={(e) => setSearchText(e.target.value)}
                  style={{
                    flex: 1,
                    border: 'none',
                    background: 'transparent',
                    color: 'var(--text-primary)',
                    fontSize: 15,
                    outline: 'none',
                    position: 'relative',
                    zIndex: 1
                  }}
                />
              </div>
              <button
                type="button"
                className="refractive-glass"
                onClick={() => setSearchOpen(false)}
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: 'var(--text-primary)',
                  cursor: 'pointer'
                }}
              >
                <X size={19} style={{ position: 'relative', zIndex: 1 }} />
              </button>
            </div>
            <div style={{ flex: 1, overflowY: 'auto' }} className="speed-list">
              {searchResults.map((item, idx) => (
                <InteractiveProductCard
                  key={item.id}
                  item={item}
                  variant="speed"
                  index={idx}
                  onQuickAdd={(prod) => {
                    onAddToCart(prod);
                    showToast(`+1 ${prod.name}`);
                    setSearchOpen(false);
                  }}
                  onLongPressOpen={(prod) => {
                    setSearchOpen(false);
                    setPeekProduct(prod);
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Smooth Convx Glass Order Detail Sheet (No QRIS) */}
      {selectedOrder && (
        <div className="sheet-backdrop" onClick={() => setSelectedOrder(null)}>
          <div
            className="sheet-panel"
            style={{ ...orderSheetDismiss.sheetStyle, padding: '0 20px 28px' }}
            {...orderSheetDismiss.sheetTouchProps}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sheet-grabber" />
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginTop: 8,
                marginBottom: 14
              }}
            >
              <div>
                <h3 style={{ fontSize: 20, fontWeight: 800 }}>Rincian Pesanan</h3>
                <div style={{ fontSize: 12.5, color: 'var(--text-secondary)' }}>
                  {selectedOrder.customerName} • {selectedOrder.tableNumber || 'Takeaway'}
                </div>
              </div>
              <button
                type="button"
                className="refractive-glass"
                onClick={() => setSelectedOrder(null)}
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: 'var(--text-primary)',
                  cursor: 'pointer'
                }}
              >
                <X size={17} style={{ position: 'relative', zIndex: 1 }} />
              </button>
            </div>

            {(() => {
              const meta = ORDER_STATUS_META[selectedOrder.status] || ORDER_STATUS_META.queued;
              return (
                <div
                  className="refractive-glass"
                  style={{
                    borderRadius: 18,
                    padding: '12px 15px',
                    marginBottom: 14,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, position: 'relative', zIndex: 1 }}>
                    <Clock size={18} style={{ color: meta.color }} />
                    <div>
                      <div style={{ fontSize: 13.5, fontWeight: 800, color: meta.color }}>
                        {meta.label}
                      </div>
                      <div style={{ fontSize: 11.5, color: 'var(--text-secondary)' }}>
                        {formatDateTime(selectedOrder.createdAt)}
                      </div>
                    </div>
                  </div>
                  <Sparkles size={17} style={{ color: meta.color, position: 'relative', zIndex: 1 }} />
                </div>
              );
            })()}

            <div className="ios-grouped-card" style={{ padding: '6px 15px', marginBottom: 14 }}>
              {(selectedOrder.items || []).map((item, idx) => (
                <div
                  key={idx}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    padding: '10px 0',
                    borderBottom:
                      idx === (selectedOrder.items || []).length - 1
                        ? 'none'
                        : '1px solid var(--border-hairline)',
                    fontSize: 14
                  }}
                >
                  <span>
                    {item.qty}x {item.name}
                  </span>
                  <strong>{formatRupiah(item.price * item.qty)}</strong>
                </div>
              ))}
              {selectedOrder.note && (
                <div
                  style={{
                    fontSize: 12.5,
                    color: 'var(--text-secondary)',
                    padding: '8px 0 10px',
                    borderTop: '1px solid var(--border-hairline)'
                  }}
                >
                  Catatan: {selectedOrder.note}
                </div>
              )}
            </div>

            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: 16
              }}
            >
              <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-secondary)' }}>
                Total Pembayaran
              </span>
              <span style={{ fontSize: 21, fontWeight: 800, color: 'var(--accent)' }}>
                {formatRupiah(selectedOrder.totalPrice)}
              </span>
            </div>

            <div style={{ display: 'flex', gap: 10 }}>
              <button
                type="button"
                className="btn-ios-secondary"
                style={{ flex: 1 }}
                onClick={() => handleShareOrder(selectedOrder)}
              >
                <Share2 size={16} /> Bagikan
              </button>
              <button
                type="button"
                className="btn-ios-primary"
                style={{ flex: 1 }}
                onClick={() => setSelectedOrder(null)}
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Long-Press Cupertino Peek & Pop Preview + Context Menu */}
      <ProductLongPressModal
        item={peekProduct}
        onClose={() => setPeekProduct(null)}
        onAddToCart={(prod) => {
          onAddToCart(prod);
          showToast(`${prod.name} ditambahkan ke keranjang`);
        }}
        onOrderNow={(prod) => {
          onAddToCart(prod);
          setActiveTab('cart');
        }}
        onFilterCategory={(cat) => {
          setSelectedCategory(cat);
          setActiveTab('home');
        }}
        onShareProduct={handleShareProduct}
      />
    </>
  );
}
