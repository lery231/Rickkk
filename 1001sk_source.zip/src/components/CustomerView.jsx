import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot, addDoc, doc, query, orderBy } from 'firebase/firestore';
import { Plus, Minus, Search, ShoppingBag, ChevronRight, QrCode, CheckCircle2, Clock } from 'lucide-react';

const DEFAULT_MENU = [
  { id: 'm1', name: 'Kopi Susu Gula Aren 1001', category: 'Signature', price: 18000, desc: 'Espresso double shot dengan gula aren organik & susu segar creamy', img: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80', stock: true },
  { id: 'm2', name: 'Creamy Cold Brew SK', category: 'Signature', price: 22000, desc: 'Cold brew seduh dingin 12 jam dengan lapisan krim vanilla lembut', img: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=400&q=80', stock: true },
  { id: 'm3', name: 'Americano Ice / Hot', category: 'Espresso', price: 15000, desc: 'Espresso house-blend murni dengan air mineral dingin atau hangat', img: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=400&q=80', stock: true },
  { id: 'm4', name: 'Matcha Oat Latte', category: 'Non-Kopi', price: 24000, desc: 'Matcha Uji Jepang autentik berpadu dengan susu gandum (Oat)', img: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=400&q=80', stock: true },
  { id: 'm5', name: 'Croissant Butter Warm', category: 'Camilan', price: 18000, desc: 'Pastry croissant renyah berlapis dengan mentega Prancis hangat', img: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=400&q=80', stock: true },
  { id: 'm6', name: 'Roti Bakar Keju Coklat', category: 'Camilan', price: 16000, desc: 'Roti tawar tebal dipanggang renyah dengan keju dan coklat lumer', img: 'https://images.unsplash.com/photo-1584776296944-ab6fb57b0bdd?w=400&q=80', stock: true },
];

const STATUS_STEP_MAP = {
  pending: 1,
  diproses: 2,
  siap: 3,
  selesai: 4,
};

const STATUS_LABEL_MAP = {
  pending: 'Menunggu Konfirmasi',
  diproses: 'Sedang Diramu Barista',
  siap: 'Siap Diambil / Diantar',
  selesai: 'Pesanan Selesai',
};

export default function CustomerView({ cart, setCart, activeTab, user, showToast }) {
  const [menuList, setMenuList] = useState(DEFAULT_MENU);
  const [selectedCategory, setSelectedCategory] = useState('Semua');
  const [searchQuery, setSearchQuery] = useState('');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [qrisModalOpen, setQrisModalOpen] = useState(false);
  const [sellerQrisImg, setSellerQrisImg] = useState(null);

  const [orders, setOrders] = useState([]);
  const [customerName, setCustomerName] = useState(user?.email ? user.email.split('@')[0] : '');
  const [tableNo, setTableNo] = useState('');
  const [orderType, setOrderType] = useState('Dine-In');
  const [paymentMethod, setPaymentMethod] = useState('QRIS');
  const [loadingOrder, setLoadingOrder] = useState(false);
  const [pendingOrderPayload, setPendingOrderPayload] = useState(null);

  useEffect(() => {
    if (user?.email && !customerName) {
      setCustomerName(user.email.split('@')[0]);
    }
  }, [user]);

  useEffect(() => {
    const unsubMenu = onSnapshot(collection(db, 'menu'), (snap) => {
      if (!snap.empty) {
        const items = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setMenuList(items);
      }
    }, () => {});

    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    const unsubOrders = onSnapshot(q, (snap) => {
      const list = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setOrders(list);
    }, () => {});

    const unsubQris = onSnapshot(doc(db, 'settings', 'qris'), (docSnap) => {
      if (docSnap.exists()) {
        setSellerQrisImg(docSnap.data().qrisImage);
      }
    }, () => {});

    return () => {
      unsubMenu();
      unsubOrders();
      unsubQris();
    };
  }, []);

  const addToCart = (item) => {
    const exist = cart.find(c => c.id === item.id);
    if (exist) {
      setCart(cart.map(c => c.id === item.id ? { ...c, qty: c.qty + 1 } : c));
    } else {
      setCart([...cart, { ...item, qty: 1 }]);
      if (showToast) showToast(`${item.name} ditambahkan ke keranjang`);
    }
  };

  const updateQty = (id, delta) => {
    setCart(cart.map(c => {
      if (c.id === id) {
        const newQty = c.qty + delta;
        return newQty > 0 ? { ...c, qty: newQty } : null;
      }
      return c;
    }).filter(Boolean));
  };

  const getItemQty = (id) => {
    const found = cart.find(c => c.id === id);
    return found ? found.qty : 0;
  };

  const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const totalItems = cart.reduce((sum, item) => sum + item.qty, 0);

  const handleCheckoutInit = (e) => {
    e.preventDefault();
    if (cart.length === 0) return;

    const payload = {
      customerName: customerName || 'Pelanggan 1001 SK',
      tableNo: tableNo || (orderType === 'Takeaway' ? 'Takeaway' : 'Meja 01'),
      orderType,
      paymentMethod,
      items: cart,
      totalPrice,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    if (paymentMethod === 'QRIS') {
      setPendingOrderPayload(payload);
      setIsCartOpen(false);
      setQrisModalOpen(true);
    } else {
      submitOrderToFirestore(payload);
    }
  };

  const submitOrderToFirestore = async (payload) => {
    setLoadingOrder(true);
    try {
      await addDoc(collection(db, 'orders'), payload);
      if (showToast) showToast('Pesanan berhasil dikirim ke kasir!');
      setCart([]);
      setIsCartOpen(false);
      setQrisModalOpen(false);
      setPendingOrderPayload(null);
    } catch (err) {
      if (showToast) showToast('Gagal mengirim pesanan: ' + err.message);
    } finally {
      setLoadingOrder(false);
    }
  };

  const categories = ['Semua', 'Signature', 'Espresso', 'Non-Kopi', 'Camilan'];
  const filteredMenu = menuList.filter(m => {
    const matchCat = selectedCategory === 'Semua' || m.category === selectedCategory;
    const matchSearch = !searchQuery.trim() || 
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (m.desc && m.desc.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchCat && matchSearch;
  });

  return (
    <div className="page-transition">
      {activeTab === 'menu' && (
        <>
          <div className="ios-search-wrap">
            <div className="ios-search-box">
              <Search size={16} color="var(--text-sub)" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari kopi favorit atau camilan..."
              />
            </div>
          </div>

          <div className="ios-tabs">
            {categories.map(cat => (
              <button 
                key={cat} 
                className={`tab-btn ${selectedCategory === cat ? 'active' : ''}`}
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="menu-grid">
            {filteredMenu.map((item, idx) => {
              const qty = getItemQty(item.id);
              return (
                <div 
                  key={item.id} 
                  className="glass-panel menu-card stagger-item"
                  style={{ animationDelay: `${Math.min(idx * 45, 360)}ms` }}
                >
                  <div>
                    <div className="menu-img-wrap">
                      <img 
                        src={item.img || 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80'} 
                        alt={item.name} 
                        className="menu-img" 
                      />
                      <span className="menu-cat-pill">{item.category}</span>
                    </div>
                    <h4 className="menu-title">{item.name}</h4>
                    <p className="menu-desc">{item.desc}</p>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 4 }}>
                    <span className="menu-price">Rp {item.price.toLocaleString('id-ID')}</span>
                    {qty > 0 ? (
                      <div className="qty-pill">
                        <button onClick={() => updateQty(item.id, -1)} aria-label="Kurangi">
                          <Minus size={13} />
                        </button>
                        <span>{qty}</span>
                        <button onClick={() => updateQty(item.id, 1)} aria-label="Tambah">
                          <Plus size={13} />
                        </button>
                      </div>
                    ) : (
                      <button className="btn-add" onClick={() => addToCart(item)}>
                        <Plus size={13} /> Tambah
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {activeTab === 'orders' && (
        <div style={{ padding: 20 }} className="page-transition">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h3 style={{ fontSize: 18, fontWeight: 800 }}>Status Pesanan Realtime</h3>
            <span style={{ fontSize: 12, color: 'var(--text-sub)' }}>{orders.length} transaksi</span>
          </div>

          {orders.length === 0 ? (
            <div className="glass-panel" style={{ padding: 28, textAlign: 'center', color: 'var(--text-sub)' }}>
              <Clock size={28} style={{ margin: '0 auto 10px', opacity: 0.6 }} />
              <div style={{ fontWeight: 700, color: '#fff', marginBottom: 4 }}>Belum Ada Pesanan</div>
              <div style={{ fontSize: 12.5 }}>Pilih menu kopi favoritmu dan pesanan akan tampil secara langsung di sini.</div>
            </div>
          ) : (
            orders.map((ord, idx) => {
              const currentStep = STATUS_STEP_MAP[ord.status] || 1;
              return (
                <div 
                  key={ord.id} 
                  className="glass-panel stagger-item" 
                  style={{ padding: 16, marginBottom: 14, animationDelay: `${Math.min(idx * 50, 350)}ms` }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                    <div>
                      <strong style={{ fontSize: 15.5, color: '#fff' }}>{ord.customerName}</strong>
                      <div style={{ fontSize: 12, color: 'var(--text-sub)', marginTop: 2 }}>
                        {ord.orderType} • {ord.tableNo} • {ord.paymentMethod}
                      </div>
                    </div>
                    <span className={`badge-status status-${ord.status}`}>
                      {ord.status === 'pending' ? 'Masuk' : ord.status}
                    </span>
                  </div>

                  {/* 4-Step iOS Progress Indicator */}
                  <div className="order-progress-bar">
                    {[1, 2, 3, 4].map(step => (
                      <div key={step} className={`progress-step ${currentStep >= step ? 'done' : ''}`} />
                    ))}
                  </div>
                  <div style={{ fontSize: 11.5, color: 'var(--accent-gold)', fontWeight: 600, marginBottom: 10 }}>
                    {STATUS_LABEL_MAP[ord.status] || 'Diproses'}
                  </div>

                  <div style={{ borderTop: '1px solid var(--glass-border)', paddingTop: 10 }}>
                    {ord.items?.map((it, i) => (
                      <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: 'var(--text-sub)', marginBottom: 4 }}>
                        <span>{it.qty}x {it.name}</span>
                        <span>Rp {(it.price * it.qty).toLocaleString('id-ID')}</span>
                      </div>
                    ))}
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14.5, fontWeight: 800, color: '#fff', marginTop: 8, paddingTop: 8, borderTop: '1px dashed rgba(255,255,255,0.1)' }}>
                      <span>Total Pembayaran</span>
                      <span style={{ color: 'var(--accent-gold)' }}>Rp {ord.totalPrice?.toLocaleString('id-ID')}</span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {cart.length > 0 && activeTab === 'menu' && (
        <div className="floating-cart-bar">
          <button 
            className="ios-btn-primary" 
            style={{ justifyContent: 'space-between', padding: '13px 18px', marginTop: 0, borderRadius: 20 }}
            onClick={() => setIsCartOpen(true)}
          >
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
              <ShoppingBag size={17} />
              <span>{totalItems} Item</span>
            </span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
              Rp {totalPrice.toLocaleString('id-ID')} <ChevronRight size={17} />
            </span>
          </button>
        </div>
      )}

      {isCartOpen && (
        <div className="ios-modal-overlay" onClick={() => setIsCartOpen(false)}>
          <div className="ios-modal-sheet" onClick={(e) => e.stopPropagation()}>
            <div className="sheet-handle" />
            <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 14 }}>Detail Pesanan Kopi</h3>
            
            <div style={{ maxHeight: 210, overflowY: 'auto', paddingRight: 4 }}>
              {cart.map(item => (
                <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, paddingBottom: 10, borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14 }}>{item.name}</div>
                    <div style={{ fontSize: 12, color: 'var(--accent-gold)' }}>Rp {(item.price * item.qty).toLocaleString('id-ID')}</div>
                  </div>
                  <div className="qty-pill">
                    <button type="button" onClick={() => updateQty(item.id, -1)}><Minus size={13} /></button>
                    <span>{item.qty}</span>
                    <button type="button" onClick={() => updateQty(item.id, 1)}><Plus size={13} /></button>
                  </div>
                </div>
              ))}
            </div>

            <form onSubmit={handleCheckoutInit} style={{ marginTop: 14 }}>
              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 600 }}>Nama Pemesan</label>
                <input type="text" className="ios-input" value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Masukkan Nama Anda" required />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
                <div>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 600 }}>Tipe Pesanan</label>
                  <select className="ios-input" value={orderType} onChange={(e) => setOrderType(e.target.value)}>
                    <option value="Dine-In">Dine-In (Di Tempat)</option>
                    <option value="Takeaway">Bawa Pulang</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 600 }}>Nomor Meja</label>
                  <input type="text" className="ios-input" value={tableNo} onChange={(e) => setTableNo(e.target.value)} placeholder="Contoh: Meja 04" />
                </div>
              </div>

              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 600 }}>Metode Pembayaran</label>
                <select className="ios-input" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                  <option value="QRIS">QRIS Instant (Scan Barcode Toko)</option>
                  <option value="Tunai">Bayar Tunai di Kasir</option>
                </select>
              </div>

              <div className="glass-panel" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', margin: '14px 0' }}>
                <span style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text-sub)' }}>Total Bayar</span>
                <span style={{ fontSize: 17, fontWeight: 800, color: 'var(--accent-gold)' }}>Rp {totalPrice.toLocaleString('id-ID')}</span>
              </div>

              <button type="submit" className="ios-btn-primary" disabled={loadingOrder}>
                {paymentMethod === 'QRIS' ? <><QrCode size={17} /> Lanjut ke Pembayaran QRIS</> : 'Kirim Pesanan Sekarang'}
              </button>
              <button type="button" className="ios-btn-secondary" onClick={() => setIsCartOpen(false)}>Kembali</button>
            </form>
          </div>
        </div>
      )}

      {qrisModalOpen && pendingOrderPayload && (
        <div className="ios-modal-overlay" onClick={() => setQrisModalOpen(false)}>
          <div className="ios-modal-sheet" style={{ textAlign: 'center' }} onClick={(e) => e.stopPropagation()}>
            <div className="sheet-handle" />
            <h3 style={{ fontSize: 18, fontWeight: 800 }}>Scan QRIS Pembayaran</h3>
            <p style={{ fontSize: 12, color: 'var(--text-sub)', marginTop: 4 }}>
              Scan barcode di bawah ini dengan DANA, GoPay, OVO, BCA, atau Mobile Banking.
            </p>

            <div className="qris-display-box">
              {sellerQrisImg ? (
                <img src={sellerQrisImg} alt="QRIS Toko 1001 SK" />
              ) : (
                <div style={{ padding: 24, color: '#555', fontSize: 13 }}>
                  <QrCode size={36} style={{ margin: '0 auto 8px', opacity: 0.5 }} />
                  Penjual belum mengunggah gambar QRIS.<br/>Tunjukkan layar ini saat membayar di kasir.
                </div>
              )}
            </div>

            <div className="glass-panel" style={{ padding: 12, marginBottom: 14 }}>
              <div style={{ fontSize: 11.5, color: 'var(--text-sub)' }}>Total yang Harus Ditransfer</div>
              <div style={{ fontSize: 21, fontWeight: 800, color: 'var(--accent-gold)', marginTop: 2 }}>
                Rp {pendingOrderPayload.totalPrice.toLocaleString('id-ID')}
              </div>
            </div>

            <button 
              className="ios-btn-primary" 
              style={{ background: 'linear-gradient(135deg, #32d74b, #28cd41)', color: '#08120a' }}
              disabled={loadingOrder}
              onClick={() => submitOrderToFirestore(pendingOrderPayload)}
            >
              <CheckCircle2 size={17} />
              {loadingOrder ? 'Mengonfirmasi...' : 'Saya Sudah Transfer / Bayar'}
            </button>
            <button className="ios-btn-secondary" onClick={() => setQrisModalOpen(false)}>Batal</button>
          </div>
        </div>
      )}
    </div>
  );
}
