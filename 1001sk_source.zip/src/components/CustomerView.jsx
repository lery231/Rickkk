import React, { useState, useEffect, useMemo } from 'react';
import { db } from '../firebase';
import {
  collection,
  onSnapshot,
  addDoc,
  updateDoc,
  doc,
  query,
  where,
} from 'firebase/firestore';
import {
  Plus,
  Minus,
  Search,
  ShoppingBag,
  ChevronRight,
  QrCode,
  CheckCircle2,
  Clock,
  Trash2,
  Sparkles,
  X,
  Download,
  Copy,
  RefreshCw,
} from 'lucide-react';
import { triggerHaptic, playPaymentSuccessChime } from '../utils/soundEffects';
import { DEFAULT_CATEGORIES, FALLBACK_COFFEE_IMG } from '../utils/constants';
import { saveImage } from '../utils/saveImage';
import { sanitizeText, sanitizeImageUrl } from '../utils/securityGuard';
import {
  generateUniquePaymentCode,
  extractAmountFromNotification,
  QRIS_EXPIRY_MINUTES,
} from '../utils/qrisAutoMatcher';

const DEFAULT_MENU = [
  {
    id: 'm1',
    name: 'Kopi Susu Gula Aren 1001',
    category: 'Signature',
    price: 18000,
    desc: 'Espresso double shot dengan gula aren organik & susu segar creamy',
    img: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80',
    stock: true,
  },
  {
    id: 'm2',
    name: 'Creamy Cold Brew SK',
    category: 'Signature',
    price: 22000,
    desc: 'Cold brew seduh dingin 12 jam dengan lapisan krim vanilla lembut',
    img: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=400&q=80',
    stock: true,
  },
  {
    id: 'm3',
    name: 'Americano Ice / Hot',
    category: 'Espresso',
    price: 15000,
    desc: 'Espresso house-blend murni dengan air mineral dingin atau hangat',
    img: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=400&q=80',
    stock: true,
  },
  {
    id: 'm4',
    name: 'Matcha Oat Latte',
    category: 'Non-Kopi',
    price: 24000,
    desc: 'Matcha Uji Jepang autentik berpadu dengan susu gandum (Oat)',
    img: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=400&q=80',
    stock: true,
  },
  {
    id: 'm5',
    name: 'Croissant Butter Warm',
    category: 'Camilan',
    price: 18000,
    desc: 'Pastry croissant renyah berlapis dengan mentega Prancis hangat',
    img: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=400&q=80',
    stock: true,
  },
  {
    id: 'm6',
    name: 'Roti Bakar Keju Coklat',
    category: 'Camilan',
    price: 16000,
    desc: 'Roti tawar tebal dipanggang renyah dengan keju dan coklat lumer',
    img: 'https://images.unsplash.com/photo-1584776296944-ab6fb57b0bdd?w=400&q=80',
    stock: true,
  },
];

const STATUS_STEP_MAP = {
  menunggu_pembayaran: 0,
  pending: 1,
  diproses: 2,
  siap: 3,
  siap_diambil: 3,
  selesai: 4,
};

const STATUS_LABEL_MAP = {
  menunggu_pembayaran: 'Menunggu Transfer QRIS Otomatis...',
  pending: 'Lunas / Menunggu Konfirmasi Kasir',
  diproses: 'Sedang Diramu Barista',
  siap: 'Siap Diambil / Diantar!',
  siap_diambil: 'Siap Diambil / Diantar!',
  selesai: 'Pesanan Selesai',
};

export default function CustomerView({
  cart,
  setCart,
  activeTab,
  user,
  userRole,
  orders,
  showToast,
  searchInputRef,
  setActiveTab,
  storeOpen,
}) {
  const [menuList, setMenuList] = useState(DEFAULT_MENU);
  const [selectedCategory, setSelectedCategory] = useState('Semua');
  const [searchQuery, setSearchQuery] = useState('');
  const [categories, setCategories] = useState(DEFAULT_CATEGORIES);

  const [qrisModalOpen, setQrisModalOpen] = useState(false);
  const [sellerQrisImg, setSellerQrisImg] = useState(null);
  const [customerName, setCustomerName] = useState(user?.email ? user.email.split('@')[0] : '');
  const [orderType, setOrderType] = useState('Dine-In');
  const [orderNote, setOrderNote] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('QRIS');
  const [loadingOrder, setLoadingOrder] = useState(false);

  const [activeQrisOrderId, setActiveQrisOrderId] = useState(null);
  const [activeQrisOrder, setActiveQrisOrder] = useState(null);
  const [secondsLeft, setSecondsLeft] = useState(QRIS_EXPIRY_MINUTES * 60);
  const [deletingOrderId, setDeletingOrderId] = useState(null);

  const isSellerBlocked = userRole === 'seller';

  useEffect(() => {
    if (user?.email && !customerName) {
      setCustomerName(user.email.split('@')[0]);
    }
  }, [user]);

  useEffect(() => {
    const unsubMenu = onSnapshot(
      collection(db, 'menu'),
      (snap) => {
        if (!snap.empty) {
          const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
          setMenuList(items);
        }
      },
      () => {}
    );

    const unsubQris = onSnapshot(
      doc(db, 'settings', 'qris'),
      (docSnap) => {
        if (docSnap.exists()) {
          setSellerQrisImg(docSnap.data().qrisImage || null);
        }
      },
      () => {}
    );

    const unsubCat = onSnapshot(
      doc(db, 'settings', 'categories'),
      (snap) => {
        const list = snap.exists() ? snap.data().list : null;
        if (Array.isArray(list)) setCategories(list);
      },
      () => {}
    );

    return () => {
      unsubMenu();
      unsubQris();
      unsubCat();
    };
  }, []);

  // Real-time listener on active QRIS order + automatic payment matcher
  useEffect(() => {
    if (!activeQrisOrderId || !qrisModalOpen) return;

    const orderRef = doc(db, 'orders', activeQrisOrderId);
    const unsubOrder = onSnapshot(orderRef, (snap) => {
      if (!snap.exists()) return;
      const data = { id: snap.id, ...snap.data() };
      setActiveQrisOrder(data);

      if (data.status !== 'menunggu_pembayaran') {
        playPaymentSuccessChime();
        triggerHaptic([30, 50, 30]);
        if (showToast) showToast('Pembayaran QRIS terkonfirmasi! Pesanan masuk antrean.');
        setQrisModalOpen(false);
        setActiveQrisOrderId(null);
        setActiveQrisOrder(null);
        setActiveTab('orders');
      }
    });

    const qPay = query(collection(db, 'qris_payments'), where('matched', '==', false));
    const unsubPay = onSnapshot(
      qPay,
      async (snap) => {
        if (snap.empty || !activeQrisOrder) return;
        const expectedTotal = Number(activeQrisOrder.totalPrice);
        for (const payDoc of snap.docs) {
          const payData = payDoc.data();
          const incomingAmount = extractAmountFromNotification(payData.amount || payData.rawText);
          if (incomingAmount === expectedTotal) {
            try {
              await updateDoc(orderRef, {
                status: 'pending',
                paymentStatus: 'paid',
                paidAt: new Date().toISOString(),
                paymentProofText: String(
                  payData.rawText || `QRIS Rp ${incomingAmount.toLocaleString('id-ID')}`
                ),
              });
              await updateDoc(doc(db, 'qris_payments', payDoc.id), {
                matched: true,
                matchedOrderId: activeQrisOrder.id,
                matchedAmount: incomingAmount,
                matchedAt: new Date().toISOString(),
              });
            } catch {}
            break;
          }
        }
      },
      () => {}
    );

    return () => {
      unsubOrder();
      unsubPay();
    };
  }, [activeQrisOrderId, qrisModalOpen, activeQrisOrder, showToast, setActiveTab]);

  // Countdown timer for QRIS payment window
  useEffect(() => {
    if (!qrisModalOpen || !activeQrisOrder?.paymentExpiresAt) return;
    const tick = () => {
      const diff = Math.max(
        0,
        Math.floor((new Date(activeQrisOrder.paymentExpiresAt).getTime() - Date.now()) / 1000)
      );
      setSecondsLeft(diff);
    };
    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [qrisModalOpen, activeQrisOrder]);

  const addToCart = (item) => {
    if (isSellerBlocked) {
      if (showToast) showToast('Akun Seller tidak diperbolehkan memesan di dalam aplikasi.');
      return;
    }
    if (!storeOpen) {
      if (showToast) showToast('Toko sedang tutup, pesanan belum bisa dibuat.');
      return;
    }
    if (item.stock === false) {
      if (showToast) showToast(`${item.name} sedang habis.`);
      return;
    }
    triggerHaptic(14);
    const exist = cart.find((c) => c.id === item.id);
    if (exist) {
      setCart(cart.map((c) => (c.id === item.id ? { ...c, qty: Math.min(50, c.qty + 1) } : c)));
    } else {
      setCart([...cart, { ...item, qty: 1 }]);
      if (showToast) showToast(`${item.name} masuk keranjang`);
    }
  };

  const updateQty = (id, delta) => {
    if (isSellerBlocked) return;
    triggerHaptic(10);
    setCart(
      cart
        .map((c) => {
          if (c.id === id) {
            const newQty = Math.min(50, c.qty + delta);
            return newQty > 0 ? { ...c, qty: newQty } : null;
          }
          return c;
        })
        .filter(Boolean)
    );
  };

  const cartQtyMap = useMemo(() => {
    const map = {};
    cart.forEach((c) => {
      map[c.id] = c.qty;
    });
    return map;
  }, [cart]);

  const totalPrice = useMemo(
    () => cart.reduce((sum, item) => sum + item.price * item.qty, 0),
    [cart]
  );

  const totalItems = useMemo(
    () => cart.reduce((sum, item) => sum + item.qty, 0),
    [cart]
  );

  const handleCheckoutInit = async (e) => {
    e.preventDefault();
    if (isSellerBlocked) {
      if (showToast) showToast('Seller tidak dapat membuat pesanan.');
      return;
    }
    if (cart.length === 0) return;
    if (!storeOpen) {
      if (showToast) showToast('Toko sedang tutup, pesanan belum bisa dikirim.');
      return;
    }

    const soldOut = cart.filter((c) => menuList.find((m) => m.id === c.id)?.stock === false);
    if (soldOut.length > 0) {
      setCart(cart.filter((c) => !soldOut.includes(c)));
      if (showToast) showToast(`Habis & dihapus dari keranjang: ${soldOut.map((c) => c.name).join(', ')}`);
      return;
    }

    triggerHaptic(18);
    setLoadingOrder(true);
    const cleanCustomer = sanitizeText(customerName, 45) || 'Pelanggan 1001 SK';
    const cleanNote = sanitizeText(orderNote, 140);

    try {
      if (paymentMethod === 'QRIS') {
        const uniqueCode = generateUniquePaymentCode(orders, totalPrice);
        const exactTransferTotal = totalPrice + uniqueCode;
        const expiresAt = new Date(Date.now() + QRIS_EXPIRY_MINUTES * 60 * 1000).toISOString();

        const payload = {
          uid: user?.uid || null,
          customerName: cleanCustomer,
          orderType,
          orderNote: cleanNote,
          paymentMethod: 'QRIS',
          paymentStatus: 'unpaid',
          basePrice: totalPrice,
          uniqueCode,
          totalPrice: exactTransferTotal,
          paymentExpiresAt: expiresAt,
          items: cart.map(({ id, name, price, qty }) => ({
            id,
            name: sanitizeText(name, 60),
            price: Number(price) || 0,
            qty: Number(qty) || 1,
          })),
          status: 'menunggu_pembayaran',
          createdAt: new Date().toISOString(),
        };

        const docRef = await addDoc(collection(db, 'orders'), payload);
        setActiveQrisOrderId(docRef.id);
        setActiveQrisOrder({ id: docRef.id, ...payload });
        setCart([]);
        setOrderNote('');
        setQrisModalOpen(true);
      } else {
        const payload = {
          uid: user?.uid || null,
          customerName: cleanCustomer,
          orderType,
          orderNote: cleanNote,
          paymentMethod: 'Tunai',
          paymentStatus: 'cash_on_counter',
          items: cart.map(({ id, name, price, qty }) => ({
            id,
            name: sanitizeText(name, 60),
            price: Number(price) || 0,
            qty: Number(qty) || 1,
          })),
          totalPrice,
          status: 'pending',
          createdAt: new Date().toISOString(),
        };
        await addDoc(collection(db, 'orders'), payload);
        triggerHaptic([20, 40, 20]);
        if (showToast) showToast('Pesanan tunai berhasil dikirim ke kasir!');
        setCart([]);
        setOrderNote('');
        setActiveTab('orders');
      }
    } catch (err) {
      if (showToast) showToast('Gagal memproses pesanan: ' + err.message);
    } finally {
      setLoadingOrder(false);
    }
  };

  const handleCopyNominal = async (amount) => {
    triggerHaptic(14);
    try {
      await navigator.clipboard.writeText(String(amount));
      if (showToast) showToast(`Nominal ${amount} disalin! Tempel di aplikasi e-wallet/bank.`);
    } catch {
      if (showToast) showToast(`Transfer tepat sebesar Rp ${Number(amount).toLocaleString('id-ID')}`);
    }
  };

  const handleDeleteOrderHistory = async (orderId) => {
    triggerHaptic(15);
    setDeletingOrderId(orderId);
    try {
      await updateDoc(doc(db, 'orders', orderId), { hiddenByCustomer: true });
      if (showToast) showToast('Riwayat pesanan berhasil dihapus');
    } catch (err) {
      if (showToast) showToast('Gagal menghapus riwayat: ' + err.message);
    } finally {
      setDeletingOrderId(null);
    }
  };

  const handleClearCompletedHistory = async () => {
    const completed = orders.filter((o) => o.status === 'selesai');
    if (completed.length === 0) {
      if (showToast) showToast('Belum ada pesanan selesai untuk dibersihkan');
      return;
    }
    triggerHaptic(18);
    try {
      await Promise.all(
        completed.map((o) => updateDoc(doc(db, 'orders', o.id), { hiddenByCustomer: true }))
      );
      if (showToast) showToast(`${completed.length} riwayat selesai dibersihkan`);
    } catch (err) {
      if (showToast) showToast('Gagal membersihkan riwayat: ' + err.message);
    }
  };

  const tabCategories = ['Semua', ...categories];
  useEffect(() => {
    if (selectedCategory !== 'Semua' && !categories.includes(selectedCategory)) {
      setSelectedCategory('Semua');
    }
  }, [categories, selectedCategory]);

  const handleSaveQris = async () => {
    triggerHaptic(14);
    try {
      await saveImage(sellerQrisImg, 'QRIS-1001SK.jpg');
      if (showToast) showToast('Foto QRIS siap disimpan / dibagikan!');
    } catch (err) {
      if (showToast) showToast('Gagal menyimpan QRIS: ' + (err?.message || 'coba lagi'));
    }
  };

  const featuredItems = useMemo(() => {
    const sig = menuList.filter((m) => m.category === 'Signature');
    return sig.length > 0 ? sig : menuList.slice(0, 4);
  }, [menuList]);

  const filteredMenu = useMemo(() => {
    return menuList.filter((m) => {
      const matchCat = selectedCategory === 'Semua' || m.category === selectedCategory;
      const matchSearch =
        !searchQuery.trim() ||
        m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (m.desc && m.desc.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchCat && matchSearch;
    });
  }, [menuList, selectedCategory, searchQuery]);

  const formattedCountdown = `${String(Math.floor(secondsLeft / 60)).padStart(2, '0')}:${String(
    secondsLeft % 60
  ).padStart(2, '0')}`;

  return (
    <div className="page-transition">
      {activeTab === 'menu' && (
        <>
          {!storeOpen && (
            <div className="store-closed-note">
              Toko sedang tutup. Kamu masih bisa melihat menu, tapi belum bisa memesan.
            </div>
          )}

          {/* Search Bar */}
          <div className="ios-search-wrap">
            <div className="ios-search-box">
              <Search size={16} color="var(--text-sub)" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari kopi favorit, matcha, atau camilan..."
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: 'var(--text-sub)',
                    cursor: 'pointer',
                    display: 'flex',
                  }}
                >
                  <X size={15} />
                </button>
              )}
            </div>
          </div>

          {/* Category Tabs */}
          <div className="ios-tabs" data-no-swipe="true">
            {tabCategories.map((cat) => (
              <button
                key={cat}
                type="button"
                className={`tab-btn ${selectedCategory === cat ? 'active' : ''}`}
                onClick={() => {
                  triggerHaptic(8);
                  setSelectedCategory(cat);
                }}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Featured Carousel dengan Foto Produk */}
          {selectedCategory === 'Semua' && !searchQuery.trim() && (
            <>
              <div className="section-heading">
                <div className="section-eyebrow">Racikan Terlaris Barista</div>
                <div className="section-title">Menu Andalan 1001 SK</div>
              </div>
              <div className="featured-carousel" data-no-swipe="true">
                {featuredItems.map((item) => {
                  const safeImg = sanitizeImageUrl(item.img, FALLBACK_COFFEE_IMG);
                  return (
                    <div
                      key={item.id}
                      className="featured-card"
                      onClick={() => addToCart(item)}
                    >
                      <div className="featured-poster">
                        <img
                          src={safeImg}
                          alt={item.name}
                          loading="lazy"
                          onError={(e) => {
                            e.currentTarget.onerror = null;
                            e.currentTarget.src = FALLBACK_COFFEE_IMG;
                          }}
                        />
                        {item.stock !== false && (
                          <button
                            type="button"
                            className="featured-quick-add"
                            onClick={(e) => {
                              e.stopPropagation();
                              addToCart(item);
                            }}
                            aria-label={`Tambah ${item.name}`}
                          >
                            <Plus size={16} />
                          </button>
                        )}
                      </div>
                      <div
                        style={{
                          fontSize: 13,
                          fontWeight: 800,
                          color: 'var(--text-main)',
                          whiteSpace: 'nowrap',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                        }}
                      >
                        {item.name}
                      </div>
                      <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--accent-primary)' }}>
                        Rp {Number(item.price || 0).toLocaleString('id-ID')}
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}

          {/* Semua Menu Grid dengan Foto Produk */}
          <div className="section-heading" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
            <div>
              <div className="section-eyebrow">Geser kiri/kanan untuk cek pesanan</div>
              <div className="section-title">
                {selectedCategory === 'Semua' ? 'Semua Menu' : selectedCategory}
              </div>
            </div>
          </div>

          <div className="menu-grid">
            {filteredMenu.map((item) => {
              const qty = cartQtyMap[item.id] || 0;
              const safeImg = sanitizeImageUrl(item.img, FALLBACK_COFFEE_IMG);
              return (
                <div
                  key={item.id}
                  className={`glass-panel menu-card ${item.stock === false ? 'sold-out' : ''}`}
                >
                  <div>
                    <div className="menu-img-wrap">
                      <img
                        className="menu-img"
                        src={safeImg}
                        alt={item.name}
                        loading="lazy"
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = FALLBACK_COFFEE_IMG;
                        }}
                      />
                      <span className="menu-cat-pill">{item.category}</span>
                    </div>
                    <h4 className="menu-title">{item.name}</h4>
                    <p className="menu-desc">{item.desc}</p>
                  </div>

                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: 6,
                      marginTop: 4,
                    }}
                  >
                    <span className="menu-price">
                      Rp {Number(item.price || 0).toLocaleString('id-ID')}
                    </span>

                    {item.stock === false ? (
                      <span className="sold-out-pill">Habis</span>
                    ) : qty > 0 ? (
                      <div className="qty-pill">
                        <button
                          type="button"
                          onClick={() => updateQty(item.id, -1)}
                          aria-label="Kurangi"
                        >
                          <Minus size={13} />
                        </button>
                        <span>{qty}</span>
                        <button
                          type="button"
                          onClick={() => updateQty(item.id, 1)}
                          aria-label="Tambah"
                        >
                          <Plus size={13} />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        className="btn-add"
                        onClick={() => addToCart(item)}
                      >
                        <Plus size={13} /> Tambah
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {/* Tab Riwayat & Status Pesanan */}
      {activeTab === 'orders' && (
        <div style={{ padding: '14px 18px' }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: 10,
              marginBottom: 14,
            }}
          >
            <div>
              <h3 style={{ fontSize: 18, fontWeight: 800 }}>Status & Riwayat Pesanan</h3>
              <p style={{ fontSize: 12, color: 'var(--text-sub)' }}>
                Verifikasi QRIS otomatis & notifikasi siap ambil
              </p>
            </div>
            {orders.some((o) => o.status === 'selesai') && (
              <button
                type="button"
                className="delete-icon-btn"
                onClick={handleClearCompletedHistory}
              >
                <Trash2 size={13} /> Bersihkan Selesai
              </button>
            )}
          </div>

          {orders.length === 0 ? (
            <div className="glass-panel" style={{ padding: 26, textAlign: 'center' }}>
              <Clock size={34} color="var(--accent-primary)" style={{ marginBottom: 10 }} />
              <div style={{ fontSize: 15, fontWeight: 800, marginBottom: 4 }}>
                Belum Ada Riwayat Pesanan
              </div>
              <p style={{ fontSize: 12.5, color: 'var(--text-sub)' }}>
                Geser ke kanan untuk kembali ke menu kopi dan buat pesanan pertamamu.
              </p>
            </div>
          ) : (
            orders.map((ord) => {
              const currentStep = STATUS_STEP_MAP[ord.status] || 0;
              const isAwaitingQris = ord.status === 'menunggu_pembayaran';
              return (
                <div key={ord.id} className="glass-panel" style={{ padding: 15, marginBottom: 12 }}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      justifyContent: 'space-between',
                      gap: 8,
                    }}
                  >
                    <div>
                      <div style={{ fontSize: 14.5, fontWeight: 800 }}>{ord.customerName}</div>
                      <div style={{ fontSize: 11.5, color: 'var(--text-sub)' }}>
                        {ord.orderType} • {ord.paymentMethod}
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span className={`badge-status status-${ord.status}`}>
                        {isAwaitingQris
                          ? 'Belum Bayar'
                          : ord.status === 'pending'
                          ? 'Masuk'
                          : ord.status === 'siap_diambil'
                          ? 'Siap'
                          : ord.status}
                      </span>
                      <button
                        type="button"
                        className="delete-icon-btn"
                        disabled={deletingOrderId === ord.id}
                        onClick={() => handleDeleteOrderHistory(ord.id)}
                        title="Hapus riwayat pesanan ini"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>

                  {/* 4-Step Progress Bar */}
                  <div className="order-progress-bar">
                    {[1, 2, 3, 4].map((step) => (
                      <div
                        key={step}
                        className={`progress-step ${currentStep >= step ? 'done' : ''}`}
                      />
                    ))}
                  </div>
                  <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--accent-primary)', marginBottom: 8 }}>
                    {STATUS_LABEL_MAP[ord.status] || 'Diproses'}
                  </div>

                  {ord.orderNote && (
                    <div
                      style={{
                        fontSize: 11.5,
                        color: 'var(--text-sub)',
                        background: 'var(--glass-pill)',
                        padding: '6px 10px',
                        borderRadius: 10,
                        marginBottom: 8,
                      }}
                    >
                      Catatan: {ord.orderNote}
                    </div>
                  )}

                  <div style={{ borderTop: '1px solid var(--glass-border)', paddingTop: 8 }}>
                    {ord.items?.map((it, i) => (
                      <div
                        key={i}
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          fontSize: 12.5,
                          marginBottom: 4,
                        }}
                      >
                        <span>
                          {it.qty}x {it.name}
                        </span>
                        <span style={{ color: 'var(--text-sub)' }}>
                          Rp {(it.price * it.qty).toLocaleString('id-ID')}
                        </span>
                      </div>
                    ))}
                    {ord.uniqueCode && (
                      <div
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          fontSize: 12,
                          color: 'var(--accent-orange)',
                          fontWeight: 700,
                          marginTop: 4,
                        }}
                      >
                        <span>Kode Unik QRIS Otomatis</span>
                        <span>+Rp {ord.uniqueCode}</span>
                      </div>
                    )}
                  </div>

                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      borderTop: '1px solid var(--glass-border)',
                      marginTop: 8,
                      paddingTop: 8,
                      fontWeight: 800,
                      fontSize: 13.5,
                    }}
                  >
                    <span>Total Pembayaran</span>
                    <span style={{ color: 'var(--accent-primary)' }}>
                      Rp {Number(ord.totalPrice || 0).toLocaleString('id-ID')}
                    </span>
                  </div>

                  {isAwaitingQris && (
                    <button
                      type="button"
                      className="ios-btn-primary"
                      style={{ marginTop: 10, padding: '10px 14px', fontSize: 13 }}
                      onClick={() => {
                        setActiveQrisOrderId(ord.id);
                        setActiveQrisOrder(ord);
                        setQrisModalOpen(true);
                      }}
                    >
                      <QrCode size={16} /> Buka Kode QRIS & Nominal Transfer
                    </button>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Tab Keranjang & Checkout QRIS / Tunai */}
      {activeTab === 'cart' && !isSellerBlocked && (
        <div style={{ padding: '14px 18px' }}>
          <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 12 }}>Keranjang Pesanan</h3>

          {!storeOpen && (
            <div className="store-closed-note" style={{ margin: '0 0 12px' }}>
              Toko sedang tutup. Pesanan belum bisa dikirim.
            </div>
          )}

          {cart.length === 0 ? (
            <div className="glass-panel" style={{ padding: 26, textAlign: 'center' }}>
              <ShoppingBag size={34} color="var(--accent-primary)" style={{ marginBottom: 10 }} />
              <div style={{ fontSize: 15, fontWeight: 800, marginBottom: 4 }}>
                Keranjang Masih Kosong
              </div>
              <p style={{ fontSize: 12.5, color: 'var(--text-sub)', marginBottom: 14 }}>
                Pilih kopi atau camilan favoritmu dulu.
              </p>
              <button
                type="button"
                className="ios-btn-primary"
                style={{ marginTop: 0 }}
                onClick={() => setActiveTab('menu')}
              >
                Lihat Menu
              </button>
            </div>
          ) : (
            <>
              <div className="glass-panel" style={{ padding: 14, marginBottom: 14 }}>
                {cart.map((item) => (
                  <div
                    key={item.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: 10,
                      padding: '8px 0',
                      borderBottom: '1px solid var(--glass-border)',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
                      <img
                        src={sanitizeImageUrl(item.img, FALLBACK_COFFEE_IMG)}
                        alt={item.name}
                        style={{
                          width: 44,
                          height: 44,
                          borderRadius: 11,
                          objectFit: 'cover',
                          flexShrink: 0,
                        }}
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = FALLBACK_COFFEE_IMG;
                        }}
                      />
                      <div style={{ minWidth: 0 }}>
                        <div
                          style={{
                            fontSize: 13.5,
                            fontWeight: 800,
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >
                          {item.name}
                        </div>
                        <div style={{ fontSize: 12, color: 'var(--accent-primary)', fontWeight: 700 }}>
                          Rp {(item.price * item.qty).toLocaleString('id-ID')}
                        </div>
                      </div>
                    </div>

                    <div className="qty-pill">
                      <button type="button" onClick={() => updateQty(item.id, -1)}>
                        <Minus size={13} />
                      </button>
                      <span>{item.qty}</span>
                      <button type="button" onClick={() => updateQty(item.id, 1)}>
                        <Plus size={13} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <form onSubmit={handleCheckoutInit} className="glass-panel" style={{ padding: 16 }}>
                <div style={{ marginBottom: 11 }}>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                    Nama Pemesan
                  </label>
                  <input
                    type="text"
                    className="ios-input"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Masukkan Nama Anda"
                    required
                  />
                </div>

                <div style={{ marginBottom: 11 }}>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                    Tipe Pesanan
                  </label>
                  <select
                    className="ios-input"
                    value={orderType}
                    onChange={(e) => setOrderType(e.target.value)}
                  >
                    <option value="Dine-In">Dine-In (Di Tempat)</option>
                    <option value="Takeaway">Bawa Pulang</option>
                  </select>
                </div>

                <div style={{ marginBottom: 11 }}>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                    Catatan Barista (Opsional)
                  </label>
                  <input
                    type="text"
                    className="ios-input"
                    value={orderNote}
                    onChange={(e) => setOrderNote(e.target.value)}
                    placeholder="Contoh: Less ice, gula aren normal"
                  />
                </div>

                <div style={{ marginBottom: 14 }}>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                    Metode Pembayaran
                  </label>
                  <select
                    className="ios-input"
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                  >
                    <option value="QRIS">QRIS Otomatis (Verifikasi Instan Kode Unik)</option>
                    <option value="Tunai">Bayar Tunai di Kasir</option>
                  </select>
                </div>

                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    paddingTop: 10,
                    borderTop: '1px solid var(--glass-border)',
                    fontWeight: 800,
                    fontSize: 14.5,
                  }}
                >
                  <span>Subtotal ({totalItems} item)</span>
                  <span style={{ color: 'var(--accent-primary)' }}>
                    Rp {totalPrice.toLocaleString('id-ID')}
                  </span>
                </div>

                <button type="submit" className="ios-btn-primary" disabled={loadingOrder}>
                  {loadingOrder ? (
                    'Menyiapkan Kode QRIS...'
                  ) : paymentMethod === 'QRIS' ? (
                    <>
                      <QrCode size={17} /> Bayar via QRIS Otomatis
                    </>
                  ) : (
                    <>
                      Kirim Pesanan Sekarang <ChevronRight size={17} />
                    </>
                  )}
                </button>
              </form>
            </>
          )}
        </div>
      )}

      {/* Modal QRIS Verifikasi Otomatis */}
      {qrisModalOpen && activeQrisOrder && !isSellerBlocked && (
        <div className="ios-modal-overlay" onClick={() => setQrisModalOpen(false)}>
          <div className="ios-modal-sheet" onClick={(e) => e.stopPropagation()}>
            <div className="sheet-handle" />
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: 8,
              }}
            >
              <h3 style={{ fontSize: 18, fontWeight: 800 }}>Pembayaran QRIS Otomatis</h3>
              <span
                style={{
                  padding: '4px 10px',
                  borderRadius: 999,
                  background: 'rgba(255, 159, 10, 0.18)',
                  color: 'var(--accent-orange)',
                  fontSize: 12,
                  fontWeight: 800,
                }}
              >
                {formattedCountdown}
              </span>
            </div>

            <p style={{ fontSize: 12.5, color: 'var(--text-sub)', lineHeight: 1.45, marginBottom: 12 }}>
              Transfer <strong>tepat hingga 3 digit terakhir</strong> agar sistem mendeteksi pembayaran Anda secara otomatis tanpa konfirmasi manual.
            </p>

            {/* Box Nominal Tepat + Kode Unik */}
            <div
              className="glass-panel"
              style={{
                padding: 14,
                textAlign: 'center',
                borderColor: 'var(--accent-primary)',
                marginBottom: 12,
              }}
            >
              <div style={{ fontSize: 11.5, color: 'var(--text-sub)', marginBottom: 4 }}>
                Subtotal Rp {Number(activeQrisOrder.basePrice || 0).toLocaleString('id-ID')} + Kode Unik{' '}
                <strong style={{ color: 'var(--accent-orange)' }}>{activeQrisOrder.uniqueCode}</strong>
              </div>
              <div
                style={{
                  fontSize: 26,
                  fontWeight: 800,
                  color: 'var(--accent-primary)',
                  letterSpacing: '-0.5px',
                  marginBottom: 8,
                }}
              >
                Rp {Number(activeQrisOrder.totalPrice || 0).toLocaleString('id-ID')}
              </div>
              <button
                type="button"
                onClick={() => handleCopyNominal(activeQrisOrder.totalPrice)}
                style={{
                  background: 'var(--accent-primary)',
                  color: 'var(--accent-contrast)',
                  border: 'none',
                  borderRadius: 999,
                  padding: '6px 14px',
                  fontSize: 12,
                  fontWeight: 800,
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 6,
                  cursor: 'pointer',
                }}
              >
                <Copy size={13} /> Salin Nominal ({activeQrisOrder.totalPrice})
              </button>
            </div>

            {sellerQrisImg ? (
              <div className="qris-display-box">
                <img src={sanitizeImageUrl(sellerQrisImg)} alt="Barcode QRIS 1001 SK" />
              </div>
            ) : (
              <div
                className="glass-panel"
                style={{ padding: 20, textAlign: 'center', margin: '12px 0', fontSize: 13 }}
              >
                Penjual belum mengunggah gambar QRIS.
                <br />
                Tunjukkan layar ini saat membayar di kasir.
              </div>
            )}

            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8,
                fontSize: 12,
                fontWeight: 700,
                color: 'var(--accent-green)',
                marginBottom: 10,
              }}
            >
              <RefreshCw size={14} className="spin-slow" />
              <span>Menunggu notifikasi transfer masuk otomatis...</span>
            </div>

            {sellerQrisImg && (
              <button
                type="button"
                className="ios-btn-primary"
                style={{ marginTop: 4 }}
                onClick={handleSaveQris}
              >
                <Download size={16} /> Simpan Foto QRIS ke Galeri
              </button>
            )}
            <button
              type="button"
              className="ios-btn-secondary"
              onClick={() => {
                setQrisModalOpen(false);
                setActiveTab('orders');
              }}
            >
              Tutup (Cek Status di Tab Pesanan)
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
