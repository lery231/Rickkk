import React, { useState, useEffect, useMemo } from 'react';
import { db } from '../firebase';
import {
  collection,
  onSnapshot,
  addDoc,
  updateDoc,
  doc,
  query,
  where,
} from 'firebase/firestore';
import {
  Plus,
  Minus,
  Search,
  ShoppingBag,
  ChevronRight,
  QrCode,
  CheckCircle2,
  Clock,
  Trash2,
  Sparkles,
  X,
  Download,
  Copy,
  RefreshCw,
} from 'lucide-react';
import { triggerHaptic, playPaymentSuccessChime } from '../utils/soundEffects';
import { DEFAULT_CATEGORIES } from '../utils/constants';
import { saveImage } from '../utils/saveImage';
import {
  generateUniquePaymentCode,
  extractAmountFromNotification,
  QRIS_EXPIRY_MINUTES,
} from '../utils/qrisAutoMatcher';

const DEFAULT_MENU = [
  { id: 'm1', name: 'Kopi Susu Gula Aren 1001', category: 'Signature', price: 18000, desc: 'Espresso double shot dengan gula aren organik & susu segar creamy', img: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80', stock: true },
  { id: 'm2', name: 'Creamy Cold Brew SK', category: 'Signature', price: 22000, desc: 'Cold brew seduh dingin 12 jam dengan lapisan krim vanilla lembut', img: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=400&q=80', stock: true },
  { id: 'm3', name: 'Americano Ice / Hot', category: 'Espresso', price: 15000, desc: 'Espresso house-blend murni dengan air mineral dingin atau hangat', img: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=400&q=80', stock: true },
  { id: 'm4', name: 'Matcha Oat Latte', category: 'Non-Kopi', price: 24000, desc: 'Matcha Uji Jepang autentik berpadu dengan susu gandum (Oat)', img: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=400&q=80', stock: true },
  { id: 'm5', name: 'Croissant Butter Warm', category: 'Camilan', price: 18000, desc: 'Pastry croissant renyah berlapis dengan mentega Prancis hangat', img: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=400&q=80', stock: true },
  { id: 'm6', name: 'Roti Bakar Keju Coklat', category: 'Camilan', price: 16000, desc: 'Roti tawar tebal dipanggang renyah dengan keju dan coklat lumer', img: 'https://images.unsplash.com/photo-1584776296944-ab6fb57b0bdd?w=400&q=80', stock: true },
];

const STATUS_STEP_MAP = {
  menunggu_pembayaran: 0,
  pending: 1,
  diproses: 2,
  siap: 3,
  selesai: 4,
};

const STATUS_LABEL_MAP = {
  menunggu_pembayaran: 'Menunggu Transfer QRIS Otomatis...',
  pending: 'Lunas / Menunggu Konfirmasi Kasir',
  diproses: 'Sedang Diramu Barista',
  siap: 'Siap Diambil / Diantar!',
  selesai: 'Pesanan Selesai',
};

export default function CustomerView({
  cart,
  setCart,
  activeTab,
  user,
  userRole,
  orders,
  showToast,
  searchInputRef,
  setActiveTab,
  storeOpen,
}) {
  const [menuList, setMenuList] = useState(DEFAULT_MENU);
  const [selectedCategory, setSelectedCategory] = useState('Semua');
  const [searchQuery, setSearchQuery] = useState('');
  const [categories, setCategories] = useState(DEFAULT_CATEGORIES);

  const [qrisModalOpen, setQrisModalOpen] = useState(false);
  const [sellerQrisImg, setSellerQrisImg] = useState(null);
  const [customerName, setCustomerName] = useState(user?.email ? user.email.split('@')[0] : '');
  const [orderType, setOrderType] = useState('Dine-In');
  const [orderNote, setOrderNote] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('QRIS');
  const [loadingOrder, setLoadingOrder] = useState(false);

  // Active QRIS order awaiting automatic webhook confirmation
  const [activeQrisOrderId, setActiveQrisOrderId] = useState(null);
  const [activeQrisOrder, setActiveQrisOrder] = useState(null);
  const [secondsLeft, setSecondsLeft] = useState(QRIS_EXPIRY_MINUTES * 60);
  const [deletingOrderId, setDeletingOrderId] = useState(null);

  const isSellerBlocked = userRole === 'seller';

  useEffect(() => {
    if (user?.email && !customerName) {
      setCustomerName(user.email.split('@')[0]);
    }
  }, [user]);

  useEffect(() => {
    const unsubMenu = onSnapshot(collection(db, 'menu'), (snap) => {
      if (!snap.empty) {
        const items = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        setMenuList(items);
      }
    }, () => {});

    const unsubQris = onSnapshot(doc(db, 'settings', 'qris'), (docSnap) => {
      if (docSnap.exists()) {
        setSellerQrisImg(docSnap.data().qrisImage);
      }
    }, () => {});

    const unsubCat = onSnapshot(doc(db, 'settings', 'categories'), (snap) => {
      const list = snap.exists() ? snap.data().list : null;
      if (Array.isArray(list)) setCategories(list);
    }, () => {});

    return () => {
      unsubMenu();
      unsubQris();
      unsubCat();
    };
  }, []);

  // Real-time listener on active QRIS order + automatic payment matcher
  useEffect(() => {
    if (!activeQrisOrderId || !qrisModalOpen) return;

    const orderRef = doc(db, 'orders', activeQrisOrderId);
    const unsubOrder = onSnapshot(orderRef, (snap) => {
      if (!snap.exists()) return;
      const data = { id: snap.id, ...snap.data() };
      setActiveQrisOrder(data);

      // Begitu status berubah dari menunggu_pembayaran ke pending (lunas otomatis atau manual kasir)
      if (data.status !== 'menunggu_pembayaran') {
        playPaymentSuccessChime();
        triggerHaptic([30, 50, 30]);
        if (showToast) showToast('Pembayaran QRIS terkonfirmasi! Pesanan masuk antrean.');
        setQrisModalOpen(false);
        setActiveQrisOrderId(null);
        setActiveQrisOrder(null);
        setActiveTab('orders');
      }
    });

    // Dengarkan juga dokumen qris_payments yang belum cocok langsung dari HP pembeli
    const qPay = query(collection(db, 'qris_payments'), where('matched', '==', false));
    const unsubPay = onSnapshot(qPay, async (snap) => {
      if (snap.empty || !activeQrisOrder) return;
      const expectedTotal = Number(activeQrisOrder.totalPrice);

      for (const payDoc of snap.docs) {
        const payData = payDoc.data();
        const incomingAmount = extractAmountFromNotification(payData.amount || payData.rawText);
        if (incomingAmount === expectedTotal) {
          try {
            await updateDoc(orderRef, {
              status: 'pending',
              paymentStatus: 'paid',
              paidAt: new Date().toISOString(),
              paymentProofText: String(payData.rawText || `QRIS Rp ${incomingAmount.toLocaleString('id-ID')}`),
            });
            await updateDoc(doc(db, 'qris_payments', payDoc.id), {
              matched: true,
              matchedOrderId: activeQrisOrder.id,
              matchedAmount: incomingAmount,
              matchedAt: new Date().toISOString(),
            });
          } catch {}
          break;
        }
      }
    }, () => {});

    return () => {
      unsubOrder();
      unsubPay();
    };
  }, [activeQrisOrderId, qrisModalOpen, activeQrisOrder, showToast, setActiveTab]);

  // Countdown timer for QRIS payment window
  useEffect(() => {
    if (!qrisModalOpen || !activeQrisOrder?.paymentExpiresAt) return;
    const tick = () => {
      const diff = Math.max(
        0,
        Math.floor((new Date(activeQrisOrder.paymentExpiresAt).getTime() - Date.now()) / 1000)
      );
      setSecondsLeft(diff);
    };
    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [qrisModalOpen, activeQrisOrder]);

  const addToCart = (item) => {
    if (isSellerBlocked) {
      if (showToast) showToast('Akun Seller tidak diperbolehkan memesan di dalam aplikasi.');
      return;
    }
    if (!storeOpen) {
      if (showToast) showToast('Toko sedang tutup, pesanan belum bisa dibuat.');
      return;
    }
    if (item.stock === false) {
      if (showToast) showToast(`${item.name} sedang habis.`);
      return;
    }
    triggerHaptic(14);
    const exist = cart.find(c => c.id === item.id);
    if (exist) {
      setCart(cart.map(c => c.id === item.id ? { ...c, qty: c.qty + 1 } : c));
    } else {
      setCart([...cart, { ...item, qty: 1 }]);
      if (showToast) showToast(`${item.name} masuk keranjang`);
    }
  };

  const updateQty = (id, delta) => {
    if (isSellerBlocked) return;
    triggerHaptic(10);
    setCart(cart.map(c => {
      if (c.id === id) {
        const newQty = c.qty + delta;
        return newQty > 0 ? { ...c, qty: newQty } : null;
      }
      return c;
    }).filter(Boolean));
  };

  const cartQtyMap = useMemo(() => {
    const map = {};
    cart.forEach(c => { map[c.id] = c.qty; });
    return map;
  }, [cart]);

  const totalPrice = useMemo(
    () => cart.reduce((sum, item) => sum + (item.price * item.qty), 0),
    [cart]
  );

  const totalItems = useMemo(
    () => cart.reduce((sum, item) => sum + item.qty, 0),
    [cart]
  );

  const handleCheckoutInit = async (e) => {
    e.preventDefault();
    if (isSellerBlocked) {
      if (showToast) showToast('Seller tidak dapat membuat pesanan.');
      return;
    }
    if (cart.length === 0) return;
    if (!storeOpen) {
      if (showToast) showToast('Toko sedang tutup, pesanan belum bisa dikirim.');
      return;
    }
    const soldOut = cart.filter(c => menuList.find(m => m.id === c.id)?.stock === false);
    if (soldOut.length > 0) {
      setCart(cart.filter(c => !soldOut.includes(c)));
      if (showToast) showToast(`Habis & dihapus dari keranjang: ${soldOut.map(c => c.name).join(', ')}`);
      return;
    }

    triggerHaptic(18);
    setLoadingOrder(true);

    try {
      if (paymentMethod === 'QRIS') {
        const uniqueCode = generateUniquePaymentCode(orders, totalPrice);
        const exactTransferTotal = totalPrice + uniqueCode;
        const expiresAt = new Date(Date.now() + QRIS_EXPIRY_MINUTES * 60 * 1000).toISOString();

        const payload = {
          uid: user?.uid || null,
          customerName: customerName || 'Pelanggan 1001 SK',
          orderType,
          orderNote: orderNote.trim(),
          paymentMethod: 'QRIS',
          paymentStatus: 'unpaid',
          basePrice: totalPrice,
          uniqueCode,
          totalPrice: exactTransferTotal,
          paymentExpiresAt: expiresAt,
          items: cart.map(({ id, name, price, qty }) => ({ id, name, price, qty })),
          status: 'menunggu_pembayaran',
          createdAt: new Date().toISOString(),
        };

        const docRef = await addDoc(collection(db, 'orders'), payload);
        setActiveQrisOrderId(docRef.id);
        setActiveQrisOrder({ id: docRef.id, ...payload });
        setCart([]);
        setOrderNote('');
        setQrisModalOpen(true);
      } else {
        const payload = {
          uid: user?.uid || null,
          customerName: customerName || 'Pelanggan 1001 SK',
          orderType,
          orderNote: orderNote.trim(),
          paymentMethod: 'Tunai',
          paymentStatus: 'cash_on_counter',
          items: cart.map(({ id, name, price, qty }) => ({ id, name, price, qty })),
          totalPrice,
          status: 'pending',
          createdAt: new Date().toISOString(),
        };
        await addDoc(collection(db, 'orders'), payload);
        triggerHaptic([20, 40, 20]);
        if (showToast) showToast('Pesanan tunai berhasil dikirim ke kasir!');
        setCart([]);
        setOrderNote('');
        setActiveTab('orders');
      }
    } catch (err) {
      if (showToast) showToast('Gagal memproses pesanan: ' + err.message);
    } finally {
      setLoadingOrder(false);
    }
  };

  const handleCopyNominal = async (amount) => {
    triggerHaptic(14);
    try {
      await navigator.clipboard.writeText(String(amount));
      if (showToast) showToast(`Nominal ${amount} disalin! Tempel di aplikasi e-wallet/bank.`);
    } catch {
      if (showToast) showToast(`Transfer tepat sebesar Rp ${Number(amount).toLocaleString('id-ID')}`);
    }
  };

  const handleDeleteOrderHistory = async (orderId) => {
    triggerHaptic(15);
    setDeletingOrderId(orderId);
    try {
      await updateDoc(doc(db, 'orders', orderId), { hiddenByCustomer: true });
      if (showToast) showToast('Riwayat pesanan berhasil dihapus');
    } catch (err) {
      if (showToast) showToast('Gagal menghapus riwayat: ' + err.message);
    } finally {
      setDeletingOrderId(null);
    }
  };

  const handleClearCompletedHistory = async () => {
    const completed = orders.filter(o => o.status === 'selesai');
    if (completed.length === 0) {
      if (showToast) showToast('Belum ada pesanan selesai untuk dibersihkan');
      return;
    }
    triggerHaptic(18);
    try {
      await Promise.all(completed.map(o => updateDoc(doc(db, 'orders', o.id), { hiddenByCustomer: true })));
      if (showToast) showToast(`${completed.length} riwayat selesai dibersihkan`);
    } catch (err) {
      if (showToast) showToast('Gagal membersihkan riwayat: ' + err.message);
    }
  };

  const tabCategories = ['Semua', ...categories];
  useEffect(() => {
    if (selectedCategory !== 'Semua' && !categories.includes(selectedCategory)) setSelectedCategory('Semua');
  }, [categories, selectedCategory]);

  const handleSaveQris = async () => {
    triggerHaptic(14);
    try {
      await saveImage(sellerQrisImg, 'QRIS-1001SK.jpg');
    } catch (err) {
      if (showToast) showToast('Gagal menyimpan QRIS: ' + (err?.message || 'coba lagi'));
    }
  };

  const featuredItems = useMemo(() => {
    const sig = menuList.filter(m => m.category === 'Signature');
    return sig.length > 0 ? sig : menuList.slice(0, 4);
  }, [menuList]);

  const filteredMenu = useMemo(() => {
    return menuList.filter(m => {
      const matchCat = selectedCategory === 'Semua' || m.category === selectedCategory;
      const matchSearch = !searchQuery.trim() ||
        m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (m.desc && m.desc.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchCat && matchSearch;
    });
  }, [menuList, selectedCategory, searchQuery]);

  const formattedCountdown = `${String(Math.floor(secondsLeft / 60)).padStart(2, '0')}:${String(secondsLeft % 60).padStart(2, '0')}`;

  return (
    <div className="page-transition">
      {activeTab === 'menu' && (
        <>
          {!storeOpen && <div className="store-closed-note">Toko sedang tutup. Kamu masih bisa melihat menu, tapi belum bisa memesan.</div>}
          <div className="ios-search-wrap">
            <div className="ios-search-box">
              <Search size={17} color="var(--text-sub)" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari kopi favorit, matcha, atau camilan..."
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  style={{ background: 'none', border: 'none', color: 'var(--text-sub)', cursor: 'pointer', display: 'flex' }}
                >
                  <X size={15} />
                </button>
              )}
            </div>
          </div>

          <div className="ios-tabs">
            {tabCategories.map(cat => (
              <button
                key={cat}
                className={`tab-btn ${selectedCategory === cat ? 'active' : ''}`}
                onClick={() => { triggerHaptic(8); setSelectedCategory(cat); }}
              >
                {cat}
              </button>
            ))}
          </div>

          {selectedCategory === 'Semua' && !searchQuery.trim() && (
            <>
              <div className="section-heading">
                <div className="section-eyebrow">Racikan Terlaris Barista</div>
                <div className="section-title">Menu Andalan 1001 SK</div>
              </div>
              <div className="featured-carousel" data-no-swipe="true">
                {featuredItems.map((item) => (
                  <div key={item.id} className="featured-card" onClick={() => addToCart(item)}>
                    <div className="featured-poster">
                      <img src={item.img} alt={item.name} loading="lazy" />
                      <button
                        className="featured-quick-add"
                        onClick={(e) => { e.stopPropagation(); addToCart(item); }}
                        aria-label={`Tambah ${item.name}`}
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 800, color: 'var(--text-main)', lineHeight: 1.25 }}>{item.name}</div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--accent-primary)', marginTop: 2 }}>Rp {item.price.toLocaleString('id-ID')}</div>
                  </div>
                ))}
              </div>
            </>
          )}

          <div className="section-heading">
            <div className="section-eyebrow">Geser kiri/kanan untuk cek pesanan</div>
            <div className="section-title">{selectedCategory === 'Semua' ? 'Semua Menu' : selectedCategory}</div>
          </div>

          <div className="menu-grid">
            {filteredMenu.map((item) => {
              const qty = cartQtyMap[item.id] || 0;
              return (
                <div key={item.id} className={`glass-panel menu-card ${item.stock === false ? 'sold-out' : ''}`}>
                  <div>
                    <div className="menu-img-wrap">
                      <img src={item.img} alt={item.name} className="menu-img" loading="lazy" />
                      <span className="menu-cat-pill">{item.category}</span>
                    </div>
                    <h4 className="menu-title">{item.name}</h4>
                    <p className="menu-desc">{item.desc}</p>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 4 }}>
                    <span className="menu-price">Rp {item.price.toLocaleString('id-ID')}</span>
                    {item.stock === false ? (
                      <span className="sold-out-pill">Habis</span>
                    ) : qty > 0 ? (
                      <div className="qty-pill">
                        <button onClick={() => updateQty(item.id, -1)} aria-label="Kurangi"><Minus size={13} /></button>
                        <span>{qty}</span>
                        <button onClick={() => updateQty(item.id, 1)} aria-label="Tambah"><Plus size={13} /></button>
                      </div>
                    ) : (
                      <button className="btn-add" onClick={() => addToCart(item)}>
                        <Plus size={14} /> Tambah
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {activeTab === 'orders' && (
        <div style={{ padding: '16px 18px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
            <div>
              <h3 style={{ fontSize: 19, fontWeight: 800 }}>Status & Riwayat Pesanan</h3>
              <p style={{ fontSize: 12, color: 'var(--text-sub)' }}>Verifikasi QRIS otomatis & notifikasi siap ambil</p>
            </div>
            {orders.some(o => o.status === 'selesai') && (
              <button className="delete-icon-btn" onClick={handleClearCompletedHistory}>
                <Trash2 size={13} /> Bersihkan Selesai
              </button>
            )}
          </div>

          {orders.length === 0 ? (
            <div className="glass-panel" style={{ padding: 34, textAlign: 'center', color: 'var(--text-sub)' }}>
              <Clock size={36} style={{ margin: '0 auto 10px', opacity: 0.55 }} />
              <div style={{ fontWeight: 700, fontSize: 15, color: 'var(--text-main)' }}>Belum Ada Riwayat Pesanan</div>
              <p style={{ fontSize: 12.5, marginTop: 4 }}>Geser ke kanan untuk kembali ke menu kopi dan buat pesanan pertamamu.</p>
            </div>
          ) : (
            orders.map((ord) => {
              const currentStep = STATUS_STEP_MAP[ord.status] || 0;
              const isAwaitingQris = ord.status === 'menunggu_pembayaran';
              return (
                <div key={ord.id} className="glass-panel" style={{ padding: 16, marginBottom: 14 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                    <div>
                      <span style={{ fontWeight: 800, fontSize: 15 }}>{ord.customerName}</span>
                      <span style={{ fontSize: 11.5, color: 'var(--text-sub)', marginLeft: 8 }}>{ord.orderType} • {ord.paymentMethod}</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span className={`badge-status status-${ord.status}`}>
                        {isAwaitingQris ? 'Belum Bayar' : ord.status === 'pending' ? 'Masuk' : ord.status}
                      </span>
                      <button
                        className="delete-icon-btn"
                        disabled={deletingOrderId === ord.id}
                        onClick={() => handleDeleteOrderHistory(ord.id)}
                        title="Hapus riwayat pesanan ini"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>

                  {/* 4-Step Progress Bar */}
                  <div className="order-progress-bar">
                    {[1, 2, 3, 4].map(step => (
                      <div key={step} className={`progress-step ${currentStep >= step ? 'done' : ''}`} />
                    ))}
                  </div>
                  <div style={{ fontSize: 12, fontWeight: 700, color: isAwaitingQris ? 'var(--accent-orange)' : 'var(--accent-primary)', marginBottom: 10 }}>
                    {STATUS_LABEL_MAP[ord.status] || 'Diproses'}
                  </div>

                  {ord.orderNote && (
                    <div style={{ fontSize: 11.5, color: 'var(--text-sub)', background: 'var(--glass-pill)', padding: '6px 10px', borderRadius: 10, marginBottom: 8 }}>
                      Catatan: {ord.orderNote}
                    </div>
                  )}

                  <div style={{ borderTop: '1px solid var(--glass-border)', borderBottom: '1px solid var(--glass-border)', padding: '8px 0', margin: '8px 0' }}>
                    {ord.items?.map((it, i) => (
                      <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 4 }}>
                        <span>{it.qty}x {it.name}</span>
                        <span style={{ fontWeight: 700 }}>Rp {(it.price * it.qty).toLocaleString('id-ID')}</span>
                      </div>
                    ))}
                    {ord.uniqueCode && (
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--text-sub)', marginTop: 4 }}>
                        <span>Kode Unik QRIS Otomatis</span>
                        <span>+Rp {ord.uniqueCode}</span>
                      </div>
                    )}
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontWeight: 800, fontSize: 14 }}>
                    <span>Total Pembayaran</span>
                    <span style={{ color: 'var(--accent-primary)' }}>Rp {ord.totalPrice?.toLocaleString('id-ID')}</span>
                  </div>

                  {isAwaitingQris && (
                    <button
                      type="button"
                      className="ios-btn-primary"
                      style={{ marginTop: 10, padding: '10px 14px', fontSize: 13 }}
                      onClick={() => {
                        setActiveQrisOrderId(ord.id);
                        setActiveQrisOrder(ord);
                        setQrisModalOpen(true);
                      }}
                    >
                      <QrCode size={16} /> Buka Kode QRIS & Nominal Transfer
                    </button>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {activeTab === 'cart' && !isSellerBlocked && (
        <div style={{ padding: '16px 18px' }}>
          <h3 style={{ fontSize: 19, fontWeight: 800, marginBottom: 14 }}>Keranjang Pesanan</h3>
          {!storeOpen && <div className="store-closed-note" style={{ margin: '0 0 12px' }}>Toko sedang tutup. Pesanan belum bisa dikirim.</div>}
          {cart.length === 0 ? (
            <div className="glass-panel" style={{ padding: 34, textAlign: 'center', color: 'var(--text-sub)' }}>
              <ShoppingBag size={36} style={{ margin: '0 auto 10px', opacity: 0.55 }} />
              <div style={{ fontWeight: 700, fontSize: 15, color: 'var(--text-main)' }}>Keranjang Masih Kosong</div>
              <p style={{ fontSize: 12.5, marginTop: 4 }}>Pilih kopi atau camilan favoritmu dulu.</p>
              <button className="ios-btn-secondary" style={{ marginTop: 14 }} onClick={() => setActiveTab('menu')}>Lihat Menu</button>
            </div>
          ) : (
            <>
              <div className="glass-panel" style={{ padding: 14, marginBottom: 16 }}>
                {cart.map(item => (
                  <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--glass-border)' }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 14 }}>{item.name}</div>
                      <div style={{ fontSize: 12.5, color: 'var(--accent-primary)', fontWeight: 700 }}>Rp {(item.price * item.qty).toLocaleString('id-ID')}</div>
                    </div>
                    <div className="qty-pill">
                      <button onClick={() => updateQty(item.id, -1)}><Minus size={14} /></button>
                      <span>{item.qty}</span>
                      <button onClick={() => updateQty(item.id, 1)}><Plus size={14} /></button>
                    </div>
                  </div>
                ))}
              </div>

              <form onSubmit={handleCheckoutInit} className="glass-panel" style={{ padding: 16 }}>
                <div style={{ marginBottom: 12 }}>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Nama Pemesan</label>
                  <input type="text" className="ios-input" value={customerName} onChange={e => setCustomerName(e.target.value)} placeholder="Masukkan Nama Anda" required />
                </div>

                <div style={{ marginBottom: 12 }}>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Tipe Pesanan</label>
                  <select className="ios-input" value={orderType} onChange={e => setOrderType(e.target.value)}>
                    <option value="Dine-In">Dine-In (Di Tempat)</option>
                    <option value="Takeaway">Bawa Pulang</option>
                  </select>
                </div>

                <div style={{ marginBottom: 12 }}>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Catatan Barista (Opsional)</label>
                  <input type="text" className="ios-input" value={orderNote} onChange={e => setOrderNote(e.target.value)} placeholder="Contoh: Less ice, gula aren normal" />
                </div>

                <div style={{ marginBottom: 14 }}>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Metode Pembayaran</label>
                  <select className="ios-input" value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)}>
                    <option value="QRIS">QRIS Otomatis (Verifikasi Instan Kode Unik)</option>
                    <option value="Tunai">Bayar Tunai di Kasir</option>
                  </select>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderTop: '1px solid var(--glass-border)', fontWeight: 800, fontSize: 16 }}>
                  <span>Subtotal ({totalItems} item)</span>
                  <span style={{ color: 'var(--accent-primary)' }}>Rp {totalPrice.toLocaleString('id-ID')}</span>
                </div>

                <button type="submit" className="ios-btn-primary" disabled={!storeOpen || loadingOrder}>
                  {loadingOrder ? 'Menyiapkan Kode QRIS...' : paymentMethod === 'QRIS' ? <><QrCode size={18} /> Bayar via QRIS Otomatis</> : 'Kirim Pesanan Sekarang'}
                </button>
              </form>
            </>
          )}
        </div>
      )}

      {/* Modal QRIS Verifikasi Otomatis */}
      {qrisModalOpen && activeQrisOrder && !isSellerBlocked && (
        <div className="ios-modal-overlay" onClick={() => setQrisModalOpen(false)}>
          <div className="ios-modal-sheet" onClick={e => e.stopPropagation()}>
            <div className="sheet-handle" />
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
              <h3 style={{ fontSize: 18, fontWeight: 800 }}>Pembayaran QRIS Otomatis</h3>
              <span style={{ fontSize: 12, fontWeight: 800, color: 'var(--accent-orange)', background: 'rgba(255,159,10,0.16)', padding: '4px 10px', borderRadius: 999 }}>
                {formattedCountdown}
              </span>
            </div>
            <p style={{ fontSize: 12.5, color: 'var(--text-sub)' }}>
              Transfer <strong>tepat hingga 3 digit terakhir</strong> agar sistem mendeteksi pembayaran Anda secara otomatis tanpa konfirmasi manual.
            </p>

            {/* Box Nominal Tepat + Kode Unik */}
            <div style={{ background: 'var(--glass-pill-active)', border: '1.5px solid var(--accent-primary)', borderRadius: 18, padding: 14, marginTop: 12, textAlign: 'center' }}>
              <div style={{ fontSize: 11.5, color: 'var(--text-sub)', fontWeight: 700 }}>
                Subtotal Rp {activeQrisOrder.basePrice?.toLocaleString('id-ID')} + Kode Unik <strong>{activeQrisOrder.uniqueCode}</strong>
              </div>
              <div style={{ fontSize: 28, fontWeight: 800, color: 'var(--accent-primary)', margin: '4px 0 8px', letterSpacing: '-0.5px' }}>
                Rp {activeQrisOrder.totalPrice?.toLocaleString('id-ID')}
              </div>
              <button
                type="button"
                onClick={() => handleCopyNominal(activeQrisOrder.totalPrice)}
                style={{ background: 'var(--accent-primary)', color: 'var(--accent-contrast)', border: 'none', borderRadius: 999, padding: '6px 14px', fontSize: 12, fontWeight: 800, display: 'inline-flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}
              >
                <Copy size={13} /> Salin Nominal ({activeQrisOrder.totalPrice})
              </button>
            </div>

            {sellerQrisImg ? (
              <div className="qris-display-box">
                <img src={sellerQrisImg} alt="Barcode QRIS 1001 SK" />
              </div>
            ) : (
              <div className="glass-panel" style={{ padding: 20, textAlign: 'center', margin: '12px 0', color: 'var(--accent-orange)', fontSize: 13 }}>
                Penjual belum mengunggah gambar QRIS.<br />Tunjukkan layar ini saat membayar di kasir.
              </div>
            )}

            {/* Live Auto-Detection Indicator */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, padding: '10px 12px', borderRadius: 14, background: 'rgba(50, 215, 75, 0.12)', border: '1px solid rgba(50, 215, 75, 0.35)', color: 'var(--accent-green)', fontSize: 12.5, fontWeight: 700 }}>
              <RefreshCw size={15} />
              <span>Menunggu notifikasi transfer masuk otomatis...</span>
            </div>

            {sellerQrisImg && (
              <button type="button" className="ios-btn-secondary" onClick={handleSaveQris}>
                <Download size={16} /> Simpan Foto QRIS ke Galeri
              </button>
            )}

            <button
              type="button"
              className="ios-btn-secondary"
              onClick={() => {
                setQrisModalOpen(false);
                setActiveTab('orders');
              }}
            >
              Tutup (Cek Status di Tab Pesanan)
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
