import React, { useState, useEffect, useMemo, useRef } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot, addDoc, updateDoc, doc } from 'firebase/firestore';
import { Plus, Minus, Search, ShoppingBag, ChevronRight, QrCode, CheckCircle2, Clock, Trash2, Sparkles, X, Download } from 'lucide-react';
import { triggerHaptic } from '../utils/soundEffects';
import { DEFAULT_CATEGORIES } from '../utils/constants';
import { saveImage } from '../utils/saveImage';

const DEFAULT_MENU = [
  { id: 'm1', name: 'Kopi Susu Gula Aren 1001', category: 'Signature', price: 18000, desc: 'Espresso double shot dengan gula aren organik & susu segar creamy', img: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80', stock: true },
  { id: 'm2', name: 'Creamy Cold Brew SK', category: 'Signature', price: 22000, desc: 'Cold brew seduh dingin 12 jam dengan lapisan krim vanilla lembut', img: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=400&q=80', stock: true },
  { id: 'm3', name: 'Americano Ice / Hot', category: 'Espresso', price: 15000, desc: 'Espresso house-blend murni dengan air mineral dingin atau hangat', img: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=400&q=80', stock: true },
  { id: 'm4', name: 'Matcha Oat Latte', category: 'Non-Kopi', price: 24000, desc: 'Matcha Uji Jepang autentik berpadu dengan susu gandum (Oat)', img: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=400&q=80', stock: true },
  { id: 'm5', name: 'Croissant Butter Warm', category: 'Camilan', price: 18000, desc: 'Pastry croissant renyah berlapis dengan mentega Prancis hangat', img: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=400&q=80', stock: true },
  { id: 'm6', name: 'Roti Bakar Keju Coklat', category: 'Camilan', price: 16000, desc: 'Roti tawar tebal dipanggang renyah dengan keju dan coklat lumer', img: 'https://images.unsplash.com/photo-1584776296944-ab6fb57b0bdd?w=400&q=80', stock: true },
];

const STATUS_STEP_MAP = {
  pending: 1,
  diproses: 2,
  siap: 3,
  selesai: 4,
};

const STATUS_LABEL_MAP = {
  pending: 'Menunggu Konfirmasi Kasir',
  diproses: 'Sedang Diramu Barista',
  siap: 'Siap Diambil / Diantar!',
  selesai: 'Pesanan Selesai',
};

export default function CustomerView({
  cart,
  setCart,
  activeTab,
  user,
  userRole,
  orders,
  showToast,
  searchInputRef,
  setActiveTab,
  storeOpen,
}) {
  const [menuList, setMenuList] = useState(DEFAULT_MENU);
  const [selectedCategory, setSelectedCategory] = useState('Semua');
  const [searchQuery, setSearchQuery] = useState('');
  const [categories, setCategories] = useState(DEFAULT_CATEGORIES);
  const [qrisModalOpen, setQrisModalOpen] = useState(false);
  const [sellerQrisImg, setSellerQrisImg] = useState(null);

  const [customerName, setCustomerName] = useState(user?.email ? user.email.split('@')[0] : '');
  const [orderType, setOrderType] = useState('Dine-In');
  const [orderNote, setOrderNote] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('QRIS');
  const [loadingOrder, setLoadingOrder] = useState(false);
  const [pendingOrderPayload, setPendingOrderPayload] = useState(null);
  const [deletingOrderId, setDeletingOrderId] = useState(null);

  const isSellerBlocked = userRole === 'seller';

  useEffect(() => {
    if (user?.email && !customerName) {
      setCustomerName(user.email.split('@')[0]);
    }
  }, [user]);

  useEffect(() => {
    const unsubMenu = onSnapshot(collection(db, 'menu'), (snap) => {
      if (!snap.empty) {
        const items = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        setMenuList(items);
      }
    }, () => {});

    const unsubQris = onSnapshot(doc(db, 'settings', 'qris'), (docSnap) => {
      if (docSnap.exists()) {
        setSellerQrisImg(docSnap.data().qrisImage);
      }
    }, () => {});

    const unsubCat = onSnapshot(doc(db, 'settings', 'categories'), (snap) => {
      const list = snap.exists() ? snap.data().list : null;
      if (Array.isArray(list)) setCategories(list);
    }, () => {});

    return () => {
      unsubMenu();
      unsubQris();
      unsubCat();
    };
  }, []);

  const addToCart = (item) => {
    if (isSellerBlocked) {
      if (showToast) showToast('Akun Seller tidak diperbolehkan memesan di dalam aplikasi.');
      return;
    }
    if (!storeOpen) {
      if (showToast) showToast('Toko sedang tutup, pesanan belum bisa dibuat.');
      return;
    }
    if (item.stock === false) {
      if (showToast) showToast(`${item.name} sedang habis.`);
      return;
    }
    triggerHaptic(14);
    const exist = cart.find(c => c.id === item.id);
    if (exist) {
      setCart(cart.map(c => c.id === item.id ? { ...c, qty: c.qty + 1 } : c));
    } else {
      setCart([...cart, { ...item, qty: 1 }]);
      if (showToast) showToast(`${item.name} masuk keranjang`);
    }
  };

  const updateQty = (id, delta) => {
    if (isSellerBlocked) return;
    triggerHaptic(10);
    setCart(cart.map(c => {
      if (c.id === id) {
        const newQty = c.qty + delta;
        return newQty > 0 ? { ...c, qty: newQty } : null;
      }
      return c;
    }).filter(Boolean));
  };

  const cartQtyMap = useMemo(() => {
    const map = {};
    cart.forEach(c => { map[c.id] = c.qty; });
    return map;
  }, [cart]);

  const totalPrice = useMemo(() => cart.reduce((sum, item) => sum + (item.price * item.qty), 0), [cart]);
  const totalItems = useMemo(() => cart.reduce((sum, item) => sum + item.qty, 0), [cart]);

  const handleCheckoutInit = (e) => {
    e.preventDefault();
    if (isSellerBlocked) {
      if (showToast) showToast('Seller tidak dapat membuat pesanan.');
      return;
    }
    if (cart.length === 0) return;
    if (!storeOpen) {
      if (showToast) showToast('Toko sedang tutup, pesanan belum bisa dikirim.');
      return;
    }
    const soldOut = cart.filter(c => menuList.find(m => m.id === c.id)?.stock === false);
    if (soldOut.length > 0) {
      setCart(cart.filter(c => !soldOut.includes(c)));
      if (showToast) showToast(`Habis & dihapus dari keranjang: ${soldOut.map(c => c.name).join(', ')}`);
      return;
    }

    triggerHaptic(18);
    const payload = {
      uid: user?.uid || null,
      customerName: customerName || 'Pelanggan 1001 SK',
      orderType,
      orderNote: orderNote.trim(),
      paymentMethod,
      // Hanya data ringkas (tanpa foto base64) supaya dokumen kecil & realtime cepat
      items: cart.map(({ id, name, price, qty }) => ({ id, name, price, qty })),
      totalPrice,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    if (paymentMethod === 'QRIS') {
      setPendingOrderPayload(payload);
      setQrisModalOpen(true);
    } else {
      submitOrderToFirestore(payload);
    }
  };

  const submitOrderToFirestore = async (payload) => {
    if (isSellerBlocked) return;
    setLoadingOrder(true);
    try {
      await addDoc(collection(db, 'orders'), payload);
      triggerHaptic([20, 40, 20]);
      if (showToast) showToast('Pesanan berhasil dikirim ke kasir!');
      setCart([]);
      setOrderNote('');
      setQrisModalOpen(false);
      setPendingOrderPayload(null);
      setActiveTab('orders');
    } catch (err) {
      if (showToast) showToast('Gagal mengirim pesanan: ' + err.message);
    } finally {
      setLoadingOrder(false);
    }
  };

  const handleDeleteOrderHistory = async (orderId) => {
    triggerHaptic(15);
    setDeletingOrderId(orderId);
    try {
      await updateDoc(doc(db, 'orders', orderId), { hiddenByCustomer: true });
      if (showToast) showToast('Riwayat pesanan berhasil dihapus');
    } catch (err) {
      if (showToast) showToast('Gagal menghapus riwayat: ' + err.message);
    } finally {
      setDeletingOrderId(null);
    }
  };

  const handleClearCompletedHistory = async () => {
    const completed = orders.filter(o => o.status === 'selesai');
    if (completed.length === 0) {
      if (showToast) showToast('Belum ada pesanan selesai untuk dibersihkan');
      return;
    }
    triggerHaptic(18);
    try {
      await Promise.all(completed.map(o => updateDoc(doc(db, 'orders', o.id), { hiddenByCustomer: true })));
      if (showToast) showToast(`${completed.length} riwayat selesai dibersihkan`);
    } catch (err) {
      if (showToast) showToast('Gagal membersihkan riwayat: ' + err.message);
    }
  };

  const tabCategories = ['Semua', ...categories];

  useEffect(() => {
    if (selectedCategory !== 'Semua' && !categories.includes(selectedCategory)) setSelectedCategory('Semua');
  }, [categories, selectedCategory]);

  const handleSaveQris = async () => {
    triggerHaptic(14);
    try {
      await saveImage(sellerQrisImg, 'QRIS-1001SK.jpg');
    } catch (err) {
      if (showToast) showToast('Gagal menyimpan QRIS: ' + (err?.message || 'coba lagi'));
    }
  };

  const featuredItems = useMemo(() => {
    const sig = menuList.filter(m => m.category === 'Signature');
    return sig.length > 0 ? sig : menuList.slice(0, 4);
  }, [menuList]);

  const filteredMenu = useMemo(() => {
    return menuList.filter(m => {
      const matchCat = selectedCategory === 'Semua' || m.category === selectedCategory;
      const matchSearch = !searchQuery.trim() ||
        m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (m.desc && m.desc.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchCat && matchSearch;
    });
  }, [menuList, selectedCategory, searchQuery]);

  return (
    <div className="page-transition">
      {activeTab === 'menu' && (
        <>
          {!storeOpen && <div className="store-closed-note">Toko sedang tutup. Kamu masih bisa melihat menu, tapi belum bisa memesan.</div>}
          <div className="ios-search-wrap">
            <div className="ios-search-box">
              <Search size={16} color="var(--text-sub)" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari kopi favorit, matcha, atau camilan..."
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  style={{ background: 'none', border: 'none', color: 'var(--text-sub)', cursor: 'pointer', display: 'flex' }}
                >
                  <X size={15} />
                </button>
              )}
            </div>
          </div>

          <div className="ios-tabs" data-no-swipe="true">
            {tabCategories.map(cat => (
              <button
                key={cat}
                className={`tab-btn ${selectedCategory === cat ? 'active' : ''}`}
                onClick={() => { triggerHaptic(8); setSelectedCategory(cat); }}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Horizontal Featured Showcase (Inspired by reference screenshot) */}
          {selectedCategory === 'Semua' && !searchQuery.trim() && (
            <div style={{ marginBottom: 6 }}>
              <div className="section-heading">
                <div className="section-eyebrow">Racikan Terlaris Barista</div>
                <div className="section-title">Menu Andalan 1001 SK</div>
              </div>
              <div className="featured-carousel" data-no-swipe="true">
                {featuredItems.map((item) => (
                  <div key={`feat-${item.id}`} className="featured-card" onClick={() => addToCart(item)}>
                    <div className="featured-poster">
                      <img src={item.img} alt={item.name} loading="lazy" />
                      <button
                        type="button"
                        className="featured-quick-add"
                        onClick={(e) => { e.stopPropagation(); addToCart(item); }}
                        aria-label={`Tambah ${item.name}`}
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                    <div style={{ fontSize: 13.5, fontWeight: 800, color: 'var(--text-main)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {item.name}
                    </div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--accent-primary)', marginTop: 2 }}>
                      Rp {item.price.toLocaleString('id-ID')}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="section-heading">
            <div className="section-eyebrow">Geser kiri/kanan untuk cek pesanan</div>
            <div className="section-title">{selectedCategory === 'Semua' ? 'Semua Menu' : selectedCategory}</div>
          </div>

          <div className="menu-grid">
            {filteredMenu.map((item) => {
              const qty = cartQtyMap[item.id] || 0;
              return (
                <div key={item.id} className={`glass-panel menu-card${item.stock === false ? ' sold-out' : ''}`}>
                  <div>
                    <div className="menu-img-wrap">
                      <img
                        src={item.img || 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80'}
                        alt={item.name}
                        className="menu-img"
                        loading="lazy"
                      />
                      <span className="menu-cat-pill">{item.category}</span>
                    </div>
                    <h4 className="menu-title">{item.name}</h4>
                    <p className="menu-desc">{item.desc}</p>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 4 }}>
                    <span className="menu-price">Rp {item.price.toLocaleString('id-ID')}</span>
                    {item.stock === false ? (
                      <span className="sold-out-pill">Habis</span>
                    ) : qty > 0 ? (
                      <div className="qty-pill">
                        <button type="button" onClick={() => updateQty(item.id, -1)} aria-label="Kurangi">
                          <Minus size={13} />
                        </button>
                        <span>{qty}</span>
                        <button type="button" onClick={() => updateQty(item.id, 1)} aria-label="Tambah">
                          <Plus size={13} />
                        </button>
                      </div>
                    ) : (
                      <button type="button" className="btn-add" onClick={() => addToCart(item)}>
                        <Plus size={13} /> Tambah
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {activeTab === 'orders' && (
        <div style={{ padding: 18 }} className="page-transition">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14, gap: 8 }}>
            <div>
              <h3 style={{ fontSize: 18, fontWeight: 800 }}>Status & Riwayat Pesanan</h3>
              <div style={{ fontSize: 11.5, color: 'var(--text-sub)' }}>Notifikasi otomatis saat pesanan siap diambil</div>
            </div>
            {orders.some(o => o.status === 'selesai') && (
              <button type="button" className="delete-icon-btn" onClick={handleClearCompletedHistory}>
                <Trash2 size={13} /> Bersihkan Selesai
              </button>
            )}
          </div>

          {orders.length === 0 ? (
            <div className="glass-panel" style={{ padding: 28, textAlign: 'center', color: 'var(--text-sub)' }}>
              <Clock size={28} style={{ margin: '0 auto 10px', opacity: 0.6 }} />
              <div style={{ fontWeight: 800, color: 'var(--text-main)', marginBottom: 4 }}>Belum Ada Riwayat Pesanan</div>
              <div style={{ fontSize: 12.5 }}>Geser ke kanan untuk kembali ke menu kopi dan buat pesanan pertamamu.</div>
            </div>
          ) : (
            orders.map((ord) => {
              const currentStep = STATUS_STEP_MAP[ord.status] || 1;
              return (
                <div key={ord.id} className="glass-panel" style={{ padding: 15, marginBottom: 13 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
                    <div>
                      <strong style={{ fontSize: 15 }}>{ord.customerName}</strong>
                      <div style={{ fontSize: 12, color: 'var(--text-sub)', marginTop: 2 }}>
                        {ord.orderType} • {ord.paymentMethod}
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span className={`badge-status status-${ord.status}`}>
                        {ord.status === 'pending' ? 'Masuk' : ord.status}
                      </span>
                      <button
                        type="button"
                        className="delete-icon-btn"
                        disabled={deletingOrderId === ord.id}
                        onClick={() => handleDeleteOrderHistory(ord.id)}
                        title="Hapus riwayat pesanan ini"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>

                  {/* 4-Step Progress Bar */}
                  <div className="order-progress-bar">
                    {[1, 2, 3, 4].map(step => (
                      <div key={step} className={`progress-step ${currentStep >= step ? 'done' : ''}`} />
                    ))}
                  </div>
                  <div style={{ fontSize: 11.5, color: ord.status === 'siap' ? 'var(--accent-green)' : 'var(--accent-primary)', fontWeight: 700, marginBottom: 9 }}>
                    {STATUS_LABEL_MAP[ord.status] || 'Diproses'}
                  </div>

                  {ord.orderNote && (
                    <div style={{ fontSize: 11.5, color: 'var(--text-sub)', background: 'var(--glass-pill)', padding: '6px 10px', borderRadius: 10, marginBottom: 8 }}>
                      Catatan: {ord.orderNote}
                    </div>
                  )}

                  <div style={{ borderTop: '1px solid var(--glass-border)', paddingTop: 9 }}>
                    {ord.items?.map((it, i) => (
                      <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: 'var(--text-sub)', marginBottom: 3 }}>
                        <span>{it.qty}x {it.name}</span>
                        <span>Rp {(it.price * it.qty).toLocaleString('id-ID')}</span>
                      </div>
                    ))}
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, fontWeight: 800, marginTop: 7, paddingTop: 7, borderTop: '1px dashed var(--glass-border)' }}>
                      <span>Total Pembayaran</span>
                      <span style={{ color: 'var(--accent-primary)' }}>Rp {ord.totalPrice?.toLocaleString('id-ID')}</span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {activeTab === 'cart' && !isSellerBlocked && (
        <div style={{ padding: 18 }} className="page-transition">
          <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 12 }}>Keranjang Pesanan</h3>
          {!storeOpen && <div className="store-closed-note" style={{ margin: '0 0 12px' }}>Toko sedang tutup. Pesanan belum bisa dikirim.</div>}

          {cart.length === 0 ? (
            <div className="glass-panel" style={{ padding: 28, textAlign: 'center', color: 'var(--text-sub)' }}>
              <ShoppingBag size={28} style={{ margin: '0 auto 10px', opacity: 0.6 }} />
              <div style={{ fontWeight: 800, color: 'var(--text-main)', marginBottom: 4 }}>Keranjang Masih Kosong</div>
              <div style={{ fontSize: 12.5, marginBottom: 14 }}>Pilih kopi atau camilan favoritmu dulu.</div>
              <button type="button" className="ios-btn-primary" onClick={() => setActiveTab('menu')}>Lihat Menu</button>
            </div>
          ) : (
            <>
              <div className="glass-panel" style={{ padding: 14, marginBottom: 14 }}>
                {cart.map(item => (
                  <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10, paddingBottom: 9, borderBottom: '1px solid var(--glass-border)' }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 14 }}>{item.name}</div>
                      <div style={{ fontSize: 12, color: 'var(--accent-primary)', fontWeight: 700 }}>Rp {(item.price * item.qty).toLocaleString('id-ID')}</div>
                    </div>
                    <div className="qty-pill">
                      <button type="button" onClick={() => updateQty(item.id, -1)}><Minus size={13} /></button>
                      <span>{item.qty}</span>
                      <button type="button" onClick={() => updateQty(item.id, 1)}><Plus size={13} /></button>
                    </div>
                  </div>
                ))}
              </div>

              <form onSubmit={handleCheckoutInit} data-no-swipe="true">
                <div style={{ marginBottom: 10 }}>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Nama Pemesan</label>
                  <input type="text" className="ios-input" value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Masukkan Nama Anda" required />
                </div>
                <div style={{ marginBottom: 10 }}>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Tipe Pesanan</label>
                  <select className="ios-input" value={orderType} onChange={(e) => setOrderType(e.target.value)}>
                    <option value="Dine-In">Dine-In (Di Tempat)</option>
                    <option value="Takeaway">Bawa Pulang</option>
                  </select>
                </div>
                <div style={{ marginBottom: 10 }}>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Catatan Barista (Opsional)</label>
                  <input type="text" className="ios-input" value={orderNote} onChange={(e) => setOrderNote(e.target.value)} placeholder="Contoh: Less ice, gula aren normal" />
                </div>
                <div style={{ marginBottom: 12 }}>
                  <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Metode Pembayaran</label>
                  <select className="ios-input" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                    <option value="QRIS">QRIS Instant (Scan Barcode Toko)</option>
                    <option value="Tunai">Bayar Tunai di Kasir</option>
                  </select>
                </div>

                <div className="glass-panel" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 15px', margin: '12px 0' }}>
                  <span style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--text-sub)' }}>Total Bayar ({totalItems} item)</span>
                  <span style={{ fontSize: 17, fontWeight: 800, color: 'var(--accent-primary)' }}>Rp {totalPrice.toLocaleString('id-ID')}</span>
                </div>

                <button type="submit" className="ios-btn-primary" disabled={loadingOrder || !storeOpen}>
                  {paymentMethod === 'QRIS' ? <><QrCode size={17} /> Lanjut ke Pembayaran QRIS</> : 'Kirim Pesanan Sekarang'}
                </button>
              </form>
            </>
          )}
        </div>
      )}

      {qrisModalOpen && pendingOrderPayload && !isSellerBlocked && (
        <div className="ios-modal-overlay" onClick={() => setQrisModalOpen(false)}>
          <div className="ios-modal-sheet" style={{ textAlign: 'center' }} onClick={(e) => e.stopPropagation()}>
            <div className="sheet-handle" />
            <h3 style={{ fontSize: 18, fontWeight: 800 }}>Scan QRIS Pembayaran</h3>
            <p style={{ fontSize: 12, color: 'var(--text-sub)', marginTop: 4 }}>
              Scan barcode di bawah ini dengan DANA, GoPay, OVO, BCA, atau Mobile Banking.
            </p>

            <div className="qris-display-box">
              {sellerQrisImg ? (
                <img src={sellerQrisImg} alt="QRIS Toko 1001 SK" />
              ) : (
                <div style={{ padding: 24, color: '#555', fontSize: 13 }}>
                  <QrCode size={36} style={{ margin: '0 auto 8px', opacity: 0.5 }} />
                  Penjual belum mengunggah gambar QRIS.<br />Tunjukkan layar ini saat membayar di kasir.
                </div>
              )}
            </div>

            <div className="glass-panel" style={{ padding: 12, marginBottom: 12 }}>
              <div style={{ fontSize: 11.5, color: 'var(--text-sub)' }}>Total yang Harus Ditransfer</div>
              <div style={{ fontSize: 21, fontWeight: 800, color: 'var(--accent-primary)', marginTop: 2 }}>
                Rp {pendingOrderPayload.totalPrice.toLocaleString('id-ID')}
              </div>
            </div>

            <button
              className="ios-btn-primary"
              style={{ background: 'var(--accent-green)', color: '#071409' }}
              disabled={loadingOrder}
              onClick={() => submitOrderToFirestore(pendingOrderPayload)}
            >
              <CheckCircle2 size={17} />
              {loadingOrder ? 'Mengonfirmasi...' : 'Saya Sudah Transfer / Bayar'}
            </button>
            {sellerQrisImg && (
              <button type="button" className="ios-btn-secondary" onClick={handleSaveQris}>
                <Download size={16} /> Simpan Foto QRIS
              </button>
            )}
            <button type="button" className="ios-btn-secondary" onClick={() => setQrisModalOpen(false)}>Batal</button>
          </div>
        </div>
      )}
    </div>
  );
}
