import React, { useState, useEffect, useMemo } from 'react';
import { db } from '../firebase';
import {
  collection,
  addDoc,
  onSnapshot,
  doc,
  updateDoc,
  query,
  where,
} from 'firebase/firestore';
import {
  DEFAULT_CATEGORIES,
  ORDER_STATUS_LABELS,
  FALLBACK_COFFEE_IMG,
} from '../utils/constants';
import {
  Plus,
  Minus,
  Trash2,
  QrCode,
  Download,
  ChevronRight,
  ChevronDown,
  MoreHorizontal,
  Share2,
  CheckCircle2,
  Clock,
  ShieldAlert,
  Sparkles,
  Wifi,
} from 'lucide-react';
import { saveImage } from '../utils/saveImage';
import {
  generateUniquePaymentCode,
  QRIS_EXPIRY_MINUTES,
} from '../utils/qrisAutoMatcher';
import { sanitizeText, sanitizeImageUrl } from '../utils/securityGuard';
import { triggerHaptic } from '../utils/soundEffects';
import { useSheetSwipeDismiss } from '../hooks/useSheetSwipeDismiss';

const MOOD_PRESETS = [
  {
    key: 'Signature',
    label: 'Signature',
    gradient: 'linear-gradient(135deg, #2d3e2f 0%, #5b785c 52%, #1d2920 100%)',
  },
  {
    key: 'Espresso',
    label: 'Kopi Santai',
    gradient: 'linear-gradient(135deg, #7c3f1d 0%, #c87a3d 52%, #4a2310 100%)',
  },
  {
    key: 'Non-Kopi',
    label: 'Segar & Matcha',
    gradient: 'linear-gradient(135deg, #1b4d3e 0%, #3d8b6e 52%, #123329 100%)',
  },
  {
    key: 'Camilan',
    label: 'Teman Ngopi',
    gradient: 'linear-gradient(135deg, #4b2354 0%, #8c4a9c 52%, #2c1233 100%)',
  },
];

export default function CustomerView({
  swipeDir = 'none',
  cart,
  setCart,
  activeTab,
  user,
  userRole,
  orders,
  showToast,
  setActiveTab,
  storeOpen = true,
  searchQuery = '',
  setSearchQuery,
}) {
  const [menuList, setMenuList] = useState([]);
  const [categories, setCategories] = useState(DEFAULT_CATEGORIES);
  const [selectedCat, setSelectedCat] = useState('Semua');
  const [customerName, setCustomerName] = useState('');
  const [tableNumber, setTableNumber] = useState('');
  const [qrisDataUrl, setQrisDataUrl] = useState('');
  const [loadingOrder, setLoadingOrder] = useState(false);

  const [pendingQrisOrder, setPendingQrisOrder] = useState(null);
  const [nowTick, setNowTick] = useState(() => Date.now());
  const [showMoreActions, setShowMoreActions] = useState(false);

  const isSellerAccount = userRole === 'seller';

  useEffect(() => {
    const unsubMenu = onSnapshot(collection(db, 'menu'), (snap) => {
      const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      setMenuList(items);
    });

    const unsubCat = onSnapshot(doc(db, 'settings', 'categories'), (docSnap) => {
      if (docSnap.exists() && Array.isArray(docSnap.data().list)) {
        setCategories(docSnap.data().list);
      } else {
        setCategories(DEFAULT_CATEGORIES);
      }
    });

    const unsubQris = onSnapshot(doc(db, 'settings', 'payment'), (docSnap) => {
      if (docSnap.exists() && docSnap.data().qrisBase64) {
        setQrisDataUrl(sanitizeImageUrl(docSnap.data().qrisBase64, ''));
      } else {
        setQrisDataUrl('');
      }
    });

    return () => {
      unsubMenu();
      unsubCat();
      unsubQris();
    };
  }, []);

  useEffect(() => {
    if (user?.displayName && !customerName) {
      setCustomerName(user.displayName);
    }
  }, [user]);

  useEffect(() => {
    if (!pendingQrisOrder) return;
    const matched = orders.find((o) => o.id === pendingQrisOrder.id);
    if (matched) {
      if (matched.status !== 'menunggu_pembayaran') {
        setPendingQrisOrder(null);
        setShowMoreActions(false);
        setActiveTab('orders');
      } else {
        setPendingQrisOrder(matched);
      }
    }
  }, [orders, pendingQrisOrder, setActiveTab]);

  useEffect(() => {
    if (!pendingQrisOrder) return;
    const timer = setInterval(() => setNowTick(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [pendingQrisOrder]);

  const closePlayerSheet = () => {
    triggerHaptic(10);
    setShowMoreActions(false);
    setPendingQrisOrder(null);
    setActiveTab('orders');
  };

  const { sheetDragStyle: playerDragStyle, sheetSwipeHandlers: playerSwipeHandlers } =
    useSheetSwipeDismiss({
      onClose: closePlayerSheet,
      enabled: Boolean(pendingQrisOrder),
    });

  const addToCart = (item) => {
    if (isSellerAccount) {
      showToast('Akun Penjual tidak dapat memesan di dalam aplikasi.');
      return;
    }
    if (!storeOpen) {
      showToast('Toko sedang tutup. Pemesanan ditutup sementara.');
      return;
    }
    if (item.available === false) return;
    triggerHaptic(14);
    setCart((prev) => {
      const idx = prev.findIndex((c) => c.id === item.id);
      if (idx > -1) {
        const updated = [...prev];
        updated[idx].qty += 1;
        return updated;
      }
      return [...prev, { ...item, qty: 1 }];
    });
    showToast(`${item.name} ditambahkan`);
  };

  const updateQty = (id, delta) => {
    triggerHaptic(10);
    setCart((prev) =>
      prev
        .map((c) => (c.id === id ? { ...c, qty: c.qty + delta } : c))
        .filter((c) => c.qty > 0)
    );
  };

  const totalAmount = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  const handleCheckout = async (e) => {
    e.preventDefault();
    if (isSellerAccount) {
      showToast('Akun Penjual dilarang melakukan pemesanan.');
      return;
    }
    if (!storeOpen) {
      showToast('Toko sedang tutup. Pemesanan tidak dapat diproses.');
      return;
    }
    if (!user) {
      showToast('Silakan masuk dengan akun Anda terlebih dahulu.');
      return;
    }
    if (cart.length === 0) return;

    const cleanName = sanitizeText(customerName, 60);
    const cleanTable = sanitizeText(tableNumber, 24);
    if (!cleanName || !cleanTable) {
      showToast('Harap isi Nama Pemesan dan Nomor Meja!');
      return;
    }
    if (!qrisDataUrl) {
      showToast('QRIS Toko belum diatur oleh penjual.');
      return;
    }

    setLoadingOrder(true);
    try {
      const uniqueCode = generateUniquePaymentCode(orders, totalAmount);
      const finalPayableAmount = totalAmount + uniqueCode;
      const nowIso = new Date().toISOString();
      const expiresAtIso = new Date(Date.now() + QRIS_EXPIRY_MINUTES * 60 * 1000).toISOString();

      const newOrderPayload = {
        uid: user.uid,
        customerName: cleanName,
        tableNumber: cleanTable,
        items: cart.map((c) => ({
          id: c.id,
          name: sanitizeText(c.name, 80),
          price: Number(c.price) || 0,
          qty: Number(c.qty) || 1,
        })),
        basePrice: totalAmount,
        uniqueCode,
        totalPrice: finalPayableAmount,
        paymentMethod: 'QRIS',
        paymentStatus: 'unpaid',
        status: 'menunggu_pembayaran',
        createdAt: nowIso,
        paymentExpiresAt: expiresAtIso,
        hiddenByCustomer: false,
      };

      const docRef = await addDoc(collection(db, 'orders'), newOrderPayload);
      triggerHaptic([20, 40, 20]);
      setCart([]);
      setPendingQrisOrder({ id: docRef.id, ...newOrderPayload });
    } catch (err) {
      showToast('Gagal membuat pesanan: ' + err.message);
    } finally {
      setLoadingOrder(false);
    }
  };

  const handleDownloadQris = async () => {
    if (!qrisDataUrl) return;
    triggerHaptic(12);
    try {
      await saveImage(qrisDataUrl, 'QRIS-1001-SK.jpg');
      showToast('Gambar QRIS berhasil disimpan!');
    } catch {
      showToast('Gagal menyimpan gambar QRIS');
    }
  };

  const handleHideOrderHistory = async (order) => {
    if (!order || order.uid !== user?.uid) return;
    triggerHaptic(12);
    try {
      await updateDoc(doc(db, 'orders', order.id), { hiddenByCustomer: true });
      showToast('Riwayat pesanan dihapus');
    } catch {
      showToast('Gagal menghapus riwayat pesanan');
    }
  };

  const getStepLevel = (status) => {
    if (status === 'menunggu_pembayaran') return 1;
    if (status === 'pending') return 2;
    if (status === 'diproses') return 3;
    if (status === 'siap' || status === 'siap_diambil' || status === 'selesai') return 4;
    return 0;
  };

  const getRemainingSeconds = (expiresAtIso) => {
    if (!expiresAtIso) return QRIS_EXPIRY_MINUTES * 60;
    const diff = Math.floor((new Date(expiresAtIso).getTime() - nowTick) / 1000);
    return Math.max(0, diff);
  };

  const formatCountdown = (secs) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const filteredMenu = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return menuList.filter((m) => {
      const matchCat = selectedCat === 'Semua' || m.category === selectedCat;
      const matchSearch =
        !q ||
        String(m.name || '').toLowerCase().includes(q) ||
        String(m.description || '').toLowerCase().includes(q) ||
        String(m.category || '').toLowerCase().includes(q);
      return matchCat && matchSearch;
    });
  }, [menuList, selectedCat, searchQuery]);

  const heroPicks = useMemo(() => menuList.slice(0, 5), [menuList]);
  const quickOrderList = useMemo(() => menuList.slice(0, 4), [menuList]);

  const slideAnimClass =
    swipeDir === 'left'
      ? 'slide-from-right'
      : swipeDir === 'right'
      ? 'slide-from-left'
      : '';

  // TAB 1: BERANDA (iOS 26 Music/Lounge Fluid Layout)
  if (activeTab === 'menu') {
    const isFiltering = selectedCat !== 'Semua' || searchQuery.trim().length > 0;

    return (
      <div className={`page-transition ${slideAnimClass}`}>
        {!storeOpen && (
          <div className="store-closed-note">
            Toko 1001 SK sedang tutup sementara. Pemesanan dibuka kembali saat operasional aktif.
          </div>
        )}

        {/* Horizontal Category Filter Pills */}
        <div className="ios-tabs" data-no-swipe="true">
          {['Semua', ...categories].map((cat) => (
            <button
              key={cat}
              type="button"
              className={`tab-btn ${selectedCat === cat ? 'active' : ''}`}
              onClick={() => {
                triggerHaptic(10);
                setSelectedCat(cat);
              }}
            >
              {cat === 'Semua' && <Sparkles size={13} />}
              <span>{cat}</span>
            </button>
          ))}
        </div>

        {/* Hero Section: "Menu Pilihan >" Horizontal Cards */}
        {!isFiltering && heroPicks.length > 0 && (
          <section className="vertical-stagger-in" style={{ animationDelay: '0.02s' }}>
            <div className="music-section-header">
              <div className="music-section-title">
                <span>Menu Pilihan</span>
                <ChevronRight size={20} color="var(--text-sub)" />
              </div>
            </div>

            <div className="hero-picks-carousel" data-no-swipe="true">
              {heroPicks.map((item) => {
                const isSoldOut = item.available === false;
                return (
                  <div
                    key={item.id}
                    className="hero-pick-card"
                    onClick={() => !isSoldOut && addToCart(item)}
                  >
                    <img
                      src={sanitizeImageUrl(item.img, FALLBACK_COFFEE_IMG)}
                      alt={item.name}
                      loading="lazy"
                      onError={(e) => {
                        e.currentTarget.onerror = null;
                        e.currentTarget.src = FALLBACK_COFFEE_IMG;
                      }}
                    />
                    <div className="hero-pick-overlay">
                      <div style={{ minWidth: 0 }}>
                        <div className="hero-pick-title">{item.name}</div>
                        <div className="hero-pick-sub">
                          {item.category} • Rp {item.price?.toLocaleString('id-ID')}
                        </div>
                      </div>
                      {!isSoldOut && !isSellerAccount && (
                        <button
                          type="button"
                          className="hero-pick-add-btn"
                          onClick={(e) => {
                            e.stopPropagation();
                            addToCart(item);
                          }}
                          aria-label={`Tambah ${item.name}`}
                        >
                          <Plus size={16} />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* Section 2: "Pesan Cepat >" Compact List Rows */}
        {!isFiltering && quickOrderList.length > 0 && (
          <section className="vertical-stagger-in" style={{ animationDelay: '0.06s' }}>
            <div className="music-section-header">
              <div className="music-section-title">
                <span>Pesan Cepat</span>
                <ChevronRight size={20} color="var(--text-sub)" />
              </div>
            </div>

            <div className="speed-dial-list">
              {quickOrderList.map((item) => {
                const isSoldOut = item.available === false;
                const inCart = cart.find((c) => c.id === item.id);
                return (
                  <div
                    key={`quick-${item.id}`}
                    className="speed-dial-row"
                    onClick={() => !isSoldOut && addToCart(item)}
                  >
                    <img
                      src={sanitizeImageUrl(item.img, FALLBACK_COFFEE_IMG)}
                      alt={item.name}
                      className="speed-dial-thumb"
                      onError={(e) => {
                        e.currentTarget.onerror = null;
                        e.currentTarget.src = FALLBACK_COFFEE_IMG;
                      }}
                    />
                    <div className="speed-dial-info">
                      <div className="speed-dial-title">{item.name}</div>
                      <div className="speed-dial-sub">
                        {item.category} • Rp {item.price?.toLocaleString('id-ID')}
                      </div>
                    </div>
                    {isSoldOut ? (
                      <span className="sold-out-pill">Habis</span>
                    ) : inCart ? (
                      <span className="qty-pill" onClick={(e) => e.stopPropagation()}>
                        <button type="button" onClick={() => updateQty(item.id, -1)}>
                          <Minus size={12} />
                        </button>
                        <span>{inCart.qty}</span>
                        <button type="button" onClick={() => updateQty(item.id, 1)}>
                          <Plus size={12} />
                        </button>
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          addToCart(item);
                        }}
                        style={{
                          background: 'none',
                          border: 'none',
                          color: 'var(--text-sub)',
                          padding: 6,
                          cursor: 'pointer',
                        }}
                      >
                        <MoreHorizontal size={18} />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* Section 3: "Suasana & Kategori >" 2x2 Gradient Cards */}
        {!isFiltering && (
          <section className="vertical-stagger-in" style={{ animationDelay: '0.1s' }}>
            <div className="music-section-header">
              <div className="music-section-title">
                <span>Suasana &amp; Kategori</span>
                <ChevronRight size={20} color="var(--text-sub)" />
              </div>
            </div>

            <div className="mood-grid">
              {MOOD_PRESETS.map((mood) => (
                <div
                  key={mood.key}
                  className="mood-card"
                  style={{ background: mood.gradient }}
                  onClick={() => {
                    triggerHaptic(12);
                    setSelectedCat(mood.key);
                  }}
                >
                  <span className="mood-card-label">{mood.label}</span>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Section 4: "Semua Menu >" Square Artwork Grid */}
        <section className="vertical-stagger-in" style={{ animationDelay: '0.14s' }}>
          <div className="music-section-header">
            <div className="music-section-title">
              <span>{isFiltering ? `Hasil (${filteredMenu.length})` : 'Semua Menu'}</span>
              <ChevronRight size={20} color="var(--text-sub)" />
            </div>
            {isFiltering && (
              <button
                type="button"
                onClick={() => {
                  setSelectedCat('Semua');
                  setSearchQuery?.('');
                }}
                style={{
                  background: 'none',
                  border: 'none',
                  color: 'var(--accent-primary)',
                  fontSize: 12.5,
                  fontWeight: 700,
                  cursor: 'pointer',
                }}
              >
                Reset
              </button>
            )}
          </div>

          {filteredMenu.length === 0 ? (
            <div className="glass-panel" style={{ margin: '0 18px', textAlign: 'center', padding: 28 }}>
              <p style={{ fontSize: 13.5, color: 'var(--text-sub)' }}>
                Menu belum tersedia atau tidak ditemukan.
              </p>
            </div>
          ) : (
            <div className="menu-grid">
              {filteredMenu.map((item) => {
                const inCart = cart.find((c) => c.id === item.id);
                const isSoldOut = item.available === false;
                return (
                  <div key={item.id} className={`menu-card ${isSoldOut ? 'sold-out' : ''}`}>
                    <div>
                      <div
                        className="menu-img-wrap"
                        onClick={() => !isSoldOut && addToCart(item)}
                      >
                        <img
                          src={sanitizeImageUrl(item.img, FALLBACK_COFFEE_IMG)}
                          alt={item.name}
                          className="menu-img"
                          loading="lazy"
                          onError={(e) => {
                            e.currentTarget.onerror = null;
                            e.currentTarget.src = FALLBACK_COFFEE_IMG;
                          }}
                        />
                        <span className="menu-cat-pill">{item.category}</span>
                      </div>
                      <h3 className="menu-title">{item.name}</h3>
                      <p className="menu-desc">{item.description || 'Racikan spesial 1001 SK'}</p>
                    </div>

                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                      }}
                    >
                      <span className="menu-price">
                        Rp {item.price?.toLocaleString('id-ID')}
                      </span>

                      {isSoldOut ? (
                        <span className="sold-out-pill">Habis</span>
                      ) : isSellerAccount ? (
                        <span style={{ fontSize: 10.5, color: 'var(--text-sub)' }}>Mode Kasir</span>
                      ) : !storeOpen ? (
                        <span className="sold-out-pill">Tutup</span>
                      ) : inCart ? (
                        <div className="qty-pill">
                          <button type="button" onClick={() => updateQty(item.id, -1)}>
                            <Minus size={12} />
                          </button>
                          <span>{inCart.qty}</span>
                          <button type="button" onClick={() => updateQty(item.id, 1)}>
                            <Plus size={12} />
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          className="btn-add"
                          onClick={() => addToCart(item)}
                        >
                          <Plus size={13} /> Tambah
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    );
  }

  // TAB 2: KERANJANG & CHECKOUT
  if (activeTab === 'cart') {
    return (
      <div className={`page-transition ${slideAnimClass}`} style={{ padding: '4px 18px 20px' }}>
        {isSellerAccount ? (
          <div className="glass-panel" style={{ textAlign: 'center', padding: 28 }}>
            <ShieldAlert size={30} color="var(--accent-red)" style={{ margin: '0 auto 8px' }} />
            <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 4 }}>Akun Penjual Aktif</h3>
            <p style={{ fontSize: 13, color: 'var(--text-sub)' }}>
              Akun penjual tidak diperbolehkan melakukan pemesanan.
            </p>
          </div>
        ) : cart.length === 0 ? (
          <div className="glass-panel" style={{ textAlign: 'center', padding: 34 }}>
            <p style={{ fontSize: 14, color: 'var(--text-sub)', marginBottom: 14 }}>
              Keranjang Anda masih kosong.
            </p>
            <button
              type="button"
              className="ios-btn-primary"
              style={{ maxWidth: 210, margin: '0 auto' }}
              onClick={() => setActiveTab('menu')}
            >
              Jelajahi Menu
            </button>
          </div>
        ) : (
          <form onSubmit={handleCheckout}>
            <div className="glass-panel" style={{ marginBottom: 14 }}>
              {cart.map((item, idx) => (
                <div
                  key={item.id}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '10px 0',
                    borderBottom: idx < cart.length - 1 ? '1px solid var(--hairline)' : 'none',
                  }}
                >
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14 }}>{item.name}</div>
                    <div style={{ fontSize: 12.5, color: 'var(--text-sub)' }}>
                      Rp {(item.price * item.qty).toLocaleString('id-ID')}
                    </div>
                  </div>
                  <div className="qty-pill">
                    <button type="button" onClick={() => updateQty(item.id, -1)}>
                      <Minus size={12} />
                    </button>
                    <span>{item.qty}</span>
                    <button type="button" onClick={() => updateQty(item.id, 1)}>
                      <Plus size={12} />
                    </button>
                  </div>
                </div>
              ))}

              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  marginTop: 12,
                  paddingTop: 12,
                  borderTop: '1px solid var(--hairline)',
                  fontWeight: 800,
                  fontSize: 16,
                }}
              >
                <span>Subtotal Menu</span>
                <span style={{ color: 'var(--accent-primary)' }}>
                  Rp {totalAmount.toLocaleString('id-ID')}
                </span>
              </div>
              <p style={{ fontSize: 11.5, color: 'var(--text-sub)', marginTop: 6 }}>
                Kode unik 3 digit otomatis ditambahkan pada QRIS agar transfer langsung lunas tanpa konfirmasi manual.
              </p>
            </div>

            <div className="glass-panel">
              <label style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text-sub)' }}>
                Nama Pemesan
              </label>
              <input
                type="text"
                className="ios-input"
                placeholder="Nama Anda"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                required
              />

              <label
                style={{
                  display: 'block',
                  fontSize: 12.5,
                  fontWeight: 600,
                  color: 'var(--text-sub)',
                  marginTop: 12,
                }}
              >
                Nomor Meja / Takeaway
              </label>
              <input
                type="text"
                className="ios-input"
                placeholder="Contoh: Meja 04 / Bungkus"
                value={tableNumber}
                onChange={(e) => setTableNumber(e.target.value)}
                required
              />

              <button
                type="submit"
                className="ios-btn-primary"
                disabled={loadingOrder || !storeOpen}
              >
                <QrCode size={18} />
                <span>{loadingOrder ? 'Menyiapkan QRIS...' : 'Lanjut Bayar QRIS'}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    );
  }

  // TAB 3: PESANAN + IMMERSIVE DARK GLASS QRIS PLAYER (Swipe Down to Minimize)
  return (
    <div className={`page-transition ${slideAnimClass}`} style={{ padding: '4px 18px 20px' }}>
      {pendingQrisOrder && qrisDataUrl && (
        <div
          className="immersive-player-overlay"
          style={playerDragStyle}
          {...playerSwipeHandlers}
        >
          <div className="immersive-player-inner">
            <div className="player-grabber" onClick={closePlayerSheet} />

            {/* Top Segmented Pill ("QRIS 1001 SK | Otomatis") */}
            <div style={{ display: 'flex', justifyContent: 'center' }}>
              <div className="player-segmented-pill">
                <span className="player-seg-item active">QRIS 1001 SK</span>
                <span className="player-seg-item">Otomatis</span>
              </div>
            </div>

            {/* White QRIS Artwork Card */}
            <div className="player-artwork-card">
              <img src={qrisDataUrl} alt="QRIS 1001 SK" />
            </div>

            {/* Title & Subtitle + Action Circles */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: 10,
                marginBottom: 14,
              }}
            >
              <div>
                <div style={{ fontSize: 19, fontWeight: 800, letterSpacing: '-0.3px' }}>
                  Rp {pendingQrisOrder.totalPrice?.toLocaleString('id-ID')}
                </div>
                <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.68)', marginTop: 2 }}>
                  {pendingQrisOrder.customerName} • Meja {pendingQrisOrder.tableNumber}
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <button
                  type="button"
                  className="player-circle-icon"
                  onClick={handleDownloadQris}
                  title="Simpan QRIS"
                >
                  <Download size={16} />
                </button>
                <button
                  type="button"
                  className="player-circle-icon"
                  onClick={() => setShowMoreActions((v) => !v)}
                  title="Opsi lainnya"
                >
                  <MoreHorizontal size={17} />
                </button>
              </div>
            </div>

            {/* Dark Frosted Context Menu Popover */}
            {showMoreActions && (
              <div className="player-context-popover">
                <div
                  onClick={() => {
                    setShowMoreActions(false);
                    handleDownloadQris();
                  }}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 12,
                    padding: '13px 16px',
                    borderBottom: '1px solid rgba(255,255,255,0.1)',
                    fontSize: 14,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  <Share2 size={17} />
                  <span>Simpan / Bagikan QRIS</span>
                </div>
                <div
                  onClick={() => {
                    navigator.clipboard?.writeText(String(pendingQrisOrder.totalPrice || ''));
                    setShowMoreActions(false);
                    showToast('Nominal tepat berhasil disalin!');
                  }}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 12,
                    padding: '13px 16px',
                    borderBottom: '1px solid rgba(255,255,255,0.1)',
                    fontSize: 14,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  <CheckCircle2 size={17} />
                  <span>Salin Nominal Tepat</span>
                </div>
                <div
                  onClick={closePlayerSheet}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 12,
                    padding: '13px 16px',
                    fontSize: 14,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  <ChevronDown size={17} />
                  <span>Tutup Layar QRIS</span>
                </div>
              </div>
            )}

            {/* Progress Scrubbing Bar */}
            <div>
              <div
                style={{
                  width: '100%',
                  height: 5,
                  borderRadius: 999,
                  background: 'rgba(255,255,255,0.18)',
                  overflow: 'hidden',
                }}
              >
                <div
                  style={{
                    width: `${Math.min(
                      100,
                      Math.max(
                        8,
                        (getRemainingSeconds(pendingQrisOrder.paymentExpiresAt) /
                          (QRIS_EXPIRY_MINUTES * 60)) *
                          100
                      )
                    )}%`,
                    height: '100%',
                    background: '#ffffff',
                    borderRadius: 999,
                    transition: 'width 1s linear',
                  }}
                />
              </div>

              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  fontSize: 11,
                  color: 'rgba(255,255,255,0.62)',
                  marginTop: 7,
                }}
              >
                <span>
                  Subtotal Rp {pendingQrisOrder.basePrice?.toLocaleString('id-ID')} + Kode{' '}
                  {pendingQrisOrder.uniqueCode}
                </span>
                <span style={{ fontWeight: 700, color: '#ffffff' }}>
                  {formatCountdown(getRemainingSeconds(pendingQrisOrder.paymentExpiresAt))}
                </span>
              </div>
            </div>

            {/* Codec-Style Realtime Badge */}
            <div style={{ textAlign: 'center' }}>
              <span className="player-codec-pill">
                <Wifi size={11} style={{ display: 'inline', marginRight: 5 }} />
                Auto-Verifikasi QRIS Aktif
              </span>
            </div>

            <p
              style={{
                textAlign: 'center',
                fontSize: 12.5,
                color: 'rgba(255,255,255,0.72)',
                lineHeight: 1.45,
                marginTop: 4,
              }}
            >
              Transfer sesuai nominal tepat di atas. Geser layar ini ke bawah untuk mengecilkan ke riwayat pesanan.
            </p>
          </div>
        </div>
      )}

      {orders.length === 0 ? (
        <div className="glass-panel" style={{ textAlign: 'center', padding: 34 }}>
          <p style={{ fontSize: 14, color: 'var(--text-sub)' }}>
            Belum ada riwayat pesanan.
          </p>
        </div>
      ) : (
        orders.map((ord, idx) => {
          const step = getStepLevel(ord.status);
          const isWaitingPayment = ord.status === 'menunggu_pembayaran';
          const canDeleteHistory = !isWaitingPayment;

          return (
            <div
              key={ord.id}
              className="glass-panel vertical-stagger-in"
              style={{ marginBottom: 14, animationDelay: `${Math.min(0.25, idx * 0.04)}s` }}
            >
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  gap: 8,
                }}
              >
                <div>
                  <strong style={{ fontSize: 15.5 }}>{ord.customerName}</strong>
                  <div style={{ fontSize: 12, color: 'var(--text-sub)', marginTop: 2 }}>
                    Meja {ord.tableNumber} • QRIS
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span className={`badge-status status-${ord.status}`}>
                    {ORDER_STATUS_LABELS[ord.status] || ord.status}
                  </span>
                  {canDeleteHistory && (
                    <button
                      type="button"
                      className="delete-icon-btn"
                      onClick={() => handleHideOrderHistory(ord)}
                      title="Hapus Riwayat"
                    >
                      <Trash2 size={13} />
                    </button>
                  )}
                </div>
              </div>

              <div className="order-progress-bar">
                <div className={`progress-step ${step >= 1 ? 'done' : ''}`} />
                <div className={`progress-step ${step >= 2 ? 'done' : ''}`} />
                <div className={`progress-step ${step >= 3 ? 'done' : ''}`} />
                <div className={`progress-step ${step >= 4 ? 'done' : ''}`} />
              </div>

              {isWaitingPayment && (
                <div
                  style={{
                    marginTop: 8,
                    padding: '10px 12px',
                    borderRadius: 14,
                    background: 'rgba(255, 149, 0, 0.1)',
                    fontSize: 12,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontWeight: 700 }}>
                    <Clock size={14} color="var(--accent-orange)" />
                    <span>Menunggu transfer QRIS Rp {ord.totalPrice?.toLocaleString('id-ID')}</span>
                  </div>
                  <button
                    type="button"
                    className="ios-btn-primary"
                    style={{ marginTop: 10, padding: '10px 12px', fontSize: 13 }}
                    onClick={() => setPendingQrisOrder(ord)}
                  >
                    <QrCode size={15} />
                    <span>Buka Layar Pembayaran QRIS</span>
                  </button>
                </div>
              )}

              <div
                style={{
                  margin: '10px 0',
                  borderTop: '1px solid var(--hairline)',
                  paddingTop: 8,
                }}
              >
                {ord.items?.map((item, i) => (
                  <div
                    key={i}
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      fontSize: 13,
                      marginBottom: 4,
                    }}
                  >
                    <span>
                      {item.qty}x {item.name}
                    </span>
                    <span>Rp {(item.price * item.qty).toLocaleString('id-ID')}</span>
                  </div>
                ))}
              </div>

              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  fontWeight: 800,
                  fontSize: 14.5,
                }}
              >
                <span>Total</span>
                <span style={{ color: 'var(--accent-primary)' }}>
                  Rp {ord.totalPrice?.toLocaleString('id-ID')}
                </span>
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}
