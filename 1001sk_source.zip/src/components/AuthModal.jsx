import React, { useState } from 'react';
import { auth, db } from '../firebase';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
} from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { LogOut, User, Store, RefreshCw } from 'lucide-react';
import { triggerHaptic } from '../utils/soundEffects';
import { CURRENT_APP_VERSION } from '../utils/versionUtils';
import {
  sanitizeText,
  checkLoginRateLimit,
  recordAuthResult,
} from '../utils/securityGuard';

const friendlyError = (e) =>
  ({
    'auth/invalid-credential': 'Email atau password salah',
    'auth/email-already-in-use': 'Email sudah terdaftar, silakan login',
    'auth/weak-password': 'Password minimal 6 karakter',
    'auth/invalid-email': 'Format email tidak valid',
    'auth/network-request-failed': 'Tidak ada koneksi internet',
  }[e?.code] || e?.message || 'Gagal autentikasi');

export default function AuthModal({
  isOpen,
  onClose,
  user,
  userRole,
  setUserRole,
  showToast,
  forced = false,
  hasUpdate = false,
  onCheckUpdate,
}) {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleAuth = async (e) => {
    e.preventDefault();
    setErrorMsg('');

    const rate = checkLoginRateLimit();
    if (!rate.allowed) {
      setErrorMsg(`Terlalu banyak percobaan gagal. Coba lagi dalam ${rate.remainingSeconds} detik.`);
      return;
    }

    const cleanEmail = sanitizeText(email, 100).toLowerCase();
    const cleanName = sanitizeText(name, 50);
    if (!cleanEmail || !password) return;

    setLoading(true);
    triggerHaptic(15);
    try {
      if (isRegister) {
        const res = await createUserWithEmailAndPassword(auth, cleanEmail, password);
        await setDoc(doc(db, 'users', res.user.uid), {
          name: cleanName || 'Pelanggan 1001 SK',
          email: cleanEmail,
          role: 'customer',
          createdAt: new Date().toISOString(),
        });
        setUserRole('customer');
        recordAuthResult(true);
        if (showToast) showToast('Akun pelanggan berhasil dibuat!');
      } else {
        await signInWithEmailAndPassword(auth, cleanEmail, password);
        recordAuthResult(true);
        if (showToast) showToast('Berhasil masuk ke 1001 SK');
      }
      onClose();
    } catch (err) {
      recordAuthResult(false);
      setErrorMsg(friendlyError(err));
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    triggerHaptic(15);
    await signOut(auth);
    setUserRole('customer');
    if (showToast) showToast('Anda telah keluar dari akun');
    onClose();
  };

  return (
    <div
      className="ios-modal-overlay"
      onClick={() => {
        if (!forced && onClose) onClose();
      }}
    >
      <div className="ios-modal-sheet" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-handle" />
        <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 4 }}>
          {user ? 'Profil Akun 1001 SK' : isRegister ? 'Daftar Akun Pelanggan' : 'Masuk ke 1001 SK'}
        </h2>
        <p style={{ fontSize: 12.5, color: 'var(--text-sub)', marginBottom: 14 }}>
          {user
            ? 'Status sesi dan hak akses peran aktif'
            : forced
            ? 'Buat akun atau masuk dulu untuk mulai memesan kopi'
            : 'Login sebagai pembeli atau akun kasir (Seller)'}
        </p>

        {/* Kartu Cek Pembaruan Aplikasi */}
        <div
          className="glass-panel"
          style={{
            padding: '11px 14px',
            marginBottom: 14,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 10,
          }}
        >
          <div>
            <div style={{ fontSize: 12.5, fontWeight: 800 }}>
              {hasUpdate ? 'Pembaruan Baru Tersedia!' : 'Versi Aplikasi'}
            </div>
            <div style={{ fontSize: 11.5, color: 'var(--text-sub)' }}>
              {hasUpdate ? 'Ketuk tombol untuk update langsung' : `v${CURRENT_APP_VERSION} (Liquid Glass)`}
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              if (!forced && onClose) onClose();
              if (onCheckUpdate) onCheckUpdate();
            }}
            style={{
              padding: '7px 12px',
              borderRadius: 12,
              border: '1px solid var(--accent-primary)',
              background: hasUpdate ? 'var(--accent-primary)' : 'var(--glass-pill-active)',
              color: hasUpdate ? 'var(--accent-contrast)' : 'var(--accent-primary)',
              fontSize: 11.5,
              fontWeight: 800,
              display: 'inline-flex',
              alignItems: 'center',
              gap: 5,
              cursor: 'pointer',
            }}
          >
            <RefreshCw size={13} /> {hasUpdate ? 'Update' : 'Cek Update'}
          </button>
        </div>

        {user ? (
          <div>
            <div className="glass-panel" style={{ padding: 15, marginBottom: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                <div
                  style={{
                    width: 38,
                    height: 38,
                    borderRadius: 12,
                    background: 'var(--glass-pill-active)',
                    color: 'var(--accent-primary)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {userRole === 'seller' ? <Store size={19} /> : <User size={19} />}
                </div>
                <div>
                  <div style={{ fontSize: 11.5, color: 'var(--text-sub)' }}>Email Terdaftar</div>
                  <div style={{ fontSize: 13.5, fontWeight: 800 }}>{user.email}</div>
                </div>
              </div>
              <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--accent-primary)' }}>
                Peran Akun: {userRole === 'seller' ? 'Penjual (Seller)' : 'Pembeli (Customer)'}
              </div>
              {userRole === 'seller' && (
                <p style={{ fontSize: 11.5, color: 'var(--text-sub)', marginTop: 6 }}>
                  Akun Seller dikunci khusus untuk mengelola pesanan, menu, & QRIS. Pemesanan dinonaktifkan pada mode ini.
                </p>
              )}
            </div>

            <button
              type="button"
              className="ios-btn-primary"
              style={{ background: 'var(--accent-red)', color: '#fff' }}
              onClick={handleLogout}
            >
              <LogOut size={16} /> Keluar dari Akun
            </button>
            {!forced && (
              <button type="button" className="ios-btn-secondary" onClick={onClose}>
                Tutup
              </button>
            )}
          </div>
        ) : (
          <form onSubmit={handleAuth}>
            {errorMsg && (
              <div
                style={{
                  padding: '10px 12px',
                  borderRadius: 12,
                  background: 'rgba(255, 69, 58, 0.16)',
                  border: '1px solid rgba(255, 69, 58, 0.38)',
                  color: 'var(--accent-red)',
                  fontSize: 12.5,
                  fontWeight: 700,
                  marginBottom: 10,
                }}
              >
                {errorMsg}
              </div>
            )}

            {isRegister && (
              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                  Nama Lengkap
                </label>
                <input
                  type="text"
                  className="ios-input"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Contoh: Budi"
                  required
                />
              </div>
            )}

            <div style={{ marginBottom: 10 }}>
              <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                Email
              </label>
              <input
                type="email"
                className="ios-input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="email@domain.com"
                required
              />
            </div>

            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                Password
              </label>
              <input
                type="password"
                className="ios-input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimal 6 karakter"
                required
              />
            </div>

            <button type="submit" className="ios-btn-primary" disabled={loading}>
              {loading ? 'Memproses...' : isRegister ? 'Daftar Akun' : 'Masuk Sekarang'}
            </button>
            <button
              type="button"
              className="ios-btn-secondary"
              onClick={() => {
                setErrorMsg('');
                setIsRegister(!isRegister);
              }}
            >
              {isRegister ? 'Sudah punya akun? Login' : 'Belum punya akun? Daftar'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
