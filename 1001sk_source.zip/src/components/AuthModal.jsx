import React, { useState } from 'react';
import { auth, db } from '../firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { LogOut, User, Store } from 'lucide-react';

export default function AuthModal({ isOpen, onClose, user, userRole, setUserRole, showToast }) {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleAuth = async (e) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);

    try {
      if (isRegister) {
        const res = await createUserWithEmailAndPassword(auth, email, password);
        await setDoc(doc(db, 'users', res.user.uid), {
          name: name || 'Pelanggan 1001 SK',
          email: email,
          role: 'customer',
          createdAt: new Date().toISOString()
        });
        setUserRole('customer');
        if (showToast) showToast('Akun berhasil dibuat!');
      } else {
        await signInWithEmailAndPassword(auth, email, password);
        if (showToast) showToast('Berhasil masuk ke 1001 SK');
      }
      onClose();
    } catch (err) {
      setErrorMsg(err.message || 'Gagal autentikasi');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    setUserRole('customer');
    if (showToast) showToast('Anda telah keluar dari akun');
    onClose();
  };

  return (
    <div className="ios-modal-overlay" onClick={onClose}>
      <div className="ios-modal-sheet" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-handle" />
        <div style={{ textAlign: 'center', marginBottom: 18 }}>
          <h2 style={{ fontSize: 20, fontWeight: 800 }}>
            {user ? 'Profil Akun 1001 SK' : isRegister ? 'Daftar Akun Baru' : 'Masuk ke 1001 SK'}
          </h2>
          <p style={{ fontSize: 12, color: 'var(--text-sub)', marginTop: 4 }}>
            {user ? 'Kelola sesi akun dan status akses aplikasi' : 'Masuk sebagai pelanggan atau akun kasir/seller'}
          </p>
        </div>

        {user ? (
          <div>
            <div className="glass-panel" style={{ padding: 16, marginBottom: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                <div style={{ width: 40, height: 40, borderRadius: 12, background: 'rgba(230, 184, 125, 0.16)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent-gold)' }}>
                  {userRole === 'seller' ? <Store size={20} /> : <User size={20} />}
                </div>
                <div>
                  <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>Email Terdaftar</div>
                  <div style={{ fontSize: 14.5, fontWeight: 700, color: '#fff' }}>{user.email}</div>
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: '1px solid var(--glass-border)', paddingTop: 12 }}>
                <span style={{ fontSize: 12.5, color: 'var(--text-sub)' }}>Status Akses:</span>
                <span className={`badge-status ${userRole === 'seller' ? 'status-siap' : 'status-diproses'}`}>
                  {userRole === 'seller' ? 'Penjual (Seller)' : 'Pembeli (Customer)'}
                </span>
              </div>
            </div>

            <button className="ios-btn-primary" style={{ background: 'linear-gradient(135deg, #ff453a, #ff7e47)', color: '#fff' }} onClick={handleLogout}>
              <LogOut size={16} /> Keluar dari Akun
            </button>
            <button className="ios-btn-secondary" onClick={onClose}>Tutup</button>
          </div>
        ) : (
          <form onSubmit={handleAuth}>
            {errorMsg && (
              <div style={{ padding: 12, borderRadius: 12, background: 'rgba(255,69,58,0.18)', border: '1px solid rgba(255,69,58,0.4)', color: '#ff6961', fontSize: 12.5, marginBottom: 14 }}>
                {errorMsg}
              </div>
            )}

            {isRegister && (
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 600 }}>Nama Lengkap</label>
                <input type="text" className="ios-input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Contoh: Budi" required />
              </div>
            )}

            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 600 }}>Email</label>
              <input type="email" className="ios-input" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@domain.com" required />
            </div>

            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 600 }}>Password</label>
              <input type="password" className="ios-input" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Minimal 6 karakter" required />
            </div>

            <button type="submit" className="ios-btn-primary" disabled={loading}>
              {loading ? 'Memproses...' : isRegister ? 'Daftar Akun' : 'Masuk Sekarang'}
            </button>

            <button type="button" className="ios-btn-secondary" onClick={() => setIsRegister(!isRegister)}>
              {isRegister ? 'Sudah punya akun? Login' : 'Belum ada akun? Daftar'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
