import React, { useState } from 'react';
import { auth, db } from '../firebase';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile,
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { CURRENT_APP_VERSION } from '../utils/versionUtils';
import {
  sanitizeText,
  checkLoginRateLimit,
  recordAuthResult,
} from '../utils/securityGuard';
import { useSheetSwipeDismiss } from '../hooks/useSheetSwipeDismiss';
import {
  X,
  LogOut,
  Coffee,
  Sparkles,
  Sun,
  Moon,
  Bell,
  BellOff,
  RefreshCw,
  User,
  ChevronRight,
  Lock,
} from 'lucide-react';

export default function AuthModal({
  isOpen,
  forced = false,
  onClose,
  user,
  userRole,
  setUserRole,
  showToast,
  hasUpdate,
  onCheckUpdate,
  theme = 'light',
  onToggleTheme,
  soundEnabled = true,
  onToggleSound,
  connectionState = 'online',
  onManualSync,
}) {
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const { sheetDragStyle: settingsDragStyle, sheetSwipeHandlers: settingsSwipeHandlers } =
    useSheetSwipeDismiss({
      onClose,
      enabled: Boolean(user && !forced),
    });

  if (!isOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    const cleanEmail = email.trim().toLowerCase();
    const cleanName = sanitizeText(name, 50);

    const rateCheck = checkLoginRateLimit();
    if (!rateCheck.allowed) {
      showToast(`Terlalu banyak percobaan. Coba lagi dalam ${rateCheck.remainingSeconds} detik.`);
      return;
    }

    setLoading(true);
    try {
      if (isRegister) {
        if (password.length < 6) {
          throw new Error('Kata sandi minimal 6 karakter.');
        }
        const res = await createUserWithEmailAndPassword(auth, cleanEmail, password);
        if (cleanName) {
          await updateProfile(res.user, { displayName: cleanName });
        }
        await setDoc(doc(db, 'users', res.user.uid), {
          name: cleanName || 'Pelanggan',
          email: cleanEmail,
          role: 'customer',
          createdAt: new Date().toISOString(),
        });
        recordAuthResult(true);
        setUserRole('customer');
        showToast('Akun pelanggan 1001 SK berhasil dibuat!');
      } else {
        const res = await signInWithEmailAndPassword(auth, cleanEmail, password);
        const userDoc = await getDoc(doc(db, 'users', res.user.uid));
        const role = userDoc.exists() ? userDoc.data().role : 'customer';
        recordAuthResult(true);
        setUserRole(role);
        showToast(role === 'seller' ? 'Berhasil masuk sebagai Penjual!' : 'Selamat datang di 1001 SK!');
      }
      if (!forced) onClose();
    } catch (err) {
      recordAuthResult(false);
      showToast('Gagal: ' + (err.message || 'Periksa email dan sandi Anda'));
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    setUserRole('customer');
    showToast('Anda telah keluar dari akun');
    if (!forced) onClose();
  };

  // Full-Screen iOS "Pengaturan" Screen when User is Logged In
  if (user) {
    return (
      <div
        className="ios-settings-screen"
        style={settingsDragStyle}
        {...settingsSwipeHandlers}
      >
        <div className="ios-settings-container">
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 6 }}>
            <button
              type="button"
              className="avatar-glass-btn"
              onClick={onClose}
              aria-label="Tutup Pengaturan"
            >
              <X size={19} />
            </button>
          </div>

          <h2
            style={{
              fontSize: 32,
              fontWeight: 800,
              letterSpacing: '-0.8px',
              marginBottom: 16,
            }}
          >
            Pengaturan
          </h2>

          {/* Profile Card */}
          <div className="ios-grouped-card">
            <div className="ios-grouped-row" style={{ cursor: 'default' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 13 }}>
                <div
                  style={{
                    width: 52,
                    height: 52,
                    borderRadius: '50%',
                    background: 'var(--glass-pill)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'var(--accent-primary)',
                  }}
                >
                  <User size={25} />
                </div>
                <div>
                  <div style={{ fontSize: 17, fontWeight: 700 }}>
                    {user.displayName || 'Pelanggan 1001 SK'}
                  </div>
                  <div style={{ fontSize: 12.5, color: 'var(--text-sub)' }}>{user.email}</div>
                  <div
                    style={{
                      fontSize: 11,
                      fontWeight: 700,
                      color: 'var(--accent-primary)',
                      marginTop: 2,
                    }}
                  >
                    {userRole === 'seller' ? 'Mode Penjual / Kasir' : 'Akun Pelanggan'}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Grouped Toggles: Tema & Nada Notifikasi */}
          <div className="ios-grouped-card">
            <div className="ios-grouped-row" onClick={onToggleTheme}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <span
                  className="ios-squircle-icon"
                  style={{ background: theme === 'dark' ? '#5856d6' : '#ff9500' }}
                >
                  {theme === 'dark' ? <Moon size={17} /> : <Sun size={17} />}
                </span>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 600 }}>Tampilan Gelap</div>
                  <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>
                    {theme === 'dark' ? 'Tema Gelap Aktif' : 'Tema Terang Aktif'}
                  </div>
                </div>
              </div>
              <button
                type="button"
                className={`ios-switch ${theme === 'dark' ? 'on' : ''}`}
                aria-label="Tema"
              >
                <span className="ios-switch-knob" />
              </button>
            </div>

            <div className="ios-grouped-row" onClick={onToggleSound}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <span className="ios-squircle-icon" style={{ background: '#fa2d48' }}>
                  {soundEnabled ? <Bell size={17} /> : <BellOff size={17} />}
                </span>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 600 }}>Nada Notifikasi</div>
                  <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>
                    {soundEnabled ? 'Dering & getar aktif' : 'Hening'}
                  </div>
                </div>
              </div>
              <button
                type="button"
                className={`ios-switch ${soundEnabled ? 'on' : ''}`}
                aria-label="Nada Notifikasi"
              >
                <span className="ios-switch-knob" />
              </button>
            </div>
          </div>

          {/* Grouped System Rows: Sinkronisasi & Versi */}
          <div className="ios-grouped-card">
            <div
              className="ios-grouped-row"
              onClick={() => {
                onManualSync?.();
                showToast('Menyegarkan koneksi realtime...');
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <span className="ios-squircle-icon" style={{ background: '#34c759' }}>
                  <RefreshCw
                    size={17}
                    className={connectionState === 'reconnecting' ? 'spin-slow' : ''}
                  />
                </span>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 600 }}>Sinkronisasi Realtime</div>
                  <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>
                    {connectionState === 'online'
                      ? 'Terhubung langsung ke server'
                      : connectionState === 'reconnecting'
                      ? 'Menghubungkan ulang...'
                      : 'Offline'}
                  </div>
                </div>
              </div>
              <ChevronRight size={17} color="var(--text-sub)" />
            </div>

            <div className="ios-grouped-row" onClick={onCheckUpdate}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <span className="ios-squircle-icon" style={{ background: '#007aff' }}>
                  <Sparkles size={17} />
                </span>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 600 }}>Versi Aplikasi</div>
                  <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>
                    1001 SK v{CURRENT_APP_VERSION}
                  </div>
                </div>
              </div>
              {hasUpdate ? (
                <span
                  style={{
                    padding: '4px 10px',
                    borderRadius: 999,
                    background: 'var(--accent-primary)',
                    color: '#fff',
                    fontSize: 11,
                    fontWeight: 700,
                  }}
                >
                  Update
                </span>
              ) : (
                <ChevronRight size={17} color="var(--text-sub)" />
              )}
            </div>
          </div>

          {/* Sign Out Card */}
          <div className="ios-grouped-card">
            <div className="ios-grouped-row" onClick={handleLogout}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <span className="ios-squircle-icon" style={{ background: '#ff3b30' }}>
                  <LogOut size={17} />
                </span>
                <span style={{ fontSize: 15, fontWeight: 700, color: 'var(--accent-red)' }}>
                  Keluar dari Akun
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Login / Register Card
  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        padding: '24px 20px',
      }}
    >
      <div className="glass-panel" style={{ padding: 22 }}>
        <div style={{ textAlign: 'center', marginBottom: 18 }}>
          <div
            style={{
              width: 56,
              height: 56,
              borderRadius: 18,
              background: 'var(--accent-primary)',
              color: '#ffffff',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: 10,
              boxShadow: '0 10px 24px rgba(250, 45, 72, 0.3)',
            }}
          >
            <Coffee size={28} />
          </div>
          <h2 style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.5px' }}>
            {isRegister ? 'Daftar Akun 1001 SK' : 'Masuk ke 1001 SK'}
          </h2>
          <p style={{ fontSize: 13, color: 'var(--text-sub)', marginTop: 4 }}>
            Nikmati racikan kopi favorit dengan antarmuka iOS 26 Liquid Glass
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          {isRegister && (
            <input
              type="text"
              className="ios-input"
              placeholder="Nama Lengkap"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          )}
          <input
            type="email"
            className="ios-input"
            placeholder="Alamat Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            className="ios-input"
            placeholder="Kata Sandi"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <button type="submit" className="ios-btn-primary" disabled={loading}>
            <Lock size={16} />
            <span>
              {loading
                ? 'Memproses...'
                : isRegister
                ? 'Buat Akun Sekarang'
                : 'Masuk'}
            </span>
          </button>
        </form>

        <button
          type="button"
          className="ios-btn-secondary"
          onClick={() => setIsRegister((prev) => !prev)}
        >
          {isRegister ? 'Sudah punya akun? Masuk' : 'Belum punya akun? Daftar Baru'}
        </button>
      </div>
    </div>
  );
}
