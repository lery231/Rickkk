import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  User,
  Sun,
  Moon,
  Volume2,
  Bell,
  ShieldCheck,
  Info,
  LogOut,
  Search,
  RefreshCw,
  LogIn,
  UserPlus,
  Store,
  QrCode,
  Upload,
  Trash2
} from 'lucide-react';
import { APP_VERSION, formatRupiah } from '../utils/constants.js';
import {
  isSoundEnabled,
  setSoundEnabled,
  playOrderReadyChime,
  playTapHaptic
} from '../utils/soundEffects.js';
import { compressImageFile } from '../utils/imageCompressor.js';
import { extractNominalFromText } from '../utils/qrisAutoMatcher.js';

export default function AuthModal({
  isOpen,
  onClose,
  user,
  userProfile,
  theme,
  onToggleTheme,
  onGoogleLogin,
  onEmailLogin,
  onEmailRegister,
  onLogout,
  onManualSync,
  isSyncing,
  notifPermission,
  onRequestNotifPermission,
  authLoading,
  authError,
  storeName,
  qrisImageUrl,
  onSaveStoreSettings,
  orders,
  onUpdateOrderStatus
}) {
  const [scrolled, setScrolled] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAuthForm, setShowAuthForm] = useState(false);
  const [authMode, setAuthMode] = useState('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [closing, setClosing] = useState(false);

  const [editStoreName, setEditStoreName] = useState(storeName || '1001 SK Coffee & Lounge');
  const [editQrisUrl, setEditQrisUrl] = useState(qrisImageUrl || '');
  const [notifSmsText, setNotifSmsText] = useState('');
  const [settingsMsg, setSettingsMsg] = useState('');

  useEffect(() => {
    setEditStoreName(storeName || '1001 SK Coffee & Lounge');
  }, [storeName]);

  useEffect(() => {
    setEditQrisUrl(qrisImageUrl || '');
  }, [qrisImageUrl]);

  useEffect(() => {
    if (isOpen) setClosing(false);
  }, [isOpen]);

  if (!isOpen) return null;

  const soundOn = isSoundEnabled();
  const isSeller = userProfile?.role === 'seller';

  const triggerClose = () => {
    setClosing(true);
    window.setTimeout(() => {
      setClosing(false);
      onClose();
    }, 240);
  };

  const showNotice = (msg) => {
    setSettingsMsg(msg);
    window.setTimeout(() => setSettingsMsg(''), 3000);
  };

  const handleScroll = (e) => {
    setScrolled(e.currentTarget.scrollTop > 22);
  };

  const handleToggleSound = () => {
    const next = !soundOn;
    setSoundEnabled(next);
    if (next) playOrderReadyChime(true);
    else playTapHaptic();
  };

  const handleSubmitForm = async (e) => {
    e.preventDefault();
    if (authMode === 'login') {
      await onEmailLogin(email, password);
    } else {
      await onEmailRegister(name, email, password);
    }
  };

  const handleQrisUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await compressImageFile(file, 720, 0.85);
      setEditQrisUrl(dataUrl);
      showNotice('Gambar QRIS siap disimpan');
    } catch (err) {
      showNotice(err.message);
    }
  };

  const handleAutoMatchQris = () => {
    const nominal = extractNominalFromText(notifSmsText);
    if (!nominal) {
      showNotice('Nominal pembayaran tidak terbaca dari teks notifikasi');
      return;
    }
    const matched = (orders || []).find(
      (o) => ['pending_payment', 'queued'].includes(o.status) && Number(o.totalPrice) === nominal
    );
    if (matched && onUpdateOrderStatus) {
      onUpdateOrderStatus(matched.id, 'queued');
      setNotifSmsText('');
      showNotice(`Pembayaran ${formatRupiah(nominal)} untuk ${matched.customerName} terverifikasi!`);
    } else {
      showNotice(`Tidak ada pesanan aktif sebesar ${formatRupiah(nominal)}`);
    }
  };

  const matchesSearch = (label) => {
    if (!searchQuery.trim()) return true;
    return label.toLowerCase().includes(searchQuery.trim().toLowerCase());
  };

  return (
    <div
      className={`settings-modal-layer ${closing ? 'is-closing' : ''}`}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 130,
        background: 'var(--bg-grouped)',
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      {/* Floating Cupertino Top Back Button */}
      <div
        style={{
          position: 'fixed',
          top: 'calc(env(safe-area-inset-top, 12px) + 8px)',
          left: 16,
          right: 16,
          zIndex: 140,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          pointerEvents: 'none'
        }}
      >
        <button
          type="button"
          className="refractive-glass"
          onClick={() => {
            playTapHaptic();
            triggerClose();
          }}
          aria-label="Kembali"
          style={{
            pointerEvents: 'auto',
            width: 42,
            height: 42,
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--text-primary)',
            cursor: 'pointer'
          }}
        >
          <ChevronLeft size={22} style={{ position: 'relative', zIndex: 1 }} />
        </button>

        {scrolled && (
          <div
            className="refractive-glass"
            style={{
              pointerEvents: 'auto',
              padding: '7px 18px',
              borderRadius: 999,
              fontSize: 16,
              fontWeight: 700
            }}
          >
            <span style={{ position: 'relative', zIndex: 1 }}>Pengaturan</span>
          </div>
        )}

        <div style={{ width: 42 }} />
      </div>

      {/* Scrollable Settings Body */}
      <div
        onScroll={handleScroll}
        style={{
          flex: 1,
          overflowY: 'auto',
          padding: 'calc(env(safe-area-inset-top, 12px) + 60px) 18px 110px',
          maxWidth: 540,
          width: '100%',
          margin: '0 auto'
        }}
      >
        <h1
          style={{
            fontSize: 33,
            fontWeight: 800,
            letterSpacing: '-0.03em',
            marginBottom: 16
          }}
        >
          Pengaturan
        </h1>

        {settingsMsg && (
          <div
            className="ios-grouped-card"
            style={{
              padding: '10px 14px',
              marginBottom: 14,
              background: 'var(--accent-soft)',
              color: 'var(--accent)',
              fontSize: 13,
              fontWeight: 700
            }}
          >
            {settingsMsg}
          </div>
        )}

        {/* Group 1: Apple ID Style Account Card */}
        <div className="ios-grouped-card" style={{ marginBottom: 18 }}>
          <div
            className="settings-row"
            onClick={() => {
              if (!user) setShowAuthForm((v) => !v);
            }}
          >
            <div
              style={{
                width: 54,
                height: 54,
                borderRadius: '50%',
                background: 'var(--accent-soft)',
                color: 'var(--accent)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                overflow: 'hidden',
                flexShrink: 0
              }}
            >
              {user?.photoURL ? (
                <img
                  src={user.photoURL}
                  alt="Avatar"
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
              ) : isSeller ? (
                <Store size={25} />
              ) : (
                <User size={25} />
              )}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 17, fontWeight: 700 }}>
                {user ? userProfile?.name || user.displayName || 'Pelanggan 1001 SK' : 'Masuk Akun'}
              </div>
              <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 2 }}>
                {user
                  ? `${user.email || 'Akun Aktif'} • ${isSeller ? 'Mode Penjual' : 'Pelanggan'}`
                  : 'Sinkronisasi pesanan, riwayat, & profil Anda'}
              </div>
            </div>
            {!user && <ChevronRight size={18} style={{ color: 'var(--text-tertiary)' }} />}
          </div>

          {!user && showAuthForm && (
            <div style={{ padding: 16, borderTop: '1px solid var(--border-hairline)' }}>
              <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
                <button
                  type="button"
                  className={authMode === 'login' ? 'btn-ios-primary' : 'btn-ios-secondary'}
                  style={{ flex: 1, padding: '9px 12px', fontSize: 13 }}
                  onClick={() => setAuthMode('login')}
                >
                  Masuk
                </button>
                <button
                  type="button"
                  className={authMode === 'register' ? 'btn-ios-primary' : 'btn-ios-secondary'}
                  style={{ flex: 1, padding: '9px 12px', fontSize: 13 }}
                  onClick={() => setAuthMode('register')}
                >
                  Daftar Baru
                </button>
              </div>

              <form onSubmit={handleSubmitForm} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {authMode === 'register' && (
                  <input
                    className="ios-input"
                    type="text"
                    placeholder="Nama Lengkap"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                )}
                <input
                  className="ios-input"
                  type="email"
                  placeholder="Alamat Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
                <input
                  className="ios-input"
                  type="password"
                  placeholder="Kata Sandi"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                {authError && (
                  <div style={{ fontSize: 12.5, color: '#ff453a', fontWeight: 600 }}>{authError}</div>
                )}
                <button type="submit" className="btn-ios-primary" disabled={authLoading}>
                  {authMode === 'login' ? <LogIn size={16} /> : <UserPlus size={16} />}
                  {authLoading ? 'Memproses...' : authMode === 'login' ? 'Masuk Sekarang' : 'Buat Akun'}
                </button>
              </form>

              <button
                type="button"
                className="btn-ios-secondary"
                style={{ width: '100%', marginTop: 10 }}
                onClick={onGoogleLogin}
                disabled={authLoading}
              >
                Lanjutkan dengan Google
              </button>
            </div>
          )}
        </div>

        {/* Seller-Only Section: Pengaturan Toko & QRIS */}
        {isSeller && (
          <div className="ios-grouped-card" style={{ marginBottom: 18, padding: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <div className="squircle-icon" style={{ background: '#fa2d48' }}>
                <QrCode size={18} />
              </div>
              <div>
                <div style={{ fontSize: 15.5, fontWeight: 800 }}>Pengaturan Toko & QRIS</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                  Unggah gambar QRIS statis untuk pembayaran pelanggan
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <input
                className="ios-input"
                type="text"
                placeholder="Nama Kedai / Toko"
                value={editStoreName}
                onChange={(e) => setEditStoreName(e.target.value)}
              />
              <div style={{ display: 'flex', gap: 8 }}>
                <label className="btn-ios-secondary" style={{ flex: 1, cursor: 'pointer' }}>
                  <Upload size={16} />
                  {editQrisUrl ? 'Ganti Gambar QRIS' : 'Unggah Gambar QRIS'}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleQrisUpload}
                    style={{ display: 'none' }}
                  />
                </label>
                {editQrisUrl && (
                  <button
                    type="button"
                    className="btn-ios-secondary"
                    aria-label="Hapus QRIS"
                    style={{ color: '#ff453a', padding: '12px 14px' }}
                    onClick={() => {
                      setEditQrisUrl('');
                      showNotice('Gambar QRIS dihapus (klik Simpan untuk menerapkan)');
                    }}
                  >
                    <Trash2 size={16} />
                  </button>
                )}
              </div>

              {editQrisUrl && (
                <div style={{ textAlign: 'center', padding: 10, background: '#fff', borderRadius: 16 }}>
                  <img
                    src={editQrisUrl}
                    alt="Pratinjau QRIS Toko"
                    style={{ maxWidth: 190, width: '100%', borderRadius: 12 }}
                  />
                </div>
              )}

              <button
                type="button"
                className="btn-ios-primary"
                onClick={() => {
                  if (onSaveStoreSettings) {
                    onSaveStoreSettings({ storeName: editStoreName, qrisImageUrl: editQrisUrl });
                  }
                  showNotice('Pengaturan Toko & QRIS tersimpan');
                }}
              >
                Simpan Pengaturan QRIS
              </button>
            </div>

            <div style={{ marginTop: 16, paddingTop: 14, borderTop: '1px solid var(--border-hairline)' }}>
              <div style={{ fontSize: 13.5, fontWeight: 800, marginBottom: 4 }}>
                Verifikasi Mutasi QRIS Otomatis
              </div>
              <textarea
                className="ios-input"
                rows={2}
                placeholder="Tempel teks notifikasi pembayaran masuk..."
                value={notifSmsText}
                onChange={(e) => setNotifSmsText(e.target.value)}
              />
              <button
                type="button"
                className="btn-ios-secondary"
                style={{ width: '100%', marginTop: 8 }}
                onClick={handleAutoMatchQris}
              >
                Cocokkan Nominal Pembayaran
              </button>
            </div>
          </div>
        )}

        {/* Group 2: Display & Sound */}
        <div className="ios-grouped-card" style={{ marginBottom: 18 }}>
          {matchesSearch('Tema Tampilan Gelap Terang') && (
            <div className="settings-row" onClick={onToggleTheme}>
              <div
                className="squircle-icon"
                style={{ background: theme === 'dark' ? '#5e5ce6' : '#ff9f0a' }}
              >
                {theme === 'dark' ? <Moon size={18} /> : <Sun size={18} />}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 600 }}>Refractive Liquid Glass</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                  {theme === 'dark' ? 'Mode Gelap Aktif' : 'Mode Terang Aktif'}
                </div>
              </div>
              <button
                type="button"
                className={`ios-switch ${theme === 'dark' ? 'on' : ''}`}
                aria-label="Ubah Tema"
              >
                <div className="ios-switch-thumb" />
              </button>
            </div>
          )}

          {matchesSearch('Nada Notifikasi Suara Pesanan') && (
            <div className="settings-row" onClick={handleToggleSound}>
              <div className="squircle-icon" style={{ background: '#fa2d48' }}>
                <Volume2 size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 600 }}>Nada Notifikasi</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                  Suara dering saat pesanan siap / masuk
                </div>
              </div>
              <button
                type="button"
                className={`ios-switch ${soundOn ? 'on' : ''}`}
                aria-label="Ubah Nada Notifikasi"
              >
                <div className="ios-switch-thumb" />
              </button>
            </div>
          )}

          {matchesSearch('Izin Notifikasi Push') && (
            <div className="settings-row" onClick={onRequestNotifPermission}>
              <div className="squircle-icon" style={{ background: '#ff3b30' }}>
                <Bell size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 600 }}>Notifikasi Perangkat</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                  Status: {notifPermission === 'granted' ? 'Diizinkan' : 'Ketuk untuk mengaktifkan'}
                </div>
              </div>
              <ChevronRight size={18} style={{ color: 'var(--text-tertiary)' }} />
            </div>
          )}
        </div>

        {/* Group 3: Sync, Role Security & App Version */}
        <div className="ios-grouped-card" style={{ marginBottom: 18 }}>
          {matchesSearch('Sinkronisasi Realtime') && (
            <div className="settings-row" onClick={onManualSync}>
              <div className="squircle-icon" style={{ background: '#0a84ff' }}>
                <RefreshCw size={17} className={isSyncing ? 'spin' : ''} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 600 }}>Sinkronisasi Real-Time</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                  {isSyncing ? 'Menyegarkan data...' : 'Terhubung otomatis ke Firestore'}
                </div>
              </div>
              <ChevronRight size={18} style={{ color: 'var(--text-tertiary)' }} />
            </div>
          )}

          {matchesSearch('Keamanan Peran') && (
            <div className="settings-row">
              <div className="squircle-icon" style={{ background: '#30d158' }}>
                <ShieldCheck size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 600 }}>Keamanan Akun</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                  {isSeller
                    ? 'Akun Penjual Terproteksi (Mode Kelola Toko & QRIS)'
                    : 'Akun Pelanggan Terenkripsi'}
                </div>
              </div>
            </div>
          )}

          {matchesSearch('Tentang Aplikasi Versi') && (
            <div className="settings-row">
              <div className="squircle-icon" style={{ background: '#8e8e93' }}>
                <Info size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 600 }}>Versi Aplikasi</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                  1001 SK v{APP_VERSION} • Convx Refractive Glass HIG
                </div>
              </div>
            </div>
          )}
        </div>

        {user && (
          <button
            type="button"
            className="ios-grouped-card settings-row"
            onClick={onLogout}
            style={{
              justifyContent: 'center',
              color: '#ff453a',
              fontWeight: 700,
              fontSize: 15
            }}
          >
            <LogOut size={18} /> Keluar dari Akun
          </button>
        )}
      </div>

      {/* Floating Glass Search Bar */}
      <div
        style={{
          position: 'fixed',
          left: '50%',
          transform: 'translateX(-50%)',
          bottom: 'calc(14px + env(safe-area-inset-bottom, 6px))',
          width: 'calc(100% - 36px)',
          maxWidth: 504,
          zIndex: 140
        }}
      >
        <div
          className="refractive-glass"
          style={{
            height: 48,
            borderRadius: 999,
            padding: '0 16px',
            display: 'flex',
            alignItems: 'center',
            gap: 10
          }}
        >
          <Search size={18} style={{ color: 'var(--text-secondary)', position: 'relative', zIndex: 1 }} />
          <input
            type="text"
            placeholder="Cari pengaturan..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              flex: 1,
              border: 'none',
              background: 'transparent',
              color: 'var(--text-primary)',
              fontSize: 15,
              outline: 'none',
              position: 'relative',
              zIndex: 1
            }}
          />
        </div>
      </div>
    </div>
  );
}
