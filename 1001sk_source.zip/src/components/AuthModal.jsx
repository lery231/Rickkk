import React, { useState } from 'react';
import { auth, db } from '../firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';

export default function AuthModal({ isOpen, onClose, user, userRole, setUserRole }) {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleAuth = async (e) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);

    try {
      if (isRegister) {
        const res = await createUserWithEmailAndPassword(auth, email, password);
        await setDoc(doc(db, 'users', res.user.uid), {
          name: name || 'Pelanggan 1001 SK',
          email: email,
          role: 'customer',
          createdAt: new Date().toISOString()
        });
        setUserRole('customer');
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
      onClose();
    } catch (err) {
      setErrorMsg(err.message || 'Gagal autentikasi');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    setUserRole('customer');
    onClose();
  };

  return (
    <div className="ios-modal-overlay" onClick={onClose}>
      <div className="ios-modal-sheet" onClick={(e) => e.stopPropagation()}>
        <div style={{ textAlign: 'center', marginBottom: 16 }}>
          <div style={{ width: 40, height: 4, background: 'rgba(255,255,255,0.2)', borderRadius: 2, margin: '0 auto 16px' }} />
          <h2 style={{ fontSize: 20, fontWeight: 800 }}>
            {user ? 'Profil Akun 1001 SK' : isRegister ? 'Daftar Akun Baru' : 'Masuk ke 1001 SK'}
          </h2>
        </div>

        {user ? (
          <div>
            <div className="glass-panel" style={{ padding: 16, marginBottom: 16 }}>
              <p style={{ fontSize: 13, color: 'var(--text-sub)' }}>Email Terdaftar:</p>
              <p style={{ fontSize: 15, fontWeight: 700, color: '#fff', marginBottom: 10 }}>{user.email}</p>
              
              <p style={{ fontSize: 13, color: 'var(--text-sub)' }}>Status Akses Role:</p>
              <span className={`badge-status ${userRole === 'seller' ? 'status-siap' : 'status-diproses'}`}>
                {userRole === 'seller' ? 'Penjual (Seller / Admin)' : 'Pembeli (Customer)'}
              </span>
            </div>

            <button className="ios-btn-primary" style={{ background: 'linear-gradient(135deg, #ff453a, #ff7e47)' }} onClick={handleLogout}>
              Logout / Keluar
            </button>
            <button className="ios-btn-secondary" onClick={onClose}>Tutup</button>
          </div>
        ) : (
          <form onSubmit={handleAuth}>
            {errorMsg && (
              <div style={{ padding: 10, borderRadius: 10, background: 'rgba(255,69,58,0.2)', color: '#ff453a', fontSize: 13, marginBottom: 12 }}>
                {errorMsg}
              </div>
            )}

            {isRegister && (
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)' }}>Nama Lengkap</label>
                <input type="text" className="ios-input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Contoh: Budi" required />
              </div>
            )}

            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 12, color: 'var(--text-sub)' }}>Email</label>
              <input type="email" className="ios-input" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@domain.com" required />
            </div>

            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 12, color: 'var(--text-sub)' }}>Password</label>
              <input type="password" className="ios-input" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="******" required />
            </div>

            <button type="submit" className="ios-btn-primary" disabled={loading}>
              {loading ? 'Memproses...' : isRegister ? 'Daftar Akun' : 'Masuk Sekarang'}
            </button>

            <button type="button" className="ios-btn-secondary" onClick={() => setIsRegister(!isRegister)}>
              {isRegister ? 'Sudah punya akun? Login' : 'Belum ada akun? Daftar'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
