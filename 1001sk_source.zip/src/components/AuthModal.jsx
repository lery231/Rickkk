import React, { useState } from 'react';
import { auth, db } from '../firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { LogOut, User, Store, ShieldCheck, RefreshCw } from 'lucide-react';
import { triggerHaptic } from '../utils/soundEffects';
import { CURRENT_APP_VERSION } from '../utils/versionUtils';

const friendlyError = (e) => ({
  'auth/invalid-credential': 'Email atau password salah',
  'auth/email-already-in-use': 'Email sudah terdaftar, silakan login',
  'auth/weak-password': 'Password minimal 6 karakter',
  'auth/invalid-email': 'Format email tidak valid',
  'auth/network-request-failed': 'Tidak ada koneksi internet',
}[e?.code] || e?.message || 'Gagal autentikasi');

export default function AuthModal({
  isOpen,
  onClose,
  user,
  userRole,
  setUserRole,
  showToast,
  forced = false,
  hasUpdate = false,
  onCheckUpdate,
}) {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleAuth = async (e) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);
    triggerHaptic(15);

    try {
      if (isRegister) {
        const res = await createUserWithEmailAndPassword(auth, email, password);
        await setDoc(doc(db, 'users', res.user.uid), {
          name: name || 'Pelanggan 1001 SK',
          email: email,
          role: 'customer',
          createdAt: new Date().toISOString()
        });
        setUserRole('customer');
        if (showToast) showToast('Akun pelanggan berhasil dibuat!');
      } else {
        await signInWithEmailAndPassword(auth, email, password);
        if (showToast) showToast('Berhasil masuk ke 1001 SK');
      }
      onClose();
    } catch (err) {
      setErrorMsg(friendlyError(err));
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    triggerHaptic(15);
    await signOut(auth);
    setUserRole('customer');
    if (showToast) showToast('Anda telah keluar dari akun');
    onClose();
  };

  return (
    <div className="ios-modal-overlay" onClick={forced ? undefined : onClose}>
      <div className="ios-modal-sheet" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-handle" />
        <div style={{ textAlign: 'center', marginBottom: 16 }}>
          <h2 style={{ fontSize: 19, fontWeight: 800 }}>
            {user ? 'Profil Akun 1001 SK' : isRegister ? 'Daftar Akun Pelanggan' : 'Masuk ke 1001 SK'}
          </h2>
          <p style={{ fontSize: 12, color: 'var(--text-sub)', marginTop: 4 }}>
            {user ? 'Status sesi dan hak akses peran aktif' : forced ? 'Buat akun atau masuk dulu untuk mulai memesan kopi' : 'Login sebagai pembeli atau akun kasir (Seller)'}
          </p>
        </div>

        {/* Kartu Cek Pembaruan Aplikasi */}
        <div className="glass-panel" style={{ padding: 13, marginBottom: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 800 }}>
              {hasUpdate ? 'Pembaruan Baru Tersedia!' : 'Versi Aplikasi'}
            </div>
            <div style={{ fontSize: 11.5, color: 'var(--text-sub)' }}>
              {hasUpdate ? 'Ketuk tombol untuk update langsung' : `v${CURRENT_APP_VERSION} (Terpasang)`}
            </div>
          </div>
          <button
            type="button"
            className={`tab-btn ${hasUpdate ? 'active' : ''}`}
            onClick={() => {
              if (!forced && onClose) onClose();
              if (onCheckUpdate) onCheckUpdate();
            }}
          >
            <RefreshCw size={13} /> {hasUpdate ? 'Update' : 'Cek Update'}
          </button>
        </div>

        {user ? (
          <div>
            <div className="glass-panel" style={{ padding: 16, marginBottom: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
                <div style={{ width: 42, height: 42, borderRadius: 14, background: 'var(--glass-pill-active)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent-primary)' }}>
                  {userRole === 'seller' ? <Store size={20} /> : <User size={20} />}
                </div>
                <div>
                  <div style={{ fontSize: 11.5, color: 'var(--text-sub)' }}>Email Terdaftar</div>
                  <div style={{ fontSize: 14, fontWeight: 700 }}>{user.email}</div>
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: '1px solid var(--glass-border)', paddingTop: 12 }}>
                <span style={{ fontSize: 12.5, color: 'var(--text-sub)' }}>Peran Akun:</span>
                <span className={`badge-status ${userRole === 'seller' ? 'status-siap' : 'status-diproses'}`}>
                  {userRole === 'seller' ? 'Penjual (Seller)' : 'Pembeli (Customer)'}
                </span>
              </div>

              {userRole === 'seller' && (
                <div style={{ marginTop: 12, padding: 10, borderRadius: 12, background: 'rgba(255, 159, 10, 0.12)', border: '1px solid rgba(255, 159, 10, 0.3)', fontSize: 11.5, color: 'var(--accent-orange)', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <ShieldCheck size={16} style={{ flexShrink: 0 }} />
                  <span>Akun Seller dikunci khusus untuk mengelola pesanan & menu. Pemesanan dinonaktifkan pada mode ini.</span>
                </div>
              )}
            </div>

            <button className="ios-btn-primary" style={{ background: 'var(--accent-red)', color: '#fff' }} onClick={handleLogout}>
              <LogOut size={16} /> Keluar dari Akun
            </button>
            <button className="ios-btn-secondary" onClick={onClose}>Tutup</button>
          </div>
        ) : (
          <form onSubmit={handleAuth}>
            {errorMsg && (
              <div style={{ padding: 12, borderRadius: 12, background: 'rgba(255,69,58,0.16)', border: '1px solid rgba(255,69,58,0.38)', color: 'var(--accent-red)', fontSize: 12.5, marginBottom: 12 }}>
                {errorMsg}
              </div>
            )}

            {isRegister && (
              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Nama Lengkap</label>
                <input type="text" className="ios-input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Contoh: Budi" required />
              </div>
            )}

            <div style={{ marginBottom: 10 }}>
              <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Email</label>
              <input type="email" className="ios-input" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@domain.com" required />
            </div>

            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Password</label>
              <input type="password" className="ios-input" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Minimal 6 karakter" required />
            </div>

            <button type="submit" className="ios-btn-primary" disabled={loading}>
              {loading ? 'Memproses...' : isRegister ? 'Daftar Akun' : 'Masuk Sekarang'}
            </button>

            <button type="button" className="ios-btn-secondary" onClick={() => setIsRegister(!isRegister)}>
              {isRegister ? 'Sudah punya akun? Login' : 'Belum ada akun? Daftar'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
