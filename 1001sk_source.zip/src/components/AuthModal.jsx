import React, { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  User,
  Sun,
  Moon,
  Volume2,
  Bell,
  ShieldCheck,
  Info,
  LogOut,
  Search,
  RefreshCw,
  LogIn,
  UserPlus,
  Store
} from 'lucide-react';
import { APP_VERSION } from '../utils/constants.js';
import { isSoundEnabled, setSoundEnabled, playOrderReadyChime, playTapHaptic } from '../utils/soundEffects.js';

export default function AuthModal({
  isOpen,
  onClose,
  user,
  userProfile,
  theme,
  onToggleTheme,
  onGoogleLogin,
  onEmailLogin,
  onEmailRegister,
  onLogout,
  onManualSync,
  isSyncing,
  notifPermission,
  onRequestNotifPermission,
  authLoading,
  authError
}) {
  const [scrolled, setScrolled] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAuthForm, setShowAuthForm] = useState(false);
  const [authMode, setAuthMode] = useState('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  if (!isOpen) return null;

  const soundOn = isSoundEnabled();
  const isSeller = userProfile?.role === 'seller';

  const handleScroll = (e) => {
    setScrolled(e.currentTarget.scrollTop > 22);
  };

  const handleToggleSound = () => {
    const next = !soundOn;
    setSoundEnabled(next);
    if (next) playOrderReadyChime(true);
    else playTapHaptic();
  };

  const handleSubmitForm = async (e) => {
    e.preventDefault();
    if (authMode === 'login') {
      await onEmailLogin(email, password);
    } else {
      await onEmailRegister(name, email, password);
    }
  };

  const matchesSearch = (label) => {
    if (!searchQuery.trim()) return true;
    return label.toLowerCase().includes(searchQuery.trim().toLowerCase());
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 130,
        background: 'var(--bg-grouped)',
        display: 'flex',
        flexDirection: 'column',
        animation: 'slideSheetUp 0.34s var(--spring-smooth)'
      }}
    >
      <div
        style={{
          position: 'fixed',
          top: 0,
          left: '50%',
          transform: 'translateX(-50%)',
          width: '100%',
          maxWidth: 540,
          zIndex: 136,
          padding: 'calc(env(safe-area-inset-top, 12px) + 8px) 18px 8px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          pointerEvents: 'none'
        }}
      >
        <button
          type="button"
          className="refractive-glass"
          onClick={onClose}
          aria-label="Kembali"
          style={{
            pointerEvents: 'auto',
            width: 42,
            height: 42,
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--text-primary)',
            cursor: 'pointer'
          }}
        >
          <ChevronLeft size={22} style={{ position: 'relative', zIndex: 1 }} />
        </button>

        <div
          className="refractive-glass"
          style={{
            padding: '7px 18px',
            borderRadius: 999,
            fontSize: 16,
            fontWeight: 800,
            color: 'var(--text-primary)',
            opacity: scrolled ? 1 : 0,
            transform: scrolled ? 'translateY(0) scale(1)' : 'translateY(-8px) scale(0.92)',
            transition: 'all 0.3s var(--spring-smooth)'
          }}
        >
          <span style={{ position: 'relative', zIndex: 1 }}>Pengaturan</span>
        </div>

        <div style={{ width: 42 }} />
      </div>

      <div
        onScroll={handleScroll}
        style={{
          flex: 1,
          overflowY: 'auto',
          padding: 'calc(env(safe-area-inset-top, 12px) + 60px) 18px calc(110px + env(safe-area-inset-bottom, 16px))',
          maxWidth: 540,
          width: '100%',
          margin: '0 auto'
        }}
      >
        <h1
          style={{
            fontSize: 31,
            fontWeight: 800,
            letterSpacing: '-0.03em',
            marginBottom: 16,
            color: 'var(--text-primary)'
          }}
        >
          Pengaturan
        </h1>

        <div className="ios-grouped-card" style={{ marginBottom: 14 }}>
          <div
            className="settings-row"
            onClick={() => {
              if (!user) setShowAuthForm((v) => !v);
            }}
          >
            <div
              style={{
                width: 52,
                height: 52,
                borderRadius: '50%',
                background: isSeller ? 'var(--accent)' : 'rgba(130, 142, 168, 0.24)',
                color: isSeller ? '#fff' : 'var(--text-secondary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0,
                overflow: 'hidden'
              }}
            >
              {user?.photoURL ? (
                <img src={user.photoURL} alt="Profil" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : isSeller ? (
                <Store size={24} />
              ) : (
                <User size={25} />
              )}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 17, fontWeight: 800, color: 'var(--text-primary)' }}>
                {user ? userProfile?.name || user.displayName || 'Pelanggan 1001 SK' : 'Masuk Akun'}
              </div>
              <div
                style={{
                  fontSize: 13,
                  color: 'var(--text-secondary)',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                }}
              >
                {user
                  ? `${user.email || 'Akun Aktif'} • ${isSeller ? 'Mode Penjual' : 'Pelanggan'}`
                  : 'Sinkronisasi pesanan, riwayat, & profil Anda'}
              </div>
            </div>
            {!user && <ChevronRight size={18} style={{ color: 'var(--text-tertiary)' }} />}
          </div>

          {!user && showAuthForm && (
            <div style={{ padding: '4px 16px 16px', borderTop: '1px solid var(--border-hairline)' }}>
              <div style={{ display: 'flex', gap: 8, marginTop: 12, marginBottom: 12 }}>
                <button
                  type="button"
                  className={`ios-pill ${authMode === 'login' ? 'active' : ''}`}
                  style={{ flex: 1 }}
                  onClick={() => setAuthMode('login')}
                >
                  Masuk
                </button>
                <button
                  type="button"
                  className={`ios-pill ${authMode === 'register' ? 'active' : ''}`}
                  style={{ flex: 1 }}
                  onClick={() => setAuthMode('register')}
                >
                  Daftar Baru
                </button>
              </div>

              <form onSubmit={handleSubmitForm} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {authMode === 'register' && (
                  <input
                    className="ios-input"
                    type="text"
                    placeholder="Nama Lengkap"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                )}
                <input
                  className="ios-input"
                  type="email"
                  placeholder="Email Anda"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
                <input
                  className="ios-input"
                  type="password"
                  placeholder="Kata Sandi"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                {authError && (
                  <div style={{ fontSize: 12.5, color: '#ff453a', fontWeight: 600 }}>{authError}</div>
                )}
                <button type="submit" className="btn-ios-primary" disabled={authLoading}>
                  {authMode === 'login' ? <LogIn size={17} /> : <UserPlus size={17} />}
                  {authLoading ? 'Memproses...' : authMode === 'login' ? 'Masuk Sekarang' : 'Buat Akun'}
                </button>
              </form>

              <button
                type="button"
                className="btn-ios-secondary"
                style={{ width: '100%', marginTop: 10 }}
                onClick={onGoogleLogin}
                disabled={authLoading}
              >
                Lanjutkan dengan Google
              </button>
            </div>
          )}
        </div>

        <div className="ios-grouped-card" style={{ marginBottom: 14 }}>
          {matchesSearch('Tema Tampilan Gelap Terang') && (
            <div className="settings-row" onClick={onToggleTheme}>
              <div className="squircle-icon" style={{ background: theme === 'dark' ? '#5e5ce6' : '#ff9f0a' }}>
                {theme === 'dark' ? <Moon size={18} /> : <Sun size={18} />}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 700 }}>Refractive Liquid Glass</div>
                <div style={{ fontSize: 12.5, color: 'var(--text-secondary)' }}>
                  {theme === 'dark' ? 'Mode Gelap Aktif' : 'Mode Terang Aktif'}
                </div>
              </div>
              <button
                type="button"
                className={`ios-switch ${theme === 'dark' ? 'on' : ''}`}
                aria-label="Ubah Tema"
              >
                <div className="ios-switch-thumb" />
              </button>
            </div>
          )}

          {matchesSearch('Nada Notifikasi Suara Pesanan') && (
            <div className="settings-row" onClick={handleToggleSound}>
              <div className="squircle-icon" style={{ background: '#fa2d48' }}>
                <Volume2 size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 700 }}>Nada Notifikasi</div>
                <div style={{ fontSize: 12.5, color: 'var(--text-secondary)' }}>
                  Suara dering saat pesanan siap / masuk
                </div>
              </div>
              <button
                type="button"
                className={`ios-switch ${soundOn ? 'on' : ''}`}
                aria-label="Ubah Nada Notifikasi"
              >
                <div className="ios-switch-thumb" />
              </button>
            </div>
          )}

          {matchesSearch('Izin Notifikasi Push') && (
            <div className="settings-row" onClick={onRequestNotifPermission}>
              <div className="squircle-icon" style={{ background: '#0a84ff' }}>
                <Bell size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 700 }}>Notifikasi Perangkat</div>
                <div style={{ fontSize: 12.5, color: 'var(--text-secondary)' }}>
                  Status: {notifPermission === 'granted' ? 'Diizinkan' : 'Ketuk untuk mengaktifkan'}
                </div>
              </div>
              <ChevronRight size={18} style={{ color: 'var(--text-tertiary)' }} />
            </div>
          )}
        </div>

        <div className="ios-grouped-card" style={{ marginBottom: 14 }}>
          {matchesSearch('Sinkronisasi Realtime') && (
            <div className="settings-row" onClick={onManualSync}>
              <div className="squircle-icon" style={{ background: '#30d158' }}>
                <RefreshCw size={18} className={isSyncing ? 'spin' : ''} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 700 }}>Sinkronisasi Real-Time</div>
                <div style={{ fontSize: 12.5, color: 'var(--text-secondary)' }}>
                  {isSyncing ? 'Menyegarkan data...' : 'Terhubung otomatis ke Firestore'}
                </div>
              </div>
              <ChevronRight size={18} style={{ color: 'var(--text-tertiary)' }} />
            </div>
          )}

          {matchesSearch('Keamanan Peran') && (
            <div className="settings-row">
              <div className="squircle-icon" style={{ background: '#32ade6' }}>
                <ShieldCheck size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 700 }}>Keamanan Akun</div>
                <div style={{ fontSize: 12.5, color: 'var(--text-secondary)' }}>
                  {isSeller ? 'Akun Penjual Terproteksi (Mode Kelola Toko)' : 'Akun Pelanggan Terenkripsi'}
                </div>
              </div>
            </div>
          )}

          {matchesSearch('Tentang Aplikasi Versi') && (
            <div className="settings-row">
              <div className="squircle-icon" style={{ background: '#8e8e93' }}>
                <Info size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 700 }}>Versi Aplikasi</div>
                <div style={{ fontSize: 12.5, color: 'var(--text-secondary)' }}>
                  1001 SK v{APP_VERSION} • Convx Refractive Glass HIG
                </div>
              </div>
            </div>
          )}
        </div>

        {user && (
          <button
            type="button"
            className="btn-ios-secondary"
            style={{ width: '100%', color: '#ff453a', fontWeight: 800 }}
            onClick={onLogout}
          >
            <LogOut size={17} /> Keluar dari Akun
          </button>
        )}
      </div>

      <div
        style={{
          position: 'fixed',
          bottom: 'calc(14px + env(safe-area-inset-bottom, 6px))',
          left: '50%',
          transform: 'translateX(-50%)',
          width: 'calc(100% - 36px)',
          maxWidth: 504,
          zIndex: 136
        }}
      >
        <div
          className="refractive-glass"
          style={{
            height: 48,
            borderRadius: 999,
            padding: '0 16px',
            display: 'flex',
            alignItems: 'center',
            gap: 10
          }}
        >
          <Search size={18} style={{ color: 'var(--text-secondary)', position: 'relative', zIndex: 1 }} />
          <input
            type="text"
            placeholder="Mencari pengaturan..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              flex: 1,
              border: 'none',
              background: 'transparent',
              color: 'var(--text-primary)',
              fontSize: 15,
              outline: 'none',
              position: 'relative',
              zIndex: 1
            }}
          />
        </div>
      </div>
    </div>
  );
}
