import React, { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  User,
  Sun,
  Moon,
  Volume2,
  Bell,
  ShieldCheck,
  Info,
  LogOut,
  Search,
  RefreshCw,
  LogIn,
  UserPlus,
  Store
} from 'lucide-react';
import { APP_VERSION, SELLER_EMAIL } from '../utils/constants.js';
import { isSoundEnabled, setSoundEnabled, playOrderReadyChime, playTapHaptic } from '../utils/soundEffects.js';

export default function AuthModal({
  isOpen,
  onClose,
  user,
  userProfile,
  theme,
  onToggleTheme,
  onGoogleLogin,
  onEmailLogin,
  onEmailRegister,
  onLogout,
  onManualSync,
  isSyncing,
  notifPermission,
  onRequestNotifPermission,
  authLoading,
  authError
}) {
  const [scrolled, setScrolled] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAuthForm, setShowAuthForm] = useState(false);
  const [authMode, setAuthMode] = useState('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  if (!isOpen) return null;

  const soundOn = isSoundEnabled();
  const isSeller = userProfile?.role === 'seller';

  const handleScroll = (e) => {
    setScrolled(e.currentTarget.scrollTop > 22);
  };

  const handleToggleSound = () => {
    const next = !soundOn;
    setSoundEnabled(next);
    if (next) playOrderReadyChime(true);
    else playTapHaptic();
  };

  const handleSubmitForm = async (e) => {
    e.preventDefault();
    if (authMode === 'login') {
      await onEmailLogin(email, password);
    } else {
      await onEmailRegister(name, email, password);
    }
  };

  const matchesSearch = (label) => {
    if (!searchQuery.trim()) return true;
    return label.toLowerCase().includes(searchQuery.trim().toLowerCase());
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 80,
        background: 'rgba(4, 6, 12, 0.65)',
        backdropFilter: 'blur(18px)',
        -webkit-backdrop-filter: 'blur(18px)',
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      <div
        onScroll={handleScroll}
        className="convx-modal-animate"
        style={{
          flex: 1,
          overflowY: 'auto',
          padding: 'calc(env(safe-area-inset-top, 14px) + 12px) 16px 110px',
          maxWidth: 520,
          width: '100%',
          margin: '0 auto'
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: 12
          }}
        >
          <button type="button" className="btn-ios-glass" onClick={onClose}>
            <ChevronLeft size={18} />
            <span>Kembali</span>
          </button>
          {scrolled && <span style={{ fontWeight: 700, fontSize: 15 }}>Pengaturan</span>}
          <div style={{ width: 72 }} />
        </div>

        <h1 style={{ fontSize: 28, fontWeight: 800, margin: '4px 0 14px', letterSpacing: -0.5 }}>
          Pengaturan
        </h1>

        <div
          className="convx-glass-card"
          style={{
            padding: '10px 14px',
            marginBottom: 14,
            display: 'flex',
            alignItems: 'center',
            gap: 10
          }}
        >
          <Search size={17} style={{ color: 'var(--text-tertiary)', zIndex: 2 }} />
          <input
            type="text"
            placeholder="Cari pengaturan..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              flex: 1,
              border: 'none',
              background: 'transparent',
              color: 'var(--text-primary)',
              fontSize: 15,
              outline: 'none',
              position: 'relative',
              zIndex: 2
            }}
          />
        </div>

        {/* Profile Card */}
        <div
          className="convx-glass-card"
          onClick={() => {
            if (!user) setShowAuthForm((v) => !v);
          }}
          style={{
            padding: 16,
            marginBottom: 14,
            display: 'flex',
            alignItems: 'center',
            gap: 14,
            cursor: user ? 'default' : 'pointer'
          }}
        >
          <div
            style={{
              width: 52,
              height: 52,
              borderRadius: '50%',
              background: isSeller
                ? 'linear-gradient(135deg, #ff9f0a, #ff375f)'
                : 'linear-gradient(135deg, #0a84ff, #5e5ce6)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#fff',
              flexShrink: 0,
              zIndex: 2
            }}
          >
            {user?.photoURL ? (
              <img
                src={user.photoURL}
                alt="Avatar"
                style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }}
              />
            ) : isSeller ? (
              <Store size={24} />
            ) : (
              <User size={24} />
            )}
          </div>
          <div style={{ flex: 1, zIndex: 2 }}>
            <div style={{ fontWeight: 700, fontSize: 16 }}>
              {user ? userProfile?.name || user.displayName || 'Pelanggan 1001 SK' : 'Masuk Akun'}
            </div>
            <div style={{ fontSize: 12.5, color: 'var(--text-secondary)', marginTop: 2 }}>
              {user
                ? `${user.email || 'Akun Aktif'} • ${isSeller ? 'Mode Penjual' : 'Pelanggan'}`
                : 'Sinkronisasi pesanan, riwayat, & mode penjual'}
            </div>
          </div>
          {!user && <ChevronRight size={18} style={{ color: 'var(--text-tertiary)', zIndex: 2 }} />}
        </div>

        {!user && showAuthForm && (
          <div className="convx-glass-card" style={{ padding: 16, marginBottom: 14 }}>
            <div style={{ display: 'flex', gap: 8, marginBottom: 12, position: 'relative', zIndex: 2 }}>
              <button
                type="button"
                className={`convx-chip ${authMode === 'login' ? 'active' : ''}`}
                style={{ flex: 1 }}
                onClick={() => setAuthMode('login')}
              >
                Masuk
              </button>
              <button
                type="button"
                className={`convx-chip ${authMode === 'register' ? 'active' : ''}`}
                style={{ flex: 1 }}
                onClick={() => setAuthMode('register')}
              >
                Daftar Baru
              </button>
            </div>

            <form
              onSubmit={handleSubmitForm}
              style={{ display: 'grid', gap: 10, position: 'relative', zIndex: 2 }}
            >
              {authMode === 'register' && (
                <input
                  type="text"
                  className="ios-glass-input"
                  placeholder="Nama Lengkap"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              )}
              <input
                type="email"
                className="ios-glass-input"
                placeholder={`Email (Penjual: ${SELLER_EMAIL})`}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <input
                type="password"
                className="ios-glass-input"
                placeholder="Kata Sandi"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              {authError && (
                <div style={{ color: '#ff453a', fontSize: 12.5, fontWeight: 600 }}>{authError}</div>
              )}
              <button type="submit" className="btn-ios-primary" disabled={authLoading}>
                {authMode === 'login' ? <LogIn size={16} /> : <UserPlus size={16} />}
                <span>
                  {authLoading
                    ? 'Memproses...'
                    : authMode === 'login'
                    ? 'Masuk Sekarang'
                    : 'Buat Akun'}
                </span>
              </button>
              <button type="button" className="btn-ios-glass" onClick={onGoogleLogin}>
                Lanjutkan dengan Google
              </button>
            </form>
          </div>
        )}

        {/* Settings Group */}
        <div className="convx-glass-card" style={{ padding: 6, display: 'grid', gap: 2 }}>
          {matchesSearch('Tema Tampilan Gelap Terang') && (
            <button
              type="button"
              onClick={onToggleTheme}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 12,
                padding: '12px 12px',
                border: 'none',
                background: 'transparent',
                color: 'var(--text-primary)',
                textAlign: 'left',
                cursor: 'pointer',
                position: 'relative',
                zIndex: 2
              }}
            >
              <div
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 10,
                  background: 'rgba(255, 159, 10, 0.18)',
                  color: '#ff9f0a',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                {theme === 'dark' ? <Moon size={18} /> : <Sun size={18} />}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14.5 }}>Convx Refractive Liquid Glass</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                  {theme === 'dark' ? 'Mode Gelap Aktif' : 'Mode Terang Aktif'}
                </div>
              </div>
              <span className="convx-chip active" style={{ padding: '5px 11px', fontSize: 11.5 }}>
                Ubah
              </span>
            </button>
          )}

          {matchesSearch('Nada Notifikasi Suara Pesanan') && (
            <button
              type="button"
              onClick={handleToggleSound}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 12,
                padding: '12px 12px',
                border: 'none',
                background: 'transparent',
                color: 'var(--text-primary)',
                textAlign: 'left',
                cursor: 'pointer',
                position: 'relative',
                zIndex: 2
              }}
            >
              <div
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 10,
                  background: 'rgba(48, 209, 88, 0.18)',
                  color: '#30d158',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <Volume2 size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14.5 }}>Nada Notifikasi</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                  Suara dering saat pesanan siap / masuk
                </div>
              </div>
              <span
                className={`convx-chip ${soundOn ? 'active' : ''}`}
                style={{ padding: '5px 11px', fontSize: 11.5 }}
              >
                {soundOn ? 'Aktif' : 'Mati'}
              </span>
            </button>
          )}

          {matchesSearch('Izin Notifikasi Push') && (
            <button
              type="button"
              onClick={onRequestNotifPermission}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 12,
                padding: '12px 12px',
                border: 'none',
                background: 'transparent',
                color: 'var(--text-primary)',
                textAlign: 'left',
                cursor: 'pointer',
                position: 'relative',
                zIndex: 2
              }}
            >
              <div
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 10,
                  background: 'rgba(255, 55, 95, 0.18)',
                  color: '#ff375f',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <Bell size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14.5 }}>Notifikasi Perangkat</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                  Status: {notifPermission === 'granted' ? 'Diizinkan' : 'Ketuk untuk mengaktifkan'}
                </div>
              </div>
            </button>
          )}

          {matchesSearch('Sinkronisasi Realtime') && (
            <button
              type="button"
              onClick={onManualSync}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 12,
                padding: '12px 12px',
                border: 'none',
                background: 'transparent',
                color: 'var(--text-primary)',
                textAlign: 'left',
                cursor: 'pointer',
                position: 'relative',
                zIndex: 2
              }}
            >
              <div
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 10,
                  background: 'rgba(10, 132, 255, 0.18)',
                  color: '#0a84ff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <RefreshCw size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14.5 }}>Sinkronisasi Real-Time</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                  {isSyncing ? 'Menyegarkan data...' : 'Terhubung otomatis ke penyimpanan'}
                </div>
              </div>
            </button>
          )}

          {matchesSearch('Keamanan Peran') && (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 12,
                padding: '12px 12px',
                position: 'relative',
                zIndex: 2
              }}
            >
              <div
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 10,
                  background: 'rgba(191, 90, 242, 0.18)',
                  color: '#bf5af2',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <ShieldCheck size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14.5 }}>Keamanan Akun</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                  {isSeller
                    ? 'Akun Penjual Terproteksi (Mode Kelola Toko)'
                    : 'Akun Pelanggan Terenkripsi'}
                </div>
              </div>
            </div>
          )}

          {matchesSearch('Tentang Aplikasi Versi') && (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 12,
                padding: '12px 12px',
                position: 'relative',
                zIndex: 2
              }}
            >
              <div
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 10,
                  background: 'var(--bg-subtle)',
                  color: 'var(--text-secondary)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <Info size={18} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14.5 }}>Versi Aplikasi</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                  1001 SK v{APP_VERSION} • Convx Refractive Glass HIG
                </div>
              </div>
            </div>
          )}
        </div>

        {user && (
          <button
            type="button"
            className="btn-ios-glass"
            onClick={onLogout}
            style={{
              width: '100%',
              marginTop: 16,
              color: '#ff453a',
              borderColor: 'rgba(255, 69, 58, 0.35)',
              padding: '13px 16px'
            }}
          >
            <LogOut size={16} />
            <span>Keluar dari Akun</span>
          </button>
        )}
      </div>
    </div>
  );
}
