import React, { useState } from 'react';
import { Minus, Plus, Trash2, QrCode, ShoppingBag } from 'lucide-react';
import { formatRupiah } from '../utils/constants.js';
import { playTapHaptic } from '../utils/soundEffects.js';

export default function CartSheet({
  cart,
  defaultCustomerName,
  onUpdateQty,
  onRemoveItem,
  onCheckoutQris
}) {
  const [customerName, setCustomerName] = useState(defaultCustomerName || '');
  const [tableNumber, setTableNumber] = useState('Meja 01');
  const [note, setNote] = useState('');

  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  const handleCheckout = (e) => {
    e.preventDefault();
    if (cart.length === 0) return;
    playTapHaptic();
    onCheckoutQris({
      customerName: customerName.trim() || 'Pelanggan 1001 SK',
      tableNumber: tableNumber.trim() || 'Takeaway',
      note: note.trim(),
      items: cart,
      totalPrice
    });
  };

  if (cart.length === 0) {
    return (
      <div className="convx-glass-card" style={{ padding: 34, textAlign: 'center' }}>
        <ShoppingBag size={36} style={{ color: 'var(--text-tertiary)', marginBottom: 10 }} />
        <div style={{ fontWeight: 800, fontSize: 16 }}>Keranjang Masih Kosong</div>
        <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>
          Pilih kopi atau pastry favoritmu dari tab Menu Kopi.
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: 'grid', gap: 14 }}>
      <h2 style={{ margin: 0, fontSize: 19, fontWeight: 800 }}>Keranjang Pesanan</h2>

      <div style={{ display: 'grid', gap: 10 }}>
        {cart.map((item) => (
          <div
            key={item.cartKey}
            className="convx-glass-card"
            style={{
              padding: 12,
              display: 'flex',
              alignItems: 'center',
              gap: 12
            }}
          >
            <img
              src={item.image}
              alt={item.name}
              style={{
                width: 54,
                height: 54,
                borderRadius: 14,
                objectFit: 'cover',
                zIndex: 2
              }}
            />
            <div style={{ flex: 1, zIndex: 2 }}>
              <div style={{ fontWeight: 700, fontSize: 14 }}>{item.name}</div>
              <div style={{ fontSize: 11.5, color: 'var(--text-secondary)' }}>{item.variant}</div>
              <div style={{ fontWeight: 700, fontSize: 13, color: 'var(--accent-amber)', marginTop: 2 }}>
                {formatRupiah(item.price * item.qty)}
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 6, zIndex: 2 }}>
              <button
                type="button"
                className="btn-ios-glass"
                style={{ padding: 6 }}
                onClick={() => onUpdateQty(item.cartKey, item.qty - 1)}
              >
                <Minus size={14} />
              </button>
              <span style={{ fontWeight: 700, minWidth: 20, textAlign: 'center', fontSize: 13.5 }}>
                {item.qty}
              </span>
              <button
                type="button"
                className="btn-ios-glass"
                style={{ padding: 6 }}
                onClick={() => onUpdateQty(item.cartKey, item.qty + 1)}
              >
                <Plus size={14} />
              </button>
              <button
                type="button"
                onClick={() => onRemoveItem(item.cartKey)}
                style={{
                  border: 'none',
                  background: 'transparent',
                  color: '#ff453a',
                  cursor: 'pointer',
                  padding: 4
                }}
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={handleCheckout} className="convx-glass-card" style={{ padding: 16 }}>
        <div style={{ display: 'grid', gap: 10, position: 'relative', zIndex: 2 }}>
          <div style={{ fontWeight: 800, fontSize: 15 }}>Detail Pemesan</div>
          <input
            type="text"
            className="ios-glass-input"
            placeholder="Nama Anda"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            required
          />
          <select
            className="ios-glass-input"
            value={tableNumber}
            onChange={(e) => setTableNumber(e.target.value)}
          >
            <option value="Meja 01">Dine In — Meja 01</option>
            <option value="Meja 02">Dine In — Meja 02</option>
            <option value="Meja 03">Dine In — Meja 03</option>
            <option value="Meja 04">Dine In — Meja 04</option>
            <option value="Takeaway">Takeaway / Bawa Pulang</option>
          </select>
          <input
            type="text"
            className="ios-glass-input"
            placeholder="Catatan barista (opsional)"
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />

          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingTop: 6,
              borderTop: '1px solid var(--glass-border-outer)'
            }}
          >
            <span style={{ color: 'var(--text-secondary)', fontSize: 13.5 }}>Total Pembayaran</span>
            <strong style={{ fontSize: 18, color: 'var(--accent-amber)' }}>
              {formatRupiah(totalPrice)}
            </strong>
          </div>

          <button type="submit" className="btn-ios-primary">
            <QrCode size={17} />
            <span>Bayar Sekarang via QRIS</span>
          </button>
        </div>
      </form>
    </div>
  );
}
