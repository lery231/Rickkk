import React from 'react';
import { ReceiptText, Trash2, QrCode, CheckCircle2 } from 'lucide-react';
import { ORDER_STATUS_META, formatRupiah, formatDateTime } from '../utils/constants.js';
import { playTapHaptic } from '../utils/soundEffects.js';

export default function OrdersView({ orders, onOpenQris, onDeleteOrder }) {
  if (orders.length === 0) {
    return (
      <div className="convx-glass-card" style={{ padding: 34, textAlign: 'center' }}>
        <ReceiptText size={36} style={{ color: 'var(--text-tertiary)', marginBottom: 10 }} />
        <div style={{ fontWeight: 800, fontSize: 16 }}>Belum Ada Riwayat Pesanan</div>
        <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>
          Status racikan kopimu akan tampil secara real-time di sini.
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: 'grid', gap: 14 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <h2 style={{ margin: 0, fontSize: 19, fontWeight: 800 }}>Pesanan & Riwayat</h2>
      </div>

      {orders.map((order) => {
        const meta = ORDER_STATUS_META[order.status] || ORDER_STATUS_META.queued;
        const progressPercent =
          meta.step <= 0 ? 15 : Math.min(100, Math.round((meta.step / 4) * 100));

        return (
          <div key={order.id} className="convx-glass-card" style={{ padding: 15 }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: 8,
                position: 'relative',
                zIndex: 2
              }}
            >
              <span
                style={{
                  padding: '4px 11px',
                  borderRadius: 999,
                  background: meta.bg,
                  color: meta.color,
                  fontSize: 11.5,
                  fontWeight: 700
                }}
              >
                {meta.label}
              </span>

              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 11.5, color: 'var(--text-tertiary)' }}>
                  {formatDateTime(order.createdAt)}
                </span>
                {/* Riwayat pesanan dapat dihapus */}
                <button
                  type="button"
                  onClick={() => {
                    playTapHaptic();
                    onDeleteOrder(order.id);
                  }}
                  title="Hapus Riwayat Pesanan"
                  style={{
                    width: 28,
                    height: 28,
                    borderRadius: '50%',
                    border: 'none',
                    background: 'var(--bg-subtle)',
                    color: '#ff453a',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer'
                  }}
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>

            {/* Progress Bar */}
            {order.status !== 'cancelled' && (
              <div
                style={{
                  height: 6,
                  borderRadius: 999,
                  background: 'var(--bg-subtle)',
                  overflow: 'hidden',
                  marginBottom: 10,
                  position: 'relative',
                  zIndex: 2
                }}
              >
                <div
                  style={{
                    width: `${progressPercent}%`,
                    height: '100%',
                    borderRadius: 999,
                    background: meta.color,
                    transition: 'width 0.5s cubic-bezier(0.22, 1, 0.36, 1)'
                  }}
                />
              </div>
            )}

            <div style={{ fontWeight: 700, fontSize: 14.5, position: 'relative', zIndex: 2 }}>
              #{order.id} • {order.tableNumber || 'Takeaway'}
            </div>
            <div
              style={{
                fontSize: 13,
                color: 'var(--text-secondary)',
                margin: '4px 0 10px',
                position: 'relative',
                zIndex: 2
              }}
            >
              {(order.items || []).map((i) => `${i.qty}x ${i.name} (${i.variant})`).join(', ')}
            </div>

            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                position: 'relative',
                zIndex: 2
              }}
            >
              <strong style={{ fontSize: 15, color: 'var(--accent-amber)' }}>
                {formatRupiah(order.totalPrice)}
              </strong>

              {order.status === 'pending_payment' && (
                <button
                  type="button"
                  className="btn-ios-glass"
                  onClick={() => onOpenQris(order)}
                >
                  <QrCode size={14} />
                  <span>Tampilkan QRIS</span>
                </button>
              )}

              {order.status === 'ready' && (
                <span
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 5,
                    color: '#30d158',
                    fontSize: 12.5,
                    fontWeight: 700
                  }}
                >
                  <CheckCircle2 size={15} />
                  <span>Silakan Ambil di Bar</span>
                </span>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
