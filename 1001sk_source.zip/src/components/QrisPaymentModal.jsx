import React, { useState } from 'react';
import { QrCode, CheckCircle2, Copy, X } from 'lucide-react';
import { formatRupiah } from '../utils/constants.js';
import { playTapHaptic } from '../utils/soundEffects.js';

export default function QrisPaymentModal({ order, storeName, qrisImageUrl, onConfirmPaid, onClose }) {
  const [copied, setCopied] = useState(false);

  if (!order) return null;

  const handleCopyNominal = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(String(order.totalPrice)).catch(() => {});
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 85,
        background: 'rgba(4, 6, 12, 0.72)',
        backdropFilter: 'blur(18px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 16
      }}
    >
      <div
        className="convx-glass-card convx-modal-animate"
        style={{ width: '100%', maxWidth: 420, padding: 20, textAlign: 'center' }}
      >
        <div style={{ position: 'relative', zIndex: 2 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 800, fontSize: 16 }}>Pembayaran QRIS</span>
            <button
              type="button"
              onClick={onClose}
              style={{
                width: 30,
                height: 30,
                borderRadius: '50%',
                border: 'none',
                background: 'var(--bg-subtle)',
                color: 'var(--text-primary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer'
              }}
            >
              <X size={16} />
            </button>
          </div>

          <div style={{ fontSize: 12.5, color: 'var(--text-secondary)', marginTop: 4 }}>
            {storeName} • ID #{order.id}
          </div>

          <div
            style={{
              margin: '16px auto',
              width: 210,
              height: 210,
              borderRadius: 22,
              background: '#ffffff',
              padding: 14,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 12px 30px rgba(0,0,0,0.35)'
            }}
          >
            {qrisImageUrl ? (
              <img
                src={qrisImageUrl}
                alt="QRIS Toko"
                style={{ width: '100%', height: '100%', objectFit: 'contain' }}
              />
            ) : (
              <>
                <QrCode size={132} color="#111521" strokeWidth={1.6} />
                <span style={{ color: '#111521', fontWeight: 800, fontSize: 11, marginTop: 6 }}>
                  QRIS • {storeName}
                </span>
              </>
            )}
          </div>

          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              padding: '8px 14px',
              borderRadius: 999,
              background: 'var(--bg-subtle)',
              marginBottom: 14
            }}
          >
            <strong style={{ fontSize: 18, color: 'var(--accent-amber)' }}>
              {formatRupiah(order.totalPrice)}
            </strong>
            <button
              type="button"
              onClick={handleCopyNominal}
              style={{
                border: 'none',
                background: 'transparent',
                color: 'var(--text-primary)',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 4,
                fontSize: 12
              }}
            >
              <Copy size={14} />
              <span>{copied ? 'Tersalin' : 'Salin'}</span>
            </button>
          </div>

          <button
            type="button"
            className="btn-ios-primary"
            onClick={() => {
              playTapHaptic();
              onConfirmPaid(order.id);
            }}
          >
            <CheckCircle2 size={17} />
            <span>Saya Sudah Bayar</span>
          </button>
        </div>
      </div>
    </div>
  );
}
