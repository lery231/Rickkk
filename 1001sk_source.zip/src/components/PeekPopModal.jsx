import React from 'react';
import { Plus, Sparkles, X } from 'lucide-react';
import { DEFAULT_MENU_IMAGE, formatRupiah } from '../utils/constants.js';
import { isValidImageSrc } from '../utils/securityGuard.js';

export default function PeekPopModal({ item, isSeller, onAdd, onClose }) {
  if (!item) return null;
  const imgSrc = isValidImageSrc(item.image) ? item.image : DEFAULT_MENU_IMAGE;

  return (
    <div className="glass-modal-backdrop" onClick={onClose}>
      <div className="glass-sheet peek-pop-card" onClick={(e) => e.stopPropagation()}>
        <div className="peek-image-wrap">
          <img src={imgSrc} alt={item.name} className="peek-image" />
          <button className="icon-pill-btn floating-close" onClick={onClose} aria-label="Tutup">
            <X size={18} />
          </button>
          {item.featured && (
            <span className="glass-badge floating-badge">
              <Sparkles size={12} /> Pilihan Hari Ini
            </span>
          )}
        </div>

        <div style={{ padding: '18px 4px 6px' }}>
          <div className="row-between" style={{ alignItems: 'flex-start', gap: 12 }}>
            <div>
              <span className="muted-xs">{item.category}</span>
              <h3 style={{ margin: '4px 0 0', fontSize: 20 }}>{item.name}</h3>
            </div>
            <strong className="price-tag" style={{ fontSize: 18 }}>
              {formatRupiah(item.price)}
            </strong>
          </div>

          <p className="muted-sm" style={{ marginTop: 10, lineHeight: 1.5 }}>
            {item.desc || 'Racikan spesial 1001 SK dengan bahan baku pilihan.'}
          </p>

          {isSeller ? (
            <div className="seller-guard-banner" style={{ marginTop: 16 }}>
              Mode Penjual aktif — pemesanan dinonaktifkan untuk akun penjual.
            </div>
          ) : (
            <button
              className="glass-btn primary full-width"
              style={{ marginTop: 18 }}
              disabled={!item.available}
              onClick={() => {
                onAdd(item);
                onClose();
              }}
            >
              <Plus size={18} />
              <span>{item.available ? 'Tambah ke Keranjang' : 'Stok Habis'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
