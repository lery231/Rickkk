import React from 'react';
import { Coffee, ShoppingBag, ReceiptText, Store, UtensilsCrossed, QrCode } from 'lucide-react';
import { playTapHaptic } from '../utils/soundEffects.js';

export default function LiquidGlassTabBar({ activeTab, onChangeTab, cartCount, activeOrdersCount, isSeller }) {
  const tabs = isSeller
    ? [
        { id: 'home', label: 'Pesanan', icon: Store, badge: activeOrdersCount },
        { id: 'cart', label: 'Menu Toko', icon: UtensilsCrossed, badge: 0 },
        { id: 'orders', label: 'QRIS & Mutasi', icon: QrCode, badge: 0 }
      ]
    : [
        { id: 'home', label: 'Menu Kopi', icon: Coffee, badge: 0 },
        { id: 'cart', label: 'Keranjang', icon: ShoppingBag, badge: cartCount },
        { id: 'orders', label: 'Pesanan Saya', icon: ReceiptText, badge: activeOrdersCount }
      ];

  return (
    <nav className="convx-floating-dock" aria-label="Navigasi Utama">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            type="button"
            className={`convx-dock-btn ${isActive ? 'active' : ''}`}
            onClick={() => {
              playTapHaptic();
              onChangeTab(tab.id);
            }}
          >
            <div style={{ position: 'relative', display: 'inline-flex' }}>
              <Icon size={20} strokeWidth={isActive ? 2.4 : 1.9} />
              {tab.badge > 0 && (
                <span
                  style={{
                    position: 'absolute',
                    top: -5,
                    right: -10,
                    minWidth: 17,
                    height: 17,
                    padding: '0 4px',
                    borderRadius: 999,
                    background: '#ff375f',
                    color: '#fff',
                    fontSize: 10,
                    fontWeight: 800,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: '0 2px 8px rgba(255, 55, 95, 0.5)'
                  }}
                >
                  {tab.badge}
                </span>
              )}
            </div>
            <span>{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
