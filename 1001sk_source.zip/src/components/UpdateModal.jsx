import React, { useState } from 'react';
import { DownloadCloud, Sparkles, CheckCircle2, RefreshCw, ShieldAlert } from 'lucide-react';
import { CURRENT_APP_VERSION, executeAppUpdate } from '../utils/versionUtils';
import { triggerHaptic } from '../utils/soundEffects';

export default function UpdateModal({ isOpen, onClose, updateInfo, showToast }) {
  const [downloading, setDownloading] = useState(false);

  if (!isOpen || !updateInfo) return null;

  const isForce = Boolean(updateInfo.forceUpdate);

  const handleStartUpdate = async () => {
    triggerHaptic([20, 40, 20]);
    setDownloading(true);
    if (showToast) {
      showToast(
        updateInfo.apkUrl
          ? 'Membuka unduhan APK versi terbaru...'
          : 'Menyegarkan aplikasi ke versi terbaru...'
      );
    }

    try {
      await executeAppUpdate(updateInfo.apkUrl);
    } finally {
      setTimeout(() => {
        setDownloading(false);
        if (!isForce && onClose) onClose();
      }, 1500);
    }
  };

  return (
    <div
      className="ios-modal-overlay"
      style={{ zIndex: 3800 }}
      onClick={() => { if (!isForce && onClose) onClose(); }}
    >
      <div className="ios-modal-sheet" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-handle" />

        <div style={{ textAlign: 'center', marginBottom: 16 }}>
          <div
            style={{
              width: 54,
              height: 54,
              borderRadius: 18,
              background: 'var(--glass-pill-active)',
              border: '1px solid var(--accent-primary)',
              color: 'var(--accent-primary)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 12px',
            }}
          >
            <DownloadCloud size={26} />
          </div>

          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              padding: '4px 12px',
              borderRadius: 999,
              background: 'rgba(50, 215, 75, 0.16)',
              color: 'var(--accent-green)',
              fontSize: 11.5,
              fontWeight: 800,
              marginBottom: 8,
            }}
          >
            <Sparkles size={13} /> Pembaruan Tersedia
          </div>

          <h2 style={{ fontSize: 20, fontWeight: 800 }}>
            1001 SK v{updateInfo.latestVersion}
          </h2>
          <p style={{ fontSize: 12, color: 'var(--text-sub)', marginTop: 4 }}>
            Versi terpasang saat ini: <strong>v{CURRENT_APP_VERSION}</strong>
          </p>
        </div>

        <div className="glass-panel" style={{ padding: 15, marginBottom: 14 }}>
          <div style={{ fontSize: 12, fontWeight: 800, color: 'var(--accent-primary)', marginBottom: 6 }}>
            Catatan Pembaruan:
          </div>
          <div style={{ fontSize: 13, color: 'var(--text-main)', lineHeight: 1.5, whiteSpace: 'pre-line' }}>
            {updateInfo.changelog || '• Peningkatan performa dan stabilitas aplikasi\n• Perbaikan antarmuka & notifikasi pesanan'}
          </div>
        </div>

        {isForce && (
          <div
            style={{
              padding: 10,
              borderRadius: 12,
              background: 'rgba(255, 159, 10, 0.14)',
              border: '1px solid rgba(255, 159, 10, 0.35)',
              color: 'var(--accent-orange)',
              fontSize: 11.5,
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              marginBottom: 10,
            }}
          >
            <ShieldAlert size={16} style={{ flexShrink: 0 }} />
            <span>Pembaruan wajib diperlukan agar aplikasi tetap sinkron dengan server kasir.</span>
          </div>
        )}

        <button
          type="button"
          className="ios-btn-primary"
          disabled={downloading}
          onClick={handleStartUpdate}
        >
          {downloading ? (
            <><RefreshCw size={17} /> Memproses Pembaruan...</>
          ) : (
            <><CheckCircle2 size={17} /> Update Sekarang (v{updateInfo.latestVersion})</>
          )}
        </button>

        {!isForce && (
          <button type="button" className="ios-btn-secondary" onClick={onClose}>
            Nanti Saja
          </button>
        )}
      </div>
    </div>
  );
}
