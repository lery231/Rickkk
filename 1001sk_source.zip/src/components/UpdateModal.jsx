import React, { useState } from 'react';
import { CURRENT_APP_VERSION, executeAppUpdate } from '../utils/versionUtils';
import { useSheetSwipeDismiss } from '../hooks/useSheetSwipeDismiss';
import { DownloadCloud, X, Sparkles, RefreshCw } from 'lucide-react';

export default function UpdateModal({ isOpen, onClose, updateInfo, showToast }) {
  const [updating, setUpdating] = useState(false);

  const { sheetDragStyle, sheetSwipeHandlers } = useSheetSwipeDismiss({
    onClose,
    enabled: Boolean(isOpen && updateInfo && !updateInfo.forceUpdate),
  });

  if (!isOpen || !updateInfo) return null;

  const isForced = Boolean(updateInfo.forceUpdate);
  const hasApkLink = Boolean(updateInfo.apkUrl && updateInfo.apkUrl.trim().length > 0);

  const handleStartUpdate = async () => {
    setUpdating(true);
    if (showToast) {
      showToast(
        hasApkLink
          ? 'Membuka unduhan pembaruan APK terbaru...'
          : 'Memperbarui cache aplikasi ke versi terbaru...'
      );
    }
    try {
      await executeAppUpdate(updateInfo.apkUrl);
    } finally {
      setTimeout(() => setUpdating(false), 1800);
    }
  };

  return (
    <div
      className="ios-modal-overlay"
      style={{ zIndex: 90 }}
      onClick={() => {
        if (!isForced) onClose();
      }}
    >
      <div
        className="ios-modal-sheet"
        style={sheetDragStyle}
        {...sheetSwipeHandlers}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sheet-handle" />
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: 12,
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div
              style={{
                width: 40,
                height: 40,
                borderRadius: 12,
                background: 'var(--accent-primary)',
                color: '#ffffff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Sparkles size={20} />
            </div>
            <div>
              <h3 style={{ fontSize: 16.5, fontWeight: 800 }}>Pembaruan Tersedia</h3>
              <p style={{ fontSize: 12, color: 'var(--text-sub)' }}>
                v{CURRENT_APP_VERSION} → <strong>v{updateInfo.latestVersion}</strong>
              </p>
            </div>
          </div>

          {!isForced && (
            <button
              type="button"
              onClick={onClose}
              style={{
                background: 'none',
                border: 'none',
                color: 'var(--text-sub)',
                cursor: 'pointer',
              }}
            >
              <X size={20} />
            </button>
          )}
        </div>

        <div
          className="glass-panel"
          style={{
            background: 'var(--bg-grouped)',
            marginBottom: 14,
            padding: 12,
          }}
        >
          <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Yang Baru:</div>
          <p style={{ fontSize: 13, lineHeight: 1.45, color: 'var(--text-sub)' }}>
            {updateInfo.releaseNotes || 'Peningkatan performa dan tampilan iOS 26 Liquid Glass.'}
          </p>
        </div>

        <button
          type="button"
          className="ios-btn-primary"
          onClick={handleStartUpdate}
          disabled={updating}
        >
          {updating ? (
            <>
              <RefreshCw size={17} className="spin-slow" />
              <span>Memproses Pembaruan...</span>
            </>
          ) : (
            <>
              <DownloadCloud size={17} />
              <span>
                {hasApkLink
                  ? `Unduh & Update v${updateInfo.latestVersion}`
                  : `Perbarui Sekarang (v${updateInfo.latestVersion})`}
              </span>
            </>
          )}
        </button>

        {!isForced && (
          <button
            type="button"
            className="ios-btn-secondary"
            onClick={onClose}
            disabled={updating}
          >
            Nanti Saja
          </button>
        )}
      </div>
    </div>
  );
}
