import React, { useState } from 'react';
import { DownloadCloud, Sparkles, RefreshCw, ShieldAlert } from 'lucide-react';
import { CURRENT_APP_VERSION, executeAppUpdate } from '../utils/versionUtils';
import { triggerHaptic } from '../utils/soundEffects';

export default function UpdateModal({ isOpen, onClose, updateInfo, showToast }) {
  const [downloading, setDownloading] = useState(false);
  if (!isOpen || !updateInfo) return null;

  const isForce = Boolean(updateInfo.forceUpdate);

  const handleStartUpdate = async () => {
    triggerHaptic([20, 40, 20]);
    setDownloading(true);
    if (showToast) {
      showToast(
        updateInfo.apkUrl
          ? 'Membuka unduhan pembaruan APK...'
          : 'Memperbarui aplikasi ke versi terbaru...'
      );
    }
    try {
      await executeAppUpdate(updateInfo);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="modal-backdrop">
      <div className="glass-modal">
        <div className="modal-badge">
          {isForce ? <ShieldAlert size={16} /> : <Sparkles size={16} />}
          <span>Pembaruan v{updateInfo.latestVersion}</span>
        </div>
        <h3>Versi Baru Tersedia</h3>
        <p className="muted-text">
          Versi terpasang: v{CURRENT_APP_VERSION}. {updateInfo.notes || 'Perbaikan kecepatan realtime & notifikasi mengambang pesanan siap diambil.'}
        </p>
        <div className="modal-actions">
          {!isForce && (
            <button type="button" className="btn-secondary" onClick={onClose}>
              Nanti
            </button>
          )}
          <button
            type="button"
            className="btn-primary"
            onClick={handleStartUpdate}
            disabled={downloading}
          >
            {downloading ? <RefreshCw size={16} className="spin" /> : <DownloadCloud size={16} />}
            <span>{downloading ? 'Memproses...' : 'Perbarui Sekarang'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
