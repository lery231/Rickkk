import React, { useState } from 'react';
import { DownloadCloud, Sparkles, RefreshCw, ShieldAlert } from 'lucide-react';
import { CURRENT_APP_VERSION, executeAppUpdate } from '../utils/versionUtils';
import { triggerHaptic } from '../utils/soundEffects';

export default function UpdateModal({ isOpen, onClose, updateInfo, showToast }) {
  const [downloading, setDownloading] = useState(false);

  if (!isOpen || !updateInfo) return null;

  const isForce = Boolean(updateInfo.forceUpdate);

  const handleStartUpdate = async () => {
    triggerHaptic([20, 40, 20]);
    setDownloading(true);
    if (showToast) {
      showToast(
        updateInfo.apkUrl
          ? 'Membuka unduhan APK versi terbaru...'
          : 'Menyegarkan aplikasi ke versi terbaru...'
      );
    }
    try {
      await executeAppUpdate(updateInfo.apkUrl);
    } finally {
      setTimeout(() => {
        setDownloading(false);
        if (!isForce && onClose) onClose();
      }, 1500);
    }
  };

  return (
    <div
      className="ios-modal-overlay"
      onClick={() => {
        if (!isForce && onClose) onClose();
      }}
    >
      <div className="ios-modal-sheet" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-handle" />
        <div
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 6,
            padding: '5px 11px',
            borderRadius: 999,
            background: 'var(--glass-pill-active)',
            color: 'var(--accent-primary)',
            fontSize: 11.5,
            fontWeight: 800,
            marginBottom: 8,
          }}
        >
          <Sparkles size={14} /> Pembaruan Tersedia
        </div>

        <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 4 }}>
          1001 SK v{updateInfo.latestVersion}
        </h2>
        <p style={{ fontSize: 12.5, color: 'var(--text-sub)', marginBottom: 14 }}>
          Versi terpasang saat ini: <strong>v{CURRENT_APP_VERSION}</strong>
        </p>

        <div
          className="glass-panel"
          style={{
            padding: 14,
            marginBottom: 14,
            fontSize: 13,
            lineHeight: 1.5,
            whiteSpace: 'pre-line',
          }}
        >
          <div style={{ fontSize: 11.5, fontWeight: 800, color: 'var(--accent-primary)', marginBottom: 4 }}>
            Catatan Pembaruan:
          </div>
          {updateInfo.changelog ||
            '• Peningkatan performa dan stabilitas aplikasi\n• Perbaikan antarmuka & notifikasi pesanan'}
        </div>

        {isForce && (
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '10px 12px',
              borderRadius: 14,
              background: 'rgba(255, 69, 58, 0.14)',
              border: '1px solid rgba(255, 69, 58, 0.35)',
              color: 'var(--accent-red)',
              fontSize: 12,
              fontWeight: 700,
              marginBottom: 12,
            }}
          >
            <ShieldAlert size={16} />
            <span>Pembaruan wajib diperlukan agar aplikasi tetap sinkron dengan server kasir.</span>
          </div>
        )}

        <button
          type="button"
          className="ios-btn-primary"
          disabled={downloading}
          onClick={handleStartUpdate}
        >
          {downloading ? (
            <>
              <RefreshCw size={16} className="spin-slow" /> Memproses Pembaruan...
            </>
          ) : (
            <>
              <DownloadCloud size={16} /> Update Sekarang (v{updateInfo.latestVersion})
            </>
          )}
        </button>

        {!isForce && (
          <button type="button" className="ios-btn-secondary" onClick={onClose}>
            Nanti Saja
          </button>
        )}
      </div>
    </div>
  );
}
