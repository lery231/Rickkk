import React from 'react';
import { DownloadCloud, Sparkles, X } from 'lucide-react';
import { APP_VERSION } from '../utils/constants.js';
import { isValidHttpsUrl } from '../utils/securityGuard.js';

export default function UpdateModal({ updateInfo, onClose }) {
  if (!updateInfo) return null;
  const canDownload = isValidHttpsUrl(updateInfo.apkUrl);

  return (
    <div className="glass-modal-backdrop" onClick={() => !updateInfo.forceUpdate && onClose()}>
      <div className="glass-sheet" onClick={(e) => e.stopPropagation()} style={{ padding: '16px 20px 28px' }}>
        <div className="sheet-handle" />
        <div className="row-between" style={{ marginBottom: 12 }}>
          <div className="row-gap">
            <Sparkles size={18} />
            <strong>Pembaruan Tersedia</strong>
          </div>
          {!updateInfo.forceUpdate && (
            <button className="icon-pill-btn" onClick={onClose} aria-label="Tutup">
              <X size={18} />
            </button>
          )}
        </div>

        <h3 style={{ margin: '4px 0' }}>1001 SK v{updateInfo.latestVersion}</h3>
        <p className="muted-xs">Versi terpasang saat ini: v{APP_VERSION}</p>

        <p className="muted-sm" style={{ margin: '14px 0 18px', lineHeight: 1.5 }}>
          {updateInfo.releaseNotes || 'Pembaruan antarmuka Convx Refractive Liquid Glass, foto produk, & QRIS.'}
        </p>

        {canDownload ? (
          <a
            href={updateInfo.apkUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="glass-btn primary full-width"
            style={{ textDecoration: 'none' }}
          >
            <DownloadCloud size={18} />
            <span>Unduh APK Pembaruan</span>
          </a>
        ) : (
          <button className="glass-btn primary full-width" onClick={onClose}>
            Mengerti
          </button>
        )}
      </div>
    </div>
  );
}
