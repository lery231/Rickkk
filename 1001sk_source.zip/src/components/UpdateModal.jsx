import React from 'react';
import { DownloadCloud, Sparkles, X } from 'lucide-react';
import { APP_VERSION } from '../utils/constants.js';
import { isValidHttpsUrl } from '../utils/securityGuard.js';

export default function UpdateModal({ updateInfo, onClose }) {
  if (!updateInfo) return null;
  const canDownload = isValidHttpsUrl(updateInfo.apkUrl);

  return (
    <div
      className="sheet-backdrop"
      onClick={() => !updateInfo.forceUpdate && onClose()}
    >
      <div
        className="sheet-panel"
        onClick={(e) => e.stopPropagation()}
        style={{ padding: '0 20px 28px' }}
      >
        <div className="sheet-grabber" />
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginTop: 8,
            marginBottom: 14
          }}
        >
          <span
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              padding: '5px 12px',
              borderRadius: 999,
              background: 'var(--accent-soft)',
              color: 'var(--accent)',
              fontSize: 12,
              fontWeight: 800
            }}
          >
            <Sparkles size={14} /> Pembaruan Tersedia
          </span>
          {!updateInfo.forceUpdate && (
            <button
              type="button"
              onClick={onClose}
              style={{
                width: 32,
                height: 32,
                borderRadius: '50%',
                border: 'none',
                background: 'var(--bg-subtle)',
                color: 'var(--text-primary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer'
              }}
            >
              <X size={16} />
            </button>
          )}
        </div>

        <h3 style={{ fontSize: 21, fontWeight: 800 }}>1001 SK v{updateInfo.latestVersion}</h3>
        <div style={{ fontSize: 12.5, color: 'var(--text-secondary)', marginTop: 3 }}>
          Versi terpasang saat ini: v{APP_VERSION}
        </div>
        <p style={{ fontSize: 14, lineHeight: 1.5, color: 'var(--text-primary)', marginTop: 12, marginBottom: 18 }}>
          {updateInfo.releaseNotes || 'Pembaruan antarmuka Convx Refractive Liquid Glass, foto produk, & QRIS.'}
        </p>

        {canDownload ? (
          <a
            href={updateInfo.apkUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-ios-primary"
            style={{ textDecoration: 'none' }}
          >
            <DownloadCloud size={18} /> Unduh APK Pembaruan
          </a>
        ) : (
          <button type="button" className="btn-ios-primary" onClick={onClose}>
            Mengerti
          </button>
        )}
      </div>
    </div>
  );
}
