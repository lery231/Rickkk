import React, { useState, useEffect, useRef } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot, doc, updateDoc, addDoc, deleteDoc, setDoc, query, orderBy } from 'firebase/firestore';
import { compressAndConvertImage } from '../utils/imageCompressor';

export default function SellerView({ userRole }) {
  const [orders, setOrders] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [activeTab, setActiveTab] = useState('orders'); // 'orders' | 'menu' | 'qris'
  const [filterStatus, setFilterStatus] = useState('Semua');
  const [isAddMenuOpen, setIsAddMenuOpen] = useState(false);

  // New Menu State
  const [newMenuName, setNewMenuName] = useState('');
  const [newMenuCategory, setNewMenuCategory] = useState('Signature');
  const [newMenuPrice, setNewMenuPrice] = useState('');
  const [newMenuDesc, setNewMenuDesc] = useState('');
  const [productImgUrl, setProductImgUrl] = useState('');
  const [uploadingImg, setUploadingImg] = useState(false);

  // QRIS Settings State
  const [qrisImgUrl, setQrisImgUrl] = useState('');
  const [uploadingQris, setUploadingQris] = useState(false);

  const productFileInputRef = useRef(null);
  const qrisFileInputRef = useRef(null);

  useEffect(() => {
    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    const unsubOrders = onSnapshot(q, (snap) => {
      setOrders(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, () => {});

    const unsubMenu = onSnapshot(collection(db, 'menu'), (snap) => {
      setMenuItems(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, () => {});

    const unsubQris = onSnapshot(doc(db, 'settings', 'qris'), (docSnap) => {
      if (docSnap.exists()) {
        setQrisImgUrl(docSnap.data().qrisImage);
      }
    }, () => {});

    return () => {
      unsubOrders();
      unsubMenu();
      unsubQris();
    };
  }, []);

  const handleProductImageSelect = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingImg(true);
    try {
      const base64Img = await compressAndConvertImage(file, 600, 600, 0.75);
      setProductImgUrl(base64Img);
    } catch (err) {
      alert('Gagal memproses gambar: ' + err.message);
    } finally {
      setUploadingImg(false);
    }
  };

  const handleQrisImageSelect = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingQris(true);
    try {
      const base64Img = await compressAndConvertImage(file, 800, 800, 0.85);
      setQrisImgUrl(base64Img);
      // Save directly to Firestore settings/qris
      await setDoc(doc(db, 'settings', 'qris'), {
        qrisImage: base64Img,
        updatedAt: new Date().toISOString()
      });
      alert('Foto QRIS Toko berhasil diperbarui dan disimpan!');
    } catch (err) {
      alert('Gagal mengunggah QRIS: ' + err.message);
    } finally {
      setUploadingQris(false);
    }
  };

  const updateOrderStatus = async (orderId, newStatus) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), { status: newStatus });
    } catch (err) {
      alert('Gagal update status: ' + err.message);
    }
  };

  const handleAddMenu = async (e) => {
    e.preventDefault();
    if (!newMenuName || !newMenuPrice) return;
    try {
      await addDoc(collection(db, 'menu'), {
        name: newMenuName,
        category: newMenuCategory,
        price: parseInt(newMenuPrice, 10),
        desc: newMenuDesc || 'Menu Kopi Sehat & Fresh 1001 SK',
        img: productImgUrl || 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80',
        stock: true,
        createdAt: new Date().toISOString()
      });
      setIsAddMenuOpen(false);
      setNewMenuName('');
      setNewMenuPrice('');
      setNewMenuDesc('');
      setProductImgUrl('');
    } catch (err) {
      alert('Gagal tambah menu: ' + err.message);
    }
  };

  const handleDeleteMenu = async (id) => {
    if (window.confirm('Hapus menu ini dari daftar?')) {
      await deleteDoc(doc(db, 'menu', id));
    }
  };

  const totalOmset = orders
    .filter(o => o.status === 'selesai')
    .reduce((sum, o) => sum + (o.totalPrice || 0), 0);

  const filteredOrders = filterStatus === 'Semua' 
    ? orders 
    : orders.filter(o => o.status === filterStatus.toLowerCase());

  return (
    <div style={{ padding: 20 }}>
      {/* Analytics Summary */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
        <div className="glass-panel" style={{ padding: 16 }}>
          <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>Pendapatan (Selesai)</div>
          <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--accent-gold)', marginTop: 4 }}>
            Rp {totalOmset.toLocaleString('id-ID')}
          </div>
        </div>
        <div className="glass-panel" style={{ padding: 16 }}>
          <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>Pesanan Masuk</div>
          <div style={{ fontSize: 18, fontWeight: 800, color: '#fff', marginTop: 4 }}>
            {orders.filter(o => o.status === 'pending').length} Pesanan
          </div>
        </div>
      </div>

      {/* Mode Navigation Tabs */}
      <div className="ios-tabs" style={{ paddingLeft: 0, paddingRight: 0, marginBottom: 16 }}>
        <button className={`tab-btn ${activeTab === 'orders' ? 'active' : ''}`} onClick={() => setActiveTab('orders')}>
          📋 Pesanan ({orders.length})
        </button>
        <button className={`tab-btn ${activeTab === 'menu' ? 'active' : ''}`} onClick={() => setActiveTab('menu')}>
          ☕ Kelola Menu
        </button>
        <button className={`tab-btn ${activeTab === 'qris' ? 'active' : ''}`} onClick={() => setActiveTab('qris')}>
          📱 Set QRIS Toko
        </button>
      </div>

      {/* ORDERS TAB */}
      {activeTab === 'orders' && (
        <div>
          <div className="ios-tabs" style={{ paddingLeft: 0, marginBottom: 14 }}>
            {['Semua', 'Pending', 'Diproses', 'Siap', 'Selesai'].map(st => (
              <button key={st} className={`tab-btn ${filterStatus === st ? 'active' : ''}`} onClick={() => setFilterStatus(st)}>
                {st}
              </button>
            ))}
          </div>

          {filteredOrders.length === 0 ? (
            <div className="glass-panel" style={{ padding: 24, textAlign: 'center', color: 'var(--text-sub)' }}>
              Tidak ada pesanan pada kategori ini.
            </div>
          ) : (
            filteredOrders.map(ord => (
              <div key={ord.id} className="glass-panel" style={{ padding: 16, marginBottom: 14 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <div>
                    <div style={{ fontSize: 16, fontWeight: 800, color: '#fff' }}>{ord.customerName}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>
                      Tipe: {ord.orderType} • {ord.tableNo} • {ord.paymentMethod}
                    </div>
                  </div>
                  <span className={`badge-status status-${ord.status}`}>{ord.status}</span>
                </div>

                <div style={{ borderTop: '1px solid var(--glass-border)', borderBottom: '1px solid var(--glass-border)', padding: '8px 0', margin: '8px 0' }}>
                  {ord.items?.map((it, i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, margin: '2px 0' }}>
                      <span>{it.qty}x {it.name}</span>
                      <span>Rp {(it.price * it.qty).toLocaleString('id-ID')}</span>
                    </div>
                  ))}
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, marginTop: 6, color: 'var(--accent-gold)' }}>
                    <span>Total:</span>
                    <span>Rp {ord.totalPrice?.toLocaleString('id-ID')}</span>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                  {ord.status === 'pending' && (
                    <button className="ios-btn-primary" style={{ padding: '8px 12px', fontSize: 12, marginTop: 0 }} onClick={() => updateOrderStatus(ord.id, 'diproses')}>
                      &rarr; Terima & Proses
                    </button>
                  )}
                  {ord.status === 'diproses' && (
                    <button className="ios-btn-primary" style={{ padding: '8px 12px', fontSize: 12, marginTop: 0, background: 'linear-gradient(135deg, #0a84ff, #30b0c7)' }} onClick={() => updateOrderStatus(ord.id, 'siap')}>
                      &rarr; Tandai Siap Diambil
                    </button>
                  )}
                  {ord.status === 'siap' && (
                    <button className="ios-btn-primary" style={{ padding: '8px 12px', fontSize: 12, marginTop: 0, background: 'linear-gradient(135deg, #34c759, #30d158)' }} onClick={() => updateOrderStatus(ord.id, 'selesai')}>
                      ✓ Selesai
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* MENU MANAGMENT TAB */}
      {activeTab === 'menu' && (
        <div>
          <button className="ios-btn-primary" style={{ marginBottom: 16 }} onClick={() => setIsAddMenuOpen(true)}>
            + Tambah Menu Baru (Dengan Foto Galeri)
          </button>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {menuItems.map(item => (
              <div key={item.id} className="glass-panel" style={{ padding: 14, display: 'flex', gap: 12, alignItems: 'center' }}>
                <img src={item.img} alt={item.name} style={{ width: 60, height: 60, borderRadius: 12, objectFit: 'cover' }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 15, color: '#fff' }}>{item.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--accent-gold)' }}>Rp {item.price?.toLocaleString('id-ID')} ({item.category})</div>
                </div>
                <button className="tab-btn" style={{ borderColor: 'var(--accent-red)', color: 'var(--accent-red)' }} onClick={() => handleDeleteMenu(item.id)}>
                  Hapus
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SET QRIS TAB */}
      {activeTab === 'qris' && (
        <div className="glass-panel" style={{ padding: 20 }}>
          <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 8 }}>Pengaturan QRIS Pembayaran Toko</h3>
          <p style={{ fontSize: 12, color: 'var(--text-sub)', marginBottom: 16 }}>
            Unggah foto barcode QRIS (BCA, DANA, GoPay, OVO, dll) dari galeri HP Anda. Barcode ini akan muncul otomatis saat pembeli memilih metode QRIS.
          </p>

          <input 
            type="file" 
            accept="image/*" 
            ref={qrisFileInputRef} 
            style={{ display: 'none' }} 
            onChange={handleQrisImageSelect} 
          />

          <div className="image-picker-box" onClick={() => qrisFileInputRef.current?.click()}>
            {uploadingQris ? (
              <div style={{ padding: 20, color: 'var(--accent-gold)' }}>Memproses foto QRIS...</div>
            ) : qrisImgUrl ? (
              <div>
                <div className="qris-display-box" style={{ margin: '0 auto 10px', maxWidth: 260 }}>
                  <img src={qrisImgUrl} alt="QRIS Toko" />
                </div>
                <button className="tab-btn" style={{ borderColor: 'var(--accent-gold)', color: 'var(--accent-gold)' }}>
                  📷 Ganti Gambar QRIS dari Galeri
                </button>
              </div>
            ) : (
              <div style={{ padding: '24px 10px' }}>
                <div style={{ fontSize: 32, marginBottom: 8 }}>🖼️</div>
                <div style={{ fontWeight: 700, fontSize: 14 }}>Pilih Foto QRIS dari Galeri HP</div>
                <div style={{ fontSize: 11, color: 'var(--text-sub)', marginTop: 4 }}>Format JPG / PNG / WEBP</div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add Menu Modal Sheet */}
      {isAddMenuOpen && (
        <div className="ios-modal-overlay" onClick={() => setIsAddMenuOpen(false)}>
          <div className="ios-modal-sheet" onClick={e => e.stopPropagation()}>
            <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 16 }}>Tambah Menu Kopi 1001 SK</h3>
            <form onSubmit={handleAddMenu}>
              
              {/* Product Image Gallery Picker */}
              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)' }}>Foto Produk (Dari Galeri HP)</label>
                <input 
                  type="file" 
                  accept="image/*" 
                  ref={productFileInputRef} 
                  style={{ display: 'none' }} 
                  onChange={handleProductImageSelect} 
                />

                {uploadingImg ? (
                  <div className="image-picker-box" style={{ padding: 20, color: 'var(--accent-gold)' }}>
                    Memproses & mengoptimalkan gambar...
                  </div>
                ) : productImgUrl ? (
                  <div className="preview-img-container" onClick={() => productFileInputRef.current?.click()}>
                    <img src={productImgUrl} alt="Preview Produk" />
                    <div style={{ position: 'absolute', bottom: 8, right: 8, background: 'rgba(0,0,0,0.7)', padding: '4px 10px', borderRadius: 8, fontSize: 11, color: '#fff' }}>
                      Ganti Foto
                    </div>
                  </div>
                ) : (
                  <div className="image-picker-box" onClick={() => productFileInputRef.current?.click()}>
                    <span style={{ fontSize: 24 }}>📷</span>
                    <div style={{ fontWeight: 600, fontSize: 13, marginTop: 4 }}>Ketuk untuk Ambil Foto dari Galeri</div>
                  </div>
                )}
              </div>

              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)' }}>Nama Menu</label>
                <input type="text" className="ios-input" value={newMenuName} onChange={e => setNewMenuName(e.target.value)} placeholder="Contoh: Kopi Susu Aren" required />
              </div>
              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)' }}>Kategori</label>
                <select className="ios-input" value={newMenuCategory} onChange={e => setNewMenuCategory(e.target.value)}>
                  <option value="Signature">Signature 1001 SK</option>
                  <option value="Espresso">Espresso Base</option>
                  <option value="Non-Kopi">Non-Kopi</option>
                  <option value="Camilan">Camilan / Makanan</option>
                </select>
              </div>
              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)' }}>Harga (Rp)</label>
                <input type="number" className="ios-input" value={newMenuPrice} onChange={e => setNewMenuPrice(e.target.value)} placeholder="18000" required />
              </div>
              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)' }}>Deskripsi Singkat</label>
                <input type="text" className="ios-input" value={newMenuDesc} onChange={e => setNewMenuDesc(e.target.value)} placeholder="Deskripsi rasa & komposisi..." />
              </div>
              <button type="submit" className="ios-btn-primary">Simpan Menu Baru</button>
              <button type="button" className="ios-btn-secondary" onClick={() => setIsAddMenuOpen(false)}>Batal</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
