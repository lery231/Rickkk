import React, { useState, useEffect, useRef } from 'react';
import { db, FIREBASE_PROJECT_ID } from '../firebase';
import {
  collection,
  onSnapshot,
  doc,
  updateDoc,
  addDoc,
  deleteDoc,
  setDoc,
} from 'firebase/firestore';
import { compressAndConvertImage } from '../utils/imageCompressor';
import {
  Plus,
  Trash2,
  Camera,
  CheckCircle2,
  ArrowRight,
  Volume2,
  ShieldCheck,
  Store,
  X,
  Send,
  Copy,
  Zap,
} from 'lucide-react';
import { playNewOrderChime, triggerHaptic } from '../utils/soundEffects';
import { DEFAULT_CATEGORIES, FALLBACK_COFFEE_IMG } from '../utils/constants';
import { CURRENT_APP_VERSION, normalizeApkDownloadUrl } from '../utils/versionUtils';
import { QRIS_WEBHOOK_SECRET } from '../utils/qrisAutoMatcher';
import { sanitizeText, sanitizeImageUrl } from '../utils/securityGuard';

export default function SellerView({
  orders,
  sellerSubTab,
  setSellerSubTab,
  showToast,
  storeOpen,
}) {
  const [menuItems, setMenuItems] = useState([]);
  const [filterStatus, setFilterStatus] = useState('Semua');
  const [isAddMenuOpen, setIsAddMenuOpen] = useState(false);

  const [categories, setCategories] = useState(DEFAULT_CATEGORIES);
  const [newCatName, setNewCatName] = useState('');

  const [newMenuName, setNewMenuName] = useState('');
  const [newMenuCategory, setNewMenuCategory] = useState('Signature');
  const [newMenuPrice, setNewMenuPrice] = useState('');
  const [newMenuDesc, setNewMenuDesc] = useState('');
  const [productImgUrl, setProductImgUrl] = useState('');
  const [uploadingImg, setUploadingImg] = useState(false);

  const [qrisImgUrl, setQrisImgUrl] = useState('');
  const [uploadingQris, setUploadingQris] = useState(false);
  const [simulatingPayment, setSimulatingPayment] = useState(false);

  const [releaseVersion, setReleaseVersion] = useState(CURRENT_APP_VERSION);
  const [releaseApkUrl, setReleaseApkUrl] = useState('');
  const [releaseChangelog, setReleaseChangelog] = useState(
    '• Tampilan Liquid Glass terbaru dengan foto produk & QRIS otomatis\n• Peningkatan kecepatan sinkronisasi & notifikasi pesanan siap ambil'
  );
  const [releaseForce, setReleaseForce] = useState(false);
  const [publishingUpdate, setPublishingUpdate] = useState(false);

  const productFileInputRef = useRef(null);
  const qrisFileInputRef = useRef(null);

  const webhookUrl = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/(default)/documents/qris_payments`;
  const macrodroidJsonBody = JSON.stringify(
    {
      fields: {
        secret: { stringValue: QRIS_WEBHOOK_SECRET },
        rawText: { stringValue: '{notif_title} {notif_text}' },
        matched: { booleanValue: false },
      },
    },
    null,
    2
  );

  useEffect(() => {
    const unsubMenu = onSnapshot(
      collection(db, 'menu'),
      (snap) => {
        setMenuItems(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      },
      () => {}
    );

    const unsubQris = onSnapshot(
      doc(db, 'settings', 'qris'),
      (docSnap) => {
        if (docSnap.exists()) {
          setQrisImgUrl(docSnap.data().qrisImage || '');
        }
      },
      () => {}
    );

    const unsubCat = onSnapshot(
      doc(db, 'settings', 'categories'),
      (snap) => {
        const list = snap.exists() ? snap.data().list : null;
        if (Array.isArray(list)) setCategories(list);
      },
      () => {}
    );

    const unsubAppInfo = onSnapshot(
      doc(db, 'settings', 'app_info'),
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (data.latestVersion) setReleaseVersion(data.latestVersion);
          if (data.apkUrl) setReleaseApkUrl(data.apkUrl);
          if (data.changelog) setReleaseChangelog(data.changelog);
          setReleaseForce(Boolean(data.forceUpdate));
        }
      },
      () => {}
    );

    return () => {
      unsubQris();
      unsubMenu();
      unsubCat();
      unsubAppInfo();
    };
  }, []);

  const handleProductImageSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingImg(true);
    try {
      const base64Img = await compressAndConvertImage(file, 600, 600, 0.75);
      setProductImgUrl(base64Img);
      if (showToast) showToast('Foto produk siap digunakan');
    } catch (err) {
      if (showToast) showToast('Gagal memproses gambar: ' + err.message);
    } finally {
      setUploadingImg(false);
    }
  };

  const handleQrisImageSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingQris(true);
    try {
      const base64Img = await compressAndConvertImage(file, 800, 800, 0.85);
      setQrisImgUrl(base64Img);
      await setDoc(doc(db, 'settings', 'qris'), {
        qrisImage: base64Img,
        updatedAt: new Date().toISOString(),
      });
      triggerHaptic(20);
      if (showToast) showToast('Barcode QRIS Toko berhasil diperbarui!');
    } catch (err) {
      if (showToast) showToast('Gagal mengunggah QRIS: ' + err.message);
    } finally {
      setUploadingQris(false);
    }
  };

  const handleCopyText = async (text, label) => {
    triggerHaptic(12);
    try {
      await navigator.clipboard.writeText(text);
      if (showToast) showToast(`${label} berhasil disalin!`);
    } catch {
      if (showToast) showToast('Gagal menyalin otomatis, silakan blok & salin teks.');
    }
  };

  const handleSimulateIncomingQris = async () => {
    const awaiting = orders.find((o) => o.status === 'menunggu_pembayaran');
    if (!awaiting) {
      if (showToast) showToast('Buat 1 pesanan QRIS dari akun pembeli dulu untuk menguji.');
      return;
    }
    setSimulatingPayment(true);
    triggerHaptic(18);
    try {
      await addDoc(collection(db, 'qris_payments'), {
        secret: QRIS_WEBHOOK_SECRET,
        rawText: `Simulasi QRIS Diterima Rp ${Number(awaiting.totalPrice).toLocaleString('id-ID')}`,
        matched: false,
        createdAt: new Date().toISOString(),
      });
      if (showToast) {
        showToast(`Simulasi notifikasi Rp ${Number(awaiting.totalPrice).toLocaleString('id-ID')} dikirim!`);
      }
    } catch (err) {
      if (showToast) showToast('Gagal simulasi: ' + err.message);
    } finally {
      setSimulatingPayment(false);
    }
  };

  const handlePublishAppUpdate = async (e) => {
    e.preventDefault();
    if (!releaseVersion.trim()) return;
    setPublishingUpdate(true);
    triggerHaptic(20);
    try {
      const cleanVer = sanitizeText(releaseVersion.replace(/^v/i, ''), 20);
      await setDoc(doc(db, 'settings', 'app_info'), {
        latestVersion: cleanVer,
        apkUrl: normalizeApkDownloadUrl(releaseApkUrl),
        changelog: releaseChangelog.trim().slice(0, 1000),
        forceUpdate: releaseForce,
        updatedAt: new Date().toISOString(),
      });
      if (showToast) showToast(`Rilis v${cleanVer} berhasil dikirim ke seluruh pengguna!`);
    } catch (err) {
      if (showToast) showToast('Gagal mempublikasikan update: ' + err.message);
    } finally {
      setPublishingUpdate(false);
    }
  };

  const updateOrderStatus = async (orderId, newStatus, extraFields = {}) => {
    triggerHaptic(16);
    try {
      await updateDoc(doc(db, 'orders', orderId), { status: newStatus, ...extraFields });
      if (showToast) {
        if (newStatus === 'siap') {
          showToast('Status SIAP DIAMBIL — Notifikasi dikirim ke pembeli!');
        } else if (extraFields.paymentStatus === 'paid') {
          showToast('Pembayaran QRIS dikonfirmasi lunas — Masuk antrean!');
        } else {
          showToast(`Status pesanan diubah ke ${newStatus.toUpperCase()}`);
        }
      }
    } catch (err) {
      if (showToast) showToast('Gagal update status: ' + err.message);
    }
  };

  const handleDeleteOrder = async (orderId) => {
    triggerHaptic(15);
    try {
      await deleteDoc(doc(db, 'orders', orderId));
      if (showToast) showToast('Riwayat pesanan dihapus');
    } catch (err) {
      if (showToast) showToast('Gagal menghapus pesanan: ' + err.message);
    }
  };

  const handleClearSelesai = async () => {
    const selesaiList = orders.filter((o) => o.status === 'selesai');
    if (selesaiList.length === 0) {
      if (showToast) showToast('Tidak ada pesanan selesai untuk dihapus');
      return;
    }
    triggerHaptic(18);
    try {
      await Promise.all(selesaiList.map((o) => deleteDoc(doc(db, 'orders', o.id))));
      if (showToast) showToast(`${selesaiList.length} riwayat pesanan selesai dihapus`);
    } catch (err) {
      if (showToast) showToast('Gagal menghapus riwayat: ' + err.message);
    }
  };

  const handleAddMenu = async (e) => {
    e.preventDefault();
    const cleanName = sanitizeText(newMenuName, 60);
    if (!cleanName || !newMenuPrice) return;
    triggerHaptic(16);
    try {
      await addDoc(collection(db, 'menu'), {
        name: cleanName,
        category: newMenuCategory,
        price: Math.max(0, parseInt(newMenuPrice, 10) || 0),
        desc: sanitizeText(newMenuDesc, 160) || 'Racikan Kopi Spesial 1001 SK',
        img:
          productImgUrl ||
          'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80',
        stock: true,
        createdAt: new Date().toISOString(),
      });
      if (showToast) showToast('Menu baru berhasil ditambahkan!');
      setIsAddMenuOpen(false);
      setNewMenuName('');
      setNewMenuPrice('');
      setNewMenuDesc('');
      setProductImgUrl('');
    } catch (err) {
      if (showToast) showToast('Gagal menambah menu: ' + err.message);
    }
  };

  const handleDeleteMenu = async (id) => {
    triggerHaptic(15);
    await deleteDoc(doc(db, 'menu', id));
    if (showToast) showToast('Menu berhasil dihapus');
  };

  const toggleStore = async () => {
    triggerHaptic(18);
    try {
      await setDoc(
        doc(db, 'settings', 'store'),
        { open: !storeOpen, updatedAt: new Date().toISOString() },
        { merge: true }
      );
      if (showToast) {
        showToast(
          !storeOpen
            ? 'Toko dibuka — pembeli bisa memesan'
            : 'Toko ditutup — pesanan baru dinonaktifkan'
        );
      }
    } catch (err) {
      if (showToast) showToast('Gagal mengubah status toko: ' + err.message);
    }
  };

  const toggleStock = async (item) => {
    triggerHaptic(14);
    const nextStock = item.stock === false;
    try {
      await updateDoc(doc(db, 'menu', item.id), { stock: nextStock });
      if (showToast) {
        showToast(nextStock ? `${item.name} tersedia lagi` : `${item.name} ditandai habis`);
      }
    } catch (err) {
      if (showToast) showToast('Gagal mengubah stok: ' + err.message);
    }
  };

  const saveCategories = async (list) => {
    try {
      await setDoc(doc(db, 'settings', 'categories'), {
        list,
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      if (showToast) showToast('Gagal menyimpan kategori: ' + err.message);
    }
  };

  const handleAddCategory = async () => {
    const name = sanitizeText(newCatName, 32);
    if (!name) return;
    if (categories.some((c) => c.toLowerCase() === name.toLowerCase())) {
      if (showToast) showToast('Kategori sudah ada');
      return;
    }
    triggerHaptic(14);
    setNewCatName('');
    await saveCategories([...categories, name]);
    if (showToast) showToast(`Kategori "${name}" ditambahkan`);
  };

  const handleDeleteCategory = async (name) => {
    const used = menuItems.filter((m) => m.category === name).length;
    if (used > 0) {
      if (showToast) {
        showToast(`Masih ada ${used} menu di kategori ${name}. Pindahkan/hapus menunya dulu.`);
      }
      return;
    }
    triggerHaptic(15);
    await saveCategories(categories.filter((c) => c !== name));
    if (showToast) showToast(`Kategori "${name}" dihapus`);
  };

  useEffect(() => {
    if (categories.length > 0 && !categories.includes(newMenuCategory)) {
      setNewMenuCategory(categories[0]);
    }
  }, [categories, newMenuCategory]);

  const totalOmset = orders
    .filter((o) => o.status === 'selesai')
    .reduce((sum, o) => sum + (o.totalPrice || 0), 0);

  const filteredOrders =
    filterStatus === 'Semua'
      ? orders
      : filterStatus === 'Belum Bayar'
      ? orders.filter((o) => o.status === 'menunggu_pembayaran')
      : orders.filter((o) => o.status === filterStatus.toLowerCase());

  return (
    <div className="page-transition" style={{ padding: '14px 18px' }}>
      {/* Seller Mode Notice Banner */}
      <div
        className="glass-panel"
        style={{
          padding: '10px 14px',
          marginBottom: 12,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 8,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 12, fontWeight: 800 }}>
          <ShieldCheck size={16} color="var(--accent-green)" />
          <span>Mode Kasir Seller • QRIS Otomatis Aktif</span>
        </div>
        <button
          type="button"
          onClick={() => {
            playNewOrderChime();
            if (showToast) showToast('Tes nada pesanan masuk berbunyi!');
          }}
          style={{
            background: 'var(--glass-pill)',
            border: '1px solid var(--glass-border)',
            color: 'var(--text-main)',
            borderRadius: 10,
            padding: '5px 9px',
            fontSize: 11,
            fontWeight: 700,
            display: 'flex',
            alignItems: 'center',
            gap: 4,
            cursor: 'pointer',
          }}
        >
          <Volume2 size={13} /> Tes Nada
        </button>
      </div>

      {/* Status Buka / Tutup Toko */}
      <div
        className="glass-panel"
        style={{
          padding: '12px 15px',
          marginBottom: 12,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 10,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Store size={20} color={storeOpen ? 'var(--accent-green)' : 'var(--accent-red)'} />
          <div>
            <div style={{ fontSize: 13.5, fontWeight: 800 }}>
              Toko {storeOpen ? 'Buka' : 'Tutup'}
            </div>
            <div style={{ fontSize: 11.5, color: 'var(--text-sub)' }}>
              {storeOpen ? 'Pembeli bisa memesan' : 'Pesanan baru dinonaktifkan'}
            </div>
          </div>
        </div>
        <button
          type="button"
          onClick={toggleStore}
          style={{
            padding: '8px 13px',
            borderRadius: 12,
            border: 'none',
            fontWeight: 800,
            fontSize: 12,
            cursor: 'pointer',
            background: storeOpen ? 'rgba(255, 69, 58, 0.16)' : 'rgba(50, 215, 75, 0.2)',
            color: storeOpen ? 'var(--accent-red)' : 'var(--accent-green)',
          }}
        >
          {storeOpen ? 'Tutup Toko' : 'Buka Toko'}
        </button>
      </div>

      {/* Summary Stats */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 10,
          marginBottom: 12,
        }}
      >
        <div className="glass-panel" style={{ padding: 14 }}>
          <div style={{ fontSize: 11.5, color: 'var(--text-sub)', fontWeight: 700 }}>
            Omset Selesai
          </div>
          <div style={{ fontSize: 16, fontWeight: 800, color: 'var(--accent-primary)', marginTop: 3 }}>
            Rp {totalOmset.toLocaleString('id-ID')}
          </div>
        </div>
        <div className="glass-panel" style={{ padding: 14 }}>
          <div style={{ fontSize: 11.5, color: 'var(--text-sub)', fontWeight: 700 }}>
            Antrean Masuk
          </div>
          <div style={{ fontSize: 16, fontWeight: 800, color: 'var(--accent-green)', marginTop: 3 }}>
            {orders.filter((o) => o.status === 'pending').length} Pesanan
          </div>
        </div>
      </div>

      {/* Sub-Tabs */}
      <div className="ios-tabs" style={{ padding: '4px 0 12px' }} data-no-swipe="true">
        <button
          type="button"
          className={`tab-btn ${sellerSubTab === 'orders' ? 'active' : ''}`}
          onClick={() => setSellerSubTab('orders')}
        >
          Pesanan ({orders.length})
        </button>
        <button
          type="button"
          className={`tab-btn ${sellerSubTab === 'menu' ? 'active' : ''}`}
          onClick={() => setSellerSubTab('menu')}
        >
          Kelola Menu
        </button>
        <button
          type="button"
          className={`tab-btn ${sellerSubTab === 'qris' ? 'active' : ''}`}
          onClick={() => setSellerSubTab('qris')}
        >
          Set QRIS Toko
        </button>
        <button
          type="button"
          className={`tab-btn ${sellerSubTab === 'update' ? 'active' : ''}`}
          onClick={() => setSellerSubTab('update')}
        >
          Rilis Update
        </button>
      </div>

      {/* SUB-TAB 1: PESANAN */}
      {sellerSubTab === 'orders' && (
        <>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: 8,
              marginBottom: 10,
            }}
          >
            <div className="ios-tabs" style={{ padding: 0, flex: 1 }} data-no-swipe="true">
              {['Semua', 'Belum Bayar', 'Pending', 'Diproses', 'Siap', 'Selesai'].map((st) => (
                <button
                  key={st}
                  type="button"
                  className={`tab-btn ${filterStatus === st ? 'active' : ''}`}
                  onClick={() => setFilterStatus(st)}
                >
                  {st}
                </button>
              ))}
            </div>
            {orders.some((o) => o.status === 'selesai') && (
              <button type="button" className="delete-icon-btn" onClick={handleClearSelesai}>
                <Trash2 size={13} /> Hapus Selesai
              </button>
            )}
          </div>

          {filteredOrders.length === 0 ? (
            <div className="glass-panel" style={{ padding: 22, textAlign: 'center', color: 'var(--text-sub)' }}>
              Tidak ada pesanan pada kategori ini.
            </div>
          ) : (
            filteredOrders.map((ord) => {
              const isUnpaidQris = ord.status === 'menunggu_pembayaran';
              return (
                <div key={ord.id} className="glass-panel" style={{ padding: 15, marginBottom: 12 }}>
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'flex-start',
                      gap: 8,
                      marginBottom: 8,
                    }}
                  >
                    <div>
                      <div style={{ fontSize: 15, fontWeight: 800 }}>{ord.customerName}</div>
                      <div style={{ fontSize: 11.5, color: 'var(--text-sub)' }}>
                        {ord.orderType} • {ord.paymentMethod}
                        {ord.paymentStatus === 'paid' && (
                          <span style={{ color: 'var(--accent-green)', fontWeight: 800 }}>
                            {' '}
                            • LUNAS OTOMATIS
                          </span>
                        )}
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span className={`badge-status status-${ord.status}`}>
                        {isUnpaidQris ? 'Belum Bayar' : ord.status}
                      </span>
                      <button
                        type="button"
                        className="delete-icon-btn"
                        onClick={() => handleDeleteOrder(ord.id)}
                        title="Hapus riwayat pesanan"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>

                  {ord.orderNote && (
                    <div
                      style={{
                        fontSize: 11.5,
                        color: 'var(--text-sub)',
                        background: 'var(--glass-pill)',
                        padding: '6px 10px',
                        borderRadius: 10,
                        marginBottom: 8,
                      }}
                    >
                      Catatan: {ord.orderNote}
                    </div>
                  )}

                  {ord.items?.map((it, i) => (
                    <div
                      key={i}
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        fontSize: 12.5,
                        marginBottom: 4,
                      }}
                    >
                      <span>
                        {it.qty}x {it.name}
                      </span>
                      <span style={{ color: 'var(--text-sub)' }}>
                        Rp {(it.price * it.qty).toLocaleString('id-ID')}
                      </span>
                    </div>
                  ))}

                  {ord.uniqueCode && (
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        fontSize: 12,
                        color: 'var(--accent-orange)',
                        fontWeight: 700,
                      }}
                    >
                      <span>Kode Unik QRIS</span>
                      <span>+Rp {ord.uniqueCode}</span>
                    </div>
                  )}

                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      fontWeight: 800,
                      fontSize: 13.5,
                      borderTop: '1px solid var(--glass-border)',
                      marginTop: 8,
                      paddingTop: 8,
                    }}
                  >
                    <span>Total Tagihan</span>
                    <span style={{ color: 'var(--accent-primary)' }}>
                      Rp {Number(ord.totalPrice || 0).toLocaleString('id-ID')}
                    </span>
                  </div>

                  {isUnpaidQris && (
                    <button
                      type="button"
                      className="ios-btn-primary"
                      onClick={() =>
                        updateOrderStatus(ord.id, 'pending', {
                          paymentStatus: 'paid',
                          paidAt: new Date().toISOString(),
                        })
                      }
                    >
                      <CheckCircle2 size={16} /> Konfirmasi Lunas Manual
                    </button>
                  )}
                  {ord.status === 'pending' && (
                    <button
                      type="button"
                      className="ios-btn-primary"
                      onClick={() => updateOrderStatus(ord.id, 'diproses')}
                    >
                      Terima & Proses <ArrowRight size={16} />
                    </button>
                  )}
                  {ord.status === 'diproses' && (
                    <button
                      type="button"
                      className="ios-btn-primary"
                      style={{ background: 'var(--accent-green)', color: '#08170c' }}
                      onClick={() => updateOrderStatus(ord.id, 'siap')}
                    >
                      <CheckCircle2 size={16} /> Tandai Siap Diambil
                    </button>
                  )}
                  {(ord.status === 'siap' || ord.status === 'siap_diambil') && (
                    <button
                      type="button"
                      className="ios-btn-secondary"
                      onClick={() => updateOrderStatus(ord.id, 'selesai')}
                    >
                      Selesaikan Pesanan
                    </button>
                  )}
                </div>
              );
            })
          )}
        </>
      )}

      {/* SUB-TAB 2: KELOLA MENU + FOTO PRODUK */}
      {sellerSubTab === 'menu' && (
        <>
          <div className="glass-panel" style={{ padding: 15, marginBottom: 12 }}>
            <div style={{ fontSize: 13.5, fontWeight: 800, marginBottom: 8 }}>Kategori Menu</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7, marginBottom: 10 }}>
              {categories.length === 0 && (
                <span style={{ fontSize: 12, color: 'var(--text-sub)' }}>Belum ada kategori.</span>
              )}
              {categories.map((c) => (
                <span key={c} className="cat-chip">
                  {c}
                  <button
                    type="button"
                    onClick={() => handleDeleteCategory(c)}
                    aria-label={`Hapus kategori ${c}`}
                  >
                    <X size={13} />
                  </button>
                </span>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                type="text"
                className="ios-input"
                style={{ marginTop: 0 }}
                value={newCatName}
                onChange={(e) => setNewCatName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddCategory();
                  }
                }}
                placeholder="Nama kategori baru"
              />
              <button
                type="button"
                className="ios-btn-primary"
                style={{ width: 'auto', marginTop: 0, whiteSpace: 'nowrap' }}
                onClick={handleAddCategory}
              >
                Tambah
              </button>
            </div>
          </div>

          <button
            type="button"
            className="ios-btn-primary"
            style={{ marginTop: 0, marginBottom: 14 }}
            onClick={() => setIsAddMenuOpen(true)}
          >
            <Plus size={17} /> Tambah Menu Baru (Galeri HP)
          </button>

          {menuItems.map((item) => (
            <div
              key={item.id}
              className="glass-panel"
              style={{
                padding: 12,
                marginBottom: 10,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: 10,
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 11, minWidth: 0 }}>
                <img
                  src={sanitizeImageUrl(item.img, FALLBACK_COFFEE_IMG)}
                  alt={item.name}
                  style={{
                    width: 52,
                    height: 52,
                    borderRadius: 13,
                    objectFit: 'cover',
                    flexShrink: 0,
                  }}
                  onError={(e) => {
                    e.currentTarget.onerror = null;
                    e.currentTarget.src = FALLBACK_COFFEE_IMG;
                  }}
                />
                <div style={{ minWidth: 0 }}>
                  <div
                    style={{
                      fontSize: 14,
                      fontWeight: 800,
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                    }}
                  >
                    {item.name}
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>
                    Rp {Number(item.price || 0).toLocaleString('id-ID')} • {item.category}
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 7, flexShrink: 0 }}>
                <button
                  type="button"
                  onClick={() => toggleStock(item)}
                  style={{
                    padding: '6px 10px',
                    borderRadius: 999,
                    border: 'none',
                    fontWeight: 800,
                    fontSize: 11,
                    cursor: 'pointer',
                    background:
                      item.stock === false ? 'rgba(255,69,58,0.16)' : 'rgba(50,215,75,0.18)',
                    color: item.stock === false ? 'var(--accent-red)' : 'var(--accent-green)',
                  }}
                >
                  {item.stock === false ? 'Habis' : 'Tersedia'}
                </button>
                <button
                  type="button"
                  className="delete-icon-btn"
                  onClick={() => handleDeleteMenu(item.id)}
                  aria-label="Hapus menu"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </>
      )}

      {/* SUB-TAB 3: PENGATURAN QRIS TOKO & WEBHOOK */}
      {sellerSubTab === 'qris' && (
        <>
          <div className="glass-panel" style={{ padding: 18, marginBottom: 14 }}>
            <h3 style={{ fontSize: 17, fontWeight: 800, marginBottom: 6 }}>
              Pengaturan QRIS Toko
            </h3>
            <p style={{ fontSize: 12.5, color: 'var(--text-sub)', lineHeight: 1.45, marginBottom: 12 }}>
              Unggah foto barcode QRIS dari galeri HP Anda. Setiap pembeli akan otomatis diberi kode unik 3 digit agar pembayaran langsung terdeteksi.
            </p>

            <input
              type="file"
              accept="image/*"
              ref={qrisFileInputRef}
              style={{ display: 'none' }}
              onChange={handleQrisImageSelect}
            />

            <div className="image-picker-box" onClick={() => qrisFileInputRef.current?.click()}>
              {uploadingQris ? (
                <div style={{ padding: 16, color: 'var(--accent-primary)', fontWeight: 700 }}>
                  Mengompresi & menyimpan QRIS...
                </div>
              ) : qrisImgUrl ? (
                <div>
                  <div className="qris-display-box" style={{ marginTop: 0 }}>
                    <img src={sanitizeImageUrl(qrisImgUrl)} alt="Barcode QRIS Toko" />
                  </div>
                  <div style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--accent-primary)' }}>
                    Ketuk untuk Ganti Gambar QRIS dari Galeri
                  </div>
                </div>
              ) : (
                <div style={{ padding: 12 }}>
                  <Camera size={28} color="var(--accent-primary)" style={{ marginBottom: 6 }} />
                  <div style={{ fontWeight: 800, fontSize: 13.5 }}>
                    Pilih Foto QRIS dari Galeri HP
                  </div>
                  <div style={{ fontSize: 11.5, color: 'var(--text-sub)', marginTop: 3 }}>
                    Mendukung format JPG / PNG / WEBP
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Panduan Webhook MacroDroid di HP Kasir */}
          <div className="glass-panel" style={{ padding: 18 }}>
            <h4 style={{ fontSize: 15, fontWeight: 800, marginBottom: 6 }}>
              Deteksi Otomatis Notifikasi HP Kasir
            </h4>
            <p style={{ fontSize: 12.5, color: 'var(--text-sub)', lineHeight: 1.45, marginBottom: 10 }}>
              Pasang aplikasi <strong>MacroDroid</strong> di HP Kasir agar setiap notifikasi QRIS masuk (GoPay Merchant, DANA Bisnis, ShopeePay, BCA/BRI) otomatis melunasi pesanan di aplikasi:
            </p>
            <p style={{ fontSize: 12, marginBottom: 6 }}>
              <strong>1. Trigger MacroDroid:</strong> Notification → Notification Received → pilih aplikasi Merchant/Bank Anda.
            </p>
            <p style={{ fontSize: 12, marginBottom: 12 }}>
              <strong>2. Action MacroDroid:</strong> Applications → HTTP Request → metode <strong>POST</strong>, Content-Type <strong>application/json</strong>.
            </p>

            <div style={{ marginBottom: 12 }}>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: 5,
                }}
              >
                <span style={{ fontSize: 11.5, fontWeight: 800, color: 'var(--text-sub)' }}>
                  URL Webhook Firestore
                </span>
                <button
                  type="button"
                  onClick={() => handleCopyText(webhookUrl, 'URL Webhook')}
                  style={{
                    background: 'var(--glass-pill-active)',
                    border: '1px solid var(--accent-primary)',
                    color: 'var(--accent-primary)',
                    borderRadius: 8,
                    padding: '4px 9px',
                    fontSize: 11,
                    fontWeight: 800,
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 4,
                    cursor: 'pointer',
                  }}
                >
                  <Copy size={12} /> Salin URL
                </button>
              </div>
              <pre
                style={{
                  background: 'var(--glass-pill)',
                  border: '1px solid var(--glass-border)',
                  borderRadius: 12,
                  padding: 10,
                  fontSize: 11,
                  overflowX: 'auto',
                  color: 'var(--text-main)',
                }}
              >
                {webhookUrl}
              </pre>
            </div>

            <div style={{ marginBottom: 14 }}>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: 5,
                }}
              >
                <span style={{ fontSize: 11.5, fontWeight: 800, color: 'var(--text-sub)' }}>
                  Request Body (JSON)
                </span>
                <button
                  type="button"
                  onClick={() => handleCopyText(macrodroidJsonBody, 'JSON Body')}
                  style={{
                    background: 'var(--glass-pill-active)',
                    border: '1px solid var(--accent-primary)',
                    color: 'var(--accent-primary)',
                    borderRadius: 8,
                    padding: '4px 9px',
                    fontSize: 11,
                    fontWeight: 800,
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 4,
                    cursor: 'pointer',
                  }}
                >
                  <Copy size={12} /> Salin JSON
                </button>
              </div>
              <pre
                style={{
                  background: 'var(--glass-pill)',
                  border: '1px solid var(--glass-border)',
                  borderRadius: 12,
                  padding: 10,
                  fontSize: 11,
                  overflowX: 'auto',
                  color: 'var(--text-main)',
                }}
              >
                {macrodroidJsonBody}
              </pre>
            </div>

            <button
              type="button"
              className="ios-btn-secondary"
              style={{
                marginTop: 0,
                borderColor: 'var(--accent-green)',
                color: 'var(--accent-green)',
              }}
              disabled={simulatingPayment}
              onClick={handleSimulateIncomingQris}
            >
              <Zap size={15} />{' '}
              {simulatingPayment
                ? 'Mengirim Simulasi...'
                : 'Tes Simulasi Notifikasi QRIS Masuk'}
            </button>
          </div>
        </>
      )}

      {/* SUB-TAB 4: RILIS UPDATE */}
      {sellerSubTab === 'update' && (
        <div className="glass-panel" style={{ padding: 20 }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: 6,
            }}
          >
            <h3 style={{ fontSize: 17, fontWeight: 800 }}>Kirim Update Dalam Aplikasi</h3>
            <span
              style={{
                fontSize: 11,
                fontWeight: 800,
                color: 'var(--accent-primary)',
                background: 'var(--glass-pill-active)',
                padding: '4px 10px',
                borderRadius: 999,
              }}
            >
              Terpasang v{CURRENT_APP_VERSION}
            </span>
          </div>
          <p style={{ fontSize: 12.5, color: 'var(--text-sub)', marginBottom: 14 }}>
            Publikasikan versi baru di sini. Seluruh HP pembeli & kasir yang membuka aplikasi 1001 SK akan otomatis memunculkan pop-up unduh pembaruan.
          </p>
          <form onSubmit={handlePublishAppUpdate}>
            <div style={{ marginBottom: 11 }}>
              <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                Nomor Versi Baru
              </label>
              <input
                type="text"
                className="ios-input"
                value={releaseVersion}
                onChange={(e) => setReleaseVersion(e.target.value)}
                placeholder="Contoh: 2.7.1"
                required
              />
            </div>
            <div style={{ marginBottom: 11 }}>
              <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                Link Google Drive File APK Terbaru
              </label>
              <input
                type="url"
                className="ios-input"
                value={releaseApkUrl}
                onChange={(e) => setReleaseApkUrl(e.target.value)}
                placeholder="Tempel link salinan dari Google Drive (https://drive.google.com/file/d/...)"
              />
            </div>
            <div style={{ marginBottom: 11 }}>
              <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                Catatan Pembaruan (Changelog)
              </label>
              <textarea
                className="ios-input"
                rows={3}
                style={{ resize: 'vertical', fontFamily: 'inherit' }}
                value={releaseChangelog}
                onChange={(e) => setReleaseChangelog(e.target.value)}
                placeholder="• Fitur baru..."
              />
            </div>
            <label
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                fontSize: 12.5,
                color: 'var(--text-main)',
                fontWeight: 600,
                marginTop: 8,
                cursor: 'pointer',
              }}
            >
              <input
                type="checkbox"
                checked={releaseForce}
                onChange={(e) => setReleaseForce(e.target.checked)}
              />
              <span>Wajibkan update (sembunyikan tombol "Nanti Saja")</span>
            </label>
            <button type="submit" className="ios-btn-primary" disabled={publishingUpdate}>
              <Send size={16} />{' '}
              {publishingUpdate ? 'Mempublikasikan...' : 'Kirim Notifikasi Update ke Pengguna'}
            </button>
          </form>
        </div>
      )}

      {/* Modal Tambah Menu + Foto Produk dari Galeri HP */}
      {isAddMenuOpen && (
        <div className="ios-modal-overlay" onClick={() => setIsAddMenuOpen(false)}>
          <div className="ios-modal-sheet" onClick={(e) => e.stopPropagation()}>
            <div className="sheet-handle" />
            <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 14 }}>
              Tambah Menu Kopi 1001 SK
            </h3>
            <form onSubmit={handleAddMenu}>
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                  Foto Produk (Dari Galeri HP)
                </label>
                <input
                  type="file"
                  accept="image/*"
                  ref={productFileInputRef}
                  style={{ display: 'none' }}
                  onChange={handleProductImageSelect}
                />
                {uploadingImg ? (
                  <div
                    className="image-picker-box"
                    style={{ padding: 18, color: 'var(--accent-primary)' }}
                  >
                    Mengoptimalkan resolusi foto...
                  </div>
                ) : productImgUrl ? (
                  <div
                    className="preview-img-container"
                    onClick={() => productFileInputRef.current?.click()}
                  >
                    <img src={productImgUrl} alt="Preview Produk" />
                    <div
                      style={{
                        position: 'absolute',
                        bottom: 8,
                        right: 8,
                        background: 'rgba(12,10,20,0.75)',
                        backdropFilter: 'blur(10px)',
                        padding: '5px 10px',
                        borderRadius: 10,
                        fontSize: 11,
                        color: '#fff',
                        fontWeight: 700,
                      }}
                    >
                      Ganti Foto
                    </div>
                  </div>
                ) : (
                  <div
                    className="image-picker-box"
                    onClick={() => productFileInputRef.current?.click()}
                  >
                    <Camera
                      size={26}
                      color="var(--accent-primary)"
                      style={{ margin: '0 auto 6px' }}
                    />
                    <div style={{ fontWeight: 700, fontSize: 13 }}>
                      Ketuk untuk Ambil Foto dari Galeri
                    </div>
                  </div>
                )}
              </div>

              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                  Nama Menu
                </label>
                <input
                  type="text"
                  className="ios-input"
                  value={newMenuName}
                  onChange={(e) => setNewMenuName(e.target.value)}
                  placeholder="Contoh: Kopi Susu Aren"
                  required
                />
              </div>

              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                  Kategori
                </label>
                <select
                  className="ios-input"
                  value={newMenuCategory}
                  onChange={(e) => setNewMenuCategory(e.target.value)}
                >
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                  Harga (Rp)
                </label>
                <input
                  type="number"
                  className="ios-input"
                  value={newMenuPrice}
                  onChange={(e) => setNewMenuPrice(e.target.value)}
                  placeholder="18000"
                  required
                />
              </div>

              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>
                  Deskripsi Singkat
                </label>
                <input
                  type="text"
                  className="ios-input"
                  value={newMenuDesc}
                  onChange={(e) => setNewMenuDesc(e.target.value)}
                  placeholder="Deskripsi rasa & komposisi..."
                />
              </div>

              <button type="submit" className="ios-btn-primary">
                Simpan Menu Baru
              </button>
              <button
                type="button"
                className="ios-btn-secondary"
                onClick={() => setIsAddMenuOpen(false)}
              >
                Batal
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
