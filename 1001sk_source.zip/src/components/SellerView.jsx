import React, { useState, useMemo } from 'react';
import {
  CheckCircle2,
  Coffee,
  PackageCheck,
  Plus,
  Trash2,
  Upload,
  QrCode,
  ShieldAlert,
  Sparkles
} from 'lucide-react';
import { MENU_CATEGORIES, ORDER_STATUS_META, formatRupiah, formatDateTime } from '../utils/constants.js';
import { compressImageFile } from '../utils/imageCompressor.js';
import { extractNominalFromText } from '../utils/qrisAutoMatcher.js';

export default function SellerView({
  activeTab,
  orders,
  menuItems,
  qrisImageUrl,
  storeName,
  onUpdateOrderStatus,
  onDeleteOrder,
  onSaveMenuItem,
  onDeleteMenuItem,
  onSaveStoreSettings
}) {
  const [newName, setNewName] = useState('');
  const [newCategory, setNewCategory] = useState('Signature Coffee');
  const [newPrice, setNewPrice] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newImage, setNewImage] = useState('');
  const [newFeatured] = useState(true);
  const [savingMenu, setSavingMenu] = useState(false);

  const [editStoreName, setEditStoreName] = useState(storeName || '1001 SK Coffee & Lounge');
  const [editQrisUrl, setEditQrisUrl] = useState(qrisImageUrl || '');
  const [notifSmsText, setNotifSmsText] = useState('');
  const [sellerMsg, setSellerMsg] = useState('');

  const showMsg = (txt) => {
    setSellerMsg(txt);
    window.setTimeout(() => setSellerMsg(''), 3000);
  };

  const activeOrders = useMemo(
    () => orders.filter((o) => !['completed', 'cancelled'].includes(o.status)),
    [orders]
  );

  const handleMenuImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await compressImageFile(file, 720, 0.8);
      setNewImage(dataUrl);
      showMsg('Foto menu siap disimpan');
    } catch (err) {
      showMsg(err.message);
    }
  };

  const handleQrisUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await compressImageFile(file, 720, 0.85);
      setEditQrisUrl(dataUrl);
      showMsg('Gambar QRIS siap disimpan');
    } catch (err) {
      showMsg(err.message);
    }
  };

  const handleCreateMenu = async (e) => {
    e.preventDefault();
    if (!newName.trim() || !newPrice || savingMenu) return;
    setSavingMenu(true);
    try {
      await onSaveMenuItem({
        name: newName.trim(),
        category: newCategory,
        price: Number(newPrice),
        desc: newDesc.trim() || 'Racikan spesial 1001 SK Coffee.',
        image:
          newImage ||
          'https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=800&q=80',
        featured: newFeatured,
        available: true
      });
      setNewName('');
      setNewPrice('');
      setNewDesc('');
      setNewImage('');
      showMsg('Menu baru ditambahkan');
    } finally {
      setSavingMenu(false);
    }
  };

  const handleAutoMatchQris = () => {
    const nominal = extractNominalFromText(notifSmsText);
    if (!nominal) {
      showMsg('Nominal pembayaran tidak terbaca dari teks notifikasi');
      return;
    }
    const matched = orders.find(
      (o) => o.status === 'pending_payment' && Number(o.totalPrice) === nominal
    );
    if (matched) {
      onUpdateOrderStatus(matched.id, 'queued');
      setNotifSmsText('');
      showMsg(`Pembayaran ${formatRupiah(nominal)} untuk ${matched.customerName} otomatis terkonfirmasi!`);
    } else {
      showMsg(`Tidak ada pesanan menunggu pembayaran sebesar ${formatRupiah(nominal)}`);
    }
  };

  return (
    <div style={{ display: 'grid', gap: 14 }}>
      {/* Proteksi Penjual: Seller tidak dapat memesan di dalam aplikasi */}
      <div
        className="convx-glass-card"
        style={{
          padding: '11px 14px',
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          borderColor: 'rgba(255, 159, 10, 0.45)'
        }}
      >
        <ShieldAlert size={18} style={{ color: '#ff9f0a', flexShrink: 0, zIndex: 2 }} />
        <span style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text-secondary)', zIndex: 2 }}>
          Mode Penjual Aktif — Pemesanan pelanggan dinonaktifkan pada akun penjual.
        </span>
      </div>

      {sellerMsg && (
        <div
          className="convx-glass-card"
          style={{
            padding: '10px 14px',
            background: 'rgba(48, 209, 88, 0.18)',
            borderColor: 'rgba(48, 209, 88, 0.45)',
            fontSize: 13,
            fontWeight: 600,
            color: '#30d158'
          }}
        >
          {sellerMsg}
        </div>
      )}

      {activeTab === 'home' && (
        <>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <h2 style={{ margin: 0, fontSize: 19, fontWeight: 800 }}>
              Pesanan Masuk ({activeOrders.length})
            </h2>
          </div>

          {orders.length === 0 ? (
            <div className="convx-glass-card" style={{ padding: 28, textAlign: 'center' }}>
              <Coffee size={32} style={{ color: 'var(--text-tertiary)', marginBottom: 8 }} />
              <div style={{ fontWeight: 700, fontSize: 15 }}>Belum Ada Pesanan Pelanggan</div>
              <div style={{ fontSize: 12.5, color: 'var(--text-secondary)', marginTop: 4 }}>
                Pesanan baru akan muncul secara otomatis di sini.
              </div>
            </div>
          ) : (
            <div style={{ display: 'grid', gap: 12 }}>
              {orders.map((order) => {
                const meta = ORDER_STATUS_META[order.status] || ORDER_STATUS_META.queued;
                return (
                  <div key={order.id} className="convx-glass-card" style={{ padding: 15 }}>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        marginBottom: 8,
                        position: 'relative',
                        zIndex: 2
                      }}
                    >
                      <span
                        style={{
                          padding: '4px 10px',
                          borderRadius: 999,
                          background: meta.bg,
                          color: meta.color,
                          fontSize: 11.5,
                          fontWeight: 700
                        }}
                      >
                        {meta.label}
                      </span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ fontSize: 11.5, color: 'var(--text-tertiary)' }}>
                          {formatDateTime(order.createdAt)}
                        </span>
                        <button
                          type="button"
                          onClick={() => onDeleteOrder(order.id)}
                          title="Hapus Riwayat Pesanan"
                          style={{
                            width: 28,
                            height: 28,
                            borderRadius: '50%',
                            border: 'none',
                            background: 'var(--bg-subtle)',
                            color: '#ff453a',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: 'pointer'
                          }}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>

                    <div style={{ fontWeight: 700, fontSize: 15, position: 'relative', zIndex: 2 }}>
                      {order.customerName} • {order.tableNumber || 'Takeaway'}
                    </div>
                    <div
                      style={{
                        fontSize: 13,
                        color: 'var(--text-secondary)',
                        margin: '6px 0',
                        position: 'relative',
                        zIndex: 2
                      }}
                    >
                      {(order.items || []).map((i) => `${i.qty}x ${i.name}`).join(', ')}
                    </div>

                    {order.note && (
                      <div
                        style={{
                          fontSize: 12,
                          color: '#ff9f0a',
                          marginBottom: 8,
                          position: 'relative',
                          zIndex: 2
                        }}
                      >
                        Catatan: {order.note}
                      </div>
                    )}

                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        marginTop: 10,
                        gap: 8,
                        flexWrap: 'wrap',
                        position: 'relative',
                        zIndex: 2
                      }}
                    >
                      <strong style={{ fontSize: 15 }}>{formatRupiah(order.totalPrice)}</strong>
                      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                        {order.status === 'pending_payment' && (
                          <button
                            type="button"
                            className="btn-ios-glass"
                            onClick={() => onUpdateOrderStatus(order.id, 'queued')}
                          >
                            <CheckCircle2 size={14} />
                            <span>Terima Bayar</span>
                          </button>
                        )}
                        {order.status === 'queued' && (
                          <button
                            type="button"
                            className="btn-ios-glass"
                            onClick={() => onUpdateOrderStatus(order.id, 'preparing')}
                          >
                            <Coffee size={14} />
                            <span>Racik</span>
                          </button>
                        )}
                        {(order.status === 'queued' || order.status === 'preparing') && (
                          <button
                            type="button"
                            className="btn-ios-glass"
                            style={{ color: '#30d158' }}
                            onClick={() => onUpdateOrderStatus(order.id, 'ready')}
                          >
                            <PackageCheck size={14} />
                            <span>Siap Diambil</span>
                          </button>
                        )}
                        {order.status === 'ready' && (
                          <button
                            type="button"
                            className="btn-ios-glass"
                            onClick={() => onUpdateOrderStatus(order.id, 'completed')}
                          >
                            <span>Selesaikan</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {activeTab === 'cart' && (
        <>
          <div className="convx-glass-card" style={{ padding: 16 }}>
            <div style={{ fontWeight: 800, fontSize: 16, marginBottom: 12, zIndex: 2, position: 'relative' }}>
              Tambah Menu Baru
            </div>
            <form
              onSubmit={handleCreateMenu}
              style={{ display: 'grid', gap: 10, position: 'relative', zIndex: 2 }}
            >
              <input
                type="text"
                className="ios-glass-input"
                placeholder="Nama Minuman / Makanan"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                required
              />
              <select
                className="ios-glass-input"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
              >
                {MENU_CATEGORIES.filter((c) => c !== 'Semua').map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
              <input
                type="number"
                className="ios-glass-input"
                placeholder="Harga (contoh: 20000)"
                value={newPrice}
                onChange={(e) => setNewPrice(e.target.value)}
                required
              />
              <input
                type="text"
                className="ios-glass-input"
                placeholder="Deskripsi singkat menu"
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
              />
              <label className="btn-ios-glass" style={{ justifyContent: 'center' }}>
                <Upload size={15} />
                <span>{newImage ? 'Ganti Foto Menu' : 'Unggah Foto Menu'}</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleMenuImageUpload}
                  style={{ display: 'none' }}
                />
              </label>
              <button type="submit" className="btn-ios-primary" disabled={savingMenu}>
                <Plus size={16} />
                <span>{savingMenu ? 'Menyimpan...' : 'Simpan Menu'}</span>
              </button>
            </form>
          </div>

          <div style={{ display: 'grid', gap: 10 }}>
            {menuItems.map((item) => (
              <div
                key={item.id}
                className="convx-glass-card"
                style={{
                  padding: 12,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 12
                }}
              >
                <img
                  src={item.image}
                  alt={item.name}
                  style={{
                    width: 54,
                    height: 54,
                    borderRadius: 14,
                    objectFit: 'cover',
                    zIndex: 2
                  }}
                />
                <div style={{ flex: 1, zIndex: 2 }}>
                  <div style={{ fontWeight: 700, fontSize: 14.5 }}>{item.name}</div>
                  <div style={{ fontSize: 12.5, color: 'var(--text-secondary)' }}>
                    {formatRupiah(item.price)} • {item.category}
                  </div>
                </div>
                <button
                  type="button"
                  className="btn-ios-glass"
                  style={{
                    padding: '6px 10px',
                    fontSize: 12,
                    color: item.available === false ? '#ff453a' : '#30d158',
                    zIndex: 2
                  }}
                  onClick={() => onSaveMenuItem({ ...item, available: item.available === false })}
                >
                  {item.available === false ? 'Habis' : 'Tersedia'}
                </button>
                <button
                  type="button"
                  onClick={() => onDeleteMenuItem(item.id)}
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: '50%',
                    border: 'none',
                    background: 'var(--bg-subtle)',
                    color: '#ff453a',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    zIndex: 2
                  }}
                >
                  <Trash2 size={15} />
                </button>
              </div>
            ))}
          </div>
        </>
      )}

      {activeTab === 'orders' && (
        <div style={{ display: 'grid', gap: 14 }}>
          <div className="convx-glass-card" style={{ padding: 16 }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                fontWeight: 800,
                fontSize: 16,
                marginBottom: 12,
                position: 'relative',
                zIndex: 2
              }}
            >
              <QrCode size={18} style={{ color: '#ff9f0a' }} />
              <span>Pengaturan QRIS Toko</span>
            </div>
            <div style={{ display: 'grid', gap: 10, position: 'relative', zIndex: 2 }}>
              <input
                type="text"
                className="ios-glass-input"
                placeholder="Nama Kedai / Toko"
                value={editStoreName}
                onChange={(e) => setEditStoreName(e.target.value)}
              />
              <label className="btn-ios-glass">
                <Upload size={15} />
                <span>Unggah Gambar QRIS Statis</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleQrisUpload}
                  style={{ display: 'none' }}
                />
              </label>
              {editQrisUrl && (
                <img
                  src={editQrisUrl}
                  alt="Preview QRIS"
                  style={{
                    width: 160,
                    height: 160,
                    objectFit: 'contain',
                    borderRadius: 16,
                    margin: '4px auto',
                    background: '#fff',
                    padding: 8
                  }}
                />
              )}
              <button
                type="button"
                className="btn-ios-primary"
                onClick={() => {
                  onSaveStoreSettings({ storeName: editStoreName, qrisImageUrl: editQrisUrl });
                  showMsg('Pengaturan QRIS toko tersimpan');
                }}
              >
                Simpan Pengaturan QRIS
              </button>
            </div>
          </div>

          <div className="convx-glass-card" style={{ padding: 16 }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                fontWeight: 800,
                fontSize: 16,
                marginBottom: 6,
                position: 'relative',
                zIndex: 2
              }}
            >
              <Sparkles size={18} style={{ color: '#30d158' }} />
              <span>Cocokkan Mutasi QRIS Otomatis</span>
            </div>
            <div
              style={{
                fontSize: 12.5,
                color: 'var(--text-secondary)',
                marginBottom: 10,
                position: 'relative',
                zIndex: 2
              }}
            >
              Tempel teks notifikasi pembayaran masuk (Dana / GoPay / BCA / BRI) untuk memverifikasi
              nominal otomatis.
            </div>
            <textarea
              rows={3}
              className="ios-glass-input"
              placeholder="Contoh: Pembayaran QRIS diterima sebesar Rp 18.000 dari..."
              value={notifSmsText}
              onChange={(e) => setNotifSmsText(e.target.value)}
              style={{ position: 'relative', zIndex: 2, resize: 'vertical' }}
            />
            <button
              type="button"
              className="btn-ios-primary"
              style={{ marginTop: 10, position: 'relative', zIndex: 2 }}
              onClick={handleAutoMatchQris}
            >
              Verifikasi Mutasi Sekarang
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
