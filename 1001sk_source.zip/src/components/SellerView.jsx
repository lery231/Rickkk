import React, { useState, useMemo } from 'react';
import {
  CheckCircle2,
  Coffee,
  PackageCheck,
  Plus,
  Trash2,
  Upload,
  QrCode,
  ShieldAlert,
  Sparkles,
  X
} from 'lucide-react';
import {
  MENU_CATEGORIES,
  ORDER_STATUS_META,
  formatRupiah,
  formatDateTime
} from '../utils/constants.js';
import { compressImageFile } from '../utils/imageCompressor.js';
import { extractNominalFromText } from '../utils/qrisAutoMatcher.js';

export default function SellerView({
  activeTab,
  orders,
  menuItems,
  qrisImageUrl,
  storeName,
  onUpdateOrderStatus,
  onDeleteOrder,
  onSaveMenuItem,
  onDeleteMenuItem,
  onSaveStoreSettings
}) {
  const [newName, setNewName] = useState('');
  const [newCategory, setNewCategory] = useState('Signature Coffee');
  const [newPrice, setNewPrice] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newImage, setNewImage] = useState('');
  const [newFeatured, setNewFeatured] = useState(true);
  const [savingMenu, setSavingMenu] = useState(false);

  const [editStoreName, setEditStoreName] = useState(storeName || '1001 SK Coffee & Lounge');
  const [editQrisUrl, setEditQrisUrl] = useState(qrisImageUrl || '');
  const [notifSmsText, setNotifSmsText] = useState('');
  const [sellerMsg, setSellerMsg] = useState('');

  const showMsg = (txt) => {
    setSellerMsg(txt);
    window.setTimeout(() => setSellerMsg(''), 3000);
  };

  const activeOrders = useMemo(
    () => orders.filter((o) => !['completed', 'cancelled'].includes(o.status)),
    [orders]
  );

  const handleMenuImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await compressImageFile(file, 720, 0.8);
      setNewImage(dataUrl);
      showMsg('Foto menu siap disimpan');
    } catch (err) {
      showMsg(err.message);
    }
  };

  const handleQrisUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await compressImageFile(file, 720, 0.85);
      setEditQrisUrl(dataUrl);
      showMsg('Gambar QRIS siap disimpan');
    } catch (err) {
      showMsg(err.message);
    }
  };

  const handleCreateMenu = async (e) => {
    e.preventDefault();
    if (!newName.trim() || !newPrice || savingMenu) return;
    setSavingMenu(true);
    try {
      await onSaveMenuItem({
        name: newName.trim(),
        category: newCategory,
        price: Number(newPrice),
        desc: newDesc.trim() || 'Racikan spesial 1001 SK Coffee.',
        image:
          newImage ||
          'https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=800&q=80',
        featured: newFeatured,
        available: true
      });
      setNewName('');
      setNewPrice('');
      setNewDesc('');
      setNewImage('');
      showMsg('Menu baru ditambahkan');
    } finally {
      setSavingMenu(false);
    }
  };

  const handleAutoMatchQris = () => {
    const nominal = extractNominalFromText(notifSmsText);
    if (!nominal) {
      showMsg('Nominal pembayaran tidak terbaca dari teks notifikasi');
      return;
    }
    const matched = orders.find(
      (o) => o.status === 'pending_payment' && Number(o.totalPrice) === nominal
    );
    if (matched) {
      onUpdateOrderStatus(matched.id, 'queued');
      setNotifSmsText('');
      showMsg(`Pembayaran ${formatRupiah(nominal)} untuk ${matched.customerName} otomatis terkonfirmasi!`);
    } else {
      showMsg(`Tidak ada pesanan menunggu pembayaran sebesar ${formatRupiah(nominal)}`);
    }
  };

  return (
    <div style={{ padding: '4px 18px 24px' }}>
      {/* Seller Protection Notice (Seller cannot place orders inside the app) */}
      <div
        className="liquid-glass-surface"
        style={{
          borderRadius: 18,
          padding: '11px 14px',
          marginBottom: 14,
          display: 'flex',
          alignItems: 'center',
          gap: 10
        }}
      >
        <ShieldAlert size={19} style={{ color: 'var(--accent)', flexShrink: 0, position: 'relative', zIndex: 1 }} />
        <div style={{ fontSize: 12.5, color: 'var(--text-primary)', fontWeight: 600, position: 'relative', zIndex: 1 }}>
          Mode Penjual Aktif — Pemesanan pelanggan dinonaktifkan pada akun penjual.
        </div>
      </div>

      {sellerMsg && (
        <div
          className="liquid-glass-surface"
          style={{
            borderRadius: 999,
            padding: '9px 16px',
            marginBottom: 12,
            fontSize: 13,
            fontWeight: 700,
            textAlign: 'center'
          }}
        >
          <span style={{ position: 'relative', zIndex: 1 }}>{sellerMsg}</span>
        </div>
      )}

      {/* TAB 1 (home): ANTREAN PESANAN MASUK */}
      {activeTab === 'home' && (
        <>
          <div className="section-header" style={{ paddingLeft: 0, paddingRight: 0 }}>
            <h2 className="section-title">Pesanan Masuk ({activeOrders.length})</h2>
          </div>

          {orders.length === 0 ? (
            <div className="ios-grouped-card" style={{ padding: 28, textAlign: 'center' }}>
              <Coffee size={34} style={{ color: 'var(--text-tertiary)', marginBottom: 8 }} />
              <div style={{ fontSize: 16, fontWeight: 800 }}>Belum Ada Pesanan Pelanggan</div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {orders.map((order) => {
                const meta = ORDER_STATUS_META[order.status] || ORDER_STATUS_META.queued;
                return (
                  <div key={order.id} className="ios-grouped-card" style={{ padding: 15 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span
                        style={{
                          padding: '4px 11px',
                          borderRadius: 999,
                          background: meta.bg,
                          color: meta.color,
                          fontSize: 12,
                          fontWeight: 800
                        }}
                      >
                        {meta.label}
                      </span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                          {formatDateTime(order.createdAt)}
                        </span>
                        <button
                          type="button"
                          onClick={() => onDeleteOrder(order.id)}
                          style={{
                            width: 28,
                            height: 28,
                            borderRadius: '50%',
                            border: 'none',
                            background: 'var(--bg-subtle)',
                            color: '#ff3b30',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: 'pointer'
                          }}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>

                    <div style={{ fontSize: 16, fontWeight: 800, marginTop: 9 }}>
                      {order.customerName} • {order.tableNumber || 'Takeaway'}
                    </div>
                    <div style={{ fontSize: 13.5, color: 'var(--text-secondary)', marginTop: 4 }}>
                      {(order.items || []).map((i) => `${i.qty}x ${i.name}`).join(', ')}
                    </div>
                    {order.note && (
                      <div style={{ fontSize: 12.5, color: 'var(--accent)', marginTop: 4, fontWeight: 600 }}>
                        Catatan: {order.note}
                      </div>
                    )}

                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginTop: 12,
                        paddingTop: 10,
                        borderTop: '1px solid var(--border-hairline)',
                        gap: 8,
                        flexWrap: 'wrap'
                      }}
                    >
                      <strong style={{ fontSize: 16, color: 'var(--accent)' }}>
                        {formatRupiah(order.totalPrice)}
                      </strong>

                      <div style={{ display: 'flex', gap: 7, flexWrap: 'wrap' }}>
                        {order.status === 'pending_payment' && (
                          <button
                            type="button"
                            className="btn-ios-secondary"
                            style={{ padding: '7px 12px', fontSize: 12.5 }}
                            onClick={() => onUpdateOrderStatus(order.id, 'queued')}
                          >
                            <CheckCircle2 size={14} /> Terima Bayar
                          </button>
                        )}
                        {order.status === 'queued' && (
                          <button
                            type="button"
                            className="btn-ios-secondary"
                            style={{ padding: '7px 12px', fontSize: 12.5 }}
                            onClick={() => onUpdateOrderStatus(order.id, 'preparing')}
                          >
                            <Coffee size={14} /> Racik
                          </button>
                        )}
                        {(order.status === 'queued' || order.status === 'preparing') && (
                          <button
                            type="button"
                            className="btn-ios-primary"
                            style={{ width: 'auto', padding: '7px 13px', fontSize: 12.5 }}
                            onClick={() => onUpdateOrderStatus(order.id, 'ready')}
                          >
                            <PackageCheck size={14} /> Siap Diambil
                          </button>
                        )}
                        {order.status === 'ready' && (
                          <button
                            type="button"
                            className="btn-ios-secondary"
                            style={{ padding: '7px 12px', fontSize: 12.5 }}
                            onClick={() => onUpdateOrderStatus(order.id, 'completed')}
                          >
                            Selesaikan
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* TAB 2 (cart): KELOLA DAFTAR MENU */}
      {activeTab === 'cart' && (
        <>
          <form onSubmit={handleCreateMenu} className="ios-grouped-card" style={{ padding: 16, marginBottom: 16 }}>
            <div style={{ fontSize: 16, fontWeight: 800, marginBottom: 12 }}>Tambah Menu Baru</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <input
                className="ios-input"
                type="text"
                placeholder="Nama Menu (Contoh: Es Kopi Susu 1001)"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                required
              />
              <select
                className="ios-input"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
              >
                {MENU_CATEGORIES.filter((c) => c !== 'Semua').map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
              <input
                className="ios-input"
                type="number"
                placeholder="Harga (Rp)"
                value={newPrice}
                onChange={(e) => setNewPrice(e.target.value)}
                required
              />
              <input
                className="ios-input"
                type="text"
                placeholder="Deskripsi singkat menu"
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
              />
              <label className="btn-ios-secondary" style={{ cursor: 'pointer' }}>
                <Upload size={16} />
                {newImage ? 'Ganti Foto Menu' : 'Unggah Foto Menu'}
                <input type="file" accept="image/*" hidden onChange={handleMenuImageUpload} />
              </label>
              <button type="submit" className="btn-ios-primary" disabled={savingMenu}>
                <Plus size={17} /> {savingMenu ? 'Menyimpan...' : 'Simpan Menu'}
              </button>
            </div>
          </form>

          <div className="ios-grouped-card">
            {menuItems.map((item) => (
              <div
                key={item.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 12,
                  padding: '12px 14px',
                  borderBottom: '1px solid var(--border-hairline)'
                }}
              >
                <img
                  src={item.image}
                  alt={item.name}
                  style={{ width: 50, height: 50, borderRadius: 12, objectFit: 'cover' }}
                />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14.5, fontWeight: 700 }}>{item.name}</div>
                  <div style={{ fontSize: 12.5, color: 'var(--text-secondary)' }}>
                    {formatRupiah(item.price)} • {item.category}
                  </div>
                </div>
                <button
                  type="button"
                  className="btn-ios-secondary"
                  style={{ padding: '6px 10px', fontSize: 12 }}
                  onClick={() => onSaveMenuItem({ ...item, available: item.available === false })}
                >
                  {item.available === false ? 'Habis' : 'Tersedia'}
                </button>
                <button
                  type="button"
                  onClick={() => onDeleteMenuItem(item.id)}
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: '50%',
                    border: 'none',
                    background: 'var(--bg-subtle)',
                    color: '#ff3b30',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer'
                  }}
                >
                  <Trash2 size={15} />
                </button>
              </div>
            ))}
          </div>
        </>
      )}

      {/* TAB 3 (orders): PENGATURAN QRIS & VERIFIKASI OTOMATIS */}
      {activeTab === 'orders' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="ios-grouped-card" style={{ padding: 16 }}>
            <div style={{ fontSize: 16, fontWeight: 800, marginBottom: 12 }}>
              <QrCode size={17} style={{ verticalAlign: 'middle', marginRight: 6 }} />
              Pengaturan QRIS Toko
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <input
                className="ios-input"
                type="text"
                placeholder="Nama Kedai / Toko"
                value={editStoreName}
                onChange={(e) => setEditStoreName(e.target.value)}
              />
              <label className="btn-ios-secondary" style={{ cursor: 'pointer' }}>
                <Upload size={16} /> Unggah Gambar QRIS Statis
                <input type="file" accept="image/*" hidden onChange={handleQrisUpload} />
              </label>
              {editQrisUrl && (
                <img
                  src={editQrisUrl}
                  alt="Preview QRIS"
                  style={{ width: 180, height: 180, objectFit: 'contain', borderRadius: 16, margin: '4px auto' }}
                />
              )}
              <button
                type="button"
                className="btn-ios-primary"
                onClick={() => {
                  onSaveStoreSettings({ storeName: editStoreName, qrisImageUrl: editQrisUrl });
                  showMsg('Pengaturan QRIS toko tersimpan');
                }}
              >
                Simpan Pengaturan QRIS
              </button>
            </div>
          </div>

          <div className="ios-grouped-card" style={{ padding: 16 }}>
            <div style={{ fontSize: 16, fontWeight: 800, marginBottom: 8 }}>
              <Sparkles size={17} style={{ verticalAlign: 'middle', marginRight: 6, color: 'var(--accent)' }} />
              Cocokkan Mutasi QRIS Otomatis
            </div>
            <p style={{ fontSize: 12.5, color: 'var(--text-secondary)', marginBottom: 10 }}>
              Tempel teks notifikasi pembayaran masuk (Dana / GoPay / BCA / BRI) untuk memverifikasi nominal otomatis.
            </p>
            <textarea
              className="ios-input"
              rows={3}
              placeholder="Contoh: Pembayaran QRIS diterima sebesar Rp 18.000..."
              value={notifSmsText}
              onChange={(e) => setNotifSmsText(e.target.value)}
            />
            <button
              type="button"
              className="btn-ios-primary"
              style={{ marginTop: 10 }}
              onClick={handleAutoMatchQris}
            >
              Verifikasi Nominal Pembayaran
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
