import React, { useState, useMemo } from 'react';
import {
  CheckCircle2,
  Coffee,
  PackageCheck,
  Plus,
  Trash2,
  ShieldAlert,
  Settings
} from 'lucide-react';
import {
  MENU_CATEGORIES,
  ORDER_STATUS_META,
  formatRupiah,
  formatDateTime
} from '../utils/constants.js';

export default function SellerView({
  activeTab,
  tabDirection,
  orders,
  menuItems,
  onUpdateOrderStatus,
  onDeleteOrder,
  onSaveMenuItem,
  onDeleteMenuItem,
  onOpenSettings
}) {
  const [newName, setNewName] = useState('');
  const [newCategory, setNewCategory] = useState('Signature Coffee');
  const [newPrice, setNewPrice] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [savingMenu, setSavingMenu] = useState(false);
  const [sellerMsg, setSellerMsg] = useState('');

  const showMsg = (txt) => {
    setSellerMsg(txt);
    window.setTimeout(() => setSellerMsg(''), 3000);
  };

  const activeOrders = useMemo(
    () => orders.filter((o) => !['completed', 'cancelled'].includes(o.status)),
    [orders]
  );

  const handleCreateMenu = async (e) => {
    e.preventDefault();
    if (!newName.trim() || !newPrice || savingMenu) return;
    setSavingMenu(true);
    try {
      await onSaveMenuItem({
        name: newName.trim(),
        category: newCategory,
        price: Number(newPrice),
        desc: newDesc.trim() || 'Racikan spesial 1001 SK Coffee.',
        featured: true,
        available: true
      });
      setNewName('');
      setNewPrice('');
      setNewDesc('');
      showMsg('Menu baru ditambahkan');
    } finally {
      setSavingMenu(false);
    }
  };

  const tabAnimClass = tabDirection === 'left' ? 'tab-slide-left' : 'tab-slide-right';

  return (
    <div key={`seller-${activeTab}`} className={tabAnimClass} style={{ padding: '4px 18px 24px' }}>
      <div
        className="refractive-glass"
        style={{
          borderRadius: 18,
          padding: '11px 14px',
          marginBottom: 14,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 10
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, position: 'relative', zIndex: 1 }}>
          <ShieldAlert size={18} style={{ color: 'var(--accent)', flexShrink: 0 }} />
          <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text-primary)' }}>
            Mode Penjual Aktif • Pengaturan QRIS ada di menu Pengaturan
          </span>
        </div>
        <button
          type="button"
          className="btn-ios-secondary"
          style={{ padding: '6px 11px', fontSize: 12, position: 'relative', zIndex: 1 }}
          onClick={onOpenSettings}
        >
          <Settings size={14} /> QRIS
        </button>
      </div>

      {sellerMsg && (
        <div
          className="toast-spring-in"
          style={{
            padding: '10px 14px',
            borderRadius: 14,
            background: 'rgba(48, 209, 88, 0.16)',
            color: '#30d158',
            fontSize: 13,
            fontWeight: 700,
            marginBottom: 12
          }}
        >
          {sellerMsg}
        </div>
      )}

      {activeTab === 'home' && (
        <>
          <div className="section-header" style={{ paddingLeft: 0, paddingRight: 0 }}>
            <h2 className="section-title">Pesanan Masuk ({activeOrders.length})</h2>
          </div>

          {orders.length === 0 ? (
            <div className="ios-grouped-card" style={{ padding: '32px 20px', textAlign: 'center' }}>
              <Coffee size={36} style={{ color: 'var(--text-tertiary)', marginBottom: 8 }} />
              <div style={{ fontSize: 16, fontWeight: 800 }}>Belum Ada Pesanan Pelanggan</div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {orders.map((order, idx) => {
                const meta = ORDER_STATUS_META[order.status] || ORDER_STATUS_META.queued;
                return (
                  <div
                    key={order.id}
                    className="ios-grouped-card card-stagger-in"
                    style={{ '--stagger': idx, padding: 15 }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span
                        style={{
                          padding: '4px 11px',
                          borderRadius: 999,
                          background: meta.bg,
                          color: meta.color,
                          fontSize: 12,
                          fontWeight: 800
                        }}
                      >
                        {meta.label}
                      </span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                          {formatDateTime(order.createdAt)}
                        </span>
                        <button
                          type="button"
                          onClick={() => onDeleteOrder(order.id)}
                          style={{
                            width: 28,
                            height: 28,
                            borderRadius: '50%',
                            border: 'none',
                            background: 'var(--bg-subtle)',
                            color: '#ff453a',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: 'pointer'
                          }}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>

                    <div style={{ fontSize: 15.5, fontWeight: 800, marginTop: 9 }}>
                      {order.customerName} • {order.tableNumber || 'Takeaway'}
                    </div>
                    <div style={{ fontSize: 13.5, color: 'var(--text-secondary)', marginTop: 3 }}>
                      {(order.items || []).map((i) => `${i.qty}x ${i.name}`).join(', ')}
                    </div>
                    {order.note && (
                      <div style={{ fontSize: 12.5, color: 'var(--accent)', marginTop: 4 }}>
                        Catatan: {order.note}
                      </div>
                    )}

                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginTop: 12,
                        paddingTop: 10,
                        borderTop: '1px solid var(--border-hairline)',
                        gap: 8,
                        flexWrap: 'wrap'
                      }}
                    >
                      <span style={{ fontSize: 15, fontWeight: 800 }}>
                        {formatRupiah(order.totalPrice)}
                      </span>
                      <div style={{ display: 'flex', gap: 6 }}>
                        {order.status === 'pending_payment' && (
                          <button
                            type="button"
                            className="btn-ios-secondary"
                            style={{ padding: '7px 12px', fontSize: 12.5 }}
                            onClick={() => onUpdateOrderStatus(order.id, 'queued')}
                          >
                            Terima Pesanan
                          </button>
                        )}
                        {order.status === 'queued' && (
                          <button
                            type="button"
                            className="btn-ios-secondary"
                            style={{ padding: '7px 12px', fontSize: 12.5 }}
                            onClick={() => onUpdateOrderStatus(order.id, 'preparing')}
                          >
                            Racik
                          </button>
                        )}
                        {(order.status === 'queued' || order.status === 'preparing') && (
                          <button
                            type="button"
                            className="btn-ios-primary"
                            style={{ padding: '7px 13px', fontSize: 12.5, width: 'auto' }}
                            onClick={() => onUpdateOrderStatus(order.id, 'ready')}
                          >
                            <PackageCheck size={15} /> Siap Diambil
                          </button>
                        )}
                        {order.status === 'ready' && (
                          <button
                            type="button"
                            className="btn-ios-secondary"
                            style={{ padding: '7px 12px', fontSize: 12.5 }}
                            onClick={() => onUpdateOrderStatus(order.id, 'completed')}
                          >
                            <CheckCircle2 size={15} /> Selesaikan
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {activeTab === 'cart' && (
        <>
          <form onSubmit={handleCreateMenu} className="ios-grouped-card" style={{ padding: 16, marginBottom: 16 }}>
            <div style={{ fontSize: 16, fontWeight: 800, marginBottom: 12 }}>Tambah Menu Baru</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <input
                className="ios-input"
                type="text"
                placeholder="Nama Menu (Contoh: Kopi Susu 1001)"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                required
              />
              <select
                className="ios-input"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
              >
                {MENU_CATEGORIES.filter((c) => c !== 'Semua').map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
              <input
                className="ios-input"
                type="number"
                placeholder="Harga (Rupiah)"
                value={newPrice}
                onChange={(e) => setNewPrice(e.target.value)}
                required
              />
              <input
                className="ios-input"
                type="text"
                placeholder="Deskripsi singkat menu"
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
              />
              <button type="submit" className="btn-ios-primary" disabled={savingMenu}>
                <Plus size={17} /> {savingMenu ? 'Menyimpan...' : 'Simpan Menu'}
              </button>
            </div>
          </form>

          <div className="ios-grouped-card">
            {menuItems.map((item) => (
              <div
                key={item.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 12,
                  padding: '12px 14px',
                  borderBottom: '1px solid var(--border-hairline)'
                }}
              >
                <div className="speed-icon-badge" style={{ width: 40, height: 40 }}>
                  <Coffee size={17} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 700 }}>{item.name}</div>
                  <div style={{ fontSize: 12.5, color: 'var(--text-secondary)' }}>
                    {formatRupiah(item.price)} • {item.category}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onSaveMenuItem({ ...item, available: item.available === false })}
                  style={{
                    padding: '5px 10px',
                    borderRadius: 999,
                    border: 'none',
                    background:
                      item.available === false
                        ? 'rgba(255,69,58,0.16)'
                        : 'rgba(48,209,88,0.16)',
                    color: item.available === false ? '#ff453a' : '#30d158',
                    fontSize: 11.5,
                    fontWeight: 800,
                    cursor: 'pointer'
                  }}
                >
                  {item.available === false ? 'Habis' : 'Tersedia'}
                </button>
                <button
                  type="button"
                  onClick={() => onDeleteMenuItem(item.id)}
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: '50%',
                    border: 'none',
                    background: 'var(--bg-subtle)',
                    color: '#ff453a',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer'
                  }}
                >
                  <Trash2 size={15} />
                </button>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
