import React, { useState, useEffect, useRef } from 'react';
import { db } from '../firebase';
import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  setDoc,
  onSnapshot,
  query,
  where,
  getDocs,
} from 'firebase/firestore';
import {
  DEFAULT_CATEGORIES,
  ORDER_STATUS_LABELS,
  FALLBACK_COFFEE_IMG,
} from '../utils/constants';
import { compressAndConvertImage } from '../utils/imageCompressor';
import { CURRENT_APP_VERSION } from '../utils/versionUtils';
import {
  extractAmountFromNotification,
  QRIS_WEBHOOK_SECRET,
} from '../utils/qrisAutoMatcher';
import { sanitizeText, sanitizeSafeUrl, sanitizeImageUrl } from '../utils/securityGuard';
import { triggerHaptic } from '../utils/soundEffects';
import { useSheetSwipeDismiss } from '../hooks/useSheetSwipeDismiss';
import {
  Plus,
  Trash2,
  CheckCircle,
  Upload,
  X,
  FolderPlus,
  Smartphone,
  Link,
  Send,
  AlertCircle,
  Zap,
  Copy,
  Check,
  Store,
} from 'lucide-react';

export default function SellerView({
  swipeDir = 'none',
  orders,
  sellerSubTab,
  setSellerSubTab,
  showToast,
  storeOpen = true,
}) {
  const [menuList, setMenuList] = useState([]);
  const [categories, setCategories] = useState(DEFAULT_CATEGORIES);
  const [newCatName, setNewCatName] = useState('');

  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('Signature');
  const [desc, setDesc] = useState('');
  const [imgBase64, setImgBase64] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [loadingMenu, setLoadingMenu] = useState(false);

  const [qrisBase64, setQrisBase64] = useState('');
  const [loadingQris, setLoadingQris] = useState(false);

  const [simNotifText, setSimNotifText] = useState('');
  const [testingAutoPay, setTestingAutoPay] = useState(false);
  const [copiedWebhook, setCopiedWebhook] = useState(false);

  const [latestVersion, setLatestVersion] = useState(CURRENT_APP_VERSION);
  const [apkUrl, setApkUrl] = useState('');
  const [releaseNotes, setReleaseNotes] = useState('');
  const [forceUpdate, setForceUpdate] = useState(false);
  const [publishingUpdate, setPublishingUpdate] = useState(false);

  const menuFileInputRef = useRef(null);
  const qrisFileInputRef = useRef(null);

  const { sheetDragStyle: addModalDragStyle, sheetSwipeHandlers: addModalSwipeHandlers } =
    useSheetSwipeDismiss({
      onClose: () => setIsAddModalOpen(false),
      enabled: isAddModalOpen,
    });

  useEffect(() => {
    const unsubMenu = onSnapshot(collection(db, 'menu'), (snap) => {
      setMenuList(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });
    const unsubCat = onSnapshot(doc(db, 'settings', 'categories'), (docSnap) => {
      if (docSnap.exists() && Array.isArray(docSnap.data().list)) {
        const list = docSnap.data().list;
        setCategories(list);
        if (list.length > 0 && !list.includes(category)) {
          setCategory(list[0]);
        }
      } else {
        setCategories(DEFAULT_CATEGORIES);
      }
    });
    const unsubQris = onSnapshot(doc(db, 'settings', 'payment'), (docSnap) => {
      if (docSnap.exists() && docSnap.data().qrisBase64) {
        setQrisBase64(sanitizeImageUrl(docSnap.data().qrisBase64, ''));
      }
    });
    const unsubAppInfo = onSnapshot(doc(db, 'settings', 'app_info'), (docSnap) => {
      if (docSnap.exists()) {
        const d = docSnap.data();
        if (d.latestVersion) setLatestVersion(d.latestVersion);
        if (d.apkUrl !== undefined) setApkUrl(d.apkUrl);
        if (d.releaseNotes !== undefined) setReleaseNotes(d.releaseNotes);
        if (d.forceUpdate !== undefined) setForceUpdate(Boolean(d.forceUpdate));
      }
    });

    return () => {
      unsubMenu();
      unsubCat();
      unsubQris();
      unsubAppInfo();
    };
  }, []);

  const handleToggleStoreOpen = async () => {
    triggerHaptic(14);
    try {
      const nextOpen = !storeOpen;
      await setDoc(
        doc(db, 'settings', 'store'),
        { open: nextOpen, updatedAt: new Date().toISOString() },
        { merge: true }
      );
      showToast(nextOpen ? 'Toko 1001 SK dibuka!' : 'Toko 1001 SK ditutup sementara.');
    } catch {
      showToast('Gagal mengubah status toko');
    }
  };

  const handleAddCategory = async (e) => {
    e.preventDefault();
    const trimmed = sanitizeText(newCatName, 28);
    if (!trimmed) return;
    if (categories.some((c) => c.toLowerCase() === trimmed.toLowerCase())) {
      showToast('Kategori tersebut sudah ada!');
      return;
    }
    try {
      const updated = [...categories, trimmed];
      await setDoc(doc(db, 'settings', 'categories'), { list: updated });
      setNewCatName('');
      showToast(`Kategori "${trimmed}" ditambahkan!`);
    } catch {
      showToast('Gagal menambah kategori');
    }
  };

  const handleDeleteCategory = async (catToRemove) => {
    if (categories.length <= 1) {
      showToast('Minimal harus tersisa 1 kategori.');
      return;
    }
    try {
      const updated = categories.filter((c) => c !== catToRemove);
      await setDoc(doc(db, 'settings', 'categories'), { list: updated });
      showToast(`Kategori "${catToRemove}" dihapus`);
    } catch {
      showToast('Gagal menghapus kategori');
    }
  };

  const handleSelectMenuImage = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressAndConvertImage(file, 600, 600, 0.78);
      setImgBase64(compressed);
      showToast('Foto menu siap!');
    } catch (err) {
      showToast(err.message || 'Gagal memproses gambar');
    }
  };

  const handleAddMenu = async (e) => {
    e.preventDefault();
    const cleanName = sanitizeText(name, 60);
    const cleanDesc = sanitizeText(desc, 140);
    const numericPrice = Math.max(0, Math.round(Number(price) || 0));
    if (!cleanName || numericPrice <= 0) {
      showToast('Nama menu dan harga valid wajib diisi!');
      return;
    }
    setLoadingMenu(true);
    try {
      await addDoc(collection(db, 'menu'), {
        name: cleanName,
        price: numericPrice,
        category,
        description: cleanDesc,
        img: imgBase64 || FALLBACK_COFFEE_IMG,
        available: true,
        createdAt: new Date().toISOString(),
      });
      setName('');
      setPrice('');
      setDesc('');
      setImgBase64('');
      setIsAddModalOpen(false);
      showToast('Menu baru berhasil disimpan!');
    } catch (err) {
      showToast('Gagal menambah menu: ' + err.message);
    } finally {
      setLoadingMenu(false);
    }
  };

  const handleToggleStock = async (item) => {
    triggerHaptic(12);
    try {
      const nextStatus = item.available === false ? true : false;
      await updateDoc(doc(db, 'menu', item.id), { available: nextStatus });
      showToast(nextStatus ? `${item.name} kembali tersedia` : `${item.name} ditandai habis`);
    } catch {
      showToast('Gagal memperbarui stok');
    }
  };

  const handleDeleteMenu = async (id) => {
    triggerHaptic(14);
    try {
      await deleteDoc(doc(db, 'menu', id));
      showToast('Menu berhasil dihapus');
    } catch {
      showToast('Gagal menghapus menu');
    }
  };

  const handleSelectQrisImage = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoadingQris(true);
    try {
      const compressed = await compressAndConvertImage(file, 750, 750, 0.85);
      await setDoc(
        doc(db, 'settings', 'payment'),
        {
          qrisBase64: compressed,
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
      setQrisBase64(compressed);
      showToast('QRIS Toko berhasil diperbarui!');
    } catch (err) {
      showToast(err.message || 'Gagal mengunggah QRIS');
    } finally {
      setLoadingQris(false);
    }
  };

  const handleTestAutoPayment = async (e) => {
    e.preventDefault();
    const detected = extractAmountFromNotification(simNotifText);
    if (!detected) {
      showToast('Nominal tidak terbaca. Contoh: QRIS masuk Rp 25.432');
      return;
    }
    setTestingAutoPay(true);
    try {
      await addDoc(collection(db, 'qris_payments'), {
        secret: QRIS_WEBHOOK_SECRET,
        amount: detected,
        rawText: sanitizeText(simNotifText, 240),
        matched: false,
        createdAt: new Date().toISOString(),
      });
      setSimNotifText('');
      showToast(`Sinyal QRIS Rp ${detected.toLocaleString('id-ID')} dikirim!`);
    } catch (err) {
      showToast('Gagal mengirim sinyal QRIS: ' + err.message);
    } finally {
      setTestingAutoPay(false);
    }
  };

  const handleUpdateOrderStatus = async (orderId, newStatus) => {
    triggerHaptic(14);
    try {
      const payload = { status: newStatus };
      if (newStatus === 'pending') {
        payload.paymentStatus = 'paid';
        payload.paidAt = new Date().toISOString();
      }
      await updateDoc(doc(db, 'orders', orderId), payload);
      showToast(`Status pesanan: ${ORDER_STATUS_LABELS[newStatus] || newStatus}`);
    } catch {
      showToast('Gagal mengubah status');
    }
  };

  const handleDeleteOrder = async (orderId) => {
    triggerHaptic(14);
    try {
      await deleteDoc(doc(db, 'orders', orderId));
      showToast('Pesanan dihapus');
    } catch {
      showToast('Gagal menghapus pesanan');
    }
  };

  const handleClearCompletedOrders = async () => {
    triggerHaptic(16);
    try {
      const q = query(collection(db, 'orders'), where('status', '==', 'selesai'));
      const snap = await getDocs(q);
      await Promise.all(snap.docs.map((d) => deleteDoc(doc(db, 'orders', d.id))));
      showToast('Riwayat pesanan selesai dibersihkan!');
    } catch {
      showToast('Gagal membersihkan riwayat');
    }
  };

  const handlePublishAppUpdate = async (e) => {
    e.preventDefault();
    const cleanVer = sanitizeText(latestVersion, 20);
    if (!cleanVer) {
      showToast('Nomor versi wajib diisi');
      return;
    }
    const cleanUrl = apkUrl.trim() ? sanitizeSafeUrl(apkUrl.trim()) : '';
    if (apkUrl.trim() && !cleanUrl) {
      showToast('URL unduhan APK harus menggunakan HTTPS yang valid');
      return;
    }

    setPublishingUpdate(true);
    try {
      await setDoc(
        doc(db, 'settings', 'app_info'),
        {
          latestVersion: cleanVer,
          apkUrl: cleanUrl,
          releaseNotes: sanitizeText(releaseNotes, 600),
          forceUpdate,
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
      showToast(`Update v${cleanVer} berhasil dipublikasikan!`);
    } catch (err) {
      showToast('Gagal mempublikasikan update: ' + err.message);
    } finally {
      setPublishingUpdate(false);
    }
  };

  const activeOrders = orders.filter((o) => o.status !== 'selesai');
  const completedOrders = orders.filter((o) => o.status === 'selesai');

  const slideAnimClass =
    swipeDir === 'left'
      ? 'slide-from-right'
      : swipeDir === 'right'
      ? 'slide-from-left'
      : '';

  return (
    <div className={`page-transition ${slideAnimClass}`} style={{ padding: '4px 18px 20px' }}>
      {/* Store Open / Close Switch Pill */}
      <div
        className="glass-panel"
        style={{
          marginBottom: 14,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '12px 16px',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Store size={19} color={storeOpen ? 'var(--accent-green)' : 'var(--accent-red)'} />
          <div>
            <div style={{ fontSize: 14, fontWeight: 700 }}>
              {storeOpen ? 'Toko Buka' : 'Toko Tutup'}
            </div>
            <div style={{ fontSize: 11.5, color: 'var(--text-sub)' }}>
              {storeOpen ? 'Menerima pesanan baru' : 'Pemesanan ditutup sementara'}
            </div>
          </div>
        </div>
        <button
          type="button"
          className={`ios-switch ${storeOpen ? 'on' : ''}`}
          onClick={handleToggleStoreOpen}
          aria-label="Toggle Status Toko"
        >
          <span className="ios-switch-knob" />
        </button>
      </div>

      {/* SUB-TAB 1: PESANAN MASUK */}
      {sellerSubTab === 'orders' && (
        <div>
          {activeOrders.length === 0 ? (
            <div className="glass-panel" style={{ textAlign: 'center', padding: 30, marginBottom: 14 }}>
              <p style={{ fontSize: 13.5, color: 'var(--text-sub)' }}>
                Belum ada antrean pesanan baru.
              </p>
            </div>
          ) : (
            activeOrders.map((ord, idx) => {
              const isWaitingQris = ord.status === 'menunggu_pembayaran';
              return (
                <div
                  key={ord.id}
                  className="glass-panel vertical-stagger-in"
                  style={{ marginBottom: 14, animationDelay: `${Math.min(0.24, idx * 0.04)}s` }}
                >
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'flex-start',
                      gap: 8,
                    }}
                  >
                    <div>
                      <strong style={{ fontSize: 15.5 }}>{ord.customerName}</strong>
                      <div style={{ fontSize: 12, color: 'var(--text-sub)', marginTop: 2 }}>
                        Meja {ord.tableNumber} • QRIS
                      </div>
                    </div>
                    <span className={`badge-status status-${ord.status}`}>
                      {ORDER_STATUS_LABELS[ord.status] || ord.status}
                    </span>
                  </div>

                  <div
                    style={{
                      margin: '10px 0',
                      borderTop: '1px solid var(--hairline)',
                      paddingTop: 8,
                    }}
                  >
                    {ord.items?.map((item, i) => (
                      <div
                        key={i}
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          fontSize: 13,
                          marginBottom: 3,
                        }}
                      >
                        <span>
                          {item.qty}x {item.name}
                        </span>
                        <span>Rp {(item.price * item.qty).toLocaleString('id-ID')}</span>
                      </div>
                    ))}
                  </div>

                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      fontWeight: 800,
                      marginBottom: 10,
                    }}
                  >
                    <span>Total Tagihan</span>
                    <span style={{ color: 'var(--accent-primary)' }}>
                      Rp {ord.totalPrice?.toLocaleString('id-ID')}
                    </span>
                  </div>

                  <div style={{ display: 'flex', gap: 8 }}>
                    {isWaitingQris && (
                      <button
                        type="button"
                        className="ios-btn-primary"
                        style={{ marginTop: 0, padding: '10px 12px', fontSize: 12.5, flex: 1 }}
                        onClick={() => handleUpdateOrderStatus(ord.id, 'pending')}
                      >
                        Verifikasi Lunas
                      </button>
                    )}
                    {ord.status === 'pending' && (
                      <button
                        type="button"
                        className="ios-btn-primary"
                        style={{ marginTop: 0, padding: '10px 12px', fontSize: 12.5, flex: 1 }}
                        onClick={() => handleUpdateOrderStatus(ord.id, 'diproses')}
                      >
                        Mulai Racik
                      </button>
                    )}
                    {ord.status === 'diproses' && (
                      <button
                        type="button"
                        className="ios-btn-primary"
                        style={{ marginTop: 0, padding: '10px 12px', fontSize: 12.5, flex: 1 }}
                        onClick={() => handleUpdateOrderStatus(ord.id, 'siap')}
                      >
                        Tandai Siap
                      </button>
                    )}
                    {(ord.status === 'siap' || ord.status === 'siap_diambil') && (
                      <button
                        type="button"
                        className="ios-btn-primary"
                        style={{
                          marginTop: 0,
                          padding: '10px 12px',
                          fontSize: 12.5,
                          flex: 1,
                          background: 'var(--accent-green)',
                        }}
                        onClick={() => handleUpdateOrderStatus(ord.id, 'selesai')}
                      >
                        Selesaikan
                      </button>
                    )}
                    <button
                      type="button"
                      className="delete-icon-btn"
                      onClick={() => handleDeleteOrder(ord.id)}
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              );
            })
          )}

          {completedOrders.length > 0 && (
            <div className="glass-panel" style={{ marginTop: 10 }}>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: 8,
                }}
              >
                <strong style={{ fontSize: 13.5 }}>Selesai ({completedOrders.length})</strong>
                <button
                  type="button"
                  onClick={handleClearCompletedOrders}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: 'var(--accent-red)',
                    fontSize: 12,
                    fontWeight: 700,
                    cursor: 'pointer',
                  }}
                >
                  Bersihkan
                </button>
              </div>
              {completedOrders.slice(0, 5).map((ord) => (
                <div
                  key={ord.id}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    fontSize: 12.5,
                    padding: '6px 0',
                    borderTop: '1px solid var(--hairline)',
                  }}
                >
                  <span>
                    {ord.customerName} (Meja {ord.tableNumber})
                  </span>
                  <span style={{ fontWeight: 700 }}>
                    Rp {ord.totalPrice?.toLocaleString('id-ID')}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 2: KELOLA MENU & KATEGORI */}
      {sellerSubTab === 'menu' && (
        <div>
          <button
            type="button"
            className="ios-btn-primary"
            style={{ marginTop: 0, marginBottom: 14 }}
            onClick={() => setIsAddModalOpen(true)}
          >
            <Plus size={18} />
            <span>Tambah Menu Baru</span>
          </button>

          <div className="glass-panel" style={{ marginBottom: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
              <FolderPlus size={16} color="var(--accent-primary)" />
              <strong style={{ fontSize: 14 }}>Kategori Menu</strong>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 10 }}>
              {categories.map((c) => (
                <span key={c} className="cat-chip">
                  <span>{c}</span>
                  <button type="button" onClick={() => handleDeleteCategory(c)}>
                    <X size={13} />
                  </button>
                </span>
              ))}
            </div>
            <form onSubmit={handleAddCategory} style={{ display: 'flex', gap: 8 }}>
              <input
                type="text"
                className="ios-input"
                style={{ marginTop: 0 }}
                placeholder="Nama kategori baru..."
                value={newCatName}
                onChange={(e) => setNewCatName(e.target.value)}
              />
              <button
                type="submit"
                className="ios-btn-primary"
                style={{ marginTop: 0, width: 'auto', padding: '0 16px' }}
              >
                Tambah
              </button>
            </form>
          </div>

          <div className="menu-grid" style={{ padding: 0 }}>
            {menuList.map((item) => {
              const isAvailable = item.available !== false;
              return (
                <div key={item.id} className="menu-card">
                  <div>
                    <div className="menu-img-wrap" onClick={() => handleToggleStock(item)}>
                      <img
                        src={sanitizeImageUrl(item.img, FALLBACK_COFFEE_IMG)}
                        alt={item.name}
                        className="menu-img"
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = FALLBACK_COFFEE_IMG;
                        }}
                      />
                      <span className="menu-cat-pill">{item.category}</span>
                    </div>
                    <h3 className="menu-title">{item.name}</h3>
                    <div className="menu-price" style={{ marginBottom: 8 }}>
                      Rp {item.price?.toLocaleString('id-ID')}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button
                      type="button"
                      className="btn-add"
                      style={{ flex: 1, justifyContent: 'center' }}
                      onClick={() => handleToggleStock(item)}
                    >
                      {isAvailable ? 'Tersedia' : 'Habis'}
                    </button>
                    <button
                      type="button"
                      className="delete-icon-btn"
                      onClick={() => handleDeleteMenu(item.id)}
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {isAddModalOpen && (
            <div className="ios-modal-overlay" onClick={() => setIsAddModalOpen(false)}>
              <div
                className="ios-modal-sheet"
                style={addModalDragStyle}
                {...addModalSwipeHandlers}
                onClick={(e) => e.stopPropagation()}
              >
                <div className="sheet-handle" />
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: 12,
                  }}
                >
                  <h3 style={{ fontSize: 17, fontWeight: 800 }}>Tambah Menu Baru</h3>
                  <button
                    type="button"
                    onClick={() => setIsAddModalOpen(false)}
                    style={{
                      background: 'none',
                      border: 'none',
                      color: 'var(--text-sub)',
                      cursor: 'pointer',
                    }}
                  >
                    <X size={20} />
                  </button>
                </div>

                <form onSubmit={handleAddMenu}>
                  <input
                    type="file"
                    accept="image/*"
                    ref={menuFileInputRef}
                    style={{ display: 'none' }}
                    onChange={handleSelectMenuImage}
                  />
                  {imgBase64 ? (
                    <div
                      className="preview-img-container"
                      onClick={() => menuFileInputRef.current?.click()}
                    >
                      <img src={imgBase64} alt="Preview" />
                    </div>
                  ) : (
                    <div
                      className="image-picker-box"
                      onClick={() => menuFileInputRef.current?.click()}
                    >
                      <Upload size={22} color="var(--accent-primary)" />
                      <div style={{ fontSize: 12.5, fontWeight: 600, marginTop: 4 }}>
                        Ketuk untuk unggah foto menu
                      </div>
                    </div>
                  )}

                  <input
                    type="text"
                    className="ios-input"
                    placeholder="Nama Menu (contoh: Kopi Susu 1001)"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                  <input
                    type="number"
                    className="ios-input"
                    placeholder="Harga (Rp)"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    required
                  />
                  <select
                    className="ios-input"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                  >
                    {categories.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                  <input
                    type="text"
                    className="ios-input"
                    placeholder="Deskripsi singkat..."
                    value={desc}
                    onChange={(e) => setDesc(e.target.value)}
                  />

                  <button type="submit" className="ios-btn-primary" disabled={loadingMenu}>
                    {loadingMenu ? 'Menyimpan...' : 'Simpan Menu'}
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 3: QRIS & AUTO-VERIFIKASI */}
      {sellerSubTab === 'qris' && (
        <div className="glass-panel">
          <h3 style={{ fontSize: 16, fontWeight: 800, marginBottom: 4 }}>
            QRIS &amp; Auto-Verifikasi
          </h3>
          <p style={{ fontSize: 12.5, color: 'var(--text-sub)', marginBottom: 12 }}>
            Unggah gambar QRIS toko Anda agar pembeli dapat membayar langsung.
          </p>

          <input
            type="file"
            accept="image/*"
            ref={qrisFileInputRef}
            style={{ display: 'none' }}
            onChange={handleSelectQrisImage}
          />
          {qrisBase64 ? (
            <div
              style={{ textAlign: 'center', marginBottom: 14, cursor: 'pointer' }}
              onClick={() => qrisFileInputRef.current?.click()}
            >
              <img
                src={qrisBase64}
                alt="QRIS Toko"
                style={{
                  maxWidth: 220,
                  borderRadius: 16,
                  border: '1px solid var(--glass-border)',
                }}
              />
              <div style={{ fontSize: 12, color: 'var(--accent-primary)', marginTop: 6, fontWeight: 700 }}>
                {loadingQris ? 'Mengunggah...' : 'Ketuk gambar untuk ganti QRIS'}
              </div>
            </div>
          ) : (
            <div
              className="image-picker-box"
              style={{ marginBottom: 14 }}
              onClick={() => qrisFileInputRef.current?.click()}
            >
              <Upload size={24} color="var(--accent-primary)" />
              <div style={{ fontSize: 13, fontWeight: 700, marginTop: 6 }}>
                Unggah Foto QRIS Toko
              </div>
            </div>
          )}

          <div
            style={{
              borderTop: '1px solid var(--hairline)',
              paddingTop: 12,
              marginTop: 8,
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
              <Zap size={15} color="var(--accent-orange)" />
              <strong style={{ fontSize: 13.5 }}>Webhook Secret</strong>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 12 }}>
              <code
                style={{
                  flex: 1,
                  padding: '8px 10px',
                  borderRadius: 10,
                  background: 'var(--bg-grouped)',
                  fontSize: 12,
                }}
              >
                {QRIS_WEBHOOK_SECRET}
              </code>
              <button
                type="button"
                className="btn-add"
                onClick={() => {
                  navigator.clipboard?.writeText(QRIS_WEBHOOK_SECRET);
                  setCopiedWebhook(true);
                  setTimeout(() => setCopiedWebhook(false), 2000);
                }}
              >
                {copiedWebhook ? <Check size={13} /> : <Copy size={13} />}
              </button>
            </div>

            <form onSubmit={handleTestAutoPayment}>
              <input
                type="text"
                className="ios-input"
                placeholder="Simulasi notif: QRIS masuk Rp 25.432"
                value={simNotifText}
                onChange={(e) => setSimNotifText(e.target.value)}
              />
              <button
                type="submit"
                className="ios-btn-secondary"
                disabled={testingAutoPay}
              >
                <CheckCircle size={15} />
                <span>{testingAutoPay ? 'Memproses...' : 'Tes Verifikasi Nominal'}</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* SUB-TAB 4: BROADCAST UPDATE APLIKASI */}
      {sellerSubTab === 'update' && (
        <div className="glass-panel">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            <Smartphone size={18} color="var(--accent-primary)" />
            <h3 style={{ fontSize: 16, fontWeight: 800 }}>Update Aplikasi Pembeli</h3>
          </div>
          <p style={{ fontSize: 12.5, color: 'var(--text-sub)', marginBottom: 12 }}>
            Versi saat ini: <strong>v{CURRENT_APP_VERSION}</strong>. Masukkan link Google Drive APK terbaru.
          </p>

          <form onSubmit={handlePublishAppUpdate}>
            <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-sub)' }}>
              Versi Terbaru
            </label>
            <input
              type="text"
              className="ios-input"
              placeholder="Contoh: 2.9.0"
              value={latestVersion}
              onChange={(e) => setLatestVersion(e.target.value)}
              required
            />

            <label
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 5,
                fontSize: 12,
                fontWeight: 600,
                color: 'var(--text-sub)',
                marginTop: 10,
              }}
            >
              <Link size={13} /> Link Download APK (Google Drive HTTPS)
            </label>
            <input
              type="url"
              className="ios-input"
              placeholder="https://drive.google.com/file/d/.../view"
              value={apkUrl}
              onChange={(e) => setApkUrl(e.target.value)}
            />

            <label
              style={{
                display: 'block',
                fontSize: 12,
                fontWeight: 600,
                color: 'var(--text-sub)',
                marginTop: 10,
              }}
            >
              Catatan Rilis
            </label>
            <textarea
              className="ios-input"
              rows={3}
              placeholder="Pembaruan fitur dan animasi..."
              value={releaseNotes}
              onChange={(e) => setReleaseNotes(e.target.value)}
            />

            <label
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                marginTop: 12,
                fontSize: 13,
                cursor: 'pointer',
              }}
            >
              <input
                type="checkbox"
                checked={forceUpdate}
                onChange={(e) => setForceUpdate(e.target.checked)}
              />
              <AlertCircle size={15} color="var(--accent-red)" />
              <span>Wajibkan pembeli mengunduh versi ini</span>
            </label>

            <button type="submit" className="ios-btn-primary" disabled={publishingUpdate}>
              <Send size={16} />
              <span>{publishingUpdate ? 'Menerbitkan...' : 'Publikasikan Update'}</span>
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
