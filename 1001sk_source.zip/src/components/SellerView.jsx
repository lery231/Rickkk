import React, { useState, useEffect, useRef } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot, doc, updateDoc, addDoc, deleteDoc, setDoc, query, orderBy } from 'firebase/firestore';
import { compressAndConvertImage } from '../utils/imageCompressor';
import { Receipt, Coffee, QrCode, Plus, Trash2, Camera, CheckCircle2, ArrowRight } from 'lucide-react';

export default function SellerView({ userRole, showToast }) {
  const [orders, setOrders] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [activeTab, setActiveTab] = useState('orders');
  const [filterStatus, setFilterStatus] = useState('Semua');
  const [isAddMenuOpen, setIsAddMenuOpen] = useState(false);

  const [newMenuName, setNewMenuName] = useState('');
  const [newMenuCategory, setNewMenuCategory] = useState('Signature');
  const [newMenuPrice, setNewMenuPrice] = useState('');
  const [newMenuDesc, setNewMenuDesc] = useState('');
  const [productImgUrl, setProductImgUrl] = useState('');
  const [uploadingImg, setUploadingImg] = useState(false);

  const [qrisImgUrl, setQrisImgUrl] = useState('');
  const [uploadingQris, setUploadingQris] = useState(false);

  const productFileInputRef = useRef(null);
  const qrisFileInputRef = useRef(null);

  useEffect(() => {
    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    const unsubOrders = onSnapshot(q, (snap) => {
      setOrders(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, () => {});

    const unsubMenu = onSnapshot(collection(db, 'menu'), (snap) => {
      setMenuItems(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, () => {});

    const unsubQris = onSnapshot(doc(db, 'settings', 'qris'), (docSnap) => {
      if (docSnap.exists()) {
        setQrisImgUrl(docSnap.data().qrisImage);
      }
    }, () => {});

    return () => {
      unsubOrders();
      unsubQris();
      unsubMenu();
    };
  }, []);

  const handleProductImageSelect = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingImg(true);
    try {
      const base64Img = await compressAndConvertImage(file, 600, 600, 0.75);
      setProductImgUrl(base64Img);
      if (showToast) showToast('Foto produk siap digunakan');
    } catch (err) {
      if (showToast) showToast('Gagal memproses gambar: ' + err.message);
    } finally {
      setUploadingImg(false);
    }
  };

  const handleQrisImageSelect = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingQris(true);
    try {
      const base64Img = await compressAndConvertImage(file, 800, 800, 0.85);
      setQrisImgUrl(base64Img);
      await setDoc(doc(db, 'settings', 'qris'), {
        qrisImage: base64Img,
        updatedAt: new Date().toISOString()
      });
      if (showToast) showToast('Barcode QRIS Toko berhasil diperbarui!');
    } catch (err) {
      if (showToast) showToast('Gagal mengunggah QRIS: ' + err.message);
    } finally {
      setUploadingQris(false);
    }
  };

  const updateOrderStatus = async (orderId, newStatus) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), { status: newStatus });
      if (showToast) showToast(`Status pesanan diubah ke ${newStatus.toUpperCase()}`);
    } catch (err) {
      if (showToast) showToast('Gagal update status: ' + err.message);
    }
  };

  const handleAddMenu = async (e) => {
    e.preventDefault();
    if (!newMenuName || !newMenuPrice) return;
    try {
      await addDoc(collection(db, 'menu'), {
        name: newMenuName,
        category: newMenuCategory,
        price: parseInt(newMenuPrice, 10),
        desc: newMenuDesc || 'Racikan Kopi Spesial 1001 SK',
        img: productImgUrl || 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80',
        stock: true,
        createdAt: new Date().toISOString()
      });
      if (showToast) showToast('Menu baru berhasil ditambahkan!');
      setIsAddMenuOpen(false);
      setNewMenuName('');
      setNewMenuPrice('');
      setNewMenuDesc('');
      setProductImgUrl('');
    } catch (err) {
      if (showToast) showToast('Gagal menambah menu: ' + err.message);
    }
  };

  const handleDeleteMenu = async (id) => {
    if (window.confirm('Hapus menu ini dari daftar?')) {
      await deleteDoc(doc(db, 'menu', id));
      if (showToast) showToast('Menu berhasil dihapus');
    }
  };

  const totalOmset = orders
    .filter(o => o.status === 'selesai')
    .reduce((sum, o) => sum + (o.totalPrice || 0), 0);

  const filteredOrders = filterStatus === 'Semua' 
    ? orders 
    : orders.filter(o => o.status === filterStatus.toLowerCase());

  return (
    <div style={{ padding: 20 }} className="page-transition">
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 18 }}>
        <div className="glass-panel" style={{ padding: 16 }}>
          <div style={{ fontSize: 11.5, color: 'var(--text-sub)', fontWeight: 600 }}>Omset Selesai</div>
          <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--accent-gold)', marginTop: 4 }}>
            Rp {totalOmset.toLocaleString('id-ID')}
          </div>
        </div>
        <div className="glass-panel" style={{ padding: 16 }}>
          <div style={{ fontSize: 11.5, color: 'var(--text-sub)', fontWeight: 600 }}>Pesanan Baru</div>
          <div style={{ fontSize: 18, fontWeight: 800, color: '#fff', marginTop: 4 }}>
            {orders.filter(o => o.status === 'pending').length} Antrean
          </div>
        </div>
      </div>

      <div className="ios-tabs" style={{ paddingLeft: 0, paddingRight: 0, marginBottom: 12 }}>
        <button className={`tab-btn ${activeTab === 'orders' ? 'active' : ''}`} onClick={() => setActiveTab('orders')}>
          <Receipt size={14} /> Pesanan ({orders.length})
        </button>
        <button className={`tab-btn ${activeTab === 'menu' ? 'active' : ''}`} onClick={() => setActiveTab('menu')}>
          <Coffee size={14} /> Kelola Menu
        </button>
        <button className={`tab-btn ${activeTab === 'qris' ? 'active' : ''}`} onClick={() => setActiveTab('qris')}>
          <QrCode size={14} /> Set QRIS Toko
        </button>
      </div>

      {activeTab === 'orders' && (
        <div className="page-transition">
          <div className="ios-tabs" style={{ paddingLeft: 0, paddingTop: 4, marginBottom: 12 }}>
            {['Semua', 'Pending', 'Diproses', 'Siap', 'Selesai'].map(st => (
              <button key={st} className={`tab-btn ${filterStatus === st ? 'active' : ''}`} onClick={() => setFilterStatus(st)}>
                {st}
              </button>
            ))}
          </div>

          {filteredOrders.length === 0 ? (
            <div className="glass-panel" style={{ padding: 24, textAlign: 'center', color: 'var(--text-sub)' }}>
              Tidak ada pesanan pada kategori ini.
            </div>
          ) : (
            filteredOrders.map((ord, idx) => (
              <div 
                key={ord.id} 
                className="glass-panel stagger-item" 
                style={{ padding: 16, marginBottom: 14, animationDelay: `${Math.min(idx * 45, 320)}ms` }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <div>
                    <div style={{ fontSize: 15.5, fontWeight: 800, color: '#fff' }}>{ord.customerName}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>
                      {ord.orderType} • {ord.tableNo} • {ord.paymentMethod}
                    </div>
                  </div>
                  <span className={`badge-status status-${ord.status}`}>{ord.status}</span>
                </div>

                <div style={{ borderTop: '1px solid var(--glass-border)', borderBottom: '1px solid var(--glass-border)', padding: '8px 0', margin: '8px 0' }}>
                  {ord.items?.map((it, i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, margin: '3px 0' }}>
                      <span>{it.qty}x {it.name}</span>
                      <span>Rp {(it.price * it.qty).toLocaleString('id-ID')}</span>
                    </div>
                  ))}
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 800, marginTop: 8, color: 'var(--accent-gold)' }}>
                    <span>Total Tagihan</span>
                    <span>Rp {ord.totalPrice?.toLocaleString('id-ID')}</span>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                  {ord.status === 'pending' && (
                    <button className="ios-btn-primary" style={{ padding: '10px 14px', fontSize: 13, marginTop: 0 }} onClick={() => updateOrderStatus(ord.id, 'diproses')}>
                      Terima & Proses <ArrowRight size={15} />
                    </button>
                  )}
                  {ord.status === 'diproses' && (
                    <button className="ios-btn-primary" style={{ padding: '10px 14px', fontSize: 13, marginTop: 0, background: 'linear-gradient(135deg, #0a84ff, #3898ff)', color: '#fff' }} onClick={() => updateOrderStatus(ord.id, 'siap')}>
                      Tandai Siap Diambil <ArrowRight size={15} />
                    </button>
                  )}
                  {ord.status === 'siap' && (
                    <button className="ios-btn-primary" style={{ padding: '10px 14px', fontSize: 13, marginTop: 0, background: 'linear-gradient(135deg, #32d74b, #28cd41)', color: '#08120a' }} onClick={() => updateOrderStatus(ord.id, 'selesai')}>
                      <CheckCircle2 size={15} /> Selesaikan Pesanan
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'menu' && (
        <div className="page-transition">
          <button className="ios-btn-primary" style={{ marginBottom: 16, marginTop: 0 }} onClick={() => setIsAddMenuOpen(true)}>
            <Plus size={17} /> Tambah Menu Baru (Galeri HP)
          </button>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {menuItems.map((item, idx) => (
              <div 
                key={item.id} 
                className="glass-panel stagger-item" 
                style={{ padding: 12, display: 'flex', gap: 12, alignItems: 'center', animationDelay: `${Math.min(idx * 45, 320)}ms` }}
              >
                <img src={item.img} alt={item.name} style={{ width: 58, height: 58, borderRadius: 14, objectFit: 'cover' }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 14.5, color: '#fff' }}>{item.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--accent-gold)', fontWeight: 700 }}>
                    Rp {item.price?.toLocaleString('id-ID')} • <span style={{ color: 'var(--text-sub)', fontWeight: 500 }}>{item.category}</span>
                  </div>
                </div>
                <button className="tab-btn" style={{ borderColor: 'rgba(255,69,58,0.45)', color: '#ff6961', padding: '8px 12px' }} onClick={() => handleDeleteMenu(item.id)}>
                  <Trash2 size={15} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'qris' && (
        <div className="glass-panel page-transition" style={{ padding: 20 }}>
          <h3 style={{ fontSize: 17.5, fontWeight: 800, marginBottom: 6 }}>Pengaturan QRIS Toko</h3>
          <p style={{ fontSize: 12, color: 'var(--text-sub)', marginBottom: 16, lineHeight: 1.4 }}>
            Unggah foto barcode QRIS dari galeri HP Anda. Gambar otomatis dikompresi dan langsung tampil saat pembeli memilih pembayaran QRIS.
          </p>

          <input 
            type="file" 
            accept="image/*" 
            ref={qrisFileInputRef} 
            style={{ display: 'none' }} 
            onChange={handleQrisImageSelect} 
          />

          <div className="image-picker-box" onClick={() => qrisFileInputRef.current?.click()}>
            {uploadingQris ? (
              <div style={{ padding: 24, color: 'var(--accent-gold)', fontWeight: 600 }}>Mengompresi & menyimpan QRIS...</div>
            ) : qrisImgUrl ? (
              <div>
                <div className="qris-display-box" style={{ margin: '0 auto 12px', maxWidth: 250 }}>
                  <img src={qrisImgUrl} alt="QRIS Toko" />
                </div>
                <button type="button" className="tab-btn" style={{ borderColor: 'var(--accent-gold)', color: 'var(--accent-gold)' }}>
                  <Camera size={14} /> Ganti Gambar QRIS dari Galeri
                </button>
              </div>
            ) : (
              <div style={{ padding: '26px 10px' }}>
                <Camera size={32} color="var(--accent-gold)" style={{ margin: '0 auto 8px' }} />
                <div style={{ fontWeight: 700, fontSize: 14 }}>Pilih Foto QRIS dari Galeri HP</div>
                <div style={{ fontSize: 11, color: 'var(--text-sub)', marginTop: 4 }}>Mendukung format JPG / PNG / WEBP</div>
              </div>
            )}
          </div>
        </div>
      )}

      {isAddMenuOpen && (
        <div className="ios-modal-overlay" onClick={() => setIsAddMenuOpen(false)}>
          <div className="ios-modal-sheet" onClick={e => e.stopPropagation()}>
            <div className="sheet-handle" />
            <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 16 }}>Tambah Menu Kopi 1001 SK</h3>
            <form onSubmit={handleAddMenu}>
              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 600 }}>Foto Produk (Dari Galeri HP)</label>
                <input 
                  type="file" 
                  accept="image/*" 
                  ref={productFileInputRef} 
                  style={{ display: 'none' }} 
                  onChange={handleProductImageSelect} 
                />

                {uploadingImg ? (
                  <div className="image-picker-box" style={{ padding: 20, color: 'var(--accent-gold)' }}>
                    Mengoptimalkan resolusi foto...
                  </div>
                ) : productImgUrl ? (
                  <div className="preview-img-container" onClick={() => productFileInputRef.current?.click()}>
                    <img src={productImgUrl} alt="Preview Produk" />
                    <div style={{ position: 'absolute', bottom: 8, right: 8, background: 'rgba(12,10,22,0.78)', backdropFilter: 'blur(10px)', padding: '5px 10px', borderRadius: 10, fontSize: 11, color: '#fff', fontWeight: 600 }}>
                      Ganti Foto
                    </div>
                  </div>
                ) : (
                  <div className="image-picker-box" onClick={() => productFileInputRef.current?.click()}>
                    <Camera size={26} color="var(--accent-gold)" style={{ margin: '0 auto 6px' }} />
                    <div style={{ fontWeight: 600, fontSize: 13 }}>Ketuk untuk Ambil Foto dari Galeri</div>
                  </div>
                )}
              </div>

              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 600 }}>Nama Menu</label>
                <input type="text" className="ios-input" value={newMenuName} onChange={e => setNewMenuName(e.target.value)} placeholder="Contoh: Kopi Susu Aren" required />
              </div>
              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 600 }}>Kategori</label>
                <select className="ios-input" value={newMenuCategory} onChange={e => setNewMenuCategory(e.target.value)}>
                  <option value="Signature">Signature 1001 SK</option>
                  <option value="Espresso">Espresso Base</option>
                  <option value="Non-Kopi">Non-Kopi</option>
                  <option value="Camilan">Camilan / Makanan</option>
                </select>
              </div>
              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 600 }}>Harga (Rp)</label>
                <input type="number" className="ios-input" value={newMenuPrice} onChange={e => setNewMenuPrice(e.target.value)} placeholder="18000" required />
              </div>
              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 600 }}>Deskripsi Singkat</label>
                <input type="text" className="ios-input" value={newMenuDesc} onChange={e => setNewMenuDesc(e.target.value)} placeholder="Deskripsi rasa & komposisi..." />
              </div>
              <button type="submit" className="ios-btn-primary">Simpan Menu Baru</button>
              <button type="button" className="ios-btn-secondary" onClick={() => setIsAddMenuOpen(false)}>Batal</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
