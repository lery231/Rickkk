import React, { useState, useEffect, useRef } from 'react';
import { db } from '../firebase';
import { collection, onSnapshot, doc, updateDoc, addDoc, deleteDoc, setDoc } from 'firebase/firestore';
import { compressAndConvertImage } from '../utils/imageCompressor';
import { Receipt, Coffee, QrCode, Plus, Trash2, Camera, CheckCircle2, ArrowRight, Volume2, ShieldCheck, Store, X } from 'lucide-react';
import { playNewOrderChime, triggerHaptic } from '../utils/soundEffects';
import { DEFAULT_CATEGORIES } from '../utils/constants';

export default function SellerView({ orders, sellerSubTab, setSellerSubTab, showToast, storeOpen }) {
  const [menuItems, setMenuItems] = useState([]);
  const [filterStatus, setFilterStatus] = useState('Semua');
  const [isAddMenuOpen, setIsAddMenuOpen] = useState(false);
  const [categories, setCategories] = useState(DEFAULT_CATEGORIES);
  const [newCatName, setNewCatName] = useState('');

  const [newMenuName, setNewMenuName] = useState('');
  const [newMenuCategory, setNewMenuCategory] = useState('Signature');
  const [newMenuPrice, setNewMenuPrice] = useState('');
  const [newMenuDesc, setNewMenuDesc] = useState('');
  const [productImgUrl, setProductImgUrl] = useState('');
  const [uploadingImg, setUploadingImg] = useState(false);

  const [qrisImgUrl, setQrisImgUrl] = useState('');
  const [uploadingQris, setUploadingQris] = useState(false);

  const productFileInputRef = useRef(null);
  const qrisFileInputRef = useRef(null);

  useEffect(() => {
    const unsubMenu = onSnapshot(collection(db, 'menu'), (snap) => {
      setMenuItems(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, () => {});

    const unsubQris = onSnapshot(doc(db, 'settings', 'qris'), (docSnap) => {
      if (docSnap.exists()) {
        setQrisImgUrl(docSnap.data().qrisImage);
      }
    }, () => {});

    const unsubCat = onSnapshot(doc(db, 'settings', 'categories'), (snap) => {
      const list = snap.exists() ? snap.data().list : null;
      if (Array.isArray(list)) setCategories(list);
    }, () => {});

    return () => {
      unsubQris();
      unsubMenu();
      unsubCat();
    };
  }, []);

  const handleProductImageSelect = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingImg(true);
    try {
      const base64Img = await compressAndConvertImage(file, 600, 600, 0.75);
      setProductImgUrl(base64Img);
      if (showToast) showToast('Foto produk siap digunakan');
    } catch (err) {
      if (showToast) showToast('Gagal memproses gambar: ' + err.message);
    } finally {
      setUploadingImg(false);
    }
  };

  const handleQrisImageSelect = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingQris(true);
    try {
      const base64Img = await compressAndConvertImage(file, 800, 800, 0.85);
      setQrisImgUrl(base64Img);
      await setDoc(doc(db, 'settings', 'qris'), {
        qrisImage: base64Img,
        updatedAt: new Date().toISOString()
      });
      triggerHaptic(20);
      if (showToast) showToast('Barcode QRIS Toko berhasil diperbarui!');
    } catch (err) {
      if (showToast) showToast('Gagal mengunggah QRIS: ' + err.message);
    } finally {
      setUploadingQris(false);
    }
  };

  const updateOrderStatus = async (orderId, newStatus) => {
    triggerHaptic(16);
    try {
      await updateDoc(doc(db, 'orders', orderId), { status: newStatus });
      if (showToast) {
        if (newStatus === 'siap') {
          showToast('Status SIAP DIABIL — Notifikasi dikirim ke pembeli!');
        } else {
          showToast(`Status pesanan diubah ke ${newStatus.toUpperCase()}`);
        }
      }
    } catch (err) {
      if (showToast) showToast('Gagal update status: ' + err.message);
    }
  };

  const handleDeleteOrder = async (orderId) => {
    triggerHaptic(15);
    try {
      await deleteDoc(doc(db, 'orders', orderId));
      if (showToast) showToast('Riwayat pesanan dihapus');
    } catch (err) {
      if (showToast) showToast('Gagal menghapus pesanan: ' + err.message);
    }
  };

  const handleClearSelesai = async () => {
    const selesaiList = orders.filter(o => o.status === 'selesai');
    if (selesaiList.length === 0) {
      if (showToast) showToast('Tidak ada pesanan selesai untuk dihapus');
      return;
    }
    triggerHaptic(18);
    try {
      await Promise.all(selesaiList.map(o => deleteDoc(doc(db, 'orders', o.id))));
      if (showToast) showToast(`${selesaiList.length} riwayat pesanan selesai dihapus`);
    } catch (err) {
      if (showToast) showToast('Gagal menghapus riwayat: ' + err.message);
    }
  };

  const handleAddMenu = async (e) => {
    e.preventDefault();
    if (!newMenuName || !newMenuPrice) return;
    triggerHaptic(16);
    try {
      await addDoc(collection(db, 'menu'), {
        name: newMenuName,
        category: newMenuCategory,
        price: parseInt(newMenuPrice, 10),
        desc: newMenuDesc || 'Racikan Kopi Spesial 1001 SK',
        img: productImgUrl || 'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80',
        stock: true,
        createdAt: new Date().toISOString()
      });
      if (showToast) showToast('Menu baru berhasil ditambahkan!');
      setIsAddMenuOpen(false);
      setNewMenuName('');
      setNewMenuPrice('');
      setNewMenuDesc('');
      setProductImgUrl('');
    } catch (err) {
      if (showToast) showToast('Gagal menambah menu: ' + err.message);
    }
  };

  const handleDeleteMenu = async (id) => {
    triggerHaptic(15);
    await deleteDoc(doc(db, 'menu', id));
    if (showToast) showToast('Menu berhasil dihapus');
  };

  const toggleStore = async () => {
    triggerHaptic(18);
    try {
      await setDoc(doc(db, 'settings', 'store'), { open: !storeOpen, updatedAt: new Date().toISOString() }, { merge: true });
      if (showToast) showToast(!storeOpen ? 'Toko dibuka — pembeli bisa memesan' : 'Toko ditutup — pesanan baru dinonaktifkan');
    } catch (err) {
      if (showToast) showToast('Gagal mengubah status toko: ' + err.message);
    }
  };

  const toggleStock = async (item) => {
    triggerHaptic(14);
    const nextStock = item.stock === false;
    try {
      await updateDoc(doc(db, 'menu', item.id), { stock: nextStock });
      if (showToast) showToast(nextStock ? `${item.name} tersedia lagi` : `${item.name} ditandai habis`);
    } catch (err) {
      if (showToast) showToast('Gagal mengubah stok: ' + err.message);
    }
  };

  const saveCategories = async (list) => {
    try {
      await setDoc(doc(db, 'settings', 'categories'), { list, updatedAt: new Date().toISOString() });
    } catch (err) {
      if (showToast) showToast('Gagal menyimpan kategori: ' + err.message);
    }
  };

  const handleAddCategory = async () => {
    const name = newCatName.trim();
    if (!name) return;
    if (categories.some(c => c.toLowerCase() === name.toLowerCase())) {
      if (showToast) showToast('Kategori sudah ada');
      return;
    }
    triggerHaptic(14);
    setNewCatName('');
    await saveCategories([...categories, name]);
    if (showToast) showToast(`Kategori "${name}" ditambahkan`);
  };

  const handleDeleteCategory = async (name) => {
    const used = menuItems.filter(m => m.category === name).length;
    if (used > 0) {
      if (showToast) showToast(`Masih ada ${used} menu di kategori ${name}. Pindahkan/hapus menunya dulu.`);
      return;
    }
    triggerHaptic(15);
    await saveCategories(categories.filter(c => c !== name));
    if (showToast) showToast(`Kategori "${name}" dihapus`);
  };

  useEffect(() => {
    if (categories.length > 0 && !categories.includes(newMenuCategory)) setNewMenuCategory(categories[0]);
  }, [categories, newMenuCategory]);

  const totalOmset = orders
    .filter(o => o.status === 'selesai')
    .reduce((sum, o) => sum + (o.totalPrice || 0), 0);

  const filteredOrders = filterStatus === 'Semua'
    ? orders
    : orders.filter(o => o.status === filterStatus.toLowerCase());

  return (
    <div style={{ padding: 18 }} className="page-transition">
      {/* Seller Mode Notice Banner */}
      <div className="glass-panel" style={{ padding: '10px 14px', marginBottom: 14, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--text-sub)', fontWeight: 600 }}>
          <ShieldCheck size={16} color="var(--accent-primary)" />
          <span>Mode Kasir Seller • Geser kiri/kanan untuk pindah tab</span>
        </div>
        <button
          type="button"
          className="tab-btn"
          style={{ padding: '5px 10px', fontSize: 11 }}
          onClick={() => { playNewOrderChime(); if (showToast) showToast('Tes nada pesanan masuk berbunyi!'); }}
        >
          <Volume2 size={13} /> Tes Nada
        </button>
      </div>

      <div className="glass-panel" style={{ padding: '12px 14px', marginBottom: 14, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Store size={20} color={storeOpen ? 'var(--accent-green)' : 'var(--accent-red)'} />
          <div>
            <div style={{ fontSize: 14, fontWeight: 800 }}>Toko {storeOpen ? 'Buka' : 'Tutup'}</div>
            <div style={{ fontSize: 11.5, color: 'var(--text-sub)' }}>{storeOpen ? 'Pembeli bisa memesan' : 'Pesanan baru dinonaktifkan'}</div>
          </div>
        </div>
        <button
          type="button"
          className="tab-btn active"
          style={{ background: storeOpen ? 'var(--accent-red)' : 'var(--accent-green)', color: storeOpen ? '#fff' : '#071409' }}
          onClick={toggleStore}
        >
          {storeOpen ? 'Tutup Toko' : 'Buka Toko'}
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 14 }}>
        <div className="glass-panel" style={{ padding: 15 }}>
          <div style={{ fontSize: 11.5, color: 'var(--text-sub)', fontWeight: 700 }}>Omset Selesai</div>
          <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--accent-primary)', marginTop: 4 }}>
            Rp {totalOmset.toLocaleString('id-ID')}
          </div>
        </div>
        <div className="glass-panel" style={{ padding: 15 }}>
          <div style={{ fontSize: 11.5, color: 'var(--text-sub)', fontWeight: 700 }}>Antrean Masuk</div>
          <div style={{ fontSize: 18, fontWeight: 800, marginTop: 4 }}>
            {orders.filter(o => o.status === 'pending').length} Pesanan
          </div>
        </div>
      </div>

      <div className="ios-tabs" data-no-swipe="true" style={{ paddingLeft: 0, paddingRight: 0, marginBottom: 8 }}>
        <button className={`tab-btn ${sellerSubTab === 'orders' ? 'active' : ''}`} onClick={() => setSellerSubTab('orders')}>
          <Receipt size={14} /> Pesanan ({orders.length})
        </button>
        <button className={`tab-btn ${sellerSubTab === 'menu' ? 'active' : ''}`} onClick={() => setSellerSubTab('menu')}>
          <Coffee size={14} /> Kelola Menu
        </button>
        <button className={`tab-btn ${sellerSubTab === 'qris' ? 'active' : ''}`} onClick={() => setSellerSubTab('qris')}>
          <QrCode size={14} /> Set QRIS Toko
        </button>
      </div>

      {sellerSubTab === 'orders' && (
        <div className="page-transition">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10, gap: 8 }}>
            <div className="ios-tabs" data-no-swipe="true" style={{ padding: 0, flex: 1 }}>
              {['Semua', 'Pending', 'Diproses', 'Siap', 'Selesai'].map(st => (
                <button key={st} className={`tab-btn ${filterStatus === st ? 'active' : ''}`} onClick={() => setFilterStatus(st)}>
                  {st}
                </button>
              ))}
            </div>
            {orders.some(o => o.status === 'selesai') && (
              <button type="button" className="delete-icon-btn" onClick={handleClearSelesai}>
                <Trash2 size={13} /> Hapus Selesai
              </button>
            )}
          </div>

          {filteredOrders.length === 0 ? (
            <div className="glass-panel" style={{ padding: 24, textAlign: 'center', color: 'var(--text-sub)' }}>
              Tidak ada pesanan pada kategori ini.
            </div>
          ) : (
            filteredOrders.map((ord) => (
              <div key={ord.id} className="glass-panel" style={{ padding: 15, marginBottom: 13 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                  <div>
                    <div style={{ fontSize: 15.5, fontWeight: 800 }}>{ord.customerName}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>
                      {ord.orderType} • {ord.paymentMethod}
                    </div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span className={`badge-status status-${ord.status}`}>{ord.status}</span>
                    <button
                      type="button"
                      className="delete-icon-btn"
                      onClick={() => handleDeleteOrder(ord.id)}
                      title="Hapus riwayat pesanan"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>

                {ord.orderNote && (
                  <div style={{ fontSize: 11.5, color: 'var(--text-sub)', background: 'var(--glass-pill)', padding: '6px 10px', borderRadius: 10, marginBottom: 8 }}>
                    Catatan: {ord.orderNote}
                  </div>
                )}

                <div style={{ borderTop: '1px solid var(--glass-border)', borderBottom: '1px solid var(--glass-border)', padding: '8px 0', margin: '8px 0' }}>
                  {ord.items?.map((it, i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, margin: '3px 0' }}>
                      <span>{it.qty}x {it.name}</span>
                      <span>Rp {(it.price * it.qty).toLocaleString('id-ID')}</span>
                    </div>
                  ))}
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 800, marginTop: 8, color: 'var(--accent-primary)' }}>
                    <span>Total Tagihan</span>
                    <span>Rp {ord.totalPrice?.toLocaleString('id-ID')}</span>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                  {ord.status === 'pending' && (
                    <button className="ios-btn-primary" style={{ padding: '10px 14px', fontSize: 13, marginTop: 0 }} onClick={() => updateOrderStatus(ord.id, 'diproses')}>
                      Terima & Proses <ArrowRight size={15} />
                    </button>
                  )}
                  {ord.status === 'diproses' && (
                    <button className="ios-btn-primary" style={{ padding: '10px 14px', fontSize: 13, marginTop: 0, background: 'var(--accent-blue)', color: '#fff' }} onClick={() => updateOrderStatus(ord.id, 'siap')}>
                      Tandai Siap Diambil <ArrowRight size={15} />
                    </button>
                  )}
                  {ord.status === 'siap' && (
                    <button className="ios-btn-primary" style={{ padding: '10px 14px', fontSize: 13, marginTop: 0, background: 'var(--accent-green)', color: '#071409' }} onClick={() => updateOrderStatus(ord.id, 'selesai')}>
                      <CheckCircle2 size={15} /> Selesaikan Pesanan
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {sellerSubTab === 'menu' && (
        <div className="page-transition">
          <div className="glass-panel" style={{ padding: 14, marginBottom: 14 }}>
            <div style={{ fontSize: 13.5, fontWeight: 800, marginBottom: 10 }}>Kategori Menu</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 10 }}>
              {categories.length === 0 && <span style={{ fontSize: 12, color: 'var(--text-sub)' }}>Belum ada kategori.</span>}
              {categories.map(c => (
                <span key={c} className="cat-chip">
                  {c}
                  <button type="button" onClick={() => handleDeleteCategory(c)} aria-label={`Hapus kategori ${c}`}><X size={13} /></button>
                </span>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                type="text"
                className="ios-input"
                style={{ marginTop: 0 }}
                value={newCatName}
                onChange={(e) => setNewCatName(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleAddCategory(); } }}
                placeholder="Nama kategori baru"
              />
              <button type="button" className="tab-btn active" onClick={handleAddCategory}><Plus size={14} /> Tambah</button>
            </div>
          </div>

          <button className="ios-btn-primary" style={{ marginBottom: 14, marginTop: 0 }} onClick={() => setIsAddMenuOpen(true)}>
            <Plus size={17} /> Tambah Menu Baru (Galeri HP)
          </button>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
            {menuItems.map((item) => (
              <div key={item.id} className="glass-panel" style={{ padding: 12, display: 'flex', gap: 12, alignItems: 'center' }}>
                <img src={item.img} alt={item.name} style={{ width: 56, height: 56, borderRadius: 14, objectFit: 'cover' }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 800, fontSize: 14.5 }}>{item.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--accent-primary)', fontWeight: 700 }}>
                    Rp {item.price?.toLocaleString('id-ID')} • <span style={{ color: 'var(--text-sub)', fontWeight: 600 }}>{item.category}</span>
                  </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'stretch' }}>
                  <button
                    type="button"
                    className="tab-btn"
                    style={{ padding: '6px 10px', fontSize: 11.5, color: item.stock === false ? 'var(--accent-red)' : 'var(--accent-green)' }}
                    onClick={() => toggleStock(item)}
                  >
                    {item.stock === false ? 'Habis' : 'Tersedia'}
                  </button>
                  <button className="delete-icon-btn" style={{ padding: '6px 10px' }} onClick={() => handleDeleteMenu(item.id)} aria-label="Hapus menu">
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {sellerSubTab === 'qris' && (
        <div className="glass-panel page-transition" style={{ padding: 18 }}>
          <h3 style={{ fontSize: 17.5, fontWeight: 800, marginBottom: 6 }}>Pengaturan QRIS Toko</h3>
          <p style={{ fontSize: 12, color: 'var(--text-sub)', marginBottom: 14, lineHeight: 1.4 }}>
            Unggah foto barcode QRIS dari galeri HP Anda. Gambar otomatis dikompresi dan langsung tampil saat pembeli memilih pembayaran QRIS.
          </p>

          <input
            type="file"
            accept="image/*"
            ref={qrisFileInputRef}
            style={{ display: 'none' }}
            onChange={handleQrisImageSelect}
          />

          <div className="image-picker-box" onClick={() => qrisFileInputRef.current?.click()}>
            {uploadingQris ? (
              <div style={{ padding: 24, color: 'var(--accent-primary)', fontWeight: 700 }}>Mengompresi & menyimpan QRIS...</div>
            ) : qrisImgUrl ? (
              <div>
                <div className="qris-display-box" style={{ margin: '0 auto 12px', maxWidth: 240 }}>
                  <img src={qrisImgUrl} alt="QRIS Toko" />
                </div>
                <button type="button" className="tab-btn active">
                  <Camera size={14} /> Ganti Gambar QRIS dari Galeri
                </button>
              </div>
            ) : (
              <div style={{ padding: '24px 10px' }}>
                <Camera size={32} color="var(--accent-primary)" style={{ margin: '0 auto 8px' }} />
                <div style={{ fontWeight: 800, fontSize: 14 }}>Pilih Foto QRIS dari Galeri HP</div>
                <div style={{ fontSize: 11, color: 'var(--text-sub)', marginTop: 4 }}>Mendukung format JPG / PNG / WEBP</div>
              </div>
            )}
          </div>
        </div>
      )}

      {isAddMenuOpen && (
        <div className="ios-modal-overlay" onClick={() => setIsAddMenuOpen(false)}>
          <div className="ios-modal-sheet" onClick={e => e.stopPropagation()}>
            <div className="sheet-handle" />
            <h3 style={{ fontSize: 18, fontWeight: 800, marginBottom: 14 }}>Tambah Menu Kopi 1001 SK</h3>
            <form onSubmit={handleAddMenu}>
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Foto Produk (Dari Galeri HP)</label>
                <input
                  type="file"
                  accept="image/*"
                  ref={productFileInputRef}
                  style={{ display: 'none' }}
                  onChange={handleProductImageSelect}
                />

                {uploadingImg ? (
                  <div className="image-picker-box" style={{ padding: 18, color: 'var(--accent-primary)' }}>
                    Mengoptimalkan resolusi foto...
                  </div>
                ) : productImgUrl ? (
                  <div className="preview-img-container" onClick={() => productFileInputRef.current?.click()}>
                    <img src={productImgUrl} alt="Preview Produk" />
                    <div style={{ position: 'absolute', bottom: 8, right: 8, background: 'rgba(12,10,20,0.75)', backdropFilter: 'blur(10px)', padding: '5px 10px', borderRadius: 10, fontSize: 11, color: '#fff', fontWeight: 700 }}>
                      Ganti Foto
                    </div>
                  </div>
                ) : (
                  <div className="image-picker-box" onClick={() => productFileInputRef.current?.click()}>
                    <Camera size={26} color="var(--accent-primary)" style={{ margin: '0 auto 6px' }} />
                    <div style={{ fontWeight: 700, fontSize: 13 }}>Ketuk untuk Ambil Foto dari Galeri</div>
                  </div>
                )}
              </div>

              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Nama Menu</label>
                <input type="text" className="ios-input" value={newMenuName} onChange={e => setNewMenuName(e.target.value)} placeholder="Contoh: Kopi Susu Aren" required />
              </div>
              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Kategori</label>
                <select className="ios-input" value={newMenuCategory} onChange={e => setNewMenuCategory(e.target.value)}>
                  {categories.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div style={{ marginBottom: 10 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Harga (Rp)</label>
                <input type="number" className="ios-input" value={newMenuPrice} onChange={e => setNewMenuPrice(e.target.value)} placeholder="18000" required />
              </div>
              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 12, color: 'var(--text-sub)', fontWeight: 700 }}>Deskripsi Singkat</label>
                <input type="text" className="ios-input" value={newMenuDesc} onChange={e => setNewMenuDesc(e.target.value)} placeholder="Deskripsi rasa & komposisi..." />
              </div>
              <button type="submit" className="ios-btn-primary">Simpan Menu Baru</button>
              <button type="button" className="ios-btn-secondary" onClick={() => setIsAddMenuOpen(false)}>Batal</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
