import React, { useState, useMemo, useEffect } from 'react';
import {
  Plus,
  Trash2,
  Upload,
  QrCode,
  ShieldAlert,
  Sparkles,
  Image as ImageIcon
} from 'lucide-react';
import {
  DEFAULT_MENU_IMAGE,
  MENU_CATEGORIES,
  ORDER_STATUS_META,
  formatRupiah,
  formatDateTime
} from '../utils/constants.js';
import { compressImageFile } from '../utils/imageCompressor.js';
import { extractNominalFromText } from '../utils/qrisAutoMatcher.js';

export default function SellerView({
  activeTab,
  tabDirection,
  orders,
  menuItems,
  qrisImageUrl,
  storeName,
  onUpdateOrderStatus,
  onDeleteOrder,
  onSaveMenuItem,
  onDeleteMenuItem,
  onSaveStoreSettings
}) {
  const [newName, setNewName] = useState('');
  const [newCategory, setNewCategory] = useState('Signature Coffee');
  const [newPrice, setNewPrice] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newImage, setNewImage] = useState('');
  const [savingMenu, setSavingMenu] = useState(false);

  const [editStoreName, setEditStoreName] = useState(storeName || '1001 SK Coffee & Lounge');
  const [editQrisUrl, setEditQrisUrl] = useState(qrisImageUrl || '');
  const [notifSmsText, setNotifSmsText] = useState('');
  const [sellerMsg, setSellerMsg] = useState('');

  useEffect(() => {
    setEditStoreName(storeName || '1001 SK Coffee & Lounge');
  }, [storeName]);

  useEffect(() => {
    setEditQrisUrl(qrisImageUrl || '');
  }, [qrisImageUrl]);

  const showMsg = (txt) => {
    setSellerMsg(txt);
    window.setTimeout(() => setSellerMsg(''), 3000);
  };

  const activeOrders = useMemo(
    () => orders.filter((o) => !['completed', 'cancelled'].includes(o.status)),
    [orders]
  );

  const handleMenuImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await compressImageFile(file, 720, 0.82);
      setNewImage(dataUrl);
      showMsg('Foto produk siap disimpan');
    } catch (err) {
      showMsg(err.message);
    }
  };

  const handleReplaceExistingItemPhoto = async (item, file) => {
    if (!file) return;
    try {
      const dataUrl = await compressImageFile(file, 720, 0.82);
      await onSaveMenuItem({ ...item, image: dataUrl });
      showMsg(`Foto ${item.name} diperbarui`);
    } catch (err) {
      showMsg(err.message);
    }
  };

  const handleQrisUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await compressImageFile(file, 720, 0.85);
      setEditQrisUrl(dataUrl);
      showMsg('Gambar QRIS siap disimpan');
    } catch (err) {
      showMsg(err.message);
    }
  };

  const handleCreateMenu = async (e) => {
    e.preventDefault();
    if (!newName.trim() || !newPrice || savingMenu) return;
    setSavingMenu(true);
    try {
      await onSaveMenuItem({
        name: newName.trim(),
        category: newCategory,
        price: Number(newPrice),
        desc: newDesc.trim() || 'Racikan spesial 1001 SK Coffee.',
        image: newImage || DEFAULT_MENU_IMAGE,
        featured: true,
        available: true
      });
      setNewName('');
      setNewPrice('');
      setNewDesc('');
      setNewImage('');
      showMsg('Menu baru & foto produk ditambahkan');
    } finally {
      setSavingMenu(false);
    }
  };

  const handleAutoMatchQris = () => {
    const nominal = extractNominalFromText(notifSmsText);
    if (!nominal) {
      showMsg('Nominal pembayaran tidak terbaca dari teks notifikasi');
      return;
    }
    const matched = orders.find(
      (o) => o.status === 'pending_payment' && Number(o.totalPrice) === nominal
    );
    if (matched) {
      onUpdateOrderStatus(matched.id, 'queued');
      setNotifSmsText('');
      showMsg(`Pembayaran ${formatRupiah(nominal)} untuk ${matched.customerName} otomatis terkonfirmasi!`);
    } else {
      showMsg(`Tidak ada pesanan menunggu pembayaran sebesar ${formatRupiah(nominal)}`);
    }
  };

  const tabAnimClass = tabDirection === 'left' ? 'tab-slide-left' : 'tab-slide-right';

  return (
    <div style={{ padding: '4px 18px 24px' }}>
      <div
        className="ios-grouped-card"
        style={{
          padding: '11px 14px',
          marginBottom: 14,
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          background: 'var(--accent-soft)'
        }}
      >
        <ShieldAlert size={18} style={{ color: 'var(--accent)', flexShrink: 0 }} />
        <div style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--text-primary)' }}>
          Mode Penjual Aktif — Pemesanan pelanggan dinonaktifkan pada akun penjual.
        </div>
      </div>

      {sellerMsg && (
        <div
          className="toast-spring-in"
          style={{
            position: 'fixed',
            top: 'calc(env(safe-area-inset-top, 12px) + 56px)',
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 185
          }}
        >
          <div
            className="refractive-glass"
            style={{ padding: '9px 18px', borderRadius: 999, fontSize: 13, fontWeight: 700 }}
          >
            <span style={{ position: 'relative', zIndex: 1 }}>{sellerMsg}</span>
          </div>
        </div>
      )}

      {activeTab === 'home' && (
        <div key="seller-home" className={tabAnimClass}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <h2 style={{ fontSize: 18, fontWeight: 800 }}>Pesanan Masuk ({activeOrders.length})</h2>
          </div>
          {orders.length === 0 ? (
            <div className="ios-grouped-card" style={{ padding: '32px 18px', textAlign: 'center' }}>
              <div style={{ fontSize: 16, fontWeight: 800 }}>Belum Ada Pesanan Pelanggan</div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {orders.map((order, idx) => {
                const meta = ORDER_STATUS_META[order.status] || ORDER_STATUS_META.queued;
                return (
                  <div
                    key={order.id}
                    className="ios-grouped-card card-stagger-in"
                    style={{ '--stagger': idx, padding: 15 }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span
                        style={{
                          padding: '4px 11px',
                          borderRadius: 999,
                          background: meta.bg,
                          color: meta.color,
                          fontSize: 12,
                          fontWeight: 800
                        }}
                      >
                        {meta.label}
                      </span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                          {formatDateTime(order.createdAt)}
                        </span>
                        <button
                          type="button"
                          onClick={() => onDeleteOrder(order.id)}
                          aria-label="Hapus pesanan"
                          style={{
                            width: 28,
                            height: 28,
                            borderRadius: '50%',
                            border: 'none',
                            background: 'var(--bg-subtle)',
                            color: '#ff453a',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: 'pointer'
                          }}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>

                    <div style={{ fontSize: 15.5, fontWeight: 800, marginTop: 10 }}>
                      {order.customerName} • {order.tableNumber || 'Takeaway'}
                    </div>
                    <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 3 }}>
                      {(order.items || []).map((i) => `${i.qty}x ${i.name}`).join(', ')}
                    </div>
                    {order.note && (
                      <div style={{ fontSize: 12.5, color: 'var(--accent)', marginTop: 4 }}>
                        Catatan: {order.note}
                      </div>
                    )}

                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginTop: 12,
                        paddingTop: 10,
                        borderTop: '1px solid var(--border-hairline)',
                        flexWrap: 'wrap',
                        gap: 8
                      }}
                    >
                      <strong style={{ fontSize: 15 }}>{formatRupiah(order.totalPrice)}</strong>
                      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                        {order.status === 'pending_payment' && (
                          <button
                            type="button"
                            className="btn-ios-secondary"
                            style={{ padding: '7px 12px', fontSize: 12 }}
                            onClick={() => onUpdateOrderStatus(order.id, 'queued')}
                          >
                            Terima Bayar
                          </button>
                        )}
                        {order.status === 'queued' && (
                          <button
                            type="button"
                            className="btn-ios-secondary"
                            style={{ padding: '7px 12px', fontSize: 12 }}
                            onClick={() => onUpdateOrderStatus(order.id, 'preparing')}
                          >
                            Racik
                          </button>
                        )}
                        {(order.status === 'queued' || order.status === 'preparing') && (
                          <button
                            type="button"
                            className="btn-ios-primary"
                            style={{ width: 'auto', padding: '7px 13px', fontSize: 12 }}
                            onClick={() => onUpdateOrderStatus(order.id, 'ready')}
                          >
                            Siap Diambil
                          </button>
                        )}
                        {order.status === 'ready' && (
                          <button
                            type="button"
                            className="btn-ios-secondary"
                            style={{ padding: '7px 12px', fontSize: 12 }}
                            onClick={() => onUpdateOrderStatus(order.id, 'completed')}
                          >
                            Selesaikan
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {activeTab === 'cart' && (
        <div key="seller-menu" className={tabAnimClass}>
          <form onSubmit={handleCreateMenu} className="ios-grouped-card" style={{ padding: 16, marginBottom: 16 }}>
            <div style={{ fontSize: 16, fontWeight: 800, marginBottom: 12 }}>Tambah Menu & Foto Produk</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <input
                className="ios-input"
                type="text"
                placeholder="Nama Menu (Contoh: Kopi Susu Aren 1001)"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                required
              />
              <select
                className="ios-input"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
              >
                {MENU_CATEGORIES.filter((c) => c !== 'Semua').map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
              <input
                className="ios-input"
                type="number"
                placeholder="Harga (Rp)"
                value={newPrice}
                onChange={(e) => setNewPrice(e.target.value)}
                required
              />
              <input
                className="ios-input"
                type="text"
                placeholder="Deskripsi singkat menu"
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
              />

              <label className="btn-ios-secondary" style={{ cursor: 'pointer' }}>
                <Upload size={16} />
                {newImage ? 'Ganti Foto Produk' : 'Unggah Foto Produk'}
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleMenuImageUpload}
                  style={{ display: 'none' }}
                />
              </label>

              {newImage && (
                <div style={{ position: 'relative', width: '100%', maxWidth: 160, margin: '4px auto 0' }}>
                  <img
                    src={newImage}
                    alt="Pratinjau Foto Menu"
                    style={{
                      width: '100%',
                      aspectRatio: '1 / 1',
                      objectFit: 'cover',
                      borderRadius: 16,
                      border: '1px solid var(--border-hairline)'
                    }}
                  />
                </div>
              )}

              <button type="submit" className="btn-ios-primary" disabled={savingMenu}>
                <Plus size={18} />
                {savingMenu ? 'Menyimpan...' : 'Simpan Menu'}
              </button>
            </div>
          </form>

          <div className="ios-grouped-card">
            {menuItems.map((item) => (
              <div
                key={item.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 11,
                  padding: '12px 14px',
                  borderBottom: '1px solid var(--border-hairline)'
                }}
              >
                <label
                  title="Ketuk untuk ganti foto produk"
                  style={{
                    position: 'relative',
                    width: 50,
                    height: 50,
                    borderRadius: 12,
                    overflow: 'hidden',
                    flexShrink: 0,
                    cursor: 'pointer',
                    background: 'var(--bg-subtle)'
                  }}
                >
                  <img
                    src={item.image || DEFAULT_MENU_IMAGE}
                    alt={item.name}
                    onError={(e) => {
                      e.currentTarget.src = DEFAULT_MENU_IMAGE;
                    }}
                    style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
                  />
                  <span
                    style={{
                      position: 'absolute',
                      right: 2,
                      bottom: 2,
                      width: 18,
                      height: 18,
                      borderRadius: '50%',
                      background: 'rgba(15, 17, 24, 0.72)',
                      color: '#fff',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}
                  >
                    <ImageIcon size={10} />
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    style={{ display: 'none' }}
                    onChange={(e) => handleReplaceExistingItemPhoto(item, e.target.files?.[0])}
                  />
                </label>

                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14.5, fontWeight: 700 }}>{item.name}</div>
                  <div style={{ fontSize: 12.5, color: 'var(--text-secondary)' }}>
                    {formatRupiah(item.price)} • {item.category}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onSaveMenuItem({ ...item, available: item.available === false })}
                  style={{
                    padding: '5px 10px',
                    borderRadius: 999,
                    border: 'none',
                    background: item.available === false ? 'rgba(255,69,58,0.16)' : 'rgba(48,209,88,0.16)',
                    color: item.available === false ? '#ff453a' : '#30d158',
                    fontSize: 11.5,
                    fontWeight: 800,
                    cursor: 'pointer'
                  }}
                >
                  {item.available === false ? 'Habis' : 'Tersedia'}
                </button>
                <button
                  type="button"
                  onClick={() => onDeleteMenuItem(item.id)}
                  aria-label="Hapus menu"
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: '50%',
                    border: 'none',
                    background: 'var(--bg-subtle)',
                    color: '#ff453a',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer'
                  }}
                >
                  <Trash2 size={15} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'orders' && (
        <div key="seller-qris" className={tabAnimClass}>
          <div className="ios-grouped-card" style={{ padding: 16, marginBottom: 16 }}>
            <div style={{ fontSize: 16, fontWeight: 800, marginBottom: 12 }}>Pengaturan QRIS Toko</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <input
                className="ios-input"
                type="text"
                placeholder="Nama Kedai / Toko"
                value={editStoreName}
                onChange={(e) => setEditStoreName(e.target.value)}
              />
              <label className="btn-ios-secondary" style={{ cursor: 'pointer' }}>
                <QrCode size={17} />
                {editQrisUrl ? 'Ganti Gambar QRIS Statis' : 'Unggah Gambar QRIS Statis'}
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleQrisUpload}
                  style={{ display: 'none' }}
                />
              </label>

              {editQrisUrl && (
                <div style={{ textAlign: 'center', padding: 10, background: '#fff', borderRadius: 16 }}>
                  <img
                    src={editQrisUrl}
                    alt="Pratinjau QRIS Toko"
                    style={{ maxWidth: 210, width: '100%', borderRadius: 12 }}
                  />
                </div>
              )}

              <button
                type="button"
                className="btn-ios-primary"
                onClick={() => {
                  onSaveStoreSettings({ storeName: editStoreName, qrisImageUrl: editQrisUrl });
                  showMsg('Pengaturan QRIS toko tersimpan');
                }}
              >
                Simpan Pengaturan QRIS
              </button>
            </div>
          </div>

          <div className="ios-grouped-card" style={{ padding: 16 }}>
            <div style={{ fontSize: 15.5, fontWeight: 800, marginBottom: 6, display: 'flex', alignItems: 'center', gap: 6 }}>
              <Sparkles size={16} style={{ color: 'var(--accent)' }} />
              Cocokkan Mutasi QRIS Otomatis
            </div>
            <p style={{ fontSize: 12.5, color: 'var(--text-secondary)', marginBottom: 10 }}>
              Tempel teks notifikasi pembayaran masuk (Dana / GoPay / BCA / BRI) untuk memverifikasi nominal otomatis.
            </p>
            <textarea
              className="ios-input"
              rows={3}
              placeholder="Contoh: Pembayaran QRIS sebesar Rp 36.000 telah diterima..."
              value={notifSmsText}
              onChange={(e) => setNotifSmsText(e.target.value)}
            />
            <button
              type="button"
              className="btn-ios-primary"
              style={{ marginTop: 10 }}
              onClick={handleAutoMatchQris}
            >
              Verifikasi Nominal Pembayaran
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
