import React from 'react';
import { BellRing, ChevronRight, X } from 'lucide-react';
import { formatRupiah } from '../utils/constants.js';

export default function FloatingOrderReadyBanner({ order, onOpenOrder, onDismiss }) {
  if (!order) return null;

  return (
    <div
      style={{
        position: 'fixed',
        top: 'calc(env(safe-area-inset-top, 12px) + 56px)',
        left: '50%',
        transform: 'translateX(-50%)',
        width: 'calc(100% - 28px)',
        maxWidth: 508,
        zIndex: 115
      }}
    >
      <div
        className="liquid-glass-surface glass-pressable"
        onClick={() => onOpenOrder && onOpenOrder(order)}
        style={{
          borderRadius: 999,
          padding: '10px 14px',
          display: 'flex',
          alignItems: 'center',
          gap: 11,
          cursor: 'pointer'
        }}
      >
        <div
          style={{
            width: 38,
            height: 38,
            borderRadius: '50%',
            background: '#34c759',
            color: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
            position: 'relative',
            zIndex: 1
          }}
        >
          <BellRing size={19} />
        </div>
        <div style={{ flex: 1, minWidth: 0, position: 'relative', zIndex: 1 }}>
          <div style={{ fontSize: 13.5, fontWeight: 800, color: 'var(--text-primary)' }}>
            Pesanan Siap Diambil!
          </div>
          <div
            style={{
              fontSize: 12,
              color: 'var(--text-secondary)',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis'
            }}
          >
            {order.customerName || 'Pelanggan'} • {formatRupiah(order.totalPrice)}
          </div>
        </div>
        <ChevronRight size={18} style={{ color: 'var(--text-secondary)', position: 'relative', zIndex: 1 }} />
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onDismiss && onDismiss();
          }}
          style={{
            width: 28,
            height: 28,
            borderRadius: '50%',
            border: 'none',
            background: 'rgba(120,120,128,0.16)',
            color: 'var(--text-primary)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            position: 'relative',
            zIndex: 2
          }}
        >
          <X size={14} />
        </button>
      </div>
    </div>
  );
}
