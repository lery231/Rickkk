import React from 'react';
import { BellRing, X, ChevronRight } from 'lucide-react';

export default function FloatingOrderReadyBanner({ readyOrders = [], onDismiss, onOpenOrders }) {
  if (!readyOrders || readyOrders.length === 0) return null;

  return (
    <div className="floating-ready-stack">
      {readyOrders.map((ord) => (
        <div
          key={ord.id}
          className="ready-card-item"
          onClick={() => {
            onDismiss?.(ord.id);
            onOpenOrders?.();
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div
              style={{
                width: 38,
                height: 38,
                borderRadius: 12,
                background: 'var(--accent-green)',
                color: '#ffffff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0,
              }}
            >
              <BellRing size={19} />
            </div>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 800 }}>Pesanan Siap Diambil!</div>
              <div style={{ fontSize: 12, color: 'var(--text-sub)' }}>
                {ord.customerName} • Meja {ord.tableNumber}
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <ChevronRight size={17} color="var(--text-sub)" />
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onDismiss?.(ord.id);
              }}
              style={{
                background: 'none',
                border: 'none',
                color: 'var(--text-sub)',
                display: 'flex',
                cursor: 'pointer',
              }}
            >
              <X size={16} />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
