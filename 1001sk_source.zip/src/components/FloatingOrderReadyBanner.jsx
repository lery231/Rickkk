import React from 'react';
import { BellRing, X, CheckCircle2 } from 'lucide-react';
import { triggerHaptic } from '../utils/soundEffects';

export default function FloatingOrderReadyBanner({ readyOrders = [], onDismiss, onOpenOrders }) {
  if (!readyOrders || readyOrders.length === 0) return null;

  return (
    <div className="floating-ready-stack">
      {readyOrders.slice(0, 2).map((ord) => (
        <div
          key={ord.id}
          className="ready-card-item"
          onClick={() => {
            triggerHaptic(14);
            if (onOpenOrders) onOpenOrders();
            if (onDismiss) onDismiss(ord.id);
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 11, flex: 1 }}>
            <div
              style={{
                width: 38,
                height: 38,
                borderRadius: '50%',
                background: 'rgba(50, 215, 75, 0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--accent-green)',
                flexShrink: 0,
              }}
            >
              <BellRing size={20} />
            </div>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 800, color: 'var(--accent-green)', display: 'flex', alignItems: 'center', gap: 5 }}>
                <CheckCircle2 size={14} /> Pesanan Siap Diambil!
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-main)' }}>
                Atas nama <strong>{ord.customerName}</strong> ({ord.orderType || 'Dine-In'})
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              triggerHaptic(10);
              if (onDismiss) onDismiss(ord.id);
            }}
            style={{
              background: 'var(--glass-pill)',
              border: '1px solid var(--glass-border)',
              color: 'var(--text-main)',
              width: 30,
              height: 30,
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              flexShrink: 0,
            }}
            aria-label="Tutup notifikasi"
          >
            <X size={15} />
          </button>
        </div>
      ))}
    </div>
  );
}
