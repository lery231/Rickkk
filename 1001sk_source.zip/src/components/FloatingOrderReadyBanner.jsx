import React, { useRef, useState } from 'react';
import { Coffee, BellRing, ArrowRight, X, CheckCircle2, Sparkles } from 'lucide-react';
import { triggerHaptic } from '../utils/soundEffects';

/**
 * Notifikasi Mengambang (Floating Heads-Up Banner) ala iOS Dynamic Island / Glassmorphism
 * Muncul otomatis di bagian atas layar saat status pesanan berubah menjadi "Siap Diambil".
 */
export default function FloatingOrderReadyBanner({
  readyQueue = [],
  onOpenOrder,
  onDismissOrder,
  theme = 'dark'
}) {
  const [dragY, setDragY] = useState(0);
  const touchStartY = useRef(null);

  if (!readyQueue || readyQueue.length === 0) return null;

  const currentOrder = readyQueue[0];
  const extraCount = readyQueue.length - 1;
  const orderCode =
    currentOrder.orderCode ||
    `#SK-${String(currentOrder.id || '').slice(-4).toUpperCase()}`;

  const itemSummary = Array.isArray(currentOrder.items)
    ? currentOrder.items
        .map((it) => `${it.qty || it.quantity || 1}x ${it.name}`)
        .join(', ')
    : currentOrder.itemsSummary || 'Pesanan kopi Anda';

  const handleTouchStart = (e) => {
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchMove = (e) => {
    if (touchStartY.current === null) return;
    const dy = e.touches[0].clientY - touchStartY.current;
    if (dy < 0) {
      setDragY(Math.max(-90, dy));
    }
  };

  const handleTouchEnd = () => {
    if (dragY < -38) {
      triggerHaptic(12);
      setDragY(0);
      onDismissOrder?.(currentOrder.id);
    } else {
      setDragY(0);
    }
    touchStartY.current = null;
  };

  const isDark = theme === 'dark';

  return (
    <div
      className="floating-ready-wrapper"
      style={{
        transform: `translate3d(0, ${dragY}px, 0)`,
        opacity: dragY < -20 ? Math.max(0.35, 1 + dragY / 90) : 1
      }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      role="alert"
      aria-live="assertive"
    >
      <div className={`floating-ready-card ${isDark ? 'dark' : 'light'}`}>
        {/* Glow bar atas */}
        <div className="floating-ready-glow-bar" />

        <div className="floating-ready-top">
          <div className="floating-ready-icon-wrap">
            <span className="floating-ready-pulse" />
            <Coffee size={20} strokeWidth={2.3} />
          </div>

          <div className="floating-ready-content">
            <div className="floating-ready-badge-row">
              <span className="floating-ready-pill">
                <BellRing size={11} />
                PESANAN SIAP DIAMBIL
              </span>
              <span className="floating-ready-code">{orderCode}</span>
              {extraCount > 0 && (
                <span className="floating-ready-more">+{extraCount} lagi</span>
              )}
            </div>

            <h4 className="floating-ready-title">
              Pesanan {currentOrder.customerName || 'Anda'} sudah siap di meja kasir!
            </h4>
            <p className="floating-ready-items">{itemSummary}</p>
          </div>

          <button
            type="button"
            className="floating-ready-close"
            aria-label="Tutup notifikasi"
            onClick={() => {
              triggerHaptic(10);
              onDismissOrder?.(currentOrder.id);
            }}
          >
            <X size={16} />
          </button>
        </div>

        <div className="floating-ready-actions">
          <button
            type="button"
            className="floating-ready-btn-primary"
            onClick={() => {
              triggerHaptic([15, 30, 15]);
              onOpenOrder?.(currentOrder);
            }}
          >
            <CheckCircle2 size={15} />
            <span>Ambil Sekarang & Lihat Detail</span>
            <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}
