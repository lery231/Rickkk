import React, { useState, useMemo } from 'react';
import { Search, Plus, Sparkles, Flame } from 'lucide-react';
import { MENU_CATEGORIES, formatRupiah } from '../utils/constants.js';
import { playTapHaptic } from '../utils/soundEffects.js';

export default function CustomerHome({ menuItems, onAddToCart }) {
  const [selectedCategory, setSelectedCategory] = useState('Semua');
  const [searchText, setSearchText] = useState('');
  const [selectedItem, setSelectedItem] = useState(null);
  const [tempVariant, setTempVariant] = useState('Ice • Normal Sugar');

  const filteredMenu = useMemo(() => {
    return menuItems.filter((item) => {
      const matchCat = selectedCategory === 'Semua' || item.category === selectedCategory;
      const matchSearch =
        !searchText.trim() ||
        item.name.toLowerCase().includes(searchText.trim().toLowerCase()) ||
        (item.desc || '').toLowerCase().includes(searchText.trim().toLowerCase());
      return matchCat && matchSearch;
    });
  }, [menuItems, selectedCategory, searchText]);

  const featuredItems = useMemo(
    () => menuItems.filter((m) => m.featured && m.available !== false),
    [menuItems]
  );

  const handleCardPointerMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    e.currentTarget.style.setProperty('--mx', `${x.toFixed(1)}%`);
    e.currentTarget.style.setProperty('--my', `${y.toFixed(1)}%`);
  };

  return (
    <div style={{ display: 'grid', gap: 16 }}>
      {/* Search Bar */}
      <div
        className="convx-glass-card"
        style={{
          padding: '10px 14px',
          display: 'flex',
          alignItems: 'center',
          gap: 10
        }}
      >
        <Search size={18} style={{ color: 'var(--text-tertiary)', zIndex: 2 }} />
        <input
          type="text"
          placeholder="Cari kopi susu, V60, matcha, croissant..."
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          style={{
            flex: 1,
            border: 'none',
            background: 'transparent',
            color: 'var(--text-primary)',
            fontSize: 14.5,
            outline: 'none',
            position: 'relative',
            zIndex: 2
          }}
        />
      </div>

      {/* Category Filter Pills */}
      <div
        style={{
          display: 'flex',
          gap: 8,
          overflowX: 'auto',
          paddingBottom: 4,
          scrollbarWidth: 'none'
        }}
      >
        {MENU_CATEGORIES.map((cat) => (
          <button
            key={cat}
            type="button"
            className={`convx-chip ${selectedCategory === cat ? 'active' : ''}`}
            onClick={() => {
              playTapHaptic();
              setSelectedCategory(cat);
            }}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Featured Highlight */}
      {selectedCategory === 'Semua' && !searchText.trim() && featuredItems.length > 0 && (
        <div>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              marginBottom: 10,
              fontWeight: 800,
              fontSize: 16
            }}
          >
            <Flame size={18} style={{ color: '#ff9f0a' }} />
            <span>Rekomendasi Barista</span>
          </div>
          <div
            style={{
              display: 'flex',
              gap: 12,
              overflowX: 'auto',
              paddingBottom: 6,
              scrollbarWidth: 'none'
            }}
          >
            {featuredItems.map((item) => (
              <div
                key={item.id}
                className="convx-glass-card"
                onPointerMove={handleCardPointerMove}
                onClick={() => {
                  playTapHaptic();
                  setSelectedItem(item);
                }}
                style={{
                  minWidth: 235,
                  maxWidth: 235,
                  padding: 12,
                  cursor: 'pointer',
                  flexShrink: 0
                }}
              >
                <div style={{ position: 'relative', zIndex: 2 }}>
                  <img
                    src={item.image}
                    alt={item.name}
                    style={{
                      width: '100%',
                      height: 122,
                      objectFit: 'cover',
                      borderRadius: 16,
                      marginBottom: 10
                    }}
                  />
                  <div style={{ fontWeight: 700, fontSize: 14.5 }}>{item.name}</div>
                  <div
                    style={{
                      fontSize: 12,
                      color: 'var(--text-secondary)',
                      marginTop: 2,
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical',
                      overflow: 'hidden'
                    }}
                  >
                    {item.desc}
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      marginTop: 10
                    }}
                  >
                    <strong style={{ color: '#ff9f0a', fontSize: 14.5 }}>
                      {formatRupiah(item.price)}
                    </strong>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        playTapHaptic();
                        onAddToCart(item, 'Ice • Normal Sugar');
                      }}
                      style={{
                        width: 30,
                        height: 30,
                        borderRadius: '50%',
                        border: 'none',
                        background: 'linear-gradient(135deg, #ff9f0a, #ff6b00)',
                        color: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        cursor: 'pointer',
                        boxShadow: '0 4px 12px rgba(255, 149, 0, 0.45)'
                      }}
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Menu Grid */}
      <div>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            marginBottom: 10,
            fontWeight: 800,
            fontSize: 16
          }}
        >
          <Sparkles size={17} style={{ color: '#0a84ff' }} />
          <span>Daftar Menu ({filteredMenu.length})</span>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(2, minmax(0, 1fr))',
            gap: 12
          }}
        >
          {filteredMenu.map((item) => {
            const soldOut = item.available === false;
            return (
              <div
                key={item.id}
                className="convx-glass-card"
                onPointerMove={handleCardPointerMove}
                onClick={() => {
                  if (!soldOut) {
                    playTapHaptic();
                    setSelectedItem(item);
                  }
                }}
                style={{
                  padding: 11,
                  opacity: soldOut ? 0.58 : 1,
                  cursor: soldOut ? 'not-allowed' : 'pointer',
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between'
                }}
              >
                <div style={{ position: 'relative', zIndex: 2 }}>
                  <img
                    src={item.image}
                    alt={item.name}
                    style={{
                      width: '100%',
                      height: 115,
                      objectFit: 'cover',
                      borderRadius: 15,
                      marginBottom: 8
                    }}
                  />
                  <div style={{ fontWeight: 700, fontSize: 13.5, lineHeight: 1.3 }}>
                    {item.name}
                  </div>
                  <div
                    style={{
                      fontSize: 11.5,
                      color: 'var(--text-secondary)',
                      marginTop: 3,
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical',
                      overflow: 'hidden'
                    }}
                  >
                    {item.desc}
                  </div>
                </div>

                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginTop: 10,
                    position: 'relative',
                    zIndex: 2
                  }}
                >
                  <strong style={{ fontSize: 13.5, color: 'var(--accent-amber)' }}>
                    {formatRupiah(item.price)}
                  </strong>
                  {soldOut ? (
                    <span style={{ fontSize: 11, fontWeight: 700, color: '#ff453a' }}>Habis</span>
                  ) : (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        playTapHaptic();
                        onAddToCart(item, 'Ice • Normal Sugar');
                      }}
                      style={{
                        width: 28,
                        height: 28,
                        borderRadius: '50%',
                        border: 'none',
                        background: 'linear-gradient(135deg, #ff9f0a, #ff6b00)',
                        color: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        cursor: 'pointer'
                      }}
                    >
                      <Plus size={15} />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Item Variant Modal */}
      {selectedItem && (
        <div
          onClick={() => setSelectedItem(null)}
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 75,
            background: 'rgba(4, 6, 12, 0.62)',
            backdropFilter: 'blur(14px)',
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'center',
            padding: 16
          }}
        >
          <div
            className="convx-glass-card convx-modal-animate"
            onClick={(e) => e.stopPropagation()}
            style={{ width: '100%', maxWidth: 460, padding: 18 }}
          >
            <div style={{ position: 'relative', zIndex: 2 }}>
              <img
                src={selectedItem.image}
                alt={selectedItem.name}
                style={{
                  width: '100%',
                  height: 170,
                  objectFit: 'cover',
                  borderRadius: 18,
                  marginBottom: 12
                }}
              />
              <h3 style={{ margin: '0 0 4px', fontSize: 19, fontWeight: 800 }}>
                {selectedItem.name}
              </h3>
              <p style={{ margin: '0 0 12px', fontSize: 13, color: 'var(--text-secondary)' }}>
                {selectedItem.desc}
              </p>

              <div style={{ fontSize: 12.5, fontWeight: 700, marginBottom: 8 }}>Pilih Penyajian:</div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 }}>
                {[
                  'Ice • Normal Sugar',
                  'Ice • Less Sugar',
                  'Hot • Normal Sugar',
                  'Hot • Less Sugar'
                ].map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    className={`convx-chip ${tempVariant === opt ? 'active' : ''}`}
                    onClick={() => setTempVariant(opt)}
                  >
                    {opt}
                  </button>
                ))}
              </div>

              <button
                type="button"
                className="btn-ios-primary"
                onClick={() => {
                  playTapHaptic();
                  onAddToCart(selectedItem, tempVariant);
                  setSelectedItem(null);
                }}
              >
                Tambah ke Keranjang • {formatRupiah(selectedItem.price)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
