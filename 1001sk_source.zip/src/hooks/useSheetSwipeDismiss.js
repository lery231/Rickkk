import { useRef, useState } from 'react';

export function useSheetSwipeDismiss({ onDismiss, threshold = 110, enabled = true }) {
  const startYRef = useRef(0);
  const draggingRef = useRef(false);
  const [dragOffset, setDragOffset] = useState(0);
  const [isDragging, setIsDragging] = useState(false);

  const onTouchStart = (e) => {
    if (!enabled || e.touches.length !== 1) return;
    const scrollParent = e.target?.closest?.('.sheet-scroll-body');
    if (scrollParent && scrollParent.scrollTop > 4) {
      draggingRef.current = false;
      return;
    }
    startYRef.current = e.touches[0].clientY;
    draggingRef.current = true;
    setIsDragging(true);
  };

  const onTouchMove = (e) => {
    if (!draggingRef.current || e.touches.length !== 1) return;
    const dy = e.touches[0].clientY - startYRef.current;
    if (dy > 0) {
      setDragOffset(Math.min(dy, 360));
    } else {
      setDragOffset(0);
    }
  };

  const onTouchEnd = () => {
    if (!draggingRef.current) return;
    draggingRef.current = false;
    setIsDragging(false);
    if (dragOffset >= threshold) {
      setDragOffset(0);
      if (onDismiss) onDismiss();
    } else {
      setDragOffset(0);
    }
  };

  const sheetStyle =
    dragOffset > 0
      ? {
          transform: `translateY(${dragOffset}px)`,
          transition: isDragging ? 'none' : 'transform 0.36s cubic-bezier(0.22, 1.25, 0.36, 1)'
        }
      : undefined;

  return {
    dragOffset,
    isDragging,
    sheetStyle,
    sheetTouchProps: {
      onTouchStart,
      onTouchMove,
      onTouchEnd
    }
  };
}
