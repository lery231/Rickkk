import { useRef, useState } from 'react';

export function useSheetSwipeDismiss({ onClose, threshold = 95, enabled = true }) {
  const startY = useRef(0);
  const dragging = useRef(false);
  const [dragOffsetY, setDragOffsetY] = useState(0);

  const onTouchStart = (e) => {
    if (!enabled) return;
    const scrollEl = e.currentTarget;
    if (scrollEl && scrollEl.scrollTop > 4) return;
    startY.current = e.touches[0].clientY;
    dragging.current = true;
  };

  const onTouchMove = (e) => {
    if (!dragging.current || !enabled) return;
    const dy = e.touches[0].clientY - startY.current;
    if (dy > 0) {
      setDragOffsetY(Math.min(340, dy * 0.85));
    } else {
      setDragOffsetY(0);
    }
  };

  const onTouchEnd = () => {
    if (!dragging.current) return;
    dragging.current = false;
    if (dragOffsetY >= threshold) {
      setDragOffsetY(0);
      onClose?.();
    } else {
      setDragOffsetY(0);
    }
  };

  const sheetDragStyle =
    dragOffsetY > 0
      ? {
          transform: `translate3d(0, ${dragOffsetY}px, 0)`,
          transition: 'none',
        }
      : {
          transform: 'translate3d(0, 0, 0)',
          transition: 'transform 0.36s cubic-bezier(0.22, 1.25, 0.36, 1)',
        };

  return {
    sheetDragStyle,
    sheetSwipeHandlers: {
      onTouchStart,
      onTouchMove,
      onTouchEnd,
    },
  };
}
