import { useEffect, useRef } from 'react';

export function useAndroidBackButton({ onBackPress }) {
  const callbackRef = useRef(onBackPress);
  useEffect(() => {
    callbackRef.current = onBackPress;
  }, [onBackPress]);

  useEffect(() => {
    let listenerHandle = null;
    try {
      const capApp = window?.Capacitor?.Plugins?.App;
      if (capApp?.addListener) {
        listenerHandle = capApp.addListener('backButton', ({ canGoBack }) => {
          const handled = callbackRef.current?.();
          if (!handled && !canGoBack) {
            capApp.exitApp?.();
          }
        });
      }
    } catch {}

    return () => {
      if (listenerHandle?.remove) {
        listenerHandle.remove().catch(() => {});
      }
    };
  }, []);
}
