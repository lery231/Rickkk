import { useEffect, useRef } from 'react';
import { App as CapApp } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';

export function useAndroidBackButton(handler) {
  const handlerRef = useRef(handler);
  handlerRef.current = handler;

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    let listenerHandle = null;

    CapApp.addListener('backButton', (event) => {
      const handled = handlerRef.current ? handlerRef.current() : false;
      if (!handled && !event.canGoBack) {
        CapApp.exitApp();
      }
    }).then((handle) => {
      listenerHandle = handle;
    }).catch(() => {});

    return () => {
      if (listenerHandle && listenerHandle.remove) {
        listenerHandle.remove();
      }
    };
  }, []);
}
