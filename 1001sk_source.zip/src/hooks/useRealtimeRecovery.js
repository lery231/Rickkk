import { useState, useEffect, useRef, useCallback } from 'react';
import { auth, reconnectRealtimeEngine } from '../firebase';

export function useRealtimeRecovery() {
  const [syncGeneration, setSyncGeneration] = useState(0);
  const [connectionState, setConnectionState] = useState(
    typeof navigator !== 'undefined' && navigator.onLine === false ? 'offline' : 'online'
  );
  const [lastSyncAt, setLastSyncAt] = useState(() => Date.now());
  const hiddenSinceRef = useRef(null);
  const lastTriggerRef = useRef(0);

  const triggerRecovery = useCallback(async ({ forceCycle = true, reason = 'auto' } = {}) => {
    const now = Date.now();
    if (reason !== 'manual' && reason !== 'online' && now - lastTriggerRef.current < 2500) {
      return;
    }
    lastTriggerRef.current = now;

    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      setConnectionState('offline');
      return;
    }

    setConnectionState('reconnecting');
    await reconnectRealtimeEngine({ refreshToken: true, cycleNetwork: forceCycle });
    setSyncGeneration((g) => g + 1);
    setLastSyncAt(Date.now());
    setConnectionState('online');
  }, []);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        hiddenSinceRef.current = Date.now();
      } else if (document.visibilityState === 'visible') {
        const awayMs = hiddenSinceRef.current ? Date.now() - hiddenSinceRef.current : 10000;
        hiddenSinceRef.current = null;
        triggerRecovery({ forceCycle: awayMs >= 4000, reason: 'visibility' });
      }
    };

    const handleOnline = () => triggerRecovery({ forceCycle: true, reason: 'online' });
    const handleOffline = () => setConnectionState('offline');
    const handlePageShow = (event) => {
      if (event.persisted) triggerRecovery({ forceCycle: true, reason: 'pageshow' });
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('pageshow', handlePageShow);

    let capListener = null;
    try {
      const capApp = window?.Capacitor?.Plugins?.App;
      if (capApp?.addListener) {
        capListener = capApp.addListener('appStateChange', ({ isActive }) => {
          if (isActive) {
            triggerRecovery({ forceCycle: true, reason: 'capacitor-resume' });
          } else {
            hiddenSinceRef.current = Date.now();
          }
        });
      }
    } catch {}

    const keepAliveTimer = setInterval(() => {
      if (document.visibilityState === 'visible' && auth.currentUser) {
        auth.currentUser.getIdToken(false).catch(() => {});
      }
    }, 50000);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('pageshow', handlePageShow);
      clearInterval(keepAliveTimer);
      if (capListener?.remove) {
        capListener.remove().catch(() => {});
      }
    };
  }, [triggerRecovery]);

  return {
    syncGeneration,
    connectionState,
    lastSyncAt,
    manualSync: () => triggerRecovery({ forceCycle: true, reason: 'manual' }),
  };
}
