import { useEffect, useRef } from 'react';

export function useRealtimeRecovery(onRecover) {
  const recoverRef = useRef(onRecover);
  recoverRef.current = onRecover;
  const lastRunRef = useRef(0);

  useEffect(() => {
    const trigger = () => {
      const now = Date.now();
      if (now - lastRunRef.current < 2500) return;
      lastRunRef.current = now;
      if (recoverRef.current) recoverRef.current();
    };

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') trigger();
    };

    window.addEventListener('online', trigger);
    window.addEventListener('focus', trigger);
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      window.removeEventListener('online', trigger);
      window.removeEventListener('focus', trigger);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, []);
}
