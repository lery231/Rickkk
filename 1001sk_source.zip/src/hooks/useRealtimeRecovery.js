import { useState, useEffect, useRef, useCallback } from 'react';
import { auth, reconnectRealtimeEngine } from '../firebase';

/**
 * Menjaga koneksi realtime tetap hidup saat pindah tab, buka kunci HP,
 * atau kembali dari background APK tanpa perlu relog/refresh manual.
 */
export function useRealtimeRecovery() {
  const [syncGeneration, setSyncGeneration] = useState(0);
  const [connectionState, setConnectionState] = useState(
    typeof navigator !== 'undefined' && navigator.onLine === false ? 'offline' : 'online'
  );
  const [lastSyncAt, setLastSyncAt] = useState(() => Date.now());
  const hiddenSinceRef = useRef(null);
  const lastTriggerRef = useRef(0);

  const triggerRecovery = useCallback(async ({ forceCycle = true, reason = 'auto' } = {}) => {
    const now = Date.now();
    // Cegah spam reconnect dalam < 2.5 detik kecuali dipicu manual/online
    if (reason !== 'manual' && reason !== 'online' && now - lastTriggerRef.current < 2500) {
      return;
    }
    lastTriggerRef.current = now;

    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      setConnectionState('offline');
      return;
    }

    setConnectionState('reconnecting');
    await reconnectRealtimeEngine({
      refreshToken: true,
      cycleNetwork: forceCycle
    });
    setSyncGeneration((g) => g + 1);
    setLastSyncAt(Date.now());
    setConnectionState('online');
  }, []);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        hiddenSinceRef.current = Date.now();
      } else if (document.visibilityState === 'visible') {
        const awayMs = hiddenSinceRef.current ? Date.now() - hiddenSinceRef.current : 10000;
        hiddenSinceRef.current = null;
        // Jika ditinggal >= 4 detik, segarkan koneksi socket Firestore & token Auth
        triggerRecovery({ forceCycle: awayMs >= 4000, reason: 'visibility' });
      }
    };

    const handleOnline = () => {
      triggerRecovery({ forceCycle: true, reason: 'online' });
    };

    const handleOffline = () => {
      setConnectionState('offline');
    };

    const handlePageShow = (event) => {
      if (event.persisted) {
        triggerRecovery({ forceCycle: true, reason: 'pageshow' });
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('pageshow', handlePageShow);

    // Capacitor native resume listener (jika berjalan di dalam APK Android)
    let capListener = null;
    try {
      const capApp = window?.Capacitor?.Plugins?.App;
      if (capApp?.addListener) {
        capListener = capApp.addListener('appStateChange', ({ isActive }) => {
          if (isActive) {
            triggerRecovery({ forceCycle: true, reason: 'capacitor-resume' });
          } else {
            hiddenSinceRef.current = Date.now();
          }
        });
      }
    } catch {}

    // Keep-alive token Auth setiap 50 detik saat layar aktif agar tidak pernah kedaluwarsa diam-diam
    const keepAliveTimer = setInterval(() => {
      if (document.visibilityState === 'visible' && auth.currentUser) {
        auth.currentUser.getIdToken(false).catch(() => {});
      }
    }, 50000);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('pageshow', handlePageShow);
      clearInterval(keepAliveTimer);
      if (capListener?.remove) {
        capListener.remove().catch(() => {});
      }
    };
  }, [triggerRecovery]);

  return {
    syncGeneration,
    connectionState,
    lastSyncAt,
    manualSync: () => triggerRecovery({ forceCycle: true, reason: 'manual' })
  };
}
