import { useRef, useState } from 'react';

export function useSwipe({ onSwipeLeft, onSwipeRight, threshold = 58 }) {
  const touchStart = useRef({ x: 0, y: 0, ignored: false });
  const [dragOffset, setDragOffset] = useState(0);

  const onTouchStart = (e) => {
    const target = e.target;
    // Do not hijack swipe if user is scrolling a horizontal carousel or slider
    const isHorizontalScroll = target && target.closest && target.closest('[data-no-swipe="true"]');
    const touch = e.touches[0];
    touchStart.current = {
      x: touch.clientX,
      y: touch.clientY,
      ignored: Boolean(isHorizontalScroll),
    };
    setDragOffset(0);
  };

  const onTouchMove = (e) => {
    if (touchStart.current.ignored) return;
    const touch = e.touches[0];
    const deltaX = touch.clientX - touchStart.current.x;
    const deltaY = touch.clientY - touchStart.current.y;

    // Only apply subtle GPU transform feedback when horizontal intent is clear
    if (Math.abs(deltaX) > Math.abs(deltaY) * 1.25 && Math.abs(deltaX) > 12) {
      const clamped = Math.max(-42, Math.min(42, deltaX * 0.28));
      setDragOffset(clamped);
    }
  };

  const onTouchEnd = (e) => {
    if (touchStart.current.ignored) {
      setDragOffset(0);
      return;
    }
    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - touchStart.current.x;
    const deltaY = touch.clientY - touchStart.current.y;

    setDragOffset(0);

    // Ensure horizontal swipe dominates vertical scroll
    if (Math.abs(deltaX) > threshold && Math.abs(deltaX) > Math.abs(deltaY) * 1.2) {
      if (deltaX < 0 && onSwipeLeft) {
        onSwipeLeft();
      } else if (deltaX > 0 && onSwipeRight) {
        onSwipeRight();
      }
    }
  };

  return {
    dragOffset,
    swipeHandlers: {
      onTouchStart,
      onTouchMove,
      onTouchEnd,
    },
  };
}
