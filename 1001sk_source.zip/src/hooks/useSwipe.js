import { useRef } from 'react';

export function useSwipe({ onSwipeLeft, onSwipeRight, threshold = 58 }) {
  const stageRef = useRef(null);
  const start = useRef({ x: 0, y: 0, ignored: false });

  const apply = (px) => {
    const el = stageRef.current;
    if (!el) return;
    el.style.transition = px === 0 ? '' : 'none';
    el.style.transform = `translate3d(${px}px, 0, 0)`;
  };

  const onTouchStart = (e) => {
    const t = e.touches[0];
    start.current = {
      x: t.clientX,
      y: t.clientY,
      ignored: Boolean(e.target?.closest?.('[data-no-swipe="true"]'))
    };
  };

  const onTouchMove = (e) => {
    if (start.current.ignored) return;
    const t = e.touches[0];
    const dx = t.clientX - start.current.x;
    const dy = t.clientY - start.current.y;
    if (Math.abs(dx) > Math.abs(dy) * 1.25 && Math.abs(dx) > 12) {
      apply(Math.max(-42, Math.min(42, dx * 0.28)));
    }
  };

  const onTouchEnd = (e) => {
    if (start.current.ignored) return apply(0);
    const t = e.changedTouches[0];
    const dx = t.clientX - start.current.x;
    const dy = t.clientY - start.current.y;
    apply(0);
    if (Math.abs(dx) > threshold && Math.abs(dx) > Math.abs(dy) * 1.2) {
      if (dx < 0) onSwipeLeft?.();
      else onSwipeRight?.();
    }
  };

  return { stageRef, swipeHandlers: { onTouchStart, onTouchMove, onTouchEnd } };
}
