import { useRef } from 'react';

export function useSwipe({ onSwipeLeft, onSwipeRight, threshold = 58 }) {
  const startRef = useRef({ x: 0, y: 0, active: false });

  const onTouchStart = (e) => {
    if (e.touches.length !== 1) return;
    const tag = e.target?.tagName?.toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
    const horizontalScroller = e.target?.closest?.('.h-scroll, .ios-pills');
    if (horizontalScroller && horizontalScroller.scrollWidth > horizontalScroller.clientWidth + 4) {
      startRef.current.active = false;
      return;
    }
    const t = e.touches[0];
    startRef.current = { x: t.clientX, y: t.clientY, active: true };
  };

  const onTouchEnd = (e) => {
    if (!startRef.current.active || !e.changedTouches.length) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - startRef.current.x;
    const dy = t.clientY - startRef.current.y;
    startRef.current.active = false;

    if (Math.abs(dx) > threshold && Math.abs(dx) > Math.abs(dy) * 1.45) {
      if (dx < 0 && onSwipeLeft) onSwipeLeft();
      if (dx > 0 && onSwipeRight) onSwipeRight();
    }
  };

  return { onTouchStart, onTouchEnd };
}
