import { useRef, useState } from 'react';

export function useSwipe({
  onSwipeLeft,
  onSwipeRight,
  onPullRefresh,
  threshold = 56,
  pullThreshold = 74,
}) {
  const stageRef = useRef(null);
  const [pullDistance, setPullDistance] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const gesture = useRef({
    x: 0,
    y: 0,
    axis: null,
    ignored: false,
    atTop: false,
    atBottom: false,
  });

  const applyTransform = (tx, ty, scale = 1, immediate = true) => {
    const el = stageRef.current;
    if (!el) return;
    el.style.transition = immediate
      ? 'none'
      : 'transform 0.44s cubic-bezier(0.22, 1.28, 0.36, 1)';
    if (tx === 0 && ty === 0 && scale === 1) {
      el.style.transform = '';
    } else {
      el.style.transform = `translate3d(${tx}px, ${ty}px, 0) scale(${scale})`;
    }
  };

  const isAtTop = () => (window.scrollY || document.documentElement.scrollTop || 0) <= 2;

  const isAtBottom = () => {
    const scrollTop = window.scrollY || document.documentElement.scrollTop || 0;
    const viewportH = window.innerHeight || document.documentElement.clientHeight || 0;
    const docH = document.documentElement.scrollHeight || 0;
    return scrollTop + viewportH >= docH - 4;
  };

  const onTouchStart = (e) => {
    const t = e.touches[0];
    gesture.current = {
      x: t.clientX,
      y: t.clientY,
      axis: null,
      ignored: Boolean(e.target?.closest?.('[data-no-swipe="true"]')),
      atTop: isAtTop(),
      atBottom: isAtBottom(),
    };
  };

  const onTouchMove = (e) => {
    const t = e.touches[0];
    const dx = t.clientX - gesture.current.x;
    const dy = t.clientY - gesture.current.y;

    if (!gesture.current.axis) {
      if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return;
      gesture.current.axis = Math.abs(dx) > Math.abs(dy) * 1.15 ? 'x' : 'y';
    }

    if (gesture.current.axis === 'x') {
      if (gesture.current.ignored) return;
      const dampedX = Math.max(-68, Math.min(68, dx * 0.36));
      const subtleScale = 1 - Math.min(0.018, Math.abs(dampedX) * 0.00026);
      applyTransform(dampedX, 0, subtleScale, true);
      return;
    }

    if (gesture.current.axis === 'y') {
      if (dy > 0 && gesture.current.atTop && isAtTop()) {
        const dampedPull = Math.min(115, Math.pow(dy, 0.82) * 1.45);
        setPullDistance(dampedPull);
        applyTransform(0, dampedPull * 0.55, 1, true);
      } else if (dy < 0 && gesture.current.atBottom && isAtBottom()) {
        const dampedBounce = Math.max(-52, -Math.pow(Math.abs(dy), 0.78));
        applyTransform(0, dampedBounce, 1, true);
      }
    }
  };

  const onTouchEnd = async (e) => {
    const t = e.changedTouches[0];
    const dx = t.clientX - gesture.current.x;
    const dy = t.clientY - gesture.current.y;
    const axis = gesture.current.axis;

    applyTransform(0, 0, 1, false);

    if (axis === 'x' && !gesture.current.ignored) {
      if (Math.abs(dx) > threshold && Math.abs(dx) > Math.abs(dy) * 1.15) {
        if (dx < 0) onSwipeLeft?.();
        else onSwipeRight?.();
      }
    } else if (axis === 'y' && pullDistance > 0) {
      const triggered = pullDistance >= pullThreshold;
      setPullDistance(0);
      if (triggered && onPullRefresh && !isRefreshing) {
        setIsRefreshing(true);
        try {
          await onPullRefresh();
        } finally {
          setTimeout(() => setIsRefreshing(false), 550);
        }
      }
    } else {
      setPullDistance(0);
    }

    gesture.current.axis = null;
  };

  return {
    stageRef,
    pullDistance,
    isRefreshing,
    swipeHandlers: { onTouchStart, onTouchMove, onTouchEnd },
  };
}
