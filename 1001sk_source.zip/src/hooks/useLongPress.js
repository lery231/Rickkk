import { useRef, useCallback } from 'react';

export function useLongPress({ onLongPress, onClick, delay = 360, moveThreshold = 12 }) {
  const timerRef = useRef(null);
  const startPosRef = useRef({ x: 0, y: 0 });
  const longPressedRef = useRef(false);
  const movedRef = useRef(false);

  const clearTimer = useCallback(() => {
    if (timerRef.current) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const onPointerDown = useCallback(
    (e) => {
      if (e.button !== undefined && e.button !== 0) return;
      longPressedRef.current = false;
      movedRef.current = false;
      startPosRef.current = { x: e.clientX || 0, y: e.clientY || 0 };
      clearTimer();
      timerRef.current = window.setTimeout(() => {
        longPressedRef.current = true;
        if (onLongPress) onLongPress(e);
      }, delay);
    },
    [onLongPress, delay, clearTimer]
  );

  const onPointerMove = useCallback(
    (e) => {
      if (!timerRef.current) return;
      const dx = Math.abs((e.clientX || 0) - startPosRef.current.x);
      const dy = Math.abs((e.clientY || 0) - startPosRef.current.y);
      if (dx > moveThreshold || dy > moveThreshold) {
        movedRef.current = true;
        clearTimer();
      }
    },
    [moveThreshold, clearTimer]
  );

  const onPointerUp = useCallback(
    (e) => {
      clearTimer();
      if (!longPressedRef.current && !movedRef.current) {
        if (onClick) onClick(e);
      }
    },
    [onClick, clearTimer]
  );

  const onPointerCancel = useCallback(() => {
    clearTimer();
  }, [clearTimer]);

  const onContextMenu = useCallback((e) => {
    e.preventDefault();
  }, []);

  return {
    onPointerDown,
    onPointerMove,
    onPointerUp,
    onPointerCancel,
    onContextMenu
  };
}
