export const QRIS_WEBHOOK_SECRET = '1001sk_qris_auto';
export const QRIS_EXPIRY_MINUTES = 15;

export const generateUniquePaymentCode = (activeOrders = [], baseAmount = 0) => {
  const usedTotals = new Set(
    activeOrders
      .filter((o) => o.status === 'menunggu_pembayaran' && o.paymentStatus !== 'paid')
      .map((o) => Number(o.totalPrice))
  );

  for (let attempt = 0; attempt < 60; attempt++) {
    const code = Math.floor(101 + Math.random() * 799);
    if (!usedTotals.has(baseAmount + code)) {
      return code;
    }
  }
  return Math.floor(101 + Math.random() * 799);
};

export const extractAmountFromNotification = (rawInput) => {
  if (rawInput === null || rawInput === undefined) return 0;
  if (typeof rawInput === 'number' && Number.isFinite(rawInput)) {
    return Math.round(rawInput);
  }

  const text = String(rawInput).trim();
  if (!text) return 0;

  if (/^\d+$/.test(text)) {
    return parseInt(text, 10) || 0;
  }

  const currencyRegex = /(?:rp|idr)\.?\s*([0-9][0-9.,]*)/gi;
  let match;
  const candidates = [];
  while ((match = currencyRegex.exec(text)) !== null) {
    const parsed = parseIndonesianNumber(match[1]);
    if (parsed >= 100) candidates.push(parsed);
  }
  if (candidates.length > 0) return candidates[0];

  const groupedRegex = /(?:sebesar|nominal|jumlah|terima|masuk|pembayaran)\s*:?\s*([0-9]{1,3}(?:[.,][0-9]{3})+(?:[.,]00)?)/gi;
  while ((match = groupedRegex.exec(text)) !== null) {
    const parsed = parseIndonesianNumber(match[1]);
    if (parsed >= 100) candidates.push(parsed);
  }
  if (candidates.length > 0) return candidates[0];

  const anyGrouped = text.match(/\b([0-9]{1,3}(?:[.,][0-9]{3})+)\b/);
  if (anyGrouped && anyGrouped[1]) {
    return parseIndonesianNumber(anyGrouped[1]);
  }

  return 0;
};

function parseIndonesianNumber(numStr) {
  if (!numStr) return 0;
  let cleaned = numStr.replace(/[.,]00$/, '');
  cleaned = cleaned.replace(/[^0-9]/g, '');
  return parseInt(cleaned, 10) || 0;
}
