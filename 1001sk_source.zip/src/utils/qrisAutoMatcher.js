export function extractNominalFromText(text) {
  if (!text || typeof text !== 'string') return null;
  const cleaned = text.replace(/\s+/g, ' ');
  const patterns = [
    /(?:rp|idr)\.?\s*([0-9]{1,3}(?:[.,][0-9]{3})+|[0-9]{4,8})/i,
    /nominal[:\s]*([0-9]{1,3}(?:[.,][0-9]{3})+|[0-9]{4,8})/i,
    /sebesar[:\s]*(?:rp\.?\s*)?([0-9]{1,3}(?:[.,][0-9]{3})+|[0-9]{4,8})/i,
    /([0-9]{1,3}(?:\.[0-9]{3})+)/
  ];

  for (const regex of patterns) {
    const match = cleaned.match(regex);
    if (match && match[1]) {
      const numeric = Number(match[1].replace(/[.,]/g, ''));
      if (!Number.isNaN(numeric) && numeric >= 1000) {
        return numeric;
      }
    }
  }
  return null;
}
