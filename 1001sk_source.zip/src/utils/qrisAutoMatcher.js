export function extractNominalFromText(text = '') {
  if (!text) return null;
  const cleaned = String(text).replace(/\s+/g, ' ');
  const patterns = [
    /(?:rp|idr)\.?\s*([0-9]{1,3}(?:[.,][0-9]{3})+|[0-9]{4,8})/i,
    /(?:sebesar|nominal|total|pembayaran|diterima)\s*(?:rp|idr)?\.?\s*([0-9]{1,3}(?:[.,][0-9]{3})+|[0-9]{4,8})/i,
    /\b([1-9][0-9]{0,2}(?:[.,][0-9]{3})+)\b/
  ];
  for (const regex of patterns) {
    const m = cleaned.match(regex);
    if (m && m[1]) {
      const numeric = parseInt(m[1].replace(/[.,]/g, ''), 10);
      if (!Number.isNaN(numeric) && numeric >= 1000) {
        return numeric;
      }
    }
  }
  return null;
}
