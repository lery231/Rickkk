export const QRIS_WEBHOOK_SECRET = '1001sk_qris_auto';
export const QRIS_EXPIRY_MINUTES = 15;

/**
 * Menghasilkan 3 digit kode unik (101 - 899) yang belum dipakai oleh pesanan aktif
 * agar nominal transfer QRIS setiap pembeli berbeda dan akurat dicocokkan otomatis.
 */
export const generateUniquePaymentCode = (activeOrders = [], baseAmount = 0) => {
  const usedTotals = new Set(
    activeOrders
      .filter((o) => o.status === 'menunggu_pembayaran' && o.paymentStatus !== 'paid')
      .map((o) => Number(o.totalPrice))
  );

  for (let attempt = 0; attempt < 60; attempt++) {
    const code = Math.floor(101 + Math.random() * 799); // 101..899
    if (!usedTotals.has(baseAmount + code)) {
      return code;
    }
  }
  return Math.floor(101 + Math.random() * 799);
};

/**
 * Mengekstrak nominal Rupiah (integer) dari teks notifikasi HP kasir
 * (mendukung GoPay Merchant, DANA Bisnis, ShopeePay, BCA, BRI, Mandiri, BNI, dll.)
 */
export const extractAmountFromNotification = (rawInput) => {
  if (rawInput === null || rawInput === undefined) return 0;
  if (typeof rawInput === 'number' && Number.isFinite(rawInput)) {
    return Math.round(rawInput);
  }

  const text = String(rawInput).trim();
  if (!text) return 0;

  // Jika input murni angka bulat
  if (/^\d+$/.test(text)) {
    return parseInt(text, 10) || 0;
  }

  // Pola 1: Diawali Rp / IDR (misal: "Rp 18.147", "Rp18.147,00", "IDR 18,147.00")
  const currencyRegex = /(?:rp|idr)\.?\s*([0-9][0-9.,]*)/gi;
  let match;
  const candidates = [];

  while ((match = currencyRegex.exec(text)) !== null) {
    const parsed = parseIndonesianNumber(match[1]);
    if (parsed >= 100) candidates.push(parsed);
  }

  if (candidates.length > 0) {
    return candidates[0];
  }

  // Pola 2: Angka berpemisah ribuan di dalam teks notifikasi pembayaran (misal "sebesar 18.147")
  const groupedRegex = /(?:sebesar|nominal|jumlah|terima|masuk|pembayaran)\s*:?\s*([0-9]{1,3}(?:[.,][0-9]{3})+(?:[.,]00)?)/gi;
  while ((match = groupedRegex.exec(text)) !== null) {
    const parsed = parseIndonesianNumber(match[1]);
    if (parsed >= 100) candidates.push(parsed);
  }

  if (candidates.length > 0) {
    return candidates[0];
  }

  // Pola 3: Fallback angka berpemisah titik/koma pertama di dalam kalimat
  const anyGrouped = text.match(/\b([0-9]{1,3}(?:[.,][0-9]{3})+)\b/);
  if (anyGrouped && anyGrouped[1]) {
    return parseIndonesianNumber(anyGrouped[1]);
  }

  return 0;
};

function parseIndonesianNumber(numStr) {
  if (!numStr) return 0;
  // Hapus desimal sen di akhir (,00 atau .00)
  let cleaned = numStr.replace(/[.,]00$/, '');
  // Hapus semua pemisah ribuan (titik atau koma)
  cleaned = cleaned.replace(/[^0-9]/g, '');
  return parseInt(cleaned, 10) || 0;
}
