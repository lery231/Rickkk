const PRESSABLE_SELECTOR = [
  'button',
  '.hero-pick-card',
  '.speed-dial-row',
  '.mood-card',
  '.menu-img-wrap',
  '.tab-btn',
  '.dock-item',
  '.dock-circle-btn',
  '.avatar-glass-btn',
  '.ios-grouped-row',
  '.floating-mini-bar',
  '.ready-card-item',
  '.ios-btn-primary',
  '.ios-btn-secondary',
  '.btn-add',
  '.delete-icon-btn',
  '.conn-pill',
  '.image-picker-box',
].join(', ');

let initialized = false;

export function initGlobalPressAnimation() {
  if (initialized || typeof document === 'undefined') return;
  initialized = true;

  let activeEl = null;
  let releaseTimer = null;

  const setCoordinates = (el, clientX, clientY) => {
    try {
      const rect = el.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        const x = Math.max(0, Math.min(rect.width, clientX - rect.left));
        const y = Math.max(0, Math.min(rect.height, clientY - rect.top));
        el.style.setProperty('--press-x', `${Math.round(x)}px`);
        el.style.setProperty('--press-y', `${Math.round(y)}px`);
      }
    } catch {}
  };

  const clearPress = () => {
    if (!activeEl) return;
    const el = activeEl;
    activeEl = null;
    el.classList.remove('ios-pressing');
    el.classList.add('ios-releasing');
    clearTimeout(releaseTimer);
    releaseTimer = setTimeout(() => {
      el.classList.remove('ios-releasing');
    }, 320);
  };

  document.addEventListener(
    'pointerdown',
    (e) => {
      const target = e.target?.closest?.(PRESSABLE_SELECTOR);
      if (!target || target.disabled) return;
      if (activeEl && activeEl !== target) {
        activeEl.classList.remove('ios-pressing', 'ios-releasing');
      }
      activeEl = target;
      setCoordinates(target, e.clientX, e.clientY);
      target.classList.remove('ios-releasing');
      target.classList.add('ios-pressing');
    },
    { passive: true }
  );

  document.addEventListener(
    'pointermove',
    (e) => {
      if (!activeEl) return;
      setCoordinates(activeEl, e.clientX, e.clientY);
    },
    { passive: true }
  );

  document.addEventListener('pointerup', clearPress, { passive: true });
  document.addEventListener('pointercancel', clearPress, { passive: true });
  window.addEventListener('scroll', clearPress, { passive: true });
}
