export function initGlobalPressEffects() {
  if (typeof window === 'undefined') return () => {};
  const SELECTOR = [
    '.refractive-glass',
    '.glass-pressable',
    '.ios-pill',
    '.dock-item',
    '.dock-search-btn',
    '.dock-aux-circle',
    '.hero-card',
    '.speed-row',
    '.genre-tile',
    '.menu-card',
    '.settings-row',
    '.btn-ios-primary',
    '.btn-ios-secondary',
    '.mini-player-pill',
    '.peek-menu-row',
    '.peek-primary-btn'
  ].join(',');

  let activeEl = null;

  const updatePointerVars = (el, clientX, clientY) => {
    const rect = el.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const xPct = Math.max(0, Math.min(100, ((clientX - rect.left) / rect.width) * 100));
    const yPct = Math.max(0, Math.min(100, ((clientY - rect.top) / rect.height) * 100));
    el.style.setProperty('--press-x', `${xPct.toFixed(1)}%`);
    el.style.setProperty('--press-y', `${yPct.toFixed(1)}%`);
  };

  const releaseActive = () => {
    if (!activeEl) return;
    const el = activeEl;
    activeEl = null;
    el.classList.remove('is-pressed');
    el.classList.add('is-rebounding');
    window.setTimeout(() => {
      el.classList.remove('is-rebounding');
    }, 440);
  };

  const handlePointerDown = (e) => {
    const target = e.target?.closest?.(SELECTOR);
    if (!target || target.disabled) return;
    if (activeEl && activeEl !== target) releaseActive();
    activeEl = target;
    target.classList.remove('is-rebounding');
    updatePointerVars(target, e.clientX, e.clientY);
    target.classList.add('is-pressed');
  };

  const handlePointerMove = (e) => {
    if (!activeEl) return;
    updatePointerVars(activeEl, e.clientX, e.clientY);
  };

  window.addEventListener('pointerdown', handlePointerDown, { passive: true });
  window.addEventListener('pointermove', handlePointerMove, { passive: true });
  window.addEventListener('pointerup', releaseActive, { passive: true });
  window.addEventListener('pointercancel', releaseActive, { passive: true });
  window.addEventListener('blur', releaseActive, { passive: true });

  return () => {
    window.removeEventListener('pointerdown', handlePointerDown);
    window.removeEventListener('pointermove', handlePointerMove);
    window.removeEventListener('pointerup', releaseActive);
    window.removeEventListener('pointercancel', releaseActive);
    window.removeEventListener('blur', releaseActive);
  };
}
