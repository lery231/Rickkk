const LOGIN_ATTEMPT_KEY = '1001sk_auth_guard';
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 60 * 1000;

export function sanitizeText(input, maxLength = 120) {
  if (input === null || input === undefined) return '';
  return String(input)
    .replace(/[\u0000-\u001F\u007F<>]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLength);
}

export function sanitizeSafeUrl(rawUrl) {
  if (!rawUrl) return '';
  const trimmed = String(rawUrl).trim();
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol !== 'https:') return '';
    return parsed.toString();
  } catch {
    return '';
  }
}

export function sanitizeImageUrl(rawUrl, fallback = '') {
  if (!rawUrl) return fallback;
  const trimmed = String(rawUrl).trim();
  if (/^data:image\/(png|jpeg|jpg|webp|gif|svg\+xml);/i.test(trimmed)) {
    return trimmed;
  }
  if (trimmed.startsWith('blob:')) {
    return trimmed;
  }
  const safeHttps = sanitizeSafeUrl(trimmed);
  return safeHttps || fallback;
}

export function checkLoginRateLimit() {
  try {
    const raw = localStorage.getItem(LOGIN_ATTEMPT_KEY);
    if (!raw) return { allowed: true, remainingSeconds: 0 };
    const state = JSON.parse(raw);
    if (state.lockedUntil && Date.now() < state.lockedUntil) {
      return {
        allowed: false,
        remainingSeconds: Math.ceil((state.lockedUntil - Date.now()) / 1000),
      };
    }
    return { allowed: true, remainingSeconds: 0 };
  } catch {
    return { allowed: true, remainingSeconds: 0 };
  }
}

export function recordAuthResult(success) {
  try {
    if (success) {
      localStorage.removeItem(LOGIN_ATTEMPT_KEY);
      return;
    }
    const raw = localStorage.getItem(LOGIN_ATTEMPT_KEY);
    const prev = raw ? JSON.parse(raw) : { count: 0 };
    const nextCount = (prev.count || 0) + 1;
    const lockedUntil = nextCount >= MAX_FAILED_ATTEMPTS ? Date.now() + LOCKOUT_DURATION_MS : 0;
    localStorage.setItem(
      LOGIN_ATTEMPT_KEY,
      JSON.stringify({ count: nextCount >= MAX_FAILED_ATTEMPTS ? 0 : nextCount, lockedUntil })
    );
  } catch {}
}

export function initRuntimeSecurity() {
  try {
    if (typeof window !== 'undefined' && window.self !== window.top) {
      window.top.location = window.self.location;
    }
  } catch {}
}
