let audioCtx = null;

const getAudioContext = () => {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
};

// Unlock audio context on first user interaction for Android WebView compatibility
if (typeof window !== 'undefined') {
  const unlock = () => {
    getAudioContext();
  };
  window.addEventListener('pointerdown', unlock, { passive: true, once: true });
  window.addEventListener('touchstart', unlock, { passive: true, once: true });
}

const playTone = (ctx, freq, startTime, duration, volume = 0.22, type = 'sine') => {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = type;
  osc.frequency.setValueAtTime(freq, startTime);

  gain.gain.setValueAtTime(0.0001, startTime);
  gain.gain.exponentialRampToValueAtTime(volume, startTime + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(startTime);
  osc.stop(startTime + duration + 0.03);
};

// Incoming Order Chime for Seller (Warm 3-note ascending bell)
export const playNewOrderChime = () => {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    playTone(ctx, 523.25, now, 0.35, 0.25, 'sine');        // C5
    playTone(ctx, 659.25, now + 0.14, 0.38, 0.25, 'sine'); // E5
    playTone(ctx, 783.99, now + 0.28, 0.55, 0.28, 'sine'); // G5
    playTone(ctx, 1046.5, now + 0.42, 0.65, 0.22, 'triangle'); // C6 harmonic
  } catch (e) {
    // Ignore audio errors if blocked
  }
};

// Order Ready for Pickup Chime for Customer (Uplifting 4-note crystal chime)
export const playOrderReadyChime = () => {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    playTone(ctx, 587.33, now, 0.28, 0.26, 'sine');        // D5
    playTone(ctx, 739.99, now + 0.12, 0.28, 0.26, 'sine'); // F#5
    playTone(ctx, 880.00, now + 0.24, 0.35, 0.28, 'sine'); // A5
    playTone(ctx, 1174.66, now + 0.36, 0.7, 0.30, 'sine'); // D6
  } catch (e) {
    // Ignore audio errors if blocked
  }
};

// Subtle 120fps tactile feedback
export const triggerHaptic = (pattern = 14) => {
  try {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(pattern);
    }
  } catch (e) {
    // Ignore on unsupported devices
  }
};

// Request system notification permission & show banner notification
export const sendSystemNotification = (title, body) => {
  try {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'granted') {
        new Notification(title, { body, icon: '/favicon.ico' });
      } else if (Notification.permission !== 'denied') {
        Notification.requestPermission().then((perm) => {
          if (perm === 'granted') {
            new Notification(title, { body });
          }
        });
      }
    }
  } catch (e) {
    // Ignore in environments without Notification API
  }
};
