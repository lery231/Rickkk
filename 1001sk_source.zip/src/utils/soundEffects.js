const SOUND_PREF_KEY = '1001sk_sound_enabled';

export function isSoundEnabled() {
  try {
    const val = localStorage.getItem(SOUND_PREF_KEY);
    return val === null ? true : val === 'true';
  } catch {
    return true;
  }
}

export function setSoundEnabled(enabled) {
  try {
    localStorage.setItem(SOUND_PREF_KEY, enabled ? 'true' : 'false');
  } catch {
    // ignore storage errors
  }
}

function getAudioContext() {
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  if (!AudioCtx) return null;
  if (!window.__skAudioCtx) {
    window.__skAudioCtx = new AudioCtx();
  }
  if (window.__skAudioCtx.state === 'suspended') {
    window.__skAudioCtx.resume().catch(() => {});
  }
  return window.__skAudioCtx;
}

export function playTapHaptic() {
  if (navigator.vibrate) {
    navigator.vibrate(10);
  }
  if (!isSoundEnabled()) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = 'sine';
  osc.frequency.setValueAtTime(620, now);
  osc.frequency.exponentialRampToValueAtTime(320, now + 0.035);

  gain.gain.setValueAtTime(0.05, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.035);

  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(now);
  osc.stop(now + 0.04);
}

export function playOrderReadyChime(force = false) {
  if (!force && !isSoundEnabled()) return;
  if (navigator.vibrate) {
    navigator.vibrate([60, 40, 90]);
  }
  const ctx = getAudioContext();
  if (!ctx) return;

  const notes = [587.33, 783.99, 1046.5]; // D5 -> G5 -> C6 crystal glass chime
  notes.forEach((freq, idx) => {
    const start = ctx.currentTime + idx * 0.12;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, start);

    gain.gain.setValueAtTime(0.001, start);
    gain.gain.linearRampToValueAtTime(0.18, start + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0008, start + 0.48);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(start);
    osc.stop(start + 0.5);
  });
}

export function playNewOrderAlert() {
  if (!isSoundEnabled()) return;
  if (navigator.vibrate) {
    navigator.vibrate([100, 60, 100, 60, 140]);
  }
  const ctx = getAudioContext();
  if (!ctx) return;

  const notes = [523.25, 659.25, 783.99, 1046.5];
  notes.forEach((freq, idx) => {
    const start = ctx.currentTime + idx * 0.09;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, start);

    gain.gain.setValueAtTime(0.15, start);
    gain.gain.exponentialRampToValueAtTime(0.001, start + 0.32);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(start);
    osc.stop(start + 0.35);
  });
}
