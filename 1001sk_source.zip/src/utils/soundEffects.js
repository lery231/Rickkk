let audioCtx = null;

const getAudioContext = () => {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
};

if (typeof window !== 'undefined') {
  const unlock = () => { getAudioContext(); };
  window.addEventListener('pointerdown', unlock, { passive: true, once: true });
  window.addEventListener('touchstart', unlock, { passive: true, once: true });
}

const playTone = (ctx, freq, startTime, duration, volume = 0.24, type = 'sine') => {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, startTime);
  gain.gain.setValueAtTime(0.0001, startTime);
  gain.gain.exponentialRampToValueAtTime(volume, startTime + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(startTime);
  osc.stop(startTime + duration + 0.03);
};

export const playNewOrderChime = () => {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    playTone(ctx, 523.25, now, 0.35, 0.25, 'sine');
    playTone(ctx, 659.25, now + 0.14, 0.38, 0.25, 'sine');
    playTone(ctx, 783.99, now + 0.28, 0.55, 0.28, 'sine');
    playTone(ctx, 1046.5, now + 0.42, 0.65, 0.22, 'triangle');
  } catch {}
};

export const playOrderReadyChime = () => {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    playTone(ctx, 587.33, now, 0.26, 0.28, 'sine');
    playTone(ctx, 739.99, now + 0.11, 0.26, 0.28, 'sine');
    playTone(ctx, 880.0, now + 0.22, 0.34, 0.3, 'sine');
    playTone(ctx, 1174.66, now + 0.34, 0.72, 0.32, 'triangle');
  } catch {}
};

export const playPaymentSuccessChime = () => {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    playTone(ctx, 659.25, now, 0.22, 0.28, 'sine');
    playTone(ctx, 987.77, now + 0.12, 0.45, 0.3, 'sine');
    playTone(ctx, 1318.51, now + 0.24, 0.65, 0.26, 'triangle');
  } catch {}
};

export const triggerHaptic = (pattern = 14) => {
  try {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(pattern);
    }
  } catch {}
};

export const sendSystemNotification = async (title, body, options = {}) => {
  try {
    if (typeof window === 'undefined' || !('Notification' in window)) return;
    let permission = Notification.permission;
    if (permission === 'default') {
      permission = await Notification.requestPermission();
    }
    if (permission !== 'granted') return;
    const notifOptions = {
      body,
      icon: './icon-192.png',
      badge: './icon-192.png',
      vibrate: [220, 100, 220, 100, 260],
      requireInteraction: true,
      renotify: true,
      tag: options.tag || '1001sk-order-ready',
      data: options.data || {}
    };
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg && reg.showNotification) {
        await reg.showNotification(title, notifOptions);
        return;
      }
    }
    new Notification(title, notifOptions);
  } catch {}
};
