export const APP_VERSION = '2.8.3';
export const SELLER_EMAIL = 'admin@1001sk.com';

export const MENU_CATEGORIES = [
  'Semua',
  'Signature Coffee',
  'Manual Brew',
  'Non-Coffee',
  'Cold Brew & Mocktail',
  'Snack & Pastry'
];

export const ORDER_STATUS_META = {
  pending_payment: {
    label: 'Menunggu Pembayaran',
    shortLabel: 'Bayar QRIS',
    color: '#ff9f0a',
    bg: 'rgba(255, 159, 10, 0.15)',
    step: 0
  },
  queued: {
    label: 'Menunggu Dibuat',
    shortLabel: 'Antrean',
    color: '#0a84ff',
    bg: 'rgba(10, 132, 255, 0.15)',
    step: 1
  },
  preparing: {
    label: 'Sedang Diracik',
    shortLabel: 'Diracik',
    color: '#ff375f',
    bg: 'rgba(255, 55, 95, 0.15)',
    step: 2
  },
  ready: {
    label: 'Siap Diambil',
    shortLabel: 'Siap Diambil',
    color: '#30d158',
    bg: 'rgba(48, 209, 88, 0.16)',
    step: 3
  },
  completed: {
    label: 'Selesai',
    shortLabel: 'Selesai',
    color: '#8e8e93',
    bg: 'rgba(142, 142, 147, 0.15)',
    step: 4
  },
  cancelled: {
    label: 'Dibatalkan',
    shortLabel: 'Dibatalkan',
    color: '#ff453a',
    bg: 'rgba(255, 69, 58, 0.15)',
    step: -1
  }
};

export const INITIAL_MENU = [
  {
    id: 'sk-01',
    name: 'Kopi Susu 1001 Gula Aren',
    category: 'Signature Coffee',
    price: 18000,
    available: true,
    featured: true,
    desc: 'Espresso double shot house blend dengan gula aren organik khas dan susu creamy dingin.',
    image: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'sk-02',
    name: 'Caramel Macchiato Cloud',
    category: 'Signature Coffee',
    price: 24000,
    available: true,
    featured: true,
    desc: 'Velvet milk foam lembut berpadu espresso aromatik dan saus karamel panggang.',
    image: 'https://images.unsplash.com/photo-1485808191679-5f86510681a2?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'sk-03',
    name: 'V60 Kerinci Natural',
    category: 'Manual Brew',
    price: 22000,
    available: true,
    featured: true,
    desc: 'Seduhan manual biji pilihan dataran tinggi Kerinci dengan notes berry dan cokelat.',
    image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'sk-04',
    name: 'Matcha Kyoto Ceremonial',
    category: 'Non-Coffee',
    price: 25000,
    available: true,
    featured: false,
    desc: 'Bubuk matcha Uji asli dikocok segar dengan susu oat maupun fresh milk.',
    image: 'https://images.unsplash.com/photo-1515823064-d6e0c04616a7?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'sk-05',
    name: 'Citrus Berry Cold Brew',
    category: 'Cold Brew & Mocktail',
    price: 23000,
    available: true,
    featured: true,
    desc: 'Cold brew 18 jam dengan perasan jeruk segar, sirup berry, dan soda dingin.',
    image: 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'sk-06',
    name: 'Croissant Butter Almond',
    category: 'Snack & Pastry',
    price: 20000,
    available: true,
    featured: false,
    desc: 'Pastry renyah berlapis mentega Prancis dengan taburan almond panggang.',
    image: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=800&q=80'
  }
];

export function formatRupiah(amount) {
  const num = Number(amount || 0);
  return 'Rp ' + num.toLocaleString('id-ID');
}

export function formatDateTime(ts) {
  if (!ts) return 'Baru saja';
  const date = ts?.toDate ? ts.toDate() : new Date(ts);
  if (Number.isNaN(date.getTime())) return 'Baru saja';
  return date.toLocaleString('id-ID', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit'
  });
}
