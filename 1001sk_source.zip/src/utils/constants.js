export const DEFAULT_CATEGORIES = ['Signature', 'Espresso', 'Non-Kopi', 'Camilan'];
