export const DEFAULT_CATEGORIES = ['Signature', 'Espresso', 'Non-Kopi', 'Camilan'];

export const ORDER_STATUS_LABELS = {
  menunggu_pembayaran: 'Menunggu Transfer QRIS',
  pending: 'Lunas / Antrean Masuk',
  diproses: 'Sedang Diramu Barista',
  siap: 'Siap Diambil',
  siap_diambil: 'Siap Diambil',
  selesai: 'Selesai',
  dibatalkan: 'Dibatalkan'
};

export const FALLBACK_COFFEE_IMG = "data:image/svg+xml;utf8," + encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">
    <defs>
      <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#2c221e"/>
        <stop offset="100%" stop-color="#141110"/>
      </linearGradient>
    </defs>
    <rect width="400" height="400" fill="url(#g)"/>
    <text x="50%" y="48%" dominant-baseline="middle" text-anchor="middle" fill="#fa2d48" font-family="sans-serif" font-weight="800" font-size="34">1001 SK</text>
    <text x="50%" y="58%" dominant-baseline="middle" text-anchor="middle" fill="#a3a3a8" font-family="sans-serif" font-weight="600" font-size="14" letter-spacing="3">COFFEE &amp; LOUNGE</text>
  </svg>`
);

export const isOrderReadyStatus = (status) => {
  const s = String(status || '').toLowerCase().trim();
  return s === 'siap_diambil' || s === 'ready' || s === 'siap';
};
