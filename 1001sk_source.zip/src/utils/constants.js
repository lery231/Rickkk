export const DEFAULT_CATEGORIES = ['Signature', 'Espresso', 'Non-Kopi', 'Camilan'];

export const ORDER_STATUS_LABELS = {
  menunggu_pembayaran: 'Menunggu Transfer QRIS',
  pending: 'Lunas / Antrean Masuk',
  diproses: 'Sedang Diramu Barista',
  siap: 'Siap Diambil',
  siap_diambil: 'Siap Diambil',
  selesai: 'Selesai',
  dibatalkan: 'Dibatalkan'
};

export const isOrderReadyStatus = (status) => {
  const s = String(status || '').toLowerCase().trim();
  return s === 'siap_diambil' || s === 'ready' || s === 'siap';
};
