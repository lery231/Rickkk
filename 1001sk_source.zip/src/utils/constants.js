export const DEFAULT_CATEGORIES = ['Signature', 'Espresso', 'Non-Kopi', 'Camilan'];

export const ORDER_STATUS_LABELS = {
  menunggu_pembayaran: 'Menunggu Pembayaran',
  diproses: 'Sedang Diracik',
  siap_diambil: 'Siap Diambil',
  selesai: 'Selesai',
  dibatalkan: 'Dibatalkan'
};

export const isOrderReadyStatus = (status) => {
  const s = String(status || '').toLowerCase().trim();
  return s === 'siap_diambil' || s === 'ready' || s === 'siap';
};
