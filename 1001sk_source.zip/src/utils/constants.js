export const DEFAULT_CATEGORIES = ['Signature', 'Espresso', 'Non-Kopi', 'Camilan'];

export const ORDER_STATUS_LABELS = {
  menunggu_pembayaran: 'Menunggu Transfer QRIS',
  pending: 'Lunas / Antrean Masuk',
  diproses: 'Sedang Diramu Barista',
  siap: 'Siap Diambil',
  siap_diambil: 'Siap Diambil',
  selesai: 'Selesai',
  dibatalkan: 'Dibatalkan'
};

export const FALLBACK_COFFEE_IMG =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300">
      <defs>
        <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#1d192b"/>
          <stop offset="100%" stop-color="#110f1a"/>
        </linearGradient>
      </defs>
      <rect width="400" height="300" fill="url(#g)"/>
      <circle cx="200" cy="135" r="64" fill="rgba(235,196,138,0.15)"/>
      <rect x="160" y="110" width="72" height="62" rx="14" fill="#ebc48a"/>
      <path d="M232 122 h14 a15 15 0 0 1 0 30 h-14" fill="none" stroke="#ebc48a" stroke-width="8"/>
      <text x="200" y="216" text-anchor="middle" fill="#ebc48a" font-family="sans-serif" font-size="17" font-weight="bold">1001 SK COFFEE</text>
    </svg>`
  );

export const isOrderReadyStatus = (status) => {
  const s = String(status || '').toLowerCase().trim();
  return s === 'siap_diambil' || s === 'ready' || s === 'siap';
};
