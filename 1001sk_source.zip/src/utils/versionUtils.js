export const CURRENT_APP_VERSION = '2.6.1';

export function compareVersions(v1 = '0.0.0', v2 = '0.0.0') {
  const a = String(v1).replace(/^v/i, '').split('.').map(Number);
  const b = String(v2).replace(/^v/i, '').split('.').map(Number);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const diff = (a[i] || 0) - (b[i] || 0);
    if (diff !== 0) return diff > 0 ? 1 : -1;
  }
  return 0;
}

export async function executeAppUpdate(updateInfo) {
  if (updateInfo?.apkUrl) {
    window.open(updateInfo.apkUrl, '_system');
    return;
  }
  if ('serviceWorker' in navigator) {
    const regs = await navigator.serviceWorker.getRegistrations();
    await Promise.all(regs.map((r) => r.update()));
  }
  window.location.reload();
}
