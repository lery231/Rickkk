export const CURRENT_APP_VERSION = '2.4.0';

/**
 * Membandingkan dua versi semantik (misal '2.5.0' vs '2.4.0').
 * Return 1 jika v1 > v2, -1 jika v1 < v2, 0 jika sama.
 */
export const compareVersions = (v1, v2) => {
  if (!v1 || !v2) return 0;
  const clean1 = String(v1).replace(/^v/i, '').trim().split('.').map(n => parseInt(n, 10) || 0);
  const clean2 = String(v2).replace(/^v/i, '').trim().split('.').map(n => parseInt(n, 10) || 0);
  const maxLen = Math.max(clean1.length, clean2.length);

  for (let i = 0; i < maxLen; i++) {
    const num1 = clean1[i] || 0;
    const num2 = clean2[i] || 0;
    if (num1 > num2) return 1;
    if (num1 < num2) return -1;
  }
  return 0;
};

/**
 * Mengubah link berbagi Google Drive standar menjadi link unduh langsung (direct download)
 * Contoh: https://drive.google.com/file/d/FILE_ID/view?usp=sharing -> https://drive.google.com/uc?export=download&id=FILE_ID
 */
export const normalizeApkDownloadUrl = (rawUrl) => {
  if (!rawUrl) return '';
  const trimmed = rawUrl.trim();

  // Format 1: https://drive.google.com/file/d/<FILE_ID>/view...
  const fileMatch = trimmed.match(/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (fileMatch && fileMatch[1]) {
    return `https://drive.google.com/uc?export=download&id=${fileMatch[1]}`;
  }

  // Format 2: https://drive.google.com/open?id=<FILE_ID> atau uc?id=<FILE_ID>
  const idMatch = trimmed.match(/drive\.google\.com\/(?:open|uc)\?.*?id=([a-zA-Z0-9_-]+)/);
  if (idMatch && idMatch[1]) {
    return `https://drive.google.com/uc?export=download&id=${idMatch[1]}`;
  }

  return trimmed;
};

/**
 * Menjalankan unduhan APK terbaru atau menyegarkan cache Web/PWA di dalam aplikasi.
 */
export const executeAppUpdate = async (apkUrl) => {
  const cleanUrl = normalizeApkDownloadUrl(apkUrl);
  if (cleanUrl) {
    // Buka di browser sistem / download manager Android agar APK langsung terunduh
    const opened = window.open(cleanUrl, '_system');
    if (!opened) {
      const link = document.createElement('a');
      link.href = cleanUrl;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.setAttribute('download', '1001-SK-latest.apk');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
    return;
  }

  // Fallback jika tanpa URL APK (mode Web / PWA): bersihkan cache dan muat ulang
  if ('caches' in window) {
    try {
      const keys = await caches.keys();
      await Promise.all(keys.map(k => caches.delete(k)));
    } catch {}
  }
  window.location.reload();
};
