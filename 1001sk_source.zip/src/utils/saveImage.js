import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';

export async function saveDataUrlImage(dataUrl, fileName = 'QRIS-1001SK.png') {
  if (!dataUrl) throw new Error('Data gambar kosong');
  if (Capacitor.isNativePlatform()) {
    const base64Data = dataUrl.includes(',') ? dataUrl.split(',')[1] : dataUrl;
    const saved = await Filesystem.writeFile({
      path: fileName,
      data: base64Data,
      directory: Directory.Documents,
      recursive: true
    });
    return { mode: 'native', path: saved.uri };
  }
  const link = document.createElement('a');
  link.href = dataUrl;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  return { mode: 'web', path: fileName };
}
