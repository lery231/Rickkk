import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

// Di APK: tulis ke cache lalu buka menu bagikan/simpan Android. Di browser: unduh langsung.
export async function saveImage(dataUrl, filename) {
  if (Capacitor.isNativePlatform()) {
    const res = await Filesystem.writeFile({
      path: filename,
      data: dataUrl.split(',')[1],
      directory: Directory.Cache,
    });
    await Share.share({ title: 'QRIS 1001 SK', files: [res.uri] });
    return;
  }
  const a = document.createElement('a');
  a.href = dataUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
}
