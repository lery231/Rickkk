// SETUP FIREBASE KAMU DI SINI
// 1. Buka console.firebase.google.com
// 2. Buat project -> Web App -> Copy config di bawah
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  // GANTI DENGAN CONFIG ASLI DARI FIREBASE NANTI SAAT SUDAH SIAP
  apiKey: "API_KEY_KAMU",
  authDomain: "PROJECT_ID.firebaseapp.com",
  projectId: "PROJECT_ID",
  storageBucket: "PROJECT_ID.appspot.com",
  messagingSenderId: "SENDER_ID",
  appId: "APP_ID"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
