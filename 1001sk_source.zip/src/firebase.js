import { initializeApp } from 'firebase/app';
import { initializeFirestore, persistentLocalCache } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSy_MOCK_KEY",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "kopi1001sk.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "kopi1001sk",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "kopi1001sk.appspot.com",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "100110011001",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:10011001:web:1001sk"
};

const app = initializeApp(firebaseConfig);

// Auto-detect long polling = koneksi realtime lebih stabil di WebView Android.
let firestore;
try {
  firestore = initializeFirestore(app, {
    localCache: persistentLocalCache(),
    experimentalAutoDetectLongPolling: true,
  });
} catch {
  firestore = initializeFirestore(app, { experimentalAutoDetectLongPolling: true });
}

export const db = firestore;
export const auth = getAuth(app);
