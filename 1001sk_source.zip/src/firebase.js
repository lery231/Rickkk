import { initializeApp } from 'firebase/app';
import {
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  disableNetwork,
  enableNetwork
} from 'firebase/firestore';
import {
  initializeAuth,
  getAuth,
  indexedDBLocalPersistence,
  browserLocalPersistence,
  browserPopupRedirectResolver
} from 'firebase/auth';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSy_MOCK_KEY",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "kopi1001sk.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "kopi1001sk",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "kopi1001sk.appspot.com",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "100110011001",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:10011001:web:1001sk"
};

const app = initializeApp(firebaseConfig);

// Persistensi ganda (IndexedDB + LocalStorage) mencegah sesi logout sendiri di WebView APK Android
let authInstance;
try {
  authInstance = initializeAuth(app, {
    persistence: [indexedDBLocalPersistence, browserLocalPersistence],
    popupRedirectResolver: browserPopupRedirectResolver
  });
} catch {
  authInstance = getAuth(app);
}

// ForceLongPolling + multi-tab cache mencegah delay koneksi WebChannel di jaringan seluler & WebView
let firestore;
try {
  firestore = initializeFirestore(app, {
    localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
    experimentalForceLongPolling: true
  });
} catch {
  try {
    firestore = initializeFirestore(app, { experimentalForceLongPolling: true });
  } catch {
    firestore = initializeFirestore(app, {});
  }
}

export const FIREBASE_PROJECT_ID = firebaseConfig.projectId;
export const db = firestore;
export const auth = authInstance;

let isReconnecting = false;

/**
 * Memulihkan koneksi realtime Firestore & menyegarkan token Auth tanpa perlu relog APK atau refresh web.
 */
export async function reconnectRealtimeEngine({ refreshToken = true, cycleNetwork = true } = {}) {
  if (isReconnecting) return false;
  isReconnecting = true;
  try {
    if (refreshToken && auth.currentUser) {
      try {
        await auth.currentUser.getIdToken(true);
      } catch (tokenErr) {
        console.warn('[1001SK] Token refresh warning:', tokenErr?.code || tokenErr?.message);
      }
    }

    if (cycleNetwork && typeof navigator !== 'undefined' && navigator.onLine !== false) {
      await disableNetwork(db);
      await enableNetwork(db);
    }
    return true;
  } catch (err) {
    console.warn('[1001SK] Reconnect warning:', err?.message);
    try {
      await enableNetwork(db);
    } catch {}
    return false;
  } finally {
    isReconnecting = false;
  }
}
