import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';

const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const versionName = pkg.version || '2.6.3';
const parts = versionName.split('.').map((n) => parseInt(n, 10) || 0);
const versionCode = (parts[0] || 2) * 10000 + (parts[1] || 6) * 100 + (parts[2] || 3);

const androidDir = path.resolve('android');
const appDir = path.join(androidDir, 'app');

const targetKeystore = path.join(appDir, '1001sk-release.keystore');
if (fs.existsSync('1001sk-release.keystore')) {
  fs.copyFileSync('1001sk-release.keystore', targetKeystore);
  console.log('[configure-android] Keystore rilis disalin.');
} else if (!fs.existsSync(targetKeystore)) {
  execSync(
    `keytool -genkeypair -v -keystore "${targetKeystore}" -alias kopi1001sk_release -keyalg RSA -keysize 2048 -validity 10000 -storepass "Kopi1001SK#Release2026" -keypass "Kopi1001SK#Release2026" -dname "CN=1001 SK Coffee, OU=Mobile, O=1001 SK, L=Riau, S=Riau, C=ID"`,
    { stdio: 'inherit' }
  );
}

const buildGradlePath = path.join(appDir, 'build.gradle');
if (fs.existsSync(buildGradlePath)) {
  let gradle = fs.readFileSync(buildGradlePath, 'utf8');
  gradle = gradle.replace(/versionCode\s+\d+/, `versionCode ${versionCode}`);
  gradle = gradle.replace(/versionName\s+"[^"]+"/, `versionName "${versionName}"`);

  if (!gradle.includes('kopi1001sk_release')) {
    const signingBlock = `
    signingConfigs {
        release {
            storeFile file("1001sk-release.keystore")
            storePassword "Kopi1001SK#Release2026"
            keyAlias "kopi1001sk_release"
            keyPassword "Kopi1001SK#Release2026"
        }
    }
`;
    gradle = gradle.replace(/buildTypes\s*\{/, `${signingBlock}\n    buildTypes {`);
    gradle = gradle.replace(
      /(release\s*\{[\s\S]*?)(minifyEnabled)/,
      `$1signingConfig signingConfigs.release\n            $2`
    );
  }
  fs.writeFileSync(buildGradlePath, gradle, 'utf8');
  console.log(`[configure-android] build.gradle diperbarui -> v${versionName} (code ${versionCode}) + release signing.`);
}

const manifestPath = path.join(appDir, 'src', 'main', 'AndroidManifest.xml');
if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');
  const perms = [
    'android.permission.INTERNET',
    'android.permission.ACCESS_NETWORK_STATE',
    'android.permission.VIBRATE',
    'android.permission.POST_NOTIFICATIONS',
  ];
  for (const p of perms) {
    if (!manifest.includes(p)) {
      manifest = manifest.replace(
        '<application',
        `    <uses-permission android:name="${p}" />\n\n    <application`
      );
    }
  }
  fs.writeFileSync(manifestPath, manifest, 'utf8');
  console.log('[configure-android] AndroidManifest.xml diperbarui.');
}

const iconSrc = path.resolve('public', 'icon-512.png');
if (fs.existsSync(iconSrc)) {
  const resDir = path.join(appDir, 'src', 'main', 'res');
  const densities = ['mipmap-mdpi', 'mipmap-hdpi', 'mipmap-xhdpi', 'mipmap-xxhdpi', 'mipmap-xxxhdpi'];
  for (const d of densities) {
    const dPath = path.join(resDir, d);
    if (fs.existsSync(dPath)) {
      fs.copyFileSync(iconSrc, path.join(dPath, 'ic_launcher.png'));
      fs.copyFileSync(iconSrc, path.join(dPath, 'ic_launcher_round.png'));
    }
  }
  console.log('[configure-android] Ikon aplikasi 1001 SK terpasang di semua mipmap.');
}
