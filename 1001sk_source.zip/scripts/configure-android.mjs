import fs from 'node:fs';
import path from 'node:path';

const rootDir = process.cwd();
const androidDir = path.join(rootDir, 'android');
const appDir = path.join(androidDir, 'app');
const resXmlDir = path.join(appDir, 'src', 'main', 'res', 'xml');
const manifestPath = path.join(appDir, 'src', 'main', 'AndroidManifest.xml');
const buildGradlePath = path.join(appDir, 'build.gradle');

if (!fs.existsSync(appDir)) {
  console.log('Direktori android/app belum tersedia, melewati konfigurasi native.');
  process.exit(0);
}

fs.mkdirSync(resXmlDir, { recursive: true });

// 1. Network Security Config
const networkConfigPath = path.join(resXmlDir, 'network_security_config.xml');
fs.writeFileSync(
  networkConfigPath,
  `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>
</network-security-config>
`,
  'utf8'
);

// 2. Patch AndroidManifest.xml
if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');
  if (!manifest.includes('android.permission.INTERNET')) {
    manifest = manifest.replace(
      '<application',
      `    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application`
    );
  }
  if (!manifest.includes('android:networkSecurityConfig')) {
    manifest = manifest.replace(
      '<application',
      '<application android:networkSecurityConfig="@xml/network_security_config"'
    );
  }
  fs.writeFileSync(manifestPath, manifest, 'utf8');
}

// 3. Patch build.gradle for Release Signing & v2.9.0 versioning
if (fs.existsSync(buildGradlePath)) {
  let gradle = fs.readFileSync(buildGradlePath, 'utf8');
  gradle = gradle.replace(/versionCode\s+\d+/, 'versionCode 290');
  gradle = gradle.replace(/versionName\s+"[^"]+"/, 'versionName "2.9.0"');

  if (!gradle.includes('signingConfigs')) {
    const signingBlock = `
    signingConfigs {
        release {
            storeFile file("1001sk-release.jks")
            storePassword "kopi1001sk"
            keyAlias "1001sk"
            keyPassword "kopi1001sk"
        }
    }
`;
    gradle = gradle.replace('buildTypes {', `${signingBlock}
    buildTypes {`);
    gradle = gradle.replace(
      /release\s*\{/,
      'release {
            signingConfig signingConfigs.release'
    );
  }
  fs.writeFileSync(buildGradlePath, gradle, 'utf8');
}

console.log('Konfigurasi Android 1001 SK v2.9.0 berhasil diterapkan.');
