import fs from 'node:fs';
import path from 'node:path';

const rootDir = process.cwd();
const androidDir = path.join(rootDir, 'android');
const appDir = path.join(androidDir, 'app');
const buildGradlePath = path.join(appDir, 'build.gradle');
const manifestPath = path.join(appDir, 'src', 'main', 'AndroidManifest.xml');
const proguardPath = path.join(appDir, 'proguard-rules.pro');

if (!fs.existsSync(buildGradlePath)) {
  console.error('android/app/build.gradle tidak ditemukan. Jalankan npx cap add android terlebih dahulu.');
  process.exit(1);
}

const runNumber = parseInt(process.env.GITHUB_RUN_NUMBER || '1', 10) || 1;
const versionCode = 26200 + runNumber;
const versionName = '2.6.2';

const proguardRules = `
-keep class com.getcapacitor.** { *; }
-keepclassmembers class * {
    @com.getcapacitor.PluginMethod <methods>;
}
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-dontwarn okhttp3.**
-dontwarn okio.**
`;
fs.writeFileSync(proguardPath, proguardRules.trim() + '\n', 'utf8');

let gradle = fs.readFileSync(buildGradlePath, 'utf8');

gradle = gradle.replace(/versionCode\s+\d+/, `versionCode ${versionCode}`);
gradle = gradle.replace(/versionName\s+"[^"]+"/, `versionName "${versionName}"`);

const signingBlock = `
    signingConfigs {
        release {
            storeFile file("../../signing/1001sk-release.keystore")
            storePassword "Kopi1001SK#Release2026"
            keyAlias "kopi1001sk_release"
            keyPassword "Kopi1001SK#Release2026"
            enableV1Signing true
            enableV2Signing true
        }
    }
`;

if (!gradle.includes('signingConfigs')) {
  gradle = gradle.replace(/buildTypes\s*\{/, `${signingBlock}\n    buildTypes {`);
}

gradle = gradle.replace(
  /release\s*\{[\s\S]*?proguardFiles[^\n]*\n\s*\}/,
  `release {
            signingConfig signingConfigs.release
            debuggable false
            jniDebuggable false
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }`
);

fs.writeFileSync(buildGradlePath, gradle, 'utf8');

if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');

  if (manifest.includes('android:usesCleartextTraffic=')) {
    manifest = manifest.replace(/android:usesCleartextTraffic="(true|false)"/, 'android:usesCleartextTraffic="false"');
  } else {
    manifest = manifest.replace('<application', '<application\n        android:usesCleartextTraffic="false"');
  }

  if (manifest.includes('android:allowBackup=')) {
    manifest = manifest.replace(/android:allowBackup="(true|false)"/, 'android:allowBackup="false"');
  } else {
    manifest = manifest.replace('<application', '<application\n        android:allowBackup="false"');
  }

  const requiredPerms = [
    '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
    '<uses-permission android:name="android.permission.VIBRATE" />'
  ];

  for (const perm of requiredPerms) {
    if (!manifest.includes(perm)) {
      manifest = manifest.replace(
        '<uses-permission android:name="android.permission.INTERNET" />',
        `<uses-permission android:name="android.permission.INTERNET" />\n    ${perm}`
      );
    }
  }

  fs.writeFileSync(manifestPath, manifest, 'utf8');
}

const iconSrc = path.join(rootDir, 'public', 'icon-512.png');
const resDir = path.join(appDir, 'src', 'main', 'res');
if (fs.existsSync(iconSrc) && fs.existsSync(resDir)) {
  const densities = ['mipmap-mdpi', 'mipmap-hdpi', 'mipmap-xhdpi', 'mipmap-xxhdpi', 'mipmap-xxxhdpi'];
  for (const d of densities) {
    const targetDir = path.join(resDir, d);
    if (fs.existsSync(targetDir)) {
      fs.copyFileSync(iconSrc, path.join(targetDir, 'ic_launcher.png'));
      fs.copyFileSync(iconSrc, path.join(targetDir, 'ic_launcher_round.png'));
      fs.copyFileSync(iconSrc, path.join(targetDir, 'ic_launcher_foreground.png'));
    }
  }
}

console.log(`Konfigurasi Android Release selesai: versionName=${versionName}, versionCode=${versionCode}`);
