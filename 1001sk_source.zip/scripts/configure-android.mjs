import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';

const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const versionName = pkg.version || '2.7.0';
const parts = versionName.split('.').map((n) => parseInt(n, 10) || 0);
const versionCode = (parts[0] || 2) * 10000 + (parts[1] || 7) * 100 + (parts[2] || 0);

const androidDir = path.resolve('android');
const appDir = path.join(androidDir, 'app');
const targetKeystore = path.join(appDir, '1001sk-release.keystore');

if (fs.existsSync('1001sk-release.keystore')) {
  fs.copyFileSync('1001sk-release.keystore', targetKeystore);
  console.log('[configure-android] Keystore rilis disalin.');
} else if (!fs.existsSync(targetKeystore)) {
  execSync(
    `keytool -genkeypair -v -keystore "${targetKeystore}" -alias kopi1001sk_release -keyalg RSA -keysize 2048 -validity 10000 -storepass "Kopi1001SK#Release2026" -keypass "Kopi1001SK#Release2026" -dname "CN=1001 SK Coffee, OU=Mobile, O=1001 SK, L=Riau, S=Riau, C=ID"`,
    { stdio: 'inherit' }
  );
}

const proguardPath = path.join(appDir, 'proguard-rules.pro');
const proguardRules = `
# 1001 SK v2.7.0 Release Hardening & Capacitor Stability Rules
-optimizationpasses 3
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose

-keepattributes *Annotation*,JavascriptInterface,Signature,InnerClasses,EnclosingMethod
-keep class com.getcapacitor.** { *; }
-keep class * extends com.getcapacitor.Plugin { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
    @com.getcapacitor.PluginMethod <methods>;
}

-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.firebase.**
-dontwarn com.google.android.gms.**
-dontwarn okhttp3.**
-dontwarn okio.**
`;
fs.writeFileSync(proguardPath, proguardRules.trim() + '\n', 'utf8');

const resXmlDir = path.join(appDir, 'src', 'main', 'res', 'xml');
fs.mkdirSync(resXmlDir, { recursive: true });
fs.writeFileSync(
  path.join(resXmlDir, 'network_security_config.xml'),
  `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>
</network-security-config>
`,
  'utf8'
);

const buildGradlePath = path.join(appDir, 'build.gradle');
if (fs.existsSync(buildGradlePath)) {
  let gradle = fs.readFileSync(buildGradlePath, 'utf8');
  gradle = gradle.replace(/versionCode\s+\d+/, `versionCode ${versionCode}`);
  gradle = gradle.replace(/versionName\s+"[^"]+"/, `versionName "${versionName}"`);

  if (!gradle.includes('kopi1001sk_release')) {
    const signingBlock = `
    signingConfigs {
        release {
            storeFile file("1001sk-release.keystore")
            storePassword "Kopi1001SK#Release2026"
            keyAlias "kopi1001sk_release"
            keyPassword "Kopi1001SK#Release2026"
        }
    }
`;
    gradle = gradle.replace(/buildTypes\s*\{/, `${signingBlock}\n    buildTypes {`);
  }

  gradle = gradle.replace(
    /release\s*\{[\s\S]*?proguardFiles[^\n]*\n\s*\}/,
    `release {
            signingConfig signingConfigs.release
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }`
  );

  fs.writeFileSync(buildGradlePath, gradle, 'utf8');
  console.log(`[configure-android] build.gradle diperbarui -> v${versionName} (code ${versionCode}) + R8 Hardening.`);
}

const manifestPath = path.join(appDir, 'src', 'main', 'AndroidManifest.xml');
if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');
  const perms = [
    'android.permission.INTERNET',
    'android.permission.ACCESS_NETWORK_STATE',
    'android.permission.VIBRATE',
    'android.permission.POST_NOTIFICATIONS',
  ];
  for (const p of perms) {
    if (!manifest.includes(p)) {
      manifest = manifest.replace(
        '<application',
        `    <uses-permission android:name="${p}" />\n\n    <application`
      );
    }
  }

  if (!manifest.includes('android:allowBackup')) {
    manifest = manifest.replace(
      '<application',
      '<application\n        android:allowBackup="false"\n        android:usesCleartextTraffic="false"\n        android:hardwareAccelerated="true"\n        android:networkSecurityConfig="@xml/network_security_config"'
    );
  }

  fs.writeFileSync(manifestPath, manifest, 'utf8');
  console.log('[configure-android] AndroidManifest.xml diperbarui.');
}
