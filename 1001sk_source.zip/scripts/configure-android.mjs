import fs from 'node:fs';
import path from 'node:path';

const rootDir = process.cwd();
const androidDir = path.join(rootDir, 'android');
const appDir = path.join(androidDir, 'app');
const resXmlDir = path.join(appDir, 'src', 'main', 'res', 'xml');
const manifestPath = path.join(appDir, 'src', 'main', 'AndroidManifest.xml');
const buildGradlePath = path.join(appDir, 'build.gradle');
const proguardPath = path.join(appDir, 'proguard-rules.pro');
const rootKeystorePath = path.join(rootDir, '1001sk-release.keystore');
const appKeystorePath = path.join(appDir, '1001sk-release.keystore');

if (!fs.existsSync(appDir)) {
  console.error('[1001SK] Folder android/app tidak ditemukan. Jalankan npx cap add android lebih dulu.');
  process.exit(1);
}

if (fs.existsSync(rootKeystorePath)) {
  fs.copyFileSync(rootKeystorePath, appKeystorePath);
  console.log('[1001SK] Release keystore disalin ke android/app/1001sk-release.keystore');
}

const proguardRules = `
# 1001 SK ProGuard / R8 Hardening Rules
-keep class com.getcapacitor.** { *; }
-keep @com.getcapacitor.annotation.CapacitorPlugin class * { *; }
-keepclassmembers class * {
    @com.getcapacitor.PluginMethod <methods>;
}
-keep class com.kopi1001sk.app.** { *; }
-dontwarn com.google.firebase.**
-dontwarn okhttp3.**
`;
fs.writeFileSync(proguardPath, proguardRules.trim() + '\n', 'utf8');

fs.mkdirSync(resXmlDir, { recursive: true });
const networkSecurityConfig = `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>
</network-security-config>
`;
fs.writeFileSync(path.join(resXmlDir, 'network_security_config.xml'), networkSecurityConfig, 'utf8');

if (fs.existsSync(buildGradlePath)) {
  let gradle = fs.readFileSync(buildGradlePath, 'utf8');
  gradle = gradle.replace(/versionCode\s+\d+/, 'versionCode 271');
  gradle = gradle.replace(/versionName\s+"[^"]+"/, 'versionName "2.7.1"');

  if (!gradle.includes('signingConfigs')) {
    const signingBlock = `
    signingConfigs {
        release {
            storeFile file("1001sk-release.keystore")
            storePassword System.getenv("KEYSTORE_PASSWORD") ?: "Kopi1001SK#Release2026"
            keyAlias System.getenv("KEY_ALIAS") ?: "kopi1001sk_release"
            keyPassword System.getenv("KEY_PASSWORD") ?: "Kopi1001SK#Release2026"
        }
    }
`;
    gradle = gradle.replace(/buildTypes\s*\{/, signingBlock + '\n    buildTypes {');
  }

  gradle = gradle.replace(
    /release\s*\{[\s\S]*?proguardFiles[^\n]*\n\s*\}/,
    `release {
            signingConfig signingConfigs.release
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }`
  );
  fs.writeFileSync(buildGradlePath, gradle, 'utf8');
  console.log('[1001SK] build.gradle v2.7.1 & R8 minify + signing configured.');
}

if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');
  const perms = [
    'android.permission.INTERNET',
    'android.permission.ACCESS_NETWORK_STATE',
    'android.permission.POST_NOTIFICATIONS',
    'android.permission.VIBRATE',
  ];
  for (const perm of perms) {
    if (!manifest.includes(perm)) {
      manifest = manifest.replace(
        '<application',
        `    <uses-permission android:name="${perm}" />\n    <application`
      );
    }
  }
  manifest = manifest.replace(/android:allowBackup="true"/g, 'android:allowBackup="false"');
  if (!manifest.includes('android:networkSecurityConfig')) {
    manifest = manifest.replace(
      '<application',
      '<application android:networkSecurityConfig="@xml/network_security_config"'
    );
  }
  fs.writeFileSync(manifestPath, manifest, 'utf8');
  console.log('[1001SK] AndroidManifest.xml hardened.');
}
