import fs from 'node:fs';
import path from 'node:path';

const androidAppDir = path.resolve('android/app');
const buildGradlePath = path.join(androidAppDir, 'build.gradle');
const manifestPath = path.join(androidAppDir, 'src/main/AndroidManifest.xml');
const proguardPath = path.join(androidAppDir, 'proguard-rules.pro');
const resXmlDir = path.join(androidAppDir, 'src/main/res/xml');

if (!fs.existsSync(androidAppDir)) {
  console.log('Direktori android/app belum tersedia. Jalankan npx cap add android terlebih dahulu.');
  process.exit(0);
}

const proguardRules = `
-keep class com.kopi1001sk.app.** { *; }
-dontwarn com.google.firebase.**
-dontwarn okhttp3.**
`;
fs.writeFileSync(proguardPath, proguardRules.trim() + '\n', 'utf8');

fs.mkdirSync(resXmlDir, { recursive: true });
const networkSecurityConfig = `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="true">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>
</network-security-config>
`;
fs.writeFileSync(path.join(resXmlDir, 'network_security_config.xml'), networkSecurityConfig, 'utf8');

if (fs.existsSync(buildGradlePath)) {
  let gradle = fs.readFileSync(buildGradlePath, 'utf8');
  gradle = gradle.replace(/versionCode\s+\d+/, 'versionCode 284');
  gradle = gradle.replace(/versionName\s+"[^"]+"/, 'versionName "2.8.4"');

  if (!gradle.includes('signingConfigs')) {
    const signingBlock = `
    signingConfigs {
        release {
            storeFile file("1001sk-release.keystore")
            storePassword System.getenv("KEYSTORE_PASSWORD") ?: "Kopi1001SK#Release2026"
            keyAlias System.getenv("KEY_ALIAS") ?: "kopi1001sk_release"
            keyPassword System.getenv("KEY_PASSWORD") ?: "Kopi1001SK#Release2026"
        }
    }
`;
    gradle = gradle.replace(/buildTypes\s*\{/, signingBlock + '\n    buildTypes {');
  }

  gradle = gradle.replace(
    /release\s*\{[\s\S]*?proguardFiles[^\n]*\n\s*\}/,
    `release {
            signingConfig signingConfigs.release
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }`
  );
  fs.writeFileSync(buildGradlePath, gradle, 'utf8');
}

if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');
  const perms = [
    'android.permission.INTERNET',
    'android.permission.ACCESS_NETWORK_STATE',
    'android.permission.POST_NOTIFICATIONS',
    'android.permission.VIBRATE',
  ];
  for (const perm of perms) {
    if (!manifest.includes(perm)) {
      manifest = manifest.replace(
        '<application',
        `<uses-permission android:name="${perm}" />\n    <application`
      );
    }
  }
  if (!manifest.includes('networkSecurityConfig')) {
    manifest = manifest.replace(
      '<application',
      '<application android:networkSecurityConfig="@xml/network_security_config"'
    );
  }
  fs.writeFileSync(manifestPath, manifest, 'utf8');
}

console.log('Konfigurasi Android 1001 SK v2.8.4 selesai.');
