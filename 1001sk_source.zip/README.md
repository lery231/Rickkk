# 1001 SK — Coffee & Lounge (v2.9.0 Convx Refractive Liquid Glass)

Arsip proyek lengkap **1001 SK v2.9.0** siap unggah ke GitHub untuk kompilasi otomatis APK Android via **GitHub Actions**.

## Fitur Utama v2.9.0
1. **Convx Refractive Liquid Glass & Cupertino HIG**:
   - Floating Island Header, Interactive Capsule Dock dengan animasi spring, serta mode **Terang & Gelap**.
   - Navigasi **geser horizontal (Swipe)** antar-tab dan **Peek & Pop** pratinjau tekan lama pada kartu menu.
2. **Foto Produk Lengkap & Pembayaran QRIS Penuh**:
   - Foto produk tampil di Pilihan Hari Ini, Grid Menu, Keranjang, Pesanan, dan Pratinjau Tekan Lama.
   - Layar penuh QRIS saat checkout lengkap dengan tombol **Salin Nominal**, **Simpan QRIS**, **Bagikan**, dan **Verifikasi Mutasi Otomatis** untuk penjual.
3. **Kontrol Penjual, Suara Notifikasi & Riwayat Pesanan**:
   - **Penjual tidak bisa memesan** di dalam aplikasi (proteksi UI & logika checkout).
   - **Nada notifikasi** otomatis saat pesanan masuk maupun saat pesanan siap diambil.
   - **Hapus riwayat pesanan** (per item maupun hapus semua riwayat selesai/dibatalkan).
4. **Build Otomatis GitHub Actions (`build-apk.yml`)**:
   - Mendukung unggah ZIP langsung maupun ekstraksi ke repositori GitHub dengan penandatanganan keystore rilis (`assembleRelease`).
