# 1001 SK v2.8.4 — Convx Refractive Liquid Glass

Aplikasi pemesanan kopi real-time **1001 SK (Sistem Kopi)** dengan antarmuka **Convx Refractive Liquid Glass** (terinspirasi iOS 28 HIG), dukungan mode terang & gelap, pembayaran QRIS, notifikasi suara real-time, proteksi peran penjual, dan kompilasi otomatis APK Android via GitHub Actions.

## Cara Build APK Otomatis di GitHub (Tanpa Laptop)
1. Upload seluruh file proyek (atau ekstrak ZIP ini ke repositori GitHub Anda).
2. Buka tab **Actions** pada repositori GitHub Anda.
3. Workflow **Build 1001 SK v2.8.4 APK** akan berjalan otomatis dan menghasilkan file APK (`app-debug.apk` & `app-release.apk`) siap unduh di bagian **Artifacts**.

## Akun Mode Penjual (Default)
- **Email Penjual:** `admin@1001sk.com` (kata sandi bebas saat mode lokal, atau sesuai akun Firebase Anda).
- Akun penjual memiliki akses penuh ke pesanan masuk, kelola menu, unggah QRIS statis, pencocokan mutasi otomatis, dan dinonaktifkan dari fitur pemesanan pelanggan.
