# 1001 SK — Coffee & Lounge (v2.7.1 Liquid Glass Release)

Aplikasi pemesanan kopi real-time dengan antarmuka **Liquid Glass (Dark & Light)**, foto produk & unggah galeri HP, pembayaran **QRIS Otomatis (Kode Unik 3 Digit + Webhook MacroDroid)**, notifikasi mengambang pesanan siap diambil, dan proteksi keamanan R8/ProGuard.

## Cara Build Otomatis di GitHub Actions
1. Unggah seluruh isi ZIP ini ke repositori GitHub Anda.
2. Buka tab **Actions** → pilih **Build Signed Android APK (1001 SK)**.
3. Unduh hasil build **`1001-SK-v2.7.1-liquid-glass-release`** dari bagian **Artifacts**.
