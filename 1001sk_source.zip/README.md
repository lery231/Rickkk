# 1001 SK — Coffee & Lounge (v2.8.2 True iOS 26 Liquid Glass)

Pembaruan antarmuka **True iOS 26 Liquid Glass (#FA2D48)** yang disesuaikan langsung dengan video referensi:
1. **Scroll-Through Full-Bleed Header**: Konten dan gambar menu menggulir hingga ke tepi atas layar di belakang judul **Beranda** dan lingkaran profil kaca.
2. **Crystal-Clear Watery Liquid Glass**: Kaca cair transparan rendah (`0.14–0.36`) dengan `backdrop-filter: blur(18px) saturate(195%)` dan pantulan tepi tajam (*specular rim*) sehingga foto & teks di bawahnya terbiaskan dengan jelas.
3. **Morphing Liquid Lens Dock**: Indikator kapsul kaca bergeser elastis mengikuti tab aktif (**Beranda**, **Keranjang**, **Pesanan**).
4. **Two-Row Floating Bottom Cluster**: Mini-bar kaca penuh bersanding dengan tombol lingkaran kaca di atas dock bawah.
5. **Dark Liquid Glass QRIS Player & 3-Tile Popover**: Pemutar QRIS kaca gelap dengan tombol `...` yang membuka popover kaca transparan 3 ubin (**Simpan**, **Salin**, **Bagikan**).

## Cara Build APK di GitHub Actions
1. Unggah seluruh isi file ZIP ini ke repositori GitHub Anda.
2. Buka tab **Actions** -> jalankan **Build Signed Android APK (1001 SK)**.
3. Unduh hasil build **`1001-SK-v2.8.2-liquid-glass-release`** di bagian **Artifacts**.
