# 1001 SK — Coffee & Lounge (v2.8.4 Convx Refractive Liquid Glass)

Pembaruan lengkap pada **v2.8.4**:
1. **Pop-up Tekan Lama (Cupertino Peek & Pop)**: Menekan lama kartu produk di *Pilihan Hari Ini*, *Pesan Cepat*, maupun *Semua Menu* memunculkan pratinjau produk dan menu aksi kaca buram mengambang (*Tambah ke Keranjang*, *Pesan Langsung Sekarang*, *Bagikan Menu*, dan *Filter Kategori*) dengan efek blur latar belakang serta respons getar taktil.
2. **Tampilan Bersih Tanpa Foto Produk**: Seluruh gambar produk dihapus dari kartu menu, keranjang, mini-bar pesanan, hingga formulir tambah menu penjual, digantikan dengan tata letak tipografi dan aksen *Convx Refractive Liquid Glass*.
3. **Fitur QRIS Dihapus dari Pesanan & Dipindahkan ke Pengaturan**: Pelanggan dapat langsung mengirim pesanan tanpa layar pembayaran QRIS. Seluruh pengaturan **QRIS Toko** (unggah/hapus gambar QRIS statis dan verifikasi mutasi otomatis) dipindahkan ke dalam menu **Pengaturan** saat masuk menggunakan akun penjual.
4. **Animasi UI Lebih Smooth & Dinamis**: Kurva pegas (*spring physics*) pada transisi perpindahan tab, animasi muncul kartu berjenjang (*staggered reveal*), indikator *dock* elastis, serta animasi buka-tutup halus pada seluruh *sheet* dan pop-up.
