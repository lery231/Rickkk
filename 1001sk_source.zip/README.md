# 1001 SK — Coffee & Lounge (v2.8.1 iOS 26 Liquid Glass & Spring Gestures)

Aplikasi pemesanan kopi real-time dengan antarmuka **iOS 26 Liquid Glass (#FA2D48)** dan animasi gestur lengkap:
- **Swipe Kanan / Kiri**: Pelacakan jari *rubber-band* real-time dengan transisi geser halaman berpegas (*spring slide*).
- **Swipe Bawah / Atas**: *Pull-to-Refresh* dengan kapsul kaca mengambang, pantulan *rubber-band* vertikal, serta *Swipe-Down to Dismiss* pada sheet & layar QRIS.
- **Animasi Saat Menekan**: Efek kompresi pegas iOS (`scale(0.955)`) disertai kilau spekular kaca pada titik sentuh jari.

## Cara Build Otomatis di GitHub Actions
1. Unggah seluruh isi ZIP ini ke repositori GitHub Anda.
2. Buka tab **Actions** → pilih **Build Signed Android APK (1001 SK)**.
3. Unduh hasil build **`1001-SK-v2.8.1-liquid-glass-release`** dari bagian **Artifacts**.
