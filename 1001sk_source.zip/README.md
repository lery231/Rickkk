# 1001 SK — Coffee & Lounge (v2.8.3 Convx Refractive Liquid Glass)

Antarmuka **1001 SK** yang dirancang ulang mengikuti arsitektur **Convx Refractive Liquid Glass & Cupertino HIG**:
1. **Refractive Glass Surfaces (`refractive-glass`)**: Permukaan kaca buram berlapis dengan pembiasan tepi kromatik (*optical chromatic rim*), kilau meniskus atas, dan latar belakang *ambient glow* yang tenang.
2. **Cupertino Floating Controls & Morphing Pill Dock**: Bilah navigasi kapsul kaca dengan lensa aktif yang meluncur elastis (*spring physics*), tombol aksi melingkar terpisah, serta *floating mini-bar* pesanan aktif bergaya Convx MiniPlayer.
3. **Full-Screen Atmospheric QRIS Sheet**: Layar pembayaran QRIS dengan latar belakang ambient buram, pemilih mode kaca Cupertino (`QRIS` | `Rincian`), kontrol melayang, dan popover kaca 3 ubin (**Simpan**, **Salin**, **Bagikan**).
4. **Tema Terang & Gelap, Nada Notifikasi, Hapus Riwayat & Proteksi Penjual**.
