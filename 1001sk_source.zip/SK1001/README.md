# 1001 SK — Coffee & Lounge (v2.8.5 Convx Refractive Liquid Glass)

Pembaruan **v2.8.5** mengembalikan **Foto Produk Lengkap** dan **Pembayaran QRIS Penuh** di atas antarmuka **Convx Refractive Liquid Glass & Cupertino HIG**:

1. **Foto Produk Lengkap (Pelanggan & Penjual)**:
   - Foto produk tampil di **Pilihan Hari Ini**, **Pesan Cepat**, grid **Semua Menu**, **Keranjang**, **Pencarian**, **Mini-Bar Pesanan Aktif**, dan **Pratinjau Tekan Lama**.
   - Penjual dapat mengunggah foto produk saat membuat menu baru maupun mengganti foto menu yang sudah ada langsung dari daftar menu.
2. **Pembayaran QRIS Lengkap**:
   - Checkout pelanggan langsung membuka **Layar Penuh QRIS Toko** berisi kode QRIS unggahan penjual, nominal total, tombol **Simpan QRIS**, **Salin Nominal**, **Bagikan**, dan **Saya Sudah Bayar**.
   - Penjual dapat mengunggah/mengganti gambar QRIS statis melalui tab **QRIS** maupun menu **Pengaturan**, serta memverifikasi mutasi masuk secara otomatis.
3. **Siap GitHub Actions**:
   - Unggah ZIP ini langsung ke repositori GitHub untuk kompilasi APK Android otomatis melalui `.github/workflows/build-apk.yml`.

## Convx-inspired interface direction

The SK 1001 interface uses an original coffee-ordering implementation with a Convx-inspired
Cupertino / Liquid Glass visual direction: atmospheric background layers, translucent glass
surfaces, spring-based transitions, adaptive light/dark tokens, and a floating navigation dock.
The reference project is https://github.com/cosmictaserdev-creator/Convx. This project does not
reuse Convx's music-player features or claim to be the Convx application. SK 1001's ordering,
Firebase, buyer/seller, and payment flows remain its own.
