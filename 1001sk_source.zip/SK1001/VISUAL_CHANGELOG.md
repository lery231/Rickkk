# SK 1001 — Visual refinement notes

This update refines the existing SK 1001 React + Vite + Capacitor application using a Convx-inspired Cupertino / Liquid Glass design direction.

## Included
- Adaptive frosted-glass surfaces and ambient background treatment.
- More consistent page entrance, card, image, and touch feedback motion.
- Responsive product grid: two columns on narrow phones and three on wider screens.
- Improved sticky header glass treatment while scrolling.
- Safer bottom spacing for Android gesture/navigation areas and sheet scrolling.
- Visible keyboard focus, reduced-motion support, and non-backdrop-filter fallback.
- Existing buyer/seller screens, Firebase data flow, order states, QRIS/payment UI, and Capacitor setup are retained.

## Reference and scope
The visual direction references the public Convx repository: https://github.com/cosmictaserdev-creator/Convx
Convx is a Kotlin / Jetpack Compose music player. SK 1001 remains a React / Vite / Capacitor coffee-ordering app; this is a design adaptation, not a copy of Convx's application code or music features.
