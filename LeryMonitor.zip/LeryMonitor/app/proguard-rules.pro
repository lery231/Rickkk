# Anti-decompilation and Obfuscation Rules
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose

# Keep essential Android / Compose models
-keepclassmembers class * {
    @androidx.compose.runtime.Composable <methods>;
}
-keep class id.modem.monitor.SignalData { *; }
