package id.modem.monitor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LeryMonitorTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val viewModel: MonitorViewModel = viewModel()
                    MainScreen(viewModel)
                }
            }
        }
    }
}

@Composable
fun MainScreen(viewModel: MonitorViewModel) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()

    AnimatedContent(targetState = isLoggedIn, label = "ScreenTransition") { loggedIn ->
        if (loggedIn) {
            DashboardScreen(viewModel)
        } else {
            LoginScreen(viewModel)
        }
    }
}
