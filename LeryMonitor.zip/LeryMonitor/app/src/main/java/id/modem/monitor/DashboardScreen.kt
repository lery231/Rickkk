package id.modem.monitor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: MonitorViewModel) {
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Lery Monitor",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                },
                actions = {
                    IconButton(onClick = { viewModel.logout() }) {
                        Icon(Icons.Default.ExitToApp, contentDescription = "Logout", tint = Color.Red)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1E293B))
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF1E293B)) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.CellTower, contentDescription = "Sinyal") },
                    label = { Text("Sinyal & Kuota", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Lock, contentDescription = "Lock Band") },
                    label = { Text("Lock Band", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.NetworkCell, contentDescription = "APN & DNS") },
                    label = { Text("APN & DNS", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Build, contentDescription = "Alat & Fitur") },
                    label = { Text("Fitur Lain", fontSize = 10.sp) }
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(Color(0xFF0F172A))
        ) {
            when (selectedTab) {
                0 -> SignalAndQuotaTab(viewModel)
                1 -> LockBandTabScreen(viewModel)
                2 -> ApnAndDnsTabScreen(viewModel)
                3 -> ToolsAndSecurityTabScreen(viewModel)
            }
        }
    }
}

@Composable
fun SignalAndQuotaTab(viewModel: MonitorViewModel) {
    val signalInfo by viewModel.signalData.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Sisa Kuota Utama", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        Text("Telkomsel Orbit", color = Color(0xFF3D82F6), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("38.5 GB / 50 GB", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                    Text("Masa Aktif s.d 28 November 2026", fontSize = 11.sp, color = Color(0xFF94A3B8))
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Kekuatan Sinyal", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        Text(signalInfo.networkType, fontWeight = FontWeight.Bold, color = Color(0xFF3D82F6), fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.Bottom,
                        modifier = Modifier.height(30.dp)
                    ) {
                        for (i in 1..5) {
                            val active = i <= signalInfo.signalLevel
                            Box(
                                modifier = Modifier
                                    .width(12.dp)
                                    .height((i * 5 + 4).dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (active) Color(0xFF10B981) else Color(0xFF334155))
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "${signalInfo.signalLevel}/5 Bar", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    }
                }
            }
        }

        item {
            Text("Parameter Sinyal (< 1s Realtime)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MinimizedSignalBox(title = "RSRP", value = "${signalInfo.rsrp} dBm", modifier = Modifier.weight(1f))
                    MinimizedSignalBox(title = "RSRQ", value = "${signalInfo.rsrq} dB", modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MinimizedSignalBox(title = "SINR", value = "${signalInfo.sinr} dB", modifier = Modifier.weight(1f))
                    MinimizedSignalBox(title = "RSSI", value = "${signalInfo.rssi} dBm", modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun MinimizedSignalBox(title: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(Color(0xFF1E293B), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = title, fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
            Text(text = value, fontSize = 13.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun LockBandTabScreen(viewModel: MonitorViewModel) {
    var selectedBands by remember { mutableStateOf(setOf("B1", "B3", "B40")) }
    Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
        Text("Opsi Lock Band Frekuensi Orbit", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(10.dp))
        val bands = listOf("B1 (2100MHz)", "B3 (1800MHz)", "B5 (850MHz)", "B8 (900MHz)", "B40 (2300MHz)")
        bands.forEach { band ->
            val code = band.split(" ")[0]
            val isChecked = selectedBands.contains(code)
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Color(0xFF1E293B), RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(band, color = Color.White, fontSize = 13.sp)
                Checkbox(checked = isChecked, onCheckedChange = { selectedBands = if (isChecked) selectedBands - code else selectedBands + code })
            }
        }
        Spacer(modifier = Modifier.height(14.dp))
        Button(onClick = { viewModel.applyLockBand(selectedBands.toList()) }, modifier = Modifier.fillMaxWidth().height(42.dp)) {
            Text("TERAPKAN LOCK BAND", fontSize = 13.sp)
        }
    }
}

@Composable
fun ApnAndDnsTabScreen(viewModel: MonitorViewModel) {
    var apnName by remember { mutableStateOf("telkomsel") }
    var dnsPrimary by remember { mutableStateOf("1.1.1.1") }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Pengaturan APN (Access Point Name)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = apnName, onValueChange = { apnName = it }, label = { Text("Nama APN") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { viewModel.saveApn(apnName) }, modifier = Modifier.fillMaxWidth()) { Text("Simpan & Terapkan APN") }
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Fitur Pengaturan DNS Custom", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = dnsPrimary, onValueChange = { dnsPrimary = it }, label = { Text("Primary DNS (e.g. 1.1.1.1 / 8.8.8.8)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { viewModel.saveDns(dnsPrimary) }, modifier = Modifier.fillMaxWidth()) { Text("Terapkan DNS") }
                }
            }
        }
    }
}

@Composable
fun ToolsAndSecurityTabScreen(viewModel: MonitorViewModel) {
    var isDataDisabled by remember { mutableStateOf(false) }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Diagnosis & Pengoptimalan Perangkat", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Bersihkan cache memori modem dan optimalkan jalur koneksi seluler.", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { viewModel.optimizeDevice() }, modifier = Modifier.fillMaxWidth()) { Text("Jalankan Diagnosis & Optimalisasi") }
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Nonaktifkan Data Seluler", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        Switch(checked = isDataDisabled, onCheckedChange = { 
                            isDataDisabled = it
                            viewModel.toggleCellularData(!it)
                        })
                    }
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Fitur Blokir Website / URL", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    var blockedUrl by remember { mutableStateOf("") }
                    OutlinedTextField(value = blockedUrl, onValueChange = { blockedUrl = it }, label = { Text("Masukkan Domain (contoh: site.com)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { viewModel.blockWebsite(blockedUrl) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)), modifier = Modifier.fillMaxWidth()) {
                        Text("Blokir Website Ini")
                    }
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Mulai Ulang Modem (Reboot)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { viewModel.rebootModem() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)), modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("REBOOT MODEM ORBIT")
                    }
                }
            }
        }
    }
}
