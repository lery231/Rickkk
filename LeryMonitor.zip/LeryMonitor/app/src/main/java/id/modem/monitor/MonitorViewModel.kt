package id.modem.monitor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class SignalData(
    val rsrp: String = "-85",
    val rsrq: String = "-10",
    val sinr: String = "18",
    val rssi: String = "-65",
    val signalLevel: Int = 4,
    val networkType: String = "4G / LTE",
    val operator: String = "Telkomsel Orbit",
    val cellId: String = "284192",
    val pci: String = "142",
    val band: String = "B3 (1800MHz)"
)

class MonitorViewModel : ViewModel() {
    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn

    private val _isConnecting = MutableStateFlow(false)
    val isConnecting: StateFlow<Boolean> = _isConnecting

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    private val _signalData = MutableStateFlow(SignalData())
    val signalData: StateFlow<SignalData> = _signalData

    init {
        startFastSignalMonitoring()
    }

    private fun startFastSignalMonitoring() {
        viewModelScope.launch {
            while (true) {
                delay(800)
                if (_isLoggedIn.value) {
                    val randomRsrp = (-95..-75).random().toString()
                    val randomSinr = (12..25).random().toString()
                    _signalData.value = _signalData.value.copy(
                        rsrp = randomRsrp,
                        sinr = randomSinr
                    )
                }
            }
        }
    }

    fun login(gw: String, un: String, pw: String, useVariantB: Boolean = false) {
        viewModelScope.launch {
            _isConnecting.value = true
            delay(500)
            _isLoggedIn.value = true
            _isConnecting.value = false
        }
    }

    fun logout() {
        _isLoggedIn.value = false
    }

    fun applyLockBand(bands: List<String>) {}
    fun saveApn(apn: String) {}
    fun saveDns(dns: String) {}
    fun optimizeDevice() {}
    fun toggleCellularData(enable: Boolean) {}
    fun blockWebsite(url: String) {}
    fun rebootModem() {}
}
