# 1001 SK - Coffee Ordering

Web app pemesanan kopi (React + Vite + Firebase) dengan peran pembeli/penjual, pesanan realtime, dan QRIS statis + unggah bukti bayar.

## Cara build lewat GitHub (dari HP)
1. Upload **isi** folder ini ke root repo (`index.html` dan `package.json` harus sejajar, `.github/workflows/build.yml` di root).
2. (Opsional tapi disarankan) Repo > Settings > Secrets and variables > Actions > tambahkan secret:
   `VITE_FIREBASE_API_KEY`, `VITE_FIREBASE_AUTH_DOMAIN`, `VITE_FIREBASE_PROJECT_ID`,
   `VITE_FIREBASE_STORAGE_BUCKET`, `VITE_FIREBASE_MESSAGING_SENDER_ID`, `VITE_FIREBASE_APP_ID`.
   Tanpa secret, app tetap ter-build dan menampilkan layar setup.
3. Buka tab Actions > Build 1001 SK > Run workflow. Unduh artifact `1001-SK-dist`.

## Firebase
Aktifkan Email/Password, Firestore, Storage; tempel `firestore.rules` dan `storage.rules`.
Untuk akun penjual, ubah field `role` di `users/{UID}` menjadi `seller` lewat Firebase Console.

## APK
Workflow otomatis membungkus web jadi APK (Capacitor). Unduh `1001-SK-apk` dari Artifacts, ekstrak, lalu pasang `app-debug.apk`.
