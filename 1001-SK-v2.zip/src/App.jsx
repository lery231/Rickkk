import React, { useEffect, useMemo, useState } from 'react';
import {
  Coffee, ShoppingBag, ClipboardList, Settings, LogIn, LogOut, Plus, Minus,
  Clock3, Upload, QrCode, Store, AlertCircle,
} from 'lucide-react';
import {
  onAuthStateChanged, signInWithEmailAndPassword,
  createUserWithEmailAndPassword, signOut,
} from 'firebase/auth';
import {
  addDoc, collection, doc, getDoc, onSnapshot, orderBy, query,
  serverTimestamp, setDoc, updateDoc, where,
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { auth, db, storage, firebaseReady } from './firebase.js';

const money = (n) =>
  new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0,
  }).format(Number(n || 0));

const ORDER_STATUSES = ['Menunggu pembayaran', 'Pembayaran diperiksa', 'Diproses', 'Siap diambil', 'Selesai', 'Dibatalkan'];
const PAY_STATUSES = ['Belum dibayar', 'Menunggu verifikasi', 'Lunas', 'Ditolak'];

const INITIAL_MENU = [
  { id: 'americano', name: 'Americano', desc: 'Espresso dan air, clean & bold', price: 18000, category: 'Coffee', emoji: '☕', active: true },
  { id: 'latte', name: 'Cafe Latte', desc: 'Espresso dengan susu creamy', price: 24000, category: 'Coffee', emoji: '🥛', active: true },
  { id: 'aren', name: 'Kopi Susu Aren', desc: 'Espresso, susu, gula aren', price: 22000, category: 'Signature', emoji: '🧋', active: true },
  { id: 'mocha', name: 'Mocha', desc: 'Kopi, cokelat, susu', price: 26000, category: 'Signature', emoji: '🍫', active: true },
];

const EMPTY_DRAFT = { name: '', desc: '', price: '', category: 'Coffee', emoji: '☕' };

function SetupScreen() {
  return (
    <div className="setup">
      <div className="setup-card">
        <div className="brandmark"><Coffee size={25} /></div>
        <span className="eyebrow">PROJECT READY TO CONFIGURE</span>
        <h1>1001 SK</h1>
        <p>Aplikasi pemesanan kopi online dengan dashboard pembeli dan penjual, status pesanan realtime, dan pembayaran QRIS.</p>
        <div className="setup-step"><b>1. Buat project Firebase</b><span>Aktifkan Authentication (Email/Password), Firestore Database, dan Storage.</span></div>
        <div className="setup-step"><b>2. Isi konfigurasi</b><span>Tambahkan Firebase Web App config sebagai GitHub Secrets (VITE_FIREBASE_...) atau file .env untuk lokal.</span></div>
        <div className="setup-step"><b>3. Atur akun penjual</b><span>Daftar akun lewat aplikasi, lalu ubah field role di Firestore users/UID menjadi seller.</span></div>
        <p className="muted">Firebase belum dikonfigurasi, jadi data online belum aktif.</p>
      </div>
    </div>
  );
}

export default function App() {
  if (!firebaseReady) return <SetupScreen />;
  return <Shop />;
}

function Shop() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [menu, setMenu] = useState(INITIAL_MENU);
  const [orders, setOrders] = useState([]);
  const [settings, setSettings] = useState({
    shopName: '1001 SK',
    qrisUrl: '',
    open: true,
    notice: 'Selamat datang! Pesan kopi favoritmu di sini.',
  });
  const [cart, setCart] = useState({});
  const [tab, setTab] = useState('menu');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authMode, setAuthMode] = useState('login');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [proof, setProof] = useState(null);
  const [editing, setEditing] = useState(null);
  const [draft, setDraft] = useState(EMPTY_DRAFT);

  useEffect(() => {
    return onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (!u) {
        setProfile(null);
        return;
      }
      try {
        const snap = await getDoc(doc(db, 'users', u.uid));
        setProfile(snap.exists() ? snap.data() : null);
      } catch (e) {
        setProfile(null);
      }
    });
  }, []);

  useEffect(() => {
    const unsubs = [];
    unsubs.push(
      onSnapshot(
        query(collection(db, 'menu'), orderBy('name')),
        (s) => { if (!s.empty) setMenu(s.docs.map((d) => ({ id: d.id, ...d.data() }))); },
        () => {}
      )
    );
    unsubs.push(
      onSnapshot(
        doc(db, 'settings', 'store'),
        (s) => { if (s.exists()) setSettings((v) => ({ ...v, ...s.data() })); },
        () => {}
      )
    );
    return () => unsubs.forEach((f) => f());
  }, []);

  useEffect(() => {
    if (!user) {
      setOrders([]);
      return undefined;
    }
    const seller = profile?.role === 'seller';
    const q = seller
      ? query(collection(db, 'orders'), orderBy('createdAt', 'desc'))
      : query(collection(db, 'orders'), where('buyerId', '==', user.uid));
    return onSnapshot(
      q,
      (s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...d.data() }));
        list.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
        setOrders(list);
      },
      () => {}
    );
  }, [user, profile]);

  const isSeller = profile?.role === 'seller';
  const activeMenu = menu.filter((m) => m.active !== false);
  const myOrders = orders.filter((o) => isSeller || o.buyerId === user?.uid);
  const openCount = orders.filter(
    (o) => o.buyerId === user?.uid && o.status !== 'Selesai' && o.status !== 'Dibatalkan'
  ).length;
  const total = useMemo(
    () => menu.reduce((sum, m) => sum + (cart[m.id] || 0) * Number(m.price), 0),
    [menu, cart]
  );

  const changeQty = (id, delta) =>
    setCart((c) => ({ ...c, [id]: Math.max(0, (c[id] || 0) + delta) }));

  const handleAuth = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      if (authMode === 'login') {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        const c = await createUserWithEmailAndPassword(auth, email, password);
        await setDoc(doc(db, 'users', c.user.uid), {
          email,
          role: 'buyer',
          createdAt: serverTimestamp(),
        });
        setProfile({ email, role: 'buyer' });
      }
      setTab('menu');
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const placeOrder = async () => {
    if (!user) return setError('Silakan masuk atau daftar terlebih dahulu.');
    if (!settings.open) return setError('Toko sedang tutup.');
    if (total <= 0) return;
    setBusy(true);
    try {
      const items = menu
        .filter((m) => cart[m.id] > 0)
        .map((m) => ({ menuId: m.id, name: m.name, price: Number(m.price), qty: cart[m.id] }));
      await addDoc(collection(db, 'orders'), {
        buyerId: user.uid,
        buyerEmail: user.email,
        items,
        total,
        paymentMethod: 'QRIS',
        paymentStatus: 'Belum dibayar',
        status: 'Menunggu pembayaran',
        proofUrl: '',
        createdAt: serverTimestamp(),
      });
      setCart({});
      setTab('orders');
      setError('Pesanan dibuat. Buka Pesanan untuk mengirim bukti pembayaran QRIS.');
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  const sendProof = async (order) => {
    if (!proof || !user) return;
    setBusy(true);
    try {
      const r = ref(storage, `payment-proofs/${order.id}/${user.uid}-${Date.now()}-${proof.name}`);
      await uploadBytes(r, proof);
      const url = await getDownloadURL(r);
      await updateDoc(doc(db, 'orders', order.id), { proofUrl: url, paymentStatus: 'Menunggu verifikasi' });
      setProof(null);
      setError('Bukti pembayaran terkirim. Penjual akan memeriksa pembayaran.');
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  const updateOrder = async (order, changes) => {
    try {
      await updateDoc(doc(db, 'orders', order.id), changes);
    } catch (e) {
      setError(e.message);
    }
  };

  const saveMenu = async (e) => {
    e.preventDefault();
    try {
      const data = { ...draft, price: Number(draft.price), active: true };
      if (editing) await setDoc(doc(db, 'menu', editing), data);
      else await addDoc(collection(db, 'menu'), data);
      setEditing(null);
      setDraft(EMPTY_DRAFT);
    } catch (err) {
      setError(err.message);
    }
  };

  const toggleMenu = async (m) => {
    try {
      await updateDoc(doc(db, 'menu', m.id), { active: m.active === false });
    } catch (err) {
      setError(err.message);
    }
  };

  const saveSettings = async (e) => {
    e.preventDefault();
    try {
      await setDoc(doc(db, 'settings', 'store'), settings, { merge: true });
      setError('Pengaturan toko tersimpan.');
    } catch (err) {
      setError(err.message);
    }
  };

  const navBtn = (id, icon, label, extra) => (
    <button className={tab === id ? 'active' : ''} onClick={() => setTab(id)}>
      {icon} {label}{extra}
    </button>
  );

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <div className="brandmark"><Coffee size={22} /></div>
          <div>
            <b>{settings.shopName || '1001 SK'}</b>
            <small>COFFEE • ORDER ONLINE</small>
          </div>
        </div>
        <div className="headright">
          <span className={`openpill ${settings.open ? '' : 'closed'}`}>
            <i />{settings.open ? 'Buka' : 'Tutup'}
          </span>
          {user ? (
            <button className="iconbtn" title="Keluar" onClick={() => signOut(auth)}>
              <LogOut size={18} />
            </button>
          ) : (
            <button className="btn btn-dark" onClick={() => setTab('account')}>
              <LogIn size={16} /> Masuk
            </button>
          )}
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <span className="eyebrow">YOUR DAILY COFFEE RITUAL</span>
            <h1>Kopi enak.<br /><em>Hari lebih baik.</em></h1>
            <p>{settings.notice}</p>
            <button className="btn btn-light" onClick={() => setTab('menu')}>
              Pesan sekarang <ShoppingBag size={16} />
            </button>
          </div>
          <div className="hero-art">
            <div className="sun" />
            <div className="cup">☕</div>
            <div className="art-label">BREWED<br />FRESH DAILY</div>
          </div>
        </section>

        {error && (
          <div className="notice">
            <AlertCircle size={17} />
            <span>{error}</span>
            <button onClick={() => setError('')}>×</button>
          </div>
        )}

        <div className="layout">
          <aside className="sidebar">
            {navBtn('menu', <Coffee size={18} />, 'Menu kopi', null)}
            {navBtn(
              'orders',
              <ClipboardList size={18} />,
              isSeller ? 'Kelola pesanan' : 'Pesanan saya',
              !isSeller && openCount > 0 ? <span className="count">{openCount}</span> : null
            )}
            {isSeller && navBtn('manage', <Store size={18} />, 'Kelola menu', null)}
            {isSeller && navBtn('settings', <Settings size={18} />, 'Pengaturan toko', null)}
            {navBtn('account', <LogIn size={18} />, 'Akun', null)}
            <div className="side-foot">
              <span className="live-dot" /> Update pesanan realtime<br />
              <small>Didukung Firebase</small>
            </div>
          </aside>

          <section className="content">
            {tab === 'menu' && (
              <>
                <div className="section-title">
                  <div><span className="eyebrow">PILIHAN BARISTA</span><h2>Menu kopi</h2></div>
                  <span className="muted">{activeMenu.length} pilihan</span>
                </div>
                <div className="menu-grid">
                  {activeMenu.map((m) => (
                    <article className="menu-card" key={m.id}>
                      <div className="coffee-image">
                        <span>{m.emoji || '☕'}</span>
                        <small>{m.category || 'Coffee'}</small>
                      </div>
                      <div className="menu-info">
                        <h3>{m.name}</h3>
                        <p>{m.desc}</p>
                        <div className="menu-bottom">
                          <b>{money(m.price)}</b>
                          {!isSeller && (
                            <div className="qty">
                              {cart[m.id] ? (
                                <>
                                  <button onClick={() => changeQty(m.id, -1)}><Minus size={14} /></button>
                                  <b>{cart[m.id]}</b>
                                  <button onClick={() => changeQty(m.id, 1)}><Plus size={14} /></button>
                                </>
                              ) : (
                                <button className="add" onClick={() => changeQty(m.id, 1)}><Plus size={16} /></button>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
                {!isSeller && (
                  <div className="cartbar">
                    <div><small>Total pesanan</small><b>{money(total)}</b></div>
                    <button className="btn btn-dark" disabled={!total || busy} onClick={placeOrder}>
                      Pesan &amp; bayar <QrCode size={17} />
                    </button>
                  </div>
                )}
              </>
            )}

            {tab === 'orders' && (
              <>
                <div className="section-title">
                  <div>
                    <span className="eyebrow">STATUS LANGSUNG</span>
                    <h2>{isSeller ? 'Semua pesanan' : 'Pesanan saya'}</h2>
                  </div>
                  <span className="live-tag"><span className="live-dot" /> Live</span>
                </div>
                <div className="orders">
                  {!user && (
                    <div className="empty">
                      <ShoppingBag size={28} />
                      <h3>Masuk dulu</h3>
                      <p>Masuk untuk melihat pesananmu.</p>
                    </div>
                  )}
                  {myOrders.map((o) => (
                    <article className="order-card" key={o.id}>
                      <div className="order-head">
                        <div>
                          <small>ORDER #{o.id.slice(-6).toUpperCase()}</small>
                          <h3>{(o.items || []).map((i) => `${i.qty}× ${i.name}`).join(', ')}</h3>
                          {isSeller && <p className="muted">{o.buyerEmail}</p>}
                        </div>
                        <b>{money(o.total)}</b>
                      </div>
                      <div className="order-meta">
                        <span className="status"><Clock3 size={15} />{o.status}</span>
                        <span className="paystatus">{o.paymentStatus || 'Belum dibayar'}</span>
                      </div>

                      {!isSeller && o.status !== 'Dibatalkan' && o.status !== 'Selesai' && (
                        <div className="payment-box">
                          <div className="pay-title"><QrCode size={18} /><b>Pembayaran QRIS</b></div>
                          {settings.qrisUrl ? (
                            <img className="qris" src={settings.qrisUrl} alt="QRIS toko" />
                          ) : (
                            <p className="muted">QRIS belum diatur penjual. Hubungi penjual.</p>
                          )}
                          <p className="muted">
                            Bayar tepat sebesar <b>{money(o.total)}</b>, lalu unggah bukti pembayaran.
                          </p>
                          {o.proofUrl ? (
                            <a href={o.proofUrl} target="_blank" rel="noreferrer">Lihat bukti yang dikirim</a>
                          ) : (
                            <div className="upload-row">
                              <label className="file-label">
                                <Upload size={16} /> {proof ? 'Bukti dipilih' : 'Pilih bukti transfer'}
                                <input
                                  type="file"
                                  accept="image/*"
                                  onChange={(e) => setProof(e.target.files?.[0] || null)}
                                />
                              </label>
                              <button className="btn btn-dark" disabled={!proof || busy} onClick={() => sendProof(o)}>
                                Kirim bukti
                              </button>
                            </div>
                          )}
                        </div>
                      )}

                      {isSeller && (
                        <div className="seller-actions">
                          {o.proofUrl && (
                            <a href={o.proofUrl} target="_blank" rel="noreferrer">Lihat bukti pembayaran ↗</a>
                          )}
                          <select value={o.status} onChange={(e) => updateOrder(o, { status: e.target.value })}>
                            {ORDER_STATUSES.map((s) => <option key={s}>{s}</option>)}
                          </select>
                          <select
                            value={o.paymentStatus || 'Belum dibayar'}
                            onChange={(e) => updateOrder(o, { paymentStatus: e.target.value })}
                          >
                            {PAY_STATUSES.map((s) => <option key={s}>{s}</option>)}
                          </select>
                        </div>
                      )}
                    </article>
                  ))}
                  {user && myOrders.length === 0 && (
                    <div className="empty">
                      <ShoppingBag size={28} />
                      <h3>Belum ada pesanan</h3>
                      <p>Pesanan akan muncul di sini.</p>
                    </div>
                  )}
                </div>
              </>
            )}

            {tab === 'manage' && isSeller && (
              <>
                <div className="section-title">
                  <div><span className="eyebrow">KONTROL PRODUK</span><h2>Kelola menu</h2></div>
                </div>
                <form className="panel form-grid" onSubmit={saveMenu}>
                  <h3>{editing ? 'Edit menu' : 'Tambah menu kopi'}</h3>
                  <input required placeholder="Nama menu" value={draft.name}
                    onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
                  <input placeholder="Deskripsi singkat" value={draft.desc}
                    onChange={(e) => setDraft({ ...draft, desc: e.target.value })} />
                  <div className="two">
                    <input required type="number" min="0" placeholder="Harga (Rp)" value={draft.price}
                      onChange={(e) => setDraft({ ...draft, price: e.target.value })} />
                    <select value={draft.category}
                      onChange={(e) => setDraft({ ...draft, category: e.target.value })}>
                      <option>Coffee</option>
                      <option>Signature</option>
                      <option>Non-Coffee</option>
                      <option>Snack</option>
                    </select>
                  </div>
                  <input placeholder="Emoji (contoh ☕)" value={draft.emoji}
                    onChange={(e) => setDraft({ ...draft, emoji: e.target.value })} />
                  <div className="form-actions">
                    <button className="btn btn-dark">{editing ? 'Simpan perubahan' : 'Tambah menu'}</button>
                    {editing && (
                      <button type="button" className="btn btn-outline"
                        onClick={() => { setEditing(null); setDraft(EMPTY_DRAFT); }}>
                        Batal
                      </button>
                    )}
                  </div>
                </form>
                <div className="manage-list">
                  {menu.map((m) => (
                    <div className="manage-item" key={m.id}>
                      <span className="manage-emoji">{m.emoji || '☕'}</span>
                      <div><b>{m.name}</b><small>{money(m.price)} · {m.category}</small></div>
                      <button className="btn btn-outline" onClick={() => {
                        setEditing(m.id);
                        setDraft({
                          name: m.name, desc: m.desc || '', price: String(m.price),
                          category: m.category || 'Coffee', emoji: m.emoji || '☕',
                        });
                      }}>Edit</button>
                      <button className="btn btn-outline" onClick={() => toggleMenu(m)}>
                        {m.active === false ? 'Aktifkan' : 'Nonaktifkan'}
                      </button>
                    </div>
                  ))}
                </div>
              </>
            )}

            {tab === 'settings' && isSeller && (
              <>
                <div className="section-title">
                  <div><span className="eyebrow">SESUAIKAN SENDIRI</span><h2>Pengaturan toko</h2></div>
                </div>
                <form className="panel form-grid" onSubmit={saveSettings}>
                  <label>Nama toko
                    <input value={settings.shopName || ''}
                      onChange={(e) => setSettings({ ...settings, shopName: e.target.value })} />
                  </label>
                  <label>Pesan sambutan
                    <textarea rows="3" value={settings.notice || ''}
                      onChange={(e) => setSettings({ ...settings, notice: e.target.value })} />
                  </label>
                  <label>URL gambar QRIS
                    <input placeholder="https://.../qris.png" value={settings.qrisUrl || ''}
                      onChange={(e) => setSettings({ ...settings, qrisUrl: e.target.value })} />
                    <small>Unggah gambar QRIS ke hosting gambar, lalu tempel URL-nya di sini.</small>
                  </label>
                  {settings.qrisUrl && <img className="qris preview" src={settings.qrisUrl} alt="Pratinjau QRIS" />}
                  <label className="toggle-row">
                    <span><b>Status toko</b><small>Matikan jika toko sedang tutup.</small></span>
                    <input type="checkbox" checked={settings.open !== false}
                      onChange={(e) => setSettings({ ...settings, open: e.target.checked })} />
                  </label>
                  <button className="btn btn-dark">Simpan pengaturan</button>
                </form>
                <div className="notice subtle">
                  <AlertCircle size={17} />
                  <span>Versi awal memakai QRIS statis dan verifikasi manual. Pembayaran otomatis memerlukan payment gateway.</span>
                </div>
              </>
            )}

            {tab === 'account' && (
              <div className="account-wrap">
                <div className="section-title">
                  <div>
                    <span className="eyebrow">AKUN 1001 SK</span>
                    <h2>{user ? 'Akun kamu' : 'Masuk / Daftar'}</h2>
                  </div>
                </div>
                {user ? (
                  <div className="panel">
                    <div className="account-avatar">{user.email?.[0]?.toUpperCase()}</div>
                    <h3>{user.email}</h3>
                    <p className="muted">Peran: {isSeller ? 'Penjual' : 'Pembeli'}</p>
                    <p className="muted">
                      Pendaftaran baru otomatis menjadi pembeli. Peran penjual diberikan lewat Firebase Console.
                    </p>
                    <button className="btn btn-dark" onClick={() => signOut(auth)}>Keluar</button>
                  </div>
                ) : (
                  <form className="panel form-grid" onSubmit={handleAuth}>
                    <h3>{authMode === 'login' ? 'Selamat datang kembali' : 'Buat akun pembeli'}</h3>
                    <label>Email
                      <input type="email" required value={email} placeholder="nama@email.com"
                        onChange={(e) => setEmail(e.target.value)} />
                    </label>
                    <label>Kata sandi
                      <input type="password" minLength={6} required value={password}
                        placeholder="Minimal 6 karakter"
                        onChange={(e) => setPassword(e.target.value)} />
                    </label>
                    <button className="btn btn-dark" disabled={busy}>
                      {busy ? 'Memproses...' : authMode === 'login' ? 'Masuk' : 'Daftar'}
                    </button>
                    <button type="button" className="textbtn"
                      onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}>
                      {authMode === 'login' ? 'Belum punya akun? Daftar' : 'Sudah punya akun? Masuk'}
                    </button>
                  </form>
                )}
              </div>
            )}
          </section>
        </div>
      </main>

      <footer>
        <b>1001 SK</b>
        <span>Crafted for your coffee break.</span>
        <small>© 2026</small>
      </footer>
    </div>
  );
}
